'use strict';
// ============================================
// 26牛牛 - 管理员密码重置（安全运维脚本）
//
// 用法（密码绝不写进代码，只走环境变量）:
//   Windows CMD :  set NN_NEW_PASSWORD=你的新密码  &&  node database/reset-admin-password.js 37491058
//   PowerShell  :  $env:NN_NEW_PASSWORD='你的新密码'; node database/reset-admin-password.js 37491058
//   Linux/macOS :  NN_NEW_PASSWORD='你的新密码' node database/reset-admin-password.js 37491058
//
// 安全约束:
//   - 密码只从环境变量读取，脚本内不保留任何明文
//   - 只写 bcrypt 哈希（cost 12），数据库与日志都不出现明文
//   - 账号不存在 / 已停用 / 环境变量缺失时直接中止，不做任何写入
//   - 重置后自动清空进程内的环境变量副本
// 注意: 重置后所有设备需要重新登录（旧 JWT 仍然签名有效，
//       如需强制全部失效请另外把 users.token_version + 1）
// ============================================

require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const BCRYPT_COST = 12;
const MIN_LEN = 6;
const MAX_BYTES = 72; // bcrypt 硬上限，超出部分会被静默截断

async function main() {
  const username = String(process.argv[2] || '').trim();
  const password = process.env.NN_NEW_PASSWORD || '';

  if (!username) {
    console.error('用法: set NN_NEW_PASSWORD=<新密码> && node database/reset-admin-password.js <用户名>');
    process.exit(1);
  }
  if (!password) {
    console.error('缺少环境变量 NN_NEW_PASSWORD，已中止（绝不接受命令行传入密码，避免进入 shell 历史）');
    process.exit(1);
  }
  if (password.length < MIN_LEN) {
    console.error('新密码至少 ' + MIN_LEN + ' 个字符，已中止');
    process.exit(1);
  }
  if (Buffer.byteLength(password, 'utf8') > MAX_BYTES) {
    console.error('新密码不能超过 ' + MAX_BYTES + ' 字节（bcrypt 上限），已中止');
    process.exit(1);
  }

  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || '26niuniu'
  });

  try {
    const [rows] = await conn.query(
      "SELECT id, username, role, status FROM users WHERE username = ? LIMIT 1",
      [username]
    );
    if (!rows.length) {
      console.error('账号不存在: ' + username + '（未做任何修改）');
      process.exitCode = 1;
      return;
    }
    const user = rows[0];
    if (user.status !== 'active') {
      console.error('账号状态为 ' + user.status + '，已中止（未做任何修改）');
      process.exitCode = 1;
      return;
    }

    const hashed = await bcrypt.hash(password, BCRYPT_COST);
    const [result] = await conn.query(
      "UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ? AND status = 'active'",
      [hashed, user.id]
    );

    // 回读校验：确认新密码可验证通过
    const [after] = await conn.query('SELECT password_hash FROM users WHERE id = ?', [user.id]);
    const verified = after.length === 1 && (await bcrypt.compare(password, after[0].password_hash));

    console.log('密码已重置: id=' + user.id + ' username=' + user.username +
      ' role=' + user.role + ' 受影响行数=' + result.affectedRows + ' 校验通过=' + verified);
    if (!verified) {
      console.error('校验未通过，请立即检查数据库');
      process.exitCode = 1;
    }
  } finally {
    await conn.end().catch(() => {});
    // 尽早抹掉进程内的明文副本
    delete process.env.NN_NEW_PASSWORD;
  }
}

main().catch((err) => {
  console.error('执行失败:', err.message);
  process.exit(1);
});