# 当前阶段验收状态

本记录优先于旧 platform-progress.md 中的历史待办。未完成表示未满足该阶段全部要求，不表示没有代码。

## 阶段状态

| 阶段 | 状态 | 实际边界 |
|---|---|---|
| 0 审计 | 未完成 | 已读主要代码与数据库结构；全 API、素材及依赖审计未闭环 |
| 1 注册 | 未完成 | 新账户随机八位数字邀请码，保留旧 UID 码；隔离回归 9 项通过，OTP 并发闭环未验收 |
| 2 注册客服 | 未完成 | 已加现有客服链接，但未登录用户仍不能直接会话 |
| 3 OTP | 部分完成 | 6 位/5 分钟/冷却/锁定/旧码作废/一次性领取已实现；路由与页面入口已统一为仅管理员（16/16 测试含 4 项独立守卫）。并发领取消耗与完整注册集成未验收 |
| 4 登录页 | 未完成 | 已加忘记密码入口；正式 Logo 与完整移动验收未完成 |
| 5 找回页面 | 未完成 | 页面/客服入口已存在；未登录客服仍未接通 |
| 6 找回密码（人工核验） | 部分完成 | 自助找回已停用（verify/reset 一律 410），找回页仅展示人工客服核验指引；未登录客服会话仍未接通 |
| 7 我的 | 未完成 | 昵称/头像/登录记录/修改密码表单已存在；实名状态等尚未完成 |
| 8 管理后台 | 部分完成 | Dashboard 统计 + 用户查询 + 用户启停 + 实名审核 + 公告 + 资金审核 + 余额流水 + Audit Logs 已可用。2026-09-19 修复「普通用户可以看到后台」：`/admin.html`、`/admin-otp.html` 在 `express.static` 之前由 `middleware/admin-boundary.js` 页面门禁校验（HttpOnly 页面票据 + 数据库角色），非管理员一律 302 回 `/me.html?admin=denied`；新增授予/取消管理员权限、禁言/解除禁言（`users.muted_until`）。2026-09-19 追加：在线人数（`user_presence`）、禁言联动范围、封禁主动断开 Socket、禁言到期提醒、高风险动作双人复核（`admin_approvals` + 后台「复核」面板）；真实浏览器 + 真实数据库端到端 87 项通过。 |

| 9 聊天 | 未完成 | 现有消息、分页、未读、官方贴图权限；完整客服管理、防重复、移动验收未完成 |
| 10 官方素材 | 未完成 | 已接用户头像和 6 张贴图；第 7 张及完整素材清单未核实 |
| 11 我的贴图 | 未完成 | 已有上传/删除；裁剪、尺寸/完整解码校验待完善 |
| 12 推广 | 未完成 | 现有统计/邀请关系；日期筛选等完整验收未完成 |
| 13 钱包 | 未完成 | 两资产分离、充值关闭；所有资金路径和测试调整审计未全验收 |
| 14 大厅 | 未完成 | 现有大厅，教学卡片合一；最终移动验收未完成 |
| 15 教学 | 未完成 | 独立教学和综合入口；喝水机制内容及全部条目验收待核实 |
| 16 游戏核心 | 部分完成 | 26牛牛娱乐场（`/api/game/niu/*` + `public/niu.html`）后端状态机、发牌、比牌、结算、战绩、后台开关与积分发放已完成，真实 MySQL 31/31 通过；旧「红包对战」写接口仍停用（只读兼容）。**边界：娱乐积分不可充值/不可转账/不可提现** |
| 17 API | 部分完成 | `docs/api-list.md` 已由 `scripts/api-inventory.js` 扫描全部路由生成（376 行，含每个路由文件与鉴权）；`/api/health` 就绪检查已加；全部接口逐条手测未做 |
| 18 数据库 | 部分完成 | 44 表结构已落 `docs/db-structure.md`（`scripts/db-inventory.js` 可再生）；迁移 024 新增游戏积分相关列/表且全为安全增量；**约束完整性（外键/索引唯一性）逐表核对未完成** |
| 19 全测试 | 部分完成 | `npm test` 一键运行 6/6 套件全绿（离线 2 + 真实 MySQL 1 + 在线 3），`tests/run-all.js` 统一入口 |
| 20 移动 UI | 部分完成 | `tests/mobile-overflow-check.js` 26 页面 × 8 种屏宽共 54 项检查通过（无横向溢出 / 无控制台报错）；**真机 Safari / 微信内置浏览器 / 小屏安卓未测** |
| 21 清理 | 部分完成 | 已移除 `config/games.js` 里的「游戏 A / 游戏 B」占位条目（无 logo、无入口的 Demo 残留）与临时脚本残留；`tests/` 下历史诊断产物按类别保留未做归档 |
| 22 安装启动 | 部分完成 | `npm install` 已 up to date；`npm start` 启动成功并打印游戏模块就绪日志；页面 200、受保护 API 匿名 401、`/admin.html` 普通用户 302 已验证；**正式域名 / HTTPS / 反向代理 / APK 未配置** |

## 最近证据

- C:\26niuniu\tests\development-server-check.json：2026-09-17T20:35:28Z 原端口 3000 已响应，login/recovery/me 页面 200，home/admin OTP API 匿名 401。
- C:\26niuniu\tests\profile-stickers-current.txt：2026-09-17T20:35:25Z，15/15 通过。已修正测试认证中间件的数据库依赖注入；真实 HTTP/JWT，隔离数据库/上传存储，不是现有账户真实登录或群内发送。
- C:\26niuniu\tests\auth-current-state-diag.txt 与 C:\26niuniu\tests\invite-registration-current.txt：2026-09-17T20:34:30Z，分别 12/12、9/9 通过（隔离数据库）。

- C:\26niuniu\tests\change-password-report.json：11/11，通过真实 HTTP/ bcrypt 和隔离用户数据；并发冲突为模拟 affectedRows=0，非多连接实测。前端成功退出逻辑已检查，尚未浏览器验收。
- C:\26niuniu\tests\platform-smoke-diag.txt：PLATFORM_SMOKE_PASS。
- C:\26niuniu\tests\npm-install-diag.txt：up to date in 9s；此次未运行依赖漏洞审计。
- C:\26niuniu\tests\admin-sticker-live-report.json：数据库 UID 3 active/admin、邀请码 3；当时开发服务不可连接，live passed=false。报告的 recovery_maps_uid3 判断使用 OR 查询，不足以单独作为断言证据。
- 2026-09-17T20:59Z（阶段 8 后台本轮）：`tests/admin-live.js` 真实 MySQL 只读 17/17、`tests/admin-dashboard.js` 隔离 19/19；同批认证 16/16、注册 9/9、贴图与资料 15/15、找回密码通过、platform-smoke 63/63（含 `/admin.html`、`/js/admin-page.js` 与两个 admin API 匿名 401）。
- 后台 API 与页面均为只读；本轮未新增数据库表、未修改任何用户数据。
- 较早认证 12 项、注册 9 项、重置 11 项为隔离回归；Socket/贴图的历史报告有各自边界，不能当作最新全量回归。

## 最新权限边界验证

- `C:\26niuniu\middleware\admin-boundary.js` 已在 `C:\26niuniu\server.js` 静态文件与业务路由之前挂载，统一保护 `/api/admin` 及子路径，禁止缓存响应；仅当前数据库角色 admin 可通过。现有 `/api/support/lookup` 与客服聊天权限未修改。
- 2026-09-17T20:39Z：认证/边界 12/12、注册 9/9、贴图及资料 15/15；均为真实 HTTP 与隔离数据库。实际入口冒烟为 PLATFORM_SMOKE_PASS，临时测试端口启动后关闭，未更改默认端口。
- 本次 API 边界不是后台页面保护：`/admin-otp.html` 仍是公开静态壳，敏感内容由受保护 API 获取。正常浏览器导航使用 localStorage JWT，尚未实现服务器端受保护页面会话。不能宣称阶段 8 完成。
- 2026-09-19 补上「服务器端受保护页面会话」：`utils/pageSession.js`（登录下发的 HttpOnly `nn_page` Cookie，SameSite=Lax）+ `middleware/admin-boundary.js` 页面门禁，在 `express.static` 之前拦截 `/admin.html`、`/admin-otp.html`，非管理员 302 → `/me.html?admin=denied`；`POST /api/auth/logout` 清除票据，`public/js/app-common.js` 的 `logout()` 用 `keepalive` 请求确保清除。Cookie 只用于页面准入，`/api/**` 仍只认 Bearer JWT。`tests/admin-access-browser.js` 真实服务器 + 真实 MySQL + 真实 Chrome 84 项通过（含匿名/普通用户 302 与 403、票据下发与清除、授予/取消管理员、禁言/解除、封禁/解封、审计日志、被禁言用户发消息 403）。
- 2026-09-19 真实账号验收：新增 `tests/admin-real-account.js`（只读：仅登录/退出 + GET，不建号、不改任何账号、不领取 OTP 明文；口令不入库，用环境变量 `NN_ADMIN_PASSWORD` 传入，用户名/地址可用 `NN_ADMIN_USERNAME`、`NN_BASE` 覆盖），对**真实管理员账号 `37491058`（UID 10）**在 3000 端口开发服务上跑完整链路：`ADMIN_REAL_ACCOUNT PASS (46/46)`，报告 `tests/admin-real-account-report.json`。含真实 Chrome 走查：我的页两个入口 → 点「管理后台」进入 `/admin.html`（未被拦回）→ 概览「用户总数 9 / 今日注册 1」统计卡可点击 → 用户列表 9 个用户名按钮 → 查询命中 `37491058` 后其面板只有「取消管理员权限」（禁言/封禁入口不出现）→ 查询 `dodo` 的面板含「设为管理员（授予后台权限） / 禁言该账号… / 封禁账号（禁止登录）」→ `/admin-otp.html` 正常打开（列表为空，未领取任何验证码）→ 全程无 JS 异常。同一轮 HTTP 侧：普通用户票据 / 匿名 / 伪造签名访问两个管理页面均 302 → `/me.html?admin=denied` 且不下发后台 HTML，退出登录清除票据。
- 账号事实澄清：真实管理员为 `37491058`（UID 10，`bcryptjs` cost 12）；UID 3 `bobo` 是早前联调遗留的管理员测试账号（`tests/admin-live.js` 选的是「id 最小的活跃管理员」）。若要收敛后台权限，建议把 `bobo` 降级为普通用户。
- 移除明文密码硬编码的运维脚本：原 `database/fix-admin-password.js` 把某个管理员口令以明文写在源码里，任何拿到仓库的人都能直接改库。已删除，替换为 `database/reset-admin-password.js`：口令只从环境变量 `NN_NEW_PASSWORD` 读取（不接受命令行传参，避免进入 shell 历史），bcrypt cost 12，账号不存在/非 active/长度不合法时中止不写库，结束前抹掉进程内的口令副本。用法见脚本头部注释。
- OTP 路由已统一为仅管理员：`routes/admin-otp.js` 在路由级 `router.use('/admin/otp', ...)` 上加 `auth + requireRole('admin')`，不依赖外层边界也能拒绝普通用户与客服；`public/admin-otp.html` 提示与 `public/js/me-page.js` 入口同步改为仅 admin 显示。客服的账号查询、聊天与系统消息权限未改动。
- 2026-09-17T20:42:45Z 认证/边界 16/16 通过，其中 4 项把真实 OTP 路由挂载在 `/isolated` 下单独验证：匿名 401、管理员进入参数校验 400、普通用户 403、客服 403。同一轮注册 9/9、贴图与资料 15/15 通过；2026-09-17T20:43Z 实际入口冒烟 PLATFORM_SMOKE_PASS。均为真实 HTTP + 隔离数据库。
- 既有 3000 进程不保证已加载最新 middleware；本轮实际入口验证使用新测试进程。部署/日常运行需启动最新源码。

## 阶段 8 后台本轮进展

- 新增 `C:\26niuniu\routes\admin.js`：`GET /api/admin/dashboard`、`GET /api/admin/users`，在 `server.js` 挂载到 `/api`。路由级 `auth + requireRole('admin')`，独立于全局边界；响应 `no-store`。
- 后台首页 `C:\26niuniu\public\admin.html` 与 `C:\26niuniu\public\js\admin-page.js`：概览卡片、快捷入口、用户查询（分页 / 搜索），非管理员显示「无权访问」且不请求数据。「我的」页新增管理后台入口，仅 admin 可见。
- 统计项：用户总数 / 正常 / 封禁 / 今日注册、待处理 OTP、推广层级与当月新增、客服会话数、24 小时登录与失败、有效公告、今日 OTP 操作数。
- 明确不支持：在线用户（无在线状态表）、待审核实名认证（无审核表）、未读客服消息（无管理员已读游标）。三项以 `unsupported` 返回原因，不编造数字。
- 用户查询只读，不含任何修改能力；不查询 `password_hash`、OTP 明文或登录凭证；手机号按脱敏展示，普通搜索一律不回显私密字段。
- 2026-09-17T20:59Z `C:\26niuniu\tests\admin-live.js` 对真实 MySQL 只读验证 17/17：管理员 id=3(bobo) 可访问、普通用户 id=1 返回 403、匿名 401、真实子查询（最后登录 / 直属 / 二级计数）正常、手机号脱敏、模糊用户名检索可用、通配符输入不触发全表模糊匹配。该脚本仅 GET，不写入任何数据。
- 2026-09-17T20:58Z `C:\26niuniu\tests\admin-dashboard.js` 隔离测试 19/19：匿名 401、普通用户与客服 403、非登录用途凭证 401、统计与脱敏规则、LIKE 通配符清洗。
- 本轮同批复跑：认证 16/16、注册 9/9、贴图与资料 15/15、找回密码通过、实际入口冒烟 PLATFORM_SMOKE_PASS（已包含 `/admin.html`、`/js/admin-page.js` 与两个 admin API 匿名 401）。
- 尚未实现：用户启用/禁用、实名认证审核、公告增删改、聊天内容管理、Audit Logs 页面、受保护的后台页面会话（当前仍是公开静态壳 + 受保护 API）。

未重置任何现有用户密码、未改变 JWT Secret。旧 UID 邀请码不再批量覆盖；新账户按最新需求安全随机生成邀请码。修改密码使用 bcrypt、72 字节限制及原哈希条件更新。当前密码更改不撤销其他已签发登录 JWT，需补凭证版本/会话失效机制。OTP 并发与凭证消费、后台完整授权、未登录客服必须继续完成后再对外上线。
## 阶段 V5（钱包 / 充值 / 提款 / 推广奖励 / 管理后台资金模块）本轮进展

- 新增集中配置 `config/funds.js`：充值 RM30–RM50,000、9 档快捷金额、付款方式（仅银行转账）、测试收款资料（测试账户 / 测试银行 / TEST-ACCOUNT，明确「不可用于真实转账」）、充值声明与备注提示（OKOK / DONE / NOTED）、提款资产类型与收款方式、凭证上传规则（JPG/PNG/WEBP、≤5MB、尺寸 64–8000）。所有阈值只在这一处维护。
- 数据库（`database/migrations/005-funds-referral.js`，幂等、只新增）：
  - `wallet_orders.status` 扩展为 `PENDING_PAYMENT / PENDING_REVIEW / APPROVED`（保留历史 `PENDING / PROCESSING / COMPLETED / REJECTED / CANCELLED`，未改任何历史行）
  - 新增列 `account_type / account_reference / voucher_path / voucher_uploaded_at / payer_remark / before_balance / after_balance / review_reason`
  - 新增索引：`uk_wallet_order_no`（订单号唯一）、`(order_type,status,created_at)`、`(user_id,created_at)`
  - 新增表 `referral_rewards`（推广奖励 Ledger：来源 / 层级 / 比例 / 基数 / 奖励金额 / 状态 / 幂等唯一键 `unique_key`），并把排序规则对齐到库默认 `utf8mb4_unicode_ci`（避免与既有表 JOIN 冲突）
- 用户端 API：`GET /api/deposit/config`、`POST/GET /api/deposits/orders`、`GET /api/deposits/orders/:id`、`POST /api/deposits/orders/:id/voucher`（multer 内存上传 + 服务端真实内容校验 + 服务器生成文件名 + 非公开目录存储）、`GET /api/deposits/orders/:id/voucher`（本人）、`POST /api/deposits/orders/:id/cancel`；提款同理：`GET /api/withdraw/config`、`GET /api/withdraw/balance`、`POST/GET /api/withdrawals/orders`、`GET /api/withdrawals/orders/:id`、`POST /api/withdrawals/orders/:id/cancel`。
- 管理端 API：`GET /api/admin/deposits|withdrawals`（状态筛选 + 订单号/用户名搜索 + 分页 + 汇总）、详情（含流水与审计）、`.../:id/voucher` 凭证图片、`POST .../:id/review` 批准/拒绝、`POST /api/admin/withdrawals/:id/processing`；推广管理 `GET /api/admin/referrals`、`GET /api/admin/referrals/rewards`、`POST /api/admin/referrals/rewards/settle`（按已通过充值订单补结算，幂等）。
- 核心逻辑集中在 `utils/funds.js`：金额一律「分」为整数运算；审核 = 事务 + 行锁 + 状态二次校验 + 幂等（重复批准 409）；每次余额变化写 `balance_transactions`（before/after/operator/reason/related_request_id）；每次审核写 `admin_logs`（action `wallet_order_review`）；批准的充值在同一事务内触发推广奖励结算 `utils/referralRewards.js`（比例来自 `config/referral.js`：直属 0.5% / 二级 0.3%，`unique_key` 防重复发奖）。
- 前端页面：`public/deposit.html`（金额选择 + 快捷金额 + 付款方式卡片 + 测试环境提示 + USDT 客服入口 + 立即充值）、`public/deposit-detail.html`（订单号/金额/付款方式/状态 + 测试收款信息 + 充值声明 + 备注提示 + 下一步/取消）、`public/deposit-voucher.html`（选择/预览/自动压缩/提交）、重写 `public/withdraw.html`（可用测试资产、资产类型、金额、收款资料、提交 + 我的申请）；`public/wallet.html` 快捷入口改为 充值 / 提款 / 转账（未开放）/ 交易记录；`public/promote.html` 新增奖励台账（汇总 + 日期筛选 + 记录）。
- 管理后台 `public/admin.html` + `public/js/admin-page.js` 新增「充值管理」「提款管理」「推广管理」三个面板（筛选/搜索/分页/凭证查看/批准/拒绝/标记处理中/补结算），并保留原「资金审核」面板（改为复用同一套事务逻辑）。
- 权限：`middleware/admin-boundary.js` 明确 support 可访问 `/api/admin/otp*`（OTP 管理）与 `/admin-otp.html` 页面；其余 `/api/admin/**` 仍仅 admin；普通用户/匿名继续 403/401 与 302 挡回。
- 上传安全：`utils/imageCheck.js` 按文件魔数（JPEG/PNG/WEBP）判定真实类型并解析真实尺寸，拒绝伪造扩展名、畸形文件、过大/过小文件；`utils/voucherStore.js` 只写入 `storage/`（非 `public/`），文件名由服务器 UUID 生成，读取前做路径穿越校验。
- 历史数据补强：`database/backfill-invite-codes.js` 只为 `invite_code` 为空的历史账号补发 8 位随机邀请码（本次执行补发 1 个：真实管理员 UID 10），不动其它字段、不改邀请关系。
- 本轮测试（真实 HTTP/MySQL/Chrome）：
  - `tests/deposit-withdraw-e2e.js`（隔离 MySQL + 真实 HTTP）92/92：金额边界、订单唯一、凭证类型/尺寸/大小、状态机、幂等、负余额保护、权限、奖励 Ledger、审计。
  - `tests/funds-browser.js`（真实 Chrome + 真实 MySQL，`zzfunds_*` 临时账号结束即删）81/81：充值页校验与下单、详情页声明与测试资料、凭证上传与预览、后台充值/提款/推广面板、批准流程、移动端输入框深色与底部导航不遮挡聊天输入框。
  - 回归：`tests/funds-flow.js` 34/34（隔离 mock，已适配新事务逻辑）、`tests/platform-smoke.js` PASS、`tests/admin-access-browser.js` 84/84、`tests/ui-fix-browser.js` PASS、`tests/navigation-wallet.js` 通过（期望值按 V5 更新）、`tests/uid-admin-verify.js` 通过（邀请码规则更新）、`tests/otp-reveal-integration.js` 8/8（补会话级临时 users 表隔离）、`tests/recovery.js` 11/11、`tests/socket-auth.js` PASS、`tests/invite-registration.js` 9/9、`tests/profile-real.js` 7/7。
- 仍未实现（明确列出）：邀请码补发后的推广链接历史统计、真实支付/银行/USDT 通道（本项目按规则始终不接）。
- 本轮（2026-09-19，V6 治理与聊天红包）已补齐：
  - 在线状态与在线人数：新增 `user_presence`（迁移 006），Socket 连接与聊天轮询都会写心跳（内存节流 20 秒），在线 = 最近 90 秒活跃；`/api/chat/channels`、`/api/admin/dashboard`、`/api/admin/online` 返回真实人数（表不可用时返回 null 并说明原因，不用账号总数冒充）。
  - 禁言联动范围：`config/moderation.js → MUTE.SCOPE` 集中配置「聊天 / 发红包 / 建房进房 / 竞标下注 / 提交提款」默认禁止，「充值（资金流入）」默认不禁止；聊天、红包、游戏写接口、提款接口全部后端强制校验（`USER_MUTED` 403）。
  - 双人复核：新增 `admin_approvals`（迁移 006）。封禁/解封、管理员权限变更、解除禁言改为「提交 202 待复核 → 另一名管理员通过才执行」，申请人不能复核自己的请求、重复复核 409、拒绝不修改数据、执行失败自动退回待复核；系统仅剩一名活跃管理员时按配置降级为单人执行并在审计标注。后台新增「复核」面板（`GET /api/admin/approvals`、`POST /api/admin/approvals/:id/decide`）。
  - 封禁主动断开 Socket：`utils/presence.js` 维护进程内 Socket 注册表，封禁生效后推送 `account:revoked` 并断开该账号全部连接；未断开的空闲连接仍由 15 秒重认证兜底。
  - 禁言到期提醒：`GET /api/admin/mute-expiring` + 概览「禁言中 / 24 小时内解禁」+ 用户列表「即将解禁」筛选与标签，用户端会话列表返回 `my_mute`（解禁时间与原因）。
  - 聊天红包（群聊，测试资产）：迁移 007 新增 `chat_red_packets` / `chat_red_packet_claims` 并把 `chat_messages.message_type` 扩展 `redpacket`。发红包先扣发送者 `users.cash_chips` 并写流水，抢红包事务 + 行锁 + 唯一键（绝不超发）、不能抢自己的、不能重复领取、未领完 24 小时后自动退回发送者（懒清扫 + 定时任务）、红包消息禁止撤回；游戏群新增红包入口与红包气泡、领取详情/手气最佳/领取记录。
  - 本轮验证（真实环境）：`tests/moderation-redpacket-live.js` 110/110（真实 server + 真实 MySQL + 真实 Socket.IO，临时 `zzmt_*` 账号结束即删）覆盖上述全部能力；回归 `tests/admin-access-browser.js` 87/87（已在双人复核语义下更新并通过，新增第二管理员用于复核）、`tests/admin-dashboard.js` 20/20（补齐 V6 依赖桩，恢复隔离）、`tests/platform-smoke.js` PASS、`tests/socket-auth.js` PASS、`tests/funds-flow.js` 34/34。
  - 规则澄清：聊天红包与游戏内的「红包对战」不是同一功能；两者都只使用平台内部测试资产，不接任何真实资金通道。
- 本轮补充（2026-09-19，聊天「说话人名字 + 红包」收尾）已补齐：
  - 说话人名字：`public/js/chat-page.js` 新增 `speakerName()` / `nameHtml()`，每条消息都渲染名字——自己 =「我 · 用户名」（金色右对齐）、别人 = 对方用户名（取后端 `username`）、系统消息 =「系统」、游戏消息 =「游戏助手」；用户名缺失时兜底「玩家 / 我」，界面上不再出现没有名字的气泡。游戏群与在线客服留言页共用同一套渲染（`public/group-chat.html`、`public/support-chat.html`）。
  - 红包入口与气泡：游戏群输入栏新增「红包」按钮（图标 + 文案 `#rpBtn`，配置来自 `GET /api/chat/channels` 的 `red_packet`，页面没拿到时会自行补拉一次）；红包消息以气泡卡片渲染（祝福语 / 已领进度 / 待领取·已抢光·已过期·已抢 X），点击可抢或查看详情（领取记录、手气最佳）。
  - 修复（真实缺陷）：抢红包成功后接口只返回领取结果里的 `packet`，缺 `claims` / `claims_total`，导致「已抢到红包」弹层显示「领取记录（undefined 人）」。现在 `POST /api/chat/redpackets/:id/claim` 成功后统一回读完整详情（`fullPacketOrFallback()`，回读失败则退回领取结果），前端 `rpDetailHtml()` 同时加了兜底，任何来源的 packet 都不会渲染出 `undefined`。
  - 修复（数据清理遗漏）：历史自动化测试结束只删了红包主表、没删红包消息，群里留下「指向已删红包」的幽灵卡片（显示待领取、点开报错）。`tests/moderation-redpacket-live.js` 的清理补上 `chat_messages`（红包消息没有外键约束，必须显式删除）并增加残留核对；同时按只读排查清理了库里已存在的 18 条幽灵消息与 6 条 2026-09-16 的历史测试文案（真实账号的贴图消息与撤回消息保留）。
  - 启动与端口：新增 `utils/portOwner.js`（零依赖、只读探测端口占用，Windows 用 `netstat -ano` + `tasklist`，其它平台用 `lsof`/`ps`）与 `scripts/restart.js`（`npm run restart`：默认只结束 node 进程，占用者是未知进程时拒绝误杀，`npm run restart -- --force` 才结束）；`server.js` 遇到 `EADDRINUSE` 直接打印占用进程与结束命令，不再只抛堆栈。
  - 本轮验证（真实环境，全部通过）：新增 `tests/chat-name-redpacket-browser.js` 51/51（真实临时端口 server + 真实 MySQL + 真实 Chrome（无头）；临时 `zzui_*` 账号结束即删）覆盖「群聊每条消息都有名字 / 系统消息来源 / 客服留言页名字 / 红包入口 → 发红包表单 → 红包卡片 → 对方抢红包 → 领取记录带用户名 / 余额与流水一致」，并保存视觉证据 `tests/chat-name-redpacket-ui.png`；回归 `tests/moderation-redpacket-live.js` 110/110（清理后残留 0）、`tests/admin-access-browser.js` 87/87。


## 阶段 V7（26牛牛娱乐场 + 全项目最终整合，2026-09-30）

### 新增：26牛牛娱乐场（服务端全计算，非现金化）
- `config/niuGame.js`（唯一规则源）：场次、底分、抢庄、倍数白名单、各阶段时长、牌型表、每日免费积分、限流、后台开关 key。
- `utils/niuEngine.js`（纯逻辑，零依赖、可单测）：牌堆、Fisher-Yates 洗牌（`crypto.randomInt`）、发牌、牌型判定（五小牛 > 炸弹牛 > 五花牛 > 同花牛 > 牛牛 > 牛9..牛1 > 无牛）、比牌（点数 → 牌面 → 花色，绝不假平局）、结算（庄闲逐家、余额不足封顶）。
- `utils/niuRoom.js`（服务端状态机，唯一真相）：`WAITING → GRABBING → BETTING → DEALING → RESULT → SETTLEMENT → FINISHED`，人数不足作废、玩家离开作废、每步都写 `niu_rounds.status`。
- `routes/niu.js` + `socket/niuSocket.js`：REST 只接受 `room` / `grab` / `bet_level`，**任何「结果」字段一律不接受**；手牌只走定向通道（`niu:private`），别人永远看不到你的牌。
- 结算三重安全：`niu_round_players` 的 `UNIQUE(round_id,user_id)` 防重复行；`UPDATE niu_rounds SET status='FINISHED' WHERE status='SETTLEMENT'` 的 affectedRows 作幂等闸门；余额变动全部走 `utils/ledger.js` 同一事务 + 行锁 + 流水。
- 迁移 `database/migrations/024-niu-game.js`（已执行，**安全增量，零删除**）：`users.game_points`、`balance_transactions.currency_type` 枚举追加 `GAME_POINTS`（按现值追加，保留历史数据）、新建 `niu_rounds` / `niu_round_players` / `niu_user_stats`、写入开关默认值。
- `utils/ledger.js` 的 `applyBalance` 改为资产字段映射表，新增 `GAME_POINTS → users.game_points`，其它资产路径不变。

### 修复的真实缺陷（本轮发现并修掉）
1. **`grantDailyFree` 永不发放**：占位 `INSERT` 先把 `daily_free_date` 写成今天，导致随后的认领 `UPDATE` 条件永远为假。改为单条原子语句。
2. **`utils/niuEngine.js` 内嵌了半份残缺副本**：`deal()` 后面直接插入了第二个函数头，文件从 443 行膨胀、结构错位。已合并为单一实现（263 行），`tests/structure-check.js` 加入该文件长期防回归。
3. **积分不足仍能开局**：`join` 与开局前都补上 `min_points` 校验，扣光积分的玩家不会被自动拖进下一局。
4. **测试污染生产库**：`tests/funds-flow.js` 自称「Isolated DB」，但 `utils/funds.js` 的 `pushNotification` 走真实数据库 → 已桩掉，并把「通知必须真实送达」写成断言防退化。
5. **`config/games.js` 的「游戏 A / 游戏 B」**是无 logo、无入口的 Demo 占位 → 已移除，保留可直接追加的配置结构与 `public/assets/games/README.txt` 说明。

### 数据保护
- 全程只做增量：`ALTER TABLE ADD COLUMN` / `CREATE TABLE IF NOT EXISTS` / `INSERT IGNORE`，无 `DROP`、无 `DELETE users`、无重新初始化。
- 测试机器人产生的对局已用 `scripts/cleanup-niu-testdata.js` 按账号白名单精确清理（默认 dry-run，`--apply` 才执行）；**真实管理员 bobo 的 1000 积分来自每日免费发放，未被误删**。清理后 `niu_rounds=0 / niu_round_players=0`，`users=5`，53 条资金流水全部为真实业务。

### 本轮验证（全部真实环境）
- `npm test` → `TEST_ALL_PASS`，6/6 套件：结构自检 PASS、引擎 34/34、邀请码注册 PASS、**26牛牛娱乐场 31/31（真实 MySQL + 真实 HTTP + 真实 Socket.IO）**、资金流 PASS、管理员权限边界 PASS（5 用户）、Socket 握手鉴权 PASS。
- `tests/mobile-overflow-check.js` 54 项：26 页面 × 8 屏宽，无横向溢出、无控制台报错。
- 入口冒烟：`/api/health` 200、`/niu.html` 200、`/lobby.html` 200、`/api/games` 与 `/api/game/niu/config` 匿名 401、`/admin.html` 非管理员 302 → `/me.html?admin=denied`。

### 新增文档与脚本
- `docs/deployment.md`（上线步骤、环境变量、备份回滚、APK、业务红线）
- `docs/api-list.md`（`scripts/api-inventory.js` 扫描生成，可反复再生）
- `docs/db-structure.md`（`scripts/db-inventory.js` 只读 information_schema 生成）
- `docs/business-rules.md` 补「规则 6：游戏积分非现金化规则」
- `scripts/cleanup-niu-testdata.js`（测试数据清理，默认 dry-run）

### 仍未完成（不得对外宣称已上线）
- 正式域名 / HTTPS / 反向代理 / 服务器部署 / APK 打包（需 `docs/deployment.md` 第 4、6 节）。
- 真机移动端（Safari / 微信内置浏览器 / 小屏安卓）验收。
- 全 API 逐条手测、数据库约束完整性逐表核对。
- 阶段 1/2/5/6（未登录客服会话、人工找回核验）与 OTP 并发闭环。
- `bobo`（UID 3）仍是联调遗留的管理员账号，上线前建议降级为普通用户。

