@echo off
cd /d C:\26niuniu
echo Starting server...
node server.js
pause