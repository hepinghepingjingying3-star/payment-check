// ============================================
// 26牛牛 - 资金核心逻辑（充值 / 提款共用）
// ============================================
// 设计原则:
//   1. 所有金额使用「分」为单位的整数运算，避免浮点误差；写库统一 DECIMAL(20,2)
//   2. 状态机由后端强制，前端不能直接改状态 / 余额
//   3. 审核必须：事务 + 行锁(FOR UPDATE) + 状态二次校验 + 幂等（重复审核 409）
//   4. 每次余额变化都写 balance_transactions（含 before/after/operator/reason）
//   5. 每次审核都写 admin_logs 审计（绝不写密码 / OTP / 凭证内容）
// ============================================

const crypto = require('crypto');
const db = require('../config/db');
const FUNDS = require('../config/funds');
const { writeAdminLog } = require('./adminAudit');
const { settleRewards } = require('./referralRewards');
const { pushNotification } = require('./content');

const REVIEWABLE_DEPOSIT = FUNDS.DEPOSIT_REVIEWABLE;      // ['PENDING_REVIEW','PENDING']
const REVIEWABLE_WITHDRAW = FUNDS.WITHDRAW_REVIEWABLE;    // ['PENDING','PROCESSING']
const CANCELLABLE_DEPOSIT = FUNDS.DEPOSIT_CANCELLABLE;    // ['PENDING_PAYMENT','PENDING_REVIEW','PENDING']

const ORDER_TYPE_TEXT = { DEPOSIT: '充值', WITHDRAW: '提款' };
const TX_TYPE_TEXT = {
  DEPOSIT: '充值', WITHDRAW: '提款', ADMIN_GRANT: '管理员发放', ADJUST: '管理员调整',
  EXCHANGE: '兑换', GAME_BET: '游戏下注', GAME_WIN: '游戏赢', GAME_LOSE: '游戏输',
  REFERRAL_REWARD: '推广奖励'
};
const ASSET_TEXT = { CASH_CHIPS: '现金筹码', GAME_BALANCE: '游戏余额' };

/** 生成唯一订单号（前缀 + 时间 + 随机） */
function generateOrderNo(prefix) {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) +
    pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  return prefix + stamp + crypto.randomBytes(3).toString('hex').toUpperCase();
}

/** 安全的用户可见状态文案（拒绝时不泄露内部原因，只给安全文案） */
function publicRejectReason(order) {
  const raw = String(order.review_reason || order.reject_reason || '').trim();
  return raw.slice(0, 120);
}

/** 订单对象 → 前端安全结构（用户端：不含 operator_id 等内部字段） */
function toUserOrder(o) {
  return {
    id: Number(o.id),
    order_no: o.order_no,
    order_type: o.order_type,
    amount: Number(o.amount),
    asset_type: o.currency_type,
    asset_text: ASSET_TEXT[o.currency_type] || o.currency_type,
    payment_method: o.method,
    account_type: o.account_type || null,
    account_reference: o.account_reference || o.account || null,
    remark: o.payer_remark || o.remark || null,
    status: o.status,
    status_text: FUNDS.STATUS_TEXT[o.status] || o.status,
    has_voucher: Boolean(o.voucher_path),
    voucher_uploaded_at: o.voucher_uploaded_at || null,
    reject_reason: publicRejectReason(o),
    created_at: o.created_at,
    updated_at: o.updated_at || null,
    reviewed_at: o.reviewed_at || null,
    operator_username: o.reviewer_username || null
  };
}

/** 订单对象 → 后台结构（含用户与审核人） */
function toAdminOrder(o) {
  const base = toUserOrder(o);
  return Object.assign(base, {
    user: { id: Number(o.user_id), username: o.username || null, nickname: o.nickname || null },
    operator_id: o.reviewed_by ? Number(o.reviewed_by) : null,
    operator_username: o.reviewer_username || null,
    operator_remark: o.admin_note || null,
    before_balance: o.before_balance === null || o.before_balance === undefined ? null : Number(o.before_balance),
    after_balance: o.after_balance === null || o.after_balance === undefined ? null : Number(o.after_balance),
    voucher_url: o.voucher_path ? ('/api/admin/' + (o.order_type === 'DEPOSIT' ? 'deposits' : 'withdrawals') + '/' + Number(o.id) + '/voucher') : null
  });
}


// ============================================
// 充值：创建订单（PENDING_PAYMENT）
// ============================================
async function createDepositOrder(userId, amountCents, paymentMethod) {
  const amount = FUNDS.amountString(amountCents);
  let lastErr = null;
  for (let i = 0; i < 3; i++) {
    const orderNo = generateOrderNo('D');
    try {
      const [r] = await db.promise().query(
        `INSERT INTO wallet_orders (order_no, user_id, order_type, currency_type, amount, method, status)
         VALUES (?, ?, 'DEPOSIT', 'CASH_CHIPS', ?, ?, 'PENDING_PAYMENT')`,
        [orderNo, userId, amount, paymentMethod]
      );
      const order = await findMyOrder(userId, r.insertId, 'DEPOSIT');
      return { ok: true, order: order };
    } catch (e) {
      lastErr = e;
      if (e && e.code === 'ER_DUP_ENTRY') continue;   // 极端情况下订单号冲突 → 重新生成
      break;
    }
  }
  console.error('创建充值订单失败:', lastErr ? lastErr.message : 'unknown');
  return { ok: false, code: 'ORDER_CREATE_FAILED', status: 500, message: '充值订单创建失败，请稍后重试' };
}

// ============================================
// 提款：创建订单（PENDING，提交时不扣余额，仅校验可用余额）
// ============================================
async function createWithdrawalOrder(userId, assetType, amountCents, accountType, accountReference, remark) {
  const field = assetType === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
  const amount = FUNDS.amountString(amountCents);
  const account = String(accountReference || '').slice(0, FUNDS.WITHDRAW.ACCOUNT_REF_MAX);
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [uRows] = await conn.query(`SELECT ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [userId]);
    const availableCents = Math.round(Number(uRows[0] ? uRows[0].bal : 0) * 100);
    if (availableCents < amountCents) {
      await conn.rollback();
      return {
        ok: false, code: 'INSUFFICIENT_BALANCE', status: 409,
        message: '可用现金筹码不足，无法提交该提现申请',
        available: FUNDS.centsToAmount(availableCents)
      };
    }
    const orderNo = generateOrderNo('W');
    const [r] = await conn.query(
      `INSERT INTO wallet_orders
       (order_no, user_id, order_type, currency_type, amount, method, account,
        account_type, account_reference, payer_remark, status)
       VALUES (?, ?, 'WITHDRAW', ?, ?, ?, ?, ?, ?, ?, 'PENDING')`,
      [orderNo, userId, assetType, amount, accountType, account, accountType, account, remark || null]
    );
    await conn.commit();
    const order = await findMyOrder(userId, r.insertId, 'WITHDRAW');
    return { ok: true, order: order };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('创建提款订单失败:', err.message);
    return { ok: false, code: 'ORDER_CREATE_FAILED', status: 500, message: '提款申请提交失败，请稍后重试' };
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 用户端查询
// ============================================
async function findMyOrder(userId, id, orderType) {
  const [rows] = await db.promise().query(
    `SELECT ${ORDER_FIELDS}, r.username AS reviewer_username
       FROM wallet_orders o LEFT JOIN users r ON r.id = o.reviewed_by
      WHERE o.id = ? AND o.user_id = ? AND o.order_type = ? LIMIT 1`,
    [id, userId, orderType]
  );
  return rows[0] ? toUserOrder(rows[0]) : null;
}

async function listMyOrders(userId, orderType, status, limit, offset) {
  const params = [userId, orderType];
  let where = 'WHERE o.user_id = ? AND o.order_type = ?';
  if (status && FUNDS.STATUS_TEXT[status]) { where += ' AND o.status = ?'; params.push(status); }
  params.push(limit, offset);
  const [rows] = await db.promise().query(
    `SELECT ${ORDER_FIELDS} FROM wallet_orders o ${where} ORDER BY o.id DESC LIMIT ? OFFSET ?`, params
  );
  const [cnt] = await db.promise().query(
    'SELECT COUNT(*) AS c FROM wallet_orders WHERE user_id = ? AND order_type = ?', [userId, orderType]
  );
  return { list: rows.map(toUserOrder), total: Number(cnt[0] ? cnt[0].c : 0), limit: limit, offset: offset };
}

/** 用户取消自己的订单（仅允许未审核状态；已审核一律 409，绝不改余额） */
async function cancelMyOrder(userId, id, orderType) {
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, user_id, order_type, status FROM wallet_orders WHERE id = ? FOR UPDATE', [id]
    );
    const o = rows[0];
    if (!o || Number(o.user_id) !== Number(userId) || o.order_type !== orderType) {
      await conn.rollback();
      return { ok: false, code: 'ORDER_NOT_FOUND', status: 404, message: '订单不存在' };
    }
    const allowed = orderType === 'DEPOSIT' ? CANCELLABLE_DEPOSIT : ['PENDING', 'PROCESSING'];
    if (allowed.indexOf(o.status) === -1) {
      await conn.rollback();
      return { ok: false, code: 'ORDER_NOT_CANCELLABLE', status: 409, message: '该订单已审核，无法取消' };
    }
    await conn.query("UPDATE wallet_orders SET status = 'CANCELLED' WHERE id = ? AND status = ?", [id, o.status]);
    await conn.commit();
    return { ok: true, status: 'CANCELLED' };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('取消订单失败:', err.message);
    return { ok: false, code: 'CANCEL_FAILED', status: 500, message: '取消失败，请稍后重试' };
  } finally {
    if (conn) conn.release();
  }
}

/** 能否提交/更换凭证 */
function canSubmitVoucher(status) {
  return status === 'PENDING_PAYMENT' || status === 'PENDING_REVIEW' || status === 'PENDING';
}

/** 绑定凭证 → 状态进入 PENDING_REVIEW（绝不改余额） */
async function attachVoucher(userId, id, orderType, relPath) {
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, user_id, order_type, status FROM wallet_orders WHERE id = ? FOR UPDATE', [id]
    );
    const o = rows[0];
    if (!o || Number(o.user_id) !== Number(userId) || o.order_type !== orderType) {
      await conn.rollback();
      return { ok: false, code: 'ORDER_NOT_FOUND', status: 404, message: '订单不存在' };
    }
    if (!canSubmitVoucher(o.status)) {
      await conn.rollback();
      return { ok: false, code: 'ORDER_NOT_EDITABLE', status: 409, message: '该订单当前状态不能提交凭证' };
    }
    await conn.query(
      `UPDATE wallet_orders SET voucher_path = ?, voucher_uploaded_at = NOW(), status = 'PENDING_REVIEW'
       WHERE id = ? AND status = ?`,
      [relPath, id, o.status]
    );
    await conn.commit();
    return { ok: true, order: await findMyOrder(userId, id, orderType) };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('提交凭证失败:', err.message);
    return { ok: false, code: 'VOUCHER_SAVE_FAILED', status: 500, message: '凭证提交失败，请稍后重试' };
  } finally {
    if (conn) conn.release();
  }
}

const ORDER_FIELDS = `o.id, o.order_no, o.user_id, o.order_type, o.currency_type, o.amount, o.method,
  o.account, o.account_type, o.account_reference, o.voucher_path, o.voucher_uploaded_at,
  o.remark, o.payer_remark, o.status, o.created_at, o.updated_at, o.reviewed_by, o.reviewed_at,
  o.reject_reason, o.review_reason, o.admin_note, o.before_balance, o.after_balance`;


// ============================================
// 管理员审核：充值（PENDING_REVIEW → APPROVED / REJECTED）
// 幂等：只有可审核状态能通过；重复点击返回 409，绝不重复加余额
// ============================================
async function reviewDeposit(orderId, adminId, decision, opts) {
  opts = opts || {};
  const approve = decision === 'approve';
  const note = String(opts.note || '').slice(0, 255);
  const reason = String(opts.reason || '').slice(0, 255);
  if (!approve && !reason) {
    return { ok: false, code: 'REASON_REQUIRED', status: 422, message: '拒绝必须填写原因' };
  }
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, user_id, order_no, order_type, status, amount, currency_type FROM wallet_orders WHERE id = ? FOR UPDATE',
      [orderId]
    );
    const order = rows[0];
    if (!order || order.order_type !== 'DEPOSIT') {
      await conn.rollback();
      return { ok: false, code: 'ORDER_NOT_FOUND', status: 404, message: '充值订单不存在' };
    }
    if (REVIEWABLE_DEPOSIT.indexOf(order.status) === -1) {
      await conn.rollback();
      return { ok: false, code: 'ALREADY_REVIEWED', status: 409, message: '该订单已审核或当前状态不允许审核' };
    }
    const amountCents = Math.round(Number(order.amount) * 100);
    const amount = FUNDS.amountString(amountCents);

    if (!approve) {
      await conn.query(
        `UPDATE wallet_orders SET status = 'REJECTED', reviewed_by = ?, reviewed_at = NOW(),
           admin_note = ?, reject_reason = ?, review_reason = ? WHERE id = ? AND status = ?`,
        [adminId, note || null, reason, reason, orderId, order.status]
      );
      await writeAdminLog({
        adminId: adminId, targetUserId: order.user_id, action: 'wallet_order_review', conn: conn,
        detail: 'order=' + orderId + ' no=' + order.order_no + ' type=DEPOSIT decision=rejected reason=' + reason
      });
      await conn.commit();
      pushNotification(order.user_id, 'system', '充值申请已拒绝',
        '充值订单 ' + order.order_no + ' 未通过审核。' + (reason ? (' 原因：' + reason) : ''),
        '/deposit-detail.html?id=' + orderId).catch(() => {});
      return { ok: true, status: 'REJECTED', approved: false, order_no: order.order_no };
    }

    const field = 'cash_chips';
    const [uRows] = await conn.query(`SELECT ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [order.user_id]);
    const before = Number(uRows[0] ? uRows[0].bal : 0);
    const after = before + amountCents / 100;
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [after.toFixed(2), order.user_id]);
    await conn.query(
      `INSERT INTO balance_transactions
       (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id, related_request_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [order.user_id, 'CASH_CHIPS', amount, before.toFixed(2), after.toFixed(2),
        'DEPOSIT', '充值审核通过 ' + order.order_no, adminId, orderId]
    );
    await conn.query(
      `UPDATE wallet_orders SET status = 'APPROVED', reviewed_by = ?, reviewed_at = NOW(),
         admin_note = ?, reject_reason = NULL, review_reason = ?, before_balance = ?, after_balance = ?
       WHERE id = ? AND status = ?`,
      [adminId, note || null, note || null, before.toFixed(2), after.toFixed(2), orderId, order.status]
    );
    await writeAdminLog({
      adminId: adminId, targetUserId: order.user_id, action: 'wallet_order_review', conn: conn,
      detail: 'order=' + orderId + ' no=' + order.order_no + ' type=DEPOSIT decision=approved amount=' + amount +
        ' balance_before=' + before.toFixed(2) + ' balance_after=' + after.toFixed(2)
    });
    // 推广奖励：同一事务内按 config/referral.js 结算（幂等，绝不重复发奖）
    let rewards = [];
    try {
      rewards = await settleRewards(conn, {
        sourceType: 'DEPOSIT', sourceRef: order.order_no, sourceUserId: order.user_id,
        baseAmountCents: amountCents, operatorId: adminId, assetType: 'CASH_CHIPS',
        remark: '充值审核通过奖励'
      });
    } catch (e) { console.error('推广奖励结算失败:', e.message); }
    await conn.commit();
    pushNotification(order.user_id, 'system', '充值审核已通过',
      '充值订单 ' + order.order_no + ' 已审核通过，现金筹码已更新。',
      '/deposit-detail.html?id=' + orderId).catch(() => {});
    return {
      ok: true, status: 'APPROVED', approved: true, order_no: order.order_no,
      before_balance: Number(before.toFixed(2)), after_balance: Number(after.toFixed(2)), rewards: rewards
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('充值审核失败:', err.message);
    return { ok: false, code: 'REVIEW_FAILED', status: 500, message: '充值审核失败，请稍后重试' };
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 管理员审核：提款（PENDING/PROCESSING → APPROVED / REJECTED）
// 批准：事务内二次校验余额，充足才扣减；重复批准 409，绝不重复扣款
// ============================================
async function reviewWithdrawal(orderId, adminId, decision, opts) {
  opts = opts || {};
  const approve = decision === 'approve';
  const note = String(opts.note || '').slice(0, 255);
  const reason = String(opts.reason || '').slice(0, 255);
  if (!approve && !reason) {
    return { ok: false, code: 'REASON_REQUIRED', status: 422, message: '拒绝必须填写原因' };
  }
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, user_id, order_no, order_type, status, amount, currency_type FROM wallet_orders WHERE id = ? FOR UPDATE',
      [orderId]
    );
    const order = rows[0];
    if (!order || order.order_type !== 'WITHDRAW') {
      await conn.rollback();
      return { ok: false, code: 'ORDER_NOT_FOUND', status: 404, message: '提款订单不存在' };
    }
    if (REVIEWABLE_WITHDRAW.indexOf(order.status) === -1) {
      await conn.rollback();
      return { ok: false, code: 'ALREADY_REVIEWED', status: 409, message: '该订单已审核或当前状态不允许审核' };
    }
    const amountCents = Math.round(Number(order.amount) * 100);
    const amount = FUNDS.amountString(amountCents);
    const assetType = order.currency_type === 'GAME_BALANCE' ? 'GAME_BALANCE' : 'CASH_CHIPS';
    const field = assetType === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';

    if (!approve) {
      await conn.query(
        `UPDATE wallet_orders SET status = 'REJECTED', reviewed_by = ?, reviewed_at = NOW(),
           admin_note = ?, reject_reason = ?, review_reason = ? WHERE id = ? AND status = ?`,
        [adminId, note || null, reason, reason, orderId, order.status]
      );
      await writeAdminLog({
        adminId: adminId, targetUserId: order.user_id, action: 'wallet_order_review', conn: conn,
        detail: 'order=' + orderId + ' no=' + order.order_no + ' type=WITHDRAW decision=rejected reason=' + reason
      });
      await conn.commit();
      pushNotification(order.user_id, 'system', '提款申请已拒绝',
        '提款订单 ' + order.order_no + ' 未通过审核。' + (reason ? (' 原因：' + reason) : ''),
        '/withdraw-detail.html?id=' + orderId).catch(() => {});
      return { ok: true, status: 'REJECTED', approved: false, order_no: order.order_no };
    }

    const [uRows] = await conn.query(`SELECT ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [order.user_id]);
    const before = Number(uRows[0] ? uRows[0].bal : 0);
    const beforeCents = Math.round(before * 100);
    if (beforeCents < amountCents) {
      await conn.rollback();
      return {
        ok: false, code: 'INSUFFICIENT_BALANCE', status: 409,
        message: '用户可用现金筹码不足，无法批准该提现（不会产生负余额）'
      };
    }
    const after = (beforeCents - amountCents) / 100;
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [after.toFixed(2), order.user_id]);
    await conn.query(
      `INSERT INTO balance_transactions
       (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id, related_request_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [order.user_id, assetType, (-amountCents / 100).toFixed(2), before.toFixed(2), after.toFixed(2),
        'WITHDRAW', '提款审核通过 ' + order.order_no, adminId, orderId]
    );
    await conn.query(
      `UPDATE wallet_orders SET status = 'APPROVED', reviewed_by = ?, reviewed_at = NOW(),
         admin_note = ?, reject_reason = NULL, review_reason = ?, before_balance = ?, after_balance = ?
       WHERE id = ? AND status = ?`,
      [adminId, note || null, note || null, before.toFixed(2), after.toFixed(2), orderId, order.status]
    );
    await writeAdminLog({
      adminId: adminId, targetUserId: order.user_id, action: 'wallet_order_review', conn: conn,
      detail: 'order=' + orderId + ' no=' + order.order_no + ' type=WITHDRAW decision=approved amount=' + amount +
        ' balance_before=' + before.toFixed(2) + ' balance_after=' + after.toFixed(2)
    });
    await conn.commit();
    pushNotification(order.user_id, 'system', '提款审核已通过',
      '提款订单 ' + order.order_no + ' 已审核通过，现金筹码已扣减。',
      '/withdraw-detail.html?id=' + orderId).catch(() => {});
    return {
      ok: true, status: 'APPROVED', approved: true, order_no: order.order_no,
      before_balance: Number(before.toFixed(2)), after_balance: Number(after.toFixed(2))
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('提款审核失败:', err.message);
    return { ok: false, code: 'REVIEW_FAILED', status: 500, message: '提款审核失败，请稍后重试' };
  } finally {
    if (conn) conn.release();
  }
}


/** 关键字 LIKE 模式：转义通配符（下划线 / 百分号 / 反斜杠），保留用户输入的真实字符 */
function likePattern(q) {
  return '%' + String(q === null || q === undefined ? '' : q).replace(/[\\%_]/g, ch => '\\' + ch) + '%';
}

// ============================================
// 管理员查询
// ============================================
async function listOrdersForAdmin(filters) {
  filters = filters || {};
  const limit = Math.min(Math.max(parseInt(filters.limit, 10) || 20, 1), 100);
  const offset = Math.max(parseInt(filters.offset, 10) || 0, 0);
  const where = [];
  const params = [];
  if (filters.type === 'DEPOSIT' || filters.type === 'WITHDRAW') { where.push('o.order_type = ?'); params.push(filters.type); }
  const status = String(filters.status || '').toUpperCase();
  if (status && FUNDS.STATUS_TEXT[status]) { where.push('o.status = ?'); params.push(status); }
  const q = String(filters.q || '').trim().slice(0, 64);
  if (q) {
    where.push('(o.order_no LIKE ? OR u.username LIKE ? OR u.nickname LIKE ?)');
    const like = likePattern(q);
    params.push(like, like, like);
  }
  const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const [rows] = await db.promise().query(
    `SELECT ${ORDER_FIELDS}, u.username, u.nickname, r.username AS reviewer_username
     FROM wallet_orders o
     LEFT JOIN users u ON u.id = o.user_id
     LEFT JOIN users r ON r.id = o.reviewed_by
     ${clause} ORDER BY o.id DESC LIMIT ? OFFSET ?`,
    params.concat([limit, offset])
  );
  const [cnt] = await db.promise().query(
    `SELECT COUNT(*) AS c FROM wallet_orders o LEFT JOIN users u ON u.id = o.user_id ${clause}`, params
  );
  return {
    list: rows.map(toAdminOrder),
    total: Number(cnt[0] ? cnt[0].c : 0),
    limit: limit,
    offset: offset,
    summary: await orderSummary()
  };
}

async function findOrderForAdmin(orderId, type) {
  const params = [orderId];
  let extra = '';
  if (type === 'DEPOSIT' || type === 'WITHDRAW') { extra = ' AND o.order_type = ?'; params.push(type); }
  const [rows] = await db.promise().query(
    `SELECT ${ORDER_FIELDS}, u.username, u.nickname, r.username AS reviewer_username
     FROM wallet_orders o
     LEFT JOIN users u ON u.id = o.user_id
     LEFT JOIN users r ON r.id = o.reviewed_by
     WHERE o.id = ?${extra} LIMIT 1`, params
  );
  if (!rows[0]) return null;
  const order = toAdminOrder(rows[0]);
  const [txRows] = await db.promise().query(
    `SELECT id, currency_type, amount, balance_before, balance_after, type, reason, operator_id, created_at
     FROM balance_transactions WHERE related_request_id = ? ORDER BY id DESC LIMIT 10`, [orderId]
  );
  order.transactions = txRows.map(t => ({
    id: Number(t.id), currency_type: t.currency_type, amount: Number(t.amount),
    balance_before: Number(t.balance_before), balance_after: Number(t.balance_after),
    type: t.type, type_text: TX_TYPE_TEXT[t.type] || t.type, reason: t.reason || null,
    operator_id: t.operator_id ? Number(t.operator_id) : null, created_at: t.created_at
  }));
  const [logRows] = await db.promise().query(
    `SELECT id, admin_id, action, detail, created_at FROM admin_logs
     WHERE action = 'wallet_order_review' AND detail LIKE ? ORDER BY id DESC LIMIT 10`,
    ['order=' + orderId + ' %']
  );
  order.audit_logs = logRows.map(l => ({
    id: Number(l.id), admin_id: l.admin_id ? Number(l.admin_id) : null,
    action: l.action, detail: l.detail || null, created_at: l.created_at
  }));
  return order;
}

/** 各状态订单统计（后台概览 / 筛选按钮） */
async function orderSummary() {
  const [rows] = await db.promise().query(
    'SELECT order_type, status, COUNT(*) AS c FROM wallet_orders GROUP BY order_type, status'
  );
  const out = {
    deposit: { pending_payment: 0, pending_review: 0, approved: 0, rejected: 0, cancelled: 0, total: 0 },
    withdraw: { pending: 0, processing: 0, approved: 0, rejected: 0, cancelled: 0, total: 0 }
  };
  rows.forEach(r => {
    const isW = r.order_type === 'WITHDRAW';
    const g = isW ? out.withdraw : out.deposit;
    const c = Number(r.c) || 0;
    g.total += c;
    const s = String(r.status);
    if (s === 'PENDING_PAYMENT') g.pending_payment = c;
    else if (s === 'PENDING_REVIEW') g.pending_review = c;
    else if (s === 'PENDING') { if (isW) g.pending += c; else g.pending_review += c; }
    else if (s === 'PROCESSING') g.processing = c;
    else if (s === 'APPROVED' || s === 'COMPLETED') g.approved += c;
    else if (s === 'REJECTED') g.rejected = c;
    else if (s === 'CANCELLED') g.cancelled = c;
    else if (s === 'PENDING_PAYMENT') g.pending_payment = c;
  });
  return out;
}

/** 标记为处理中（提款：PENDING → PROCESSING，可选功能，不触碰余额） */
async function adminSetProcessing(orderId, adminId, note) {
  const [r] = await db.promise().query(
    `UPDATE wallet_orders SET status = 'PROCESSING', admin_note = COALESCE(?, admin_note)
     WHERE id = ? AND order_type = 'WITHDRAW' AND status = 'PENDING'`,
    [String(note || '').slice(0, 255) || null, orderId]
  );
  if (!r || Number(r.affectedRows) !== 1) {
    return { ok: false, code: 'INVALID_STATUS', status: 409, message: '只有待审核的提款订单可以标记为处理中' };
  }
  await writeAdminLog({ adminId: adminId, action: 'withdrawal_processing', detail: 'order=' + orderId });
  const [orders] = await db.promise().query(
    "SELECT user_id, order_no FROM wallet_orders WHERE id = ? AND order_type = 'WITHDRAW' LIMIT 1", [orderId]
  );
  if (orders[0]) {
    pushNotification(orders[0].user_id, 'system', '提款申请处理中',
      '提款订单 ' + orders[0].order_no + ' 正在由管理员处理。',
      '/withdraw-detail.html?id=' + orderId).catch(() => {});
  }
  return { ok: true, status: 'PROCESSING' };
}

module.exports = {
  generateOrderNo, toUserOrder, toAdminOrder, publicRejectReason,
  ORDER_FIELDS, ORDER_TYPE_TEXT, TX_TYPE_TEXT, ASSET_TEXT,
  REVIEWABLE_DEPOSIT, REVIEWABLE_WITHDRAW, CANCELLABLE_DEPOSIT,
  createDepositOrder, createWithdrawalOrder, listMyOrders, findMyOrder, cancelMyOrder, attachVoucher,
  reviewDeposit, reviewWithdrawal, listOrdersForAdmin, findOrderForAdmin, orderSummary, adminSetProcessing
};
