// ============================================
// 26牛牛 - 推广奖励 Ledger（虚拟现金筹码）
// ============================================
// 规则:
//   - 比例只来自 config/referral.js（直属 / 二级 / 自身），本文件不写死百分比
//   - 奖励必须有来源（source_type + source_ref + source_user_id）
//   - 幂等：unique_key = 来源类型:来源单号:层级:受益人，重复结算不会重复发奖
//   - 所有入账必须与「台账写入 + 余额更新 + 流水 + 审计」同一事务，绝不由前端计算
//   - 绝不接入真实赌博返水 / 现金佣金
// ============================================

const db = require('../config/db');
const REFERRAL = require('../config/referral');

// 不同来源类型适用的奖励层级
const RULES_BY_SOURCE = {
  // 充值审核通过：给上级（直属 0.5% / 二级 0.3%）发虚拟现金筹码奖励
  DEPOSIT: [
    { level: 1, rate: REFERRAL.REFERRAL_RATES.DIRECT },
    { level: 2, rate: REFERRAL.REFERRAL_RATES.SECOND_LEVEL }
  ],
  // 游戏行为（当前游戏核心已暂停，仅保留规则与表结构，不会被前端触发）
  GAME: [
    { level: 0, rate: REFERRAL.REFERRAL_RATES.SELF },
    { level: 1, rate: REFERRAL.REFERRAL_RATES.DIRECT },
    { level: 2, rate: REFERRAL.REFERRAL_RATES.SECOND_LEVEL }
  ]
};

/** 查询邀请链：{ self, direct, second }（只查 users.invited_by，关系由注册时后端写入） */
async function loadInviteChain(runner, userId) {
  const [rows] = await runner.query(
    `SELECT u.id, u.username, u.invited_by AS direct_id,
            d.invited_by AS second_id
     FROM users u LEFT JOIN users d ON d.id = u.invited_by
     WHERE u.id = ? LIMIT 1`, [userId]
  );
  const row = rows[0];
  if (!row) return null;
  return {
    self: Number(row.id),
    direct: row.direct_id ? Number(row.direct_id) : null,
    second: row.second_id ? Number(row.second_id) : null,
    username: row.username
  };
}

/** 受益人以层级取定 */
function beneficiaryOf(chain, level) {
  if (level === 0) return chain.self;
  if (level === 1) return chain.direct;
  if (level === 2) return chain.second;
  return null;
}

/**
 * 结算来源事件产生的推广奖励（幂等）
 * @param {object} conn 事务连接（调用方负责 begin/commit/rollback）
 * @param {object} o { sourceType, sourceRef, sourceUserId, baseAmountCents, operatorId, assetType, remark }
 * @returns {Promise<Array>} 本次真正新入账的奖励列表
 */
async function settleRewards(conn, o) {
  const sourceType = String(o.sourceType || '').toUpperCase();
  const rules = RULES_BY_SOURCE[sourceType];
  if (!rules) return [];

  const chain = await loadInviteChain(conn, o.sourceUserId);
  if (!chain) return [];

  const created = [];
  for (const rule of rules) {
    const userId = beneficiaryOf(chain, rule.level);
    if (!userId) continue;
    // 禁止自己邀请自己的自奖励（注册时后端已禁止，这里再做一次保护）
    if (rule.level > 0 && userId === chain.self) continue;

    const rewardCents = Math.round(o.baseAmountCents * rule.rate / 100);
    if (!Number.isSafeInteger(rewardCents) || rewardCents <= 0) continue;

    const assetType = o.assetType === 'GAME_BALANCE' ? 'GAME_BALANCE' : 'CASH_CHIPS';
    const field = assetType === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
    const uniqueKey = (sourceType + ':' + String(o.sourceRef) + ':L' + rule.level + ':U' + userId).slice(0, 160);
    const rewardAmount = (rewardCents / 100).toFixed(2);
    const baseAmount = (o.baseAmountCents / 100).toFixed(2);

    const [ins] = await conn.query(
      `INSERT INTO referral_rewards
       (user_id, source_user_id, level, rate, base_amount, reward_amount, asset_type,
        status, source_type, source_ref, unique_key, remark, operator_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE unique_key = unique_key`,
      [userId, chain.self, rule.level, rule.rate, baseAmount, rewardAmount, assetType,
        sourceType, String(o.sourceRef).slice(0, 64), uniqueKey,
        o.remark ? String(o.remark).slice(0, 255) : null, o.operatorId || null]
    );
    // 幂等判定：MySQL 对「命中唯一键并原值更新」也可能返回 affectedRows=1，
    // 因此统一以 insertId 判定是否为新插入（重复时 insertId 为 0），绝不重复入账。
    const rewardId = Number(ins.insertId);
    if (!Number.isSafeInteger(rewardId) || rewardId <= 0) continue;
    const [uRows] = await conn.query(`SELECT ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [userId]);
    const before = Number(uRows[0] ? uRows[0].bal : 0);
    const after = before + rewardCents / 100;
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [after.toFixed(2), userId]);
    await conn.query(
      `INSERT INTO balance_transactions
       (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id, related_request_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, assetType, rewardAmount, before.toFixed(2), after.toFixed(2),
        'REFERRAL_REWARD', '推广奖励 L' + rule.level + ' 来源 ' + String(o.sourceRef), o.operatorId || null, null]
    );
    await conn.query(
      `UPDATE referral_rewards SET status = 'CREDITED', credited_at = NOW() WHERE id = ? AND status = 'PENDING'`,
      [rewardId]
    );
    created.push({
      id: rewardId, user_id: userId, source_user_id: chain.self, level: rule.level,
      rate: rule.rate, base_amount: Number(baseAmount), reward_amount: Number(rewardAmount),
      asset_type: assetType, unique_key: uniqueKey
    });
  }
  return created;
}

/** 我的奖励台账（用户端，只读自己的；可选日期区间 from/to = YYYY-MM-DD） */
async function listMyRewards(userId, limit, offset, range) {
  const where = ['r.user_id = ?'];
  const params = [userId];
  const from = range && /^\d{4}-\d{2}-\d{2}$/.test(String(range.from || '')) ? String(range.from) : null;
  const to = range && /^\d{4}-\d{2}-\d{2}$/.test(String(range.to || '')) ? String(range.to) : null;
  if (from) { where.push('r.created_at >= ?'); params.push(from + ' 00:00:00'); }
  if (to) { where.push('r.created_at <= ?'); params.push(to + ' 23:59:59'); }
  params.push(limit, offset);
  const [rows] = await db.promise().query(
    `SELECT r.id, r.level, r.rate, r.base_amount, r.reward_amount, r.asset_type, r.status,
            r.source_type, r.source_ref, r.created_at, r.credited_at,
            s.username AS source_username
     FROM referral_rewards r
     LEFT JOIN users s ON s.id = r.source_user_id
     WHERE ${where.join(' AND ')}
     ORDER BY r.id DESC LIMIT ? OFFSET ?`,
    params
  );
  return rows.map(r => ({
    id: Number(r.id),
    level: Number(r.level),
    level_text: r.level === 0 ? '自身游戏奖励' : (r.level === 1 ? '直属下线' : '二级下线'),
    rate: Number(r.rate),
    base_amount: Number(r.base_amount),
    reward_amount: Number(r.reward_amount),
    asset_type: r.asset_type,
    status: r.status,
    status_text: r.status === 'CREDITED' ? '已入账' : (r.status === 'PENDING' ? '待入账' : '已作废'),
    source_type: r.source_type,
    source_ref: r.source_ref,
    source_username: r.source_username || null,
    created_at: r.created_at,
    credited_at: r.credited_at
  }));
}

/** 我的奖励汇总 */
async function myRewardSummary(userId) {
  const [rows] = await db.promise().query(
    `SELECT COALESCE(SUM(CASE WHEN status = 'CREDITED' THEN reward_amount ELSE 0 END), 0) AS credited,
            COALESCE(SUM(CASE WHEN status = 'PENDING' THEN reward_amount ELSE 0 END), 0) AS pending,
            COUNT(*) AS total
     FROM referral_rewards WHERE user_id = ?`, [userId]
  );
  const r = rows[0] || {};
  return {
    credited: Number(r.credited || 0),
    pending: Number(r.pending || 0),
    count: Number(r.total || 0)
  };
}

module.exports = { settleRewards, listMyRewards, myRewardSummary, loadInviteChain, RULES_BY_SOURCE };
