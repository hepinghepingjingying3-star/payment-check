// ============================================
// 26牛牛 - 请求工具（IP / 手机号标准化 / 统一响应）
// ============================================

/** 取客户端 IP（兼容反向代理，仅用于限流统计，不做信任判定） */
function clientIp(req) {
  const xf = req.headers['x-forwarded-for'];
  let ip = '';
  if (typeof xf === 'string' && xf.length) {
    ip = xf.split(',')[0].trim();
  }
  if (!ip) {
    ip = (req.socket && req.socket.remoteAddress) || (req.connection && req.connection.remoteAddress) || '';
  }
  // IPv6 映射写法归一
  if (ip.indexOf('::ffff:') === 0) ip = ip.slice(7);
  return ip.slice(0, 45);
}

/** 手机号标准化：去掉空格/横线/括号，保留开头 + 与数字 */
function normalizePhone(raw) {
  if (raw === null || raw === undefined) return '';
  let s = String(raw).trim();
  s = s.replace(/[\s\-()（）]/g, '');
  if (s.startsWith('+')) s = '+' + s.slice(1).replace(/[^0-9]/g, '');
  else s = s.replace(/[^0-9]/g, '');
  return s;
}

/** 手机号格式：10-15 位数字，可带 + 前缀（与注册校验一致） */
function isValidPhone(phone) {
  return /^\+?[0-9]{10,15}$/.test(String(phone || ''));
}

/** 手机号展示脱敏：+60 12-345 6789 → +60 1*-*** 6789 风格 */
function maskPhone(phone) {
  const s = String(phone || '');
  if (s.length <= 4) return s;
  const head = s.slice(0, Math.max(3, s.length - 7));
  const tail = s.slice(-4);
  return head + '****' + tail;
}

/** 站内相对路径校验（禁止外链跳转，防止钓鱼） */
function safeInternalPath(p) {
  const s = String(p || '');
  if (!s.startsWith('/')) return null;
  if (s.startsWith('//')) return null;
  if (s.indexOf('\\') >= 0) return null;
  return s.slice(0, 255);
}

function ok(res, data, extra) {
  const body = { success: true, data: data === undefined ? null : data };
  if (extra && typeof extra === 'object') Object.assign(body, extra);
  return res.json(body);
}

function fail(res, message, status, code) {
  const body = { success: false, message: message || '请求失败，请稍后重试' };
  if (code) body.code = code;
  return res.status(status || 400).json(body);
}

module.exports = { clientIp, normalizePhone, isValidPhone, maskPhone, safeInternalPath, ok, fail };