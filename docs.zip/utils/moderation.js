'use strict';
// ============================================
// 26牛牛 - 用户治理工具（禁言 / 禁言联动 / 到期提醒）
// ============================================
// 说明:
//   - 禁言数据存 users.muted_until + users.mute_reason（迁移 004）
//   - 禁言联动范围由 config/moderation.js 的 MUTE.SCOPE 集中控制：
//     被禁言时禁止的动作（聊天、发红包、建房/进房、竞标下注、提款）逐个开关，
//     充值（资金流入）默认不限制；规则只维护在配置里，不散落在路由中
//   - 后端强制校验（数据库为准），前端提示只是体验
//   - 迁移未执行时降级为「未禁言」，避免整站不可用，并打印一次明确提示
// ============================================

const db = require('../config/db');
const MOD = require('../config/moderation');

const MUTE_MIN_MINUTES = MOD.MUTE.MIN_MINUTES;
const MUTE_MAX_MINUTES = MOD.MUTE.MAX_MINUTES;
const EXPIRE_REMIND_MINUTES = MOD.MUTE.EXPIRE_REMIND_MINUTES;

let columnMissing = false;

/** yyyy-MM-dd HH:mm（本地时区，用于中文提示） */
function formatDateTime(date) {
  const pad = n => (n < 10 ? '0' : '') + n;
  return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) +
    ' ' + pad(date.getHours()) + ':' + pad(date.getMinutes());
}

/** 分钟数 → 中文时长（后台提醒用） */
function formatDuration(minutes) {
  const m = Math.max(0, Math.round(Number(minutes) || 0));
  if (m < 60) return m + ' 分钟';
  if (m < 60 * 24) return Math.round(m / 60) + ' 小时';
  return Math.round((m / (60 * 24)) * 10) / 10 + ' 天';
}

/**
 * 读取用户当前禁言状态
 * @returns {Promise<{muted:boolean, until:Date|null, reason:string|null, minutes_left:number}>}
 */
async function muteState(userId, runner) {
  const empty = { muted: false, until: null, reason: null, minutes_left: 0 };
  if (columnMissing) return empty;
  const query = runner || db.promise();
  try {
    const [rows] = await query.query('SELECT muted_until, mute_reason FROM users WHERE id = ? LIMIT 1', [userId]);
    const row = rows[0];
    if (!row) return empty;
    const until = row.muted_until ? new Date(row.muted_until) : null;
    const muted = !!(until && !Number.isNaN(until.getTime()) && until.getTime() > Date.now());
    if (!muted) return empty;
    const minutesLeft = Math.max(1, Math.round((until.getTime() - Date.now()) / 60000));
    return { muted: true, until: until, reason: row.mute_reason || null, minutes_left: minutesLeft };
  } catch (err) {
    if (err && (err.code === 'ER_BAD_FIELD_ERROR' || err.errno === 1054)) {
      columnMissing = true;
      console.error('users.muted_until 不存在，禁言功能已跳过；请运行 node database/migrations/004-moderation.js');
      return empty;
    }
    throw err;
  }
}

/** 动作中文名（scopeKey 见 config/moderation.js → SCOPE_TEXT） */
function scopeText(scopeKey) {
  return MOD.SCOPE_TEXT[scopeKey] || '执行该操作';
}

/** 统一的禁言提示文案（中文，含解禁时间与原因，按动作区分） */
function muteMessage(state, scopeKey) {
  const until = state && state.until ? '，解禁时间 ' + formatDateTime(state.until) : '';
  const reason = state && state.reason ? '（原因：' + state.reason + '）' : '';
  return '您已被管理员禁言' + until + '，暂时无法' + scopeText(scopeKey) + reason;
}

/**
 * 禁言联动校验（后端强制）
 * @returns {Promise<null|{code,status,message,state}>} null = 允许
 */
async function scopeBlocked(userId, scopeKey) {
  if (!MOD.MUTE.SCOPE[scopeKey]) return null;   // 该动作不在禁言范围内
  const state = await muteState(userId);
  if (!state.muted) return null;
  return { code: 'USER_MUTED', status: 403, message: muteMessage(state, scopeKey), state: state };
}

/** 禁言联动范围（前端展示用） */
function scopeRules() {
  return Object.keys(MOD.MUTE.SCOPE).map(function (key) {
    return { key: key, label: scopeText(key), blocked: !!MOD.MUTE.SCOPE[key] };
  });
}

/** 用户端禁言摘要（聊天页横幅 / 个人中心提示） */
async function muteSummary(userId) {
  const state = await muteState(userId);
  if (!state.muted) {
    return { muted: false, muted_until: null, minutes_left: 0, reason: null, notice: null, rules: scopeRules() };
  }
  return {
    muted: true,
    muted_until: state.until,
    minutes_left: state.minutes_left,
    muted_until_text: formatDateTime(state.until),
    reason: state.reason,
    notice: muteMessage(state, 'chat'),
    expiring_soon: state.minutes_left <= EXPIRE_REMIND_MINUTES,
    rules: scopeRules()
  };
}

/** 后台：当前被禁言人数 / 即将解禁人数（表列缺失时返回 null，不编造 0） */
async function mutedSummary() {
  if (columnMissing) return { muted_now: null, expiring_24h: null, expiring_1h: null };
  try {
    const [rows] = await db.promise().query(
      `SELECT
         SUM(muted_until > NOW()) AS muted_now,
         SUM(muted_until > NOW() AND muted_until <= DATE_ADD(NOW(), INTERVAL ? MINUTE)) AS expiring_24h,
         SUM(muted_until > NOW() AND muted_until <= DATE_ADD(NOW(), INTERVAL 60 MINUTE)) AS expiring_1h
       FROM users`,
      [EXPIRE_REMIND_MINUTES]
    );
    const r = rows[0] || {};
    return {
      muted_now: Number(r.muted_now) || 0,
      expiring_24h: Number(r.expiring_24h) || 0,
      expiring_1h: Number(r.expiring_1h) || 0
    };
  } catch (err) {
    if (err && (err.code === 'ER_BAD_FIELD_ERROR' || err.errno === 1054)) {
      columnMissing = true;
      return { muted_now: null, expiring_24h: null, expiring_1h: null };
    }
    throw err;
  }
}

/** 后台：即将解禁（到期提醒）列表 */
async function expiringMutes(limit) {
  if (columnMissing) return [];
  const n = Math.min(Math.max(Number(limit) || 20, 1), 100);
  const [rows] = await db.promise().query(
    `SELECT id, username, nickname, muted_until, mute_reason,
            TIMESTAMPDIFF(MINUTE, NOW(), muted_until) AS minutes_left
     FROM users
     WHERE muted_until > NOW() AND muted_until <= DATE_ADD(NOW(), INTERVAL ? MINUTE)
     ORDER BY muted_until ASC LIMIT ?`,
    [EXPIRE_REMIND_MINUTES, n]
  );
  return rows.map(r => ({
    id: Number(r.id),
    username: r.username || null,
    nickname: r.nickname || null,
    muted_until: r.muted_until,
    mute_reason: r.mute_reason || null,
    minutes_left: Number(r.minutes_left) || 0,
    minutes_left_text: formatDuration(r.minutes_left)
  }));
}

module.exports = {
  muteState, muteMessage, formatDateTime, formatDuration,
  scopeBlocked, scopeText, scopeRules, muteSummary, mutedSummary, expiringMutes,
  MUTE_MIN_MINUTES, MUTE_MAX_MINUTES, EXPIRE_REMIND_MINUTES
};
