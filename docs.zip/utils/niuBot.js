'use strict';
// ============================================
// 26牛牛游戏机器人（后端权威，与管理员浏览器无关）
// ============================================
// 核心原则：
//   1) 机器人是「系统身份」：显示名固定「26牛牛游戏机器人」+ 官方头像，
//      绝不显示管理员用户名，绝不用 Emoji / 随机头像 / AI 头像冒充。
//   2) 机器人由后端驱动：管理员点「启动」只是把 running=1 写库，
//      真正的节拍跑在服务端 setInterval；管理员关网页 / 玩家退出都不影响。
//   3) 只有真实管理员能控制（路由层 requireRole('admin')，普通用户 403）。
//   4) 防重复：状态单例 + game_rounds.uq_game_rounds_active
//      + niu_bot_events UNIQUE(round_id,event_type)。
//   5) 停止语义：只停「自动推进」，绝不删房间 / 删局 / 删聊天 / 删玩家 / 删历史。
// ============================================

const db = require('./../config/db');
const NG = require('../config/niuGame');
const siteSettings = require('./siteSettings');
const chat = require('./niuChat');

const STATE_ID = NG.BOT.STATE_ID;

/** 全部可配置话术的键（顺序即后台展示顺序） */
const TEMPLATE_KEYS = Object.keys(NG.BOT.TEMPLATES);

/** 默认模板（来自 config/niuGame.js，唯一来源） */
function defaultTemplates() {
  const out = {};
  TEMPLATE_KEYS.forEach(k => { out[k] = NG.BOT.TEMPLATES[k]; });
  return out;
}

/**
 * 生效模板 = 代码默认值 ← 数据库覆盖（未设置过的键回落默认值）
 *
 * 注意：这里直读 system_settings，不走 siteSettings.getAll()。
 * 因为 getAll 只返回 SETTINGS 白名单里注册过的键，而 niu_bot_tpl_* 是机器人
 * 自己的话术键（自由文案），不在那张枚举表里，走 getAll 会被静默丢弃，
 * 导致「保存成功但永远读回默认值」。
 */
async function templates() {
  const base = defaultTemplates();
  const prefix = NG.BOT.TEMPLATE_KEY_PREFIX;
  try {
    const [rows] = await db.promise().query(
      'SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE ?',
      [prefix + '%']);
    rows.forEach(r => {
      const k = String(r.setting_key).slice(prefix.length);
      if (TEMPLATE_KEYS.indexOf(k) < 0) return;
      let v = r.setting_value;
      if (typeof v === 'string') {
        try { v = JSON.parse(v); } catch (e) { /* 兼容历史纯文本写入 */ }
      }
      const text = String(v === null || v === undefined ? '' : v).trim();
      if (text) base[k] = text;
    });
  } catch (e) {
    console.error('[niu-bot] 读取话术模板失败，改用代码默认值:', e.message);
  }
  return base;
}

/** 取一条模板文案（替换 {name} 之类占位符） */
async function line(key, vars) {
  const all = await templates();
  let text = all[key] || NG.BOT.TEMPLATES[key] || '';
  const map = vars || {};
  Object.keys(map).forEach(k => { text = text.split('{' + k + '}').join(String(map[k])); });
  return text;
}

// ---------- 状态行 ----------
/** 读机器人状态单例；表缺失（未跑迁移）时返回安全默认值，绝不抛错拖垮游戏 */
async function readState() {
  try {
    const [rows] = await db.promise().query('SELECT * FROM niu_bot_state WHERE id = ?', [STATE_ID]);
    if (rows.length) return rows[0];
  } catch (e) {
    console.error('[niu-bot] 读取机器人状态失败（迁移 026 是否已执行？）:', e.message);
  }
  return {
    id: STATE_ID, running: 0, auto_messages: 1, room_key: 'junior',
    chat_channel: NG.CHAT.GROUP_CHANNEL, current_round_id: null, current_round_pk: null,
    current_phase: null, phase_ends_at: null, started_at: null, stopped_at: null,
    started_by: null, updated_by: null
  };
}

/** 机器人是否正在运行（状态机推进的唯一总闸门） */
async function isRunning() {
  const s = await readState();
  return Number(s.running) === 1;
}

/** 是否自动播报阶段话术（关掉后状态机照常维护，只是不发提示消息） */
async function autoMessages() {
  const s = await readState();
  return Number(s.auto_messages) === 1;
}

// ---------- 事件幂等（防重复消息）----------
/**
 * 认领一个机器人事件。同一 round_id + event_type 已认领过则返回 false，
 * 调用方据此跳过发消息 —— 服务器重启 / 重复启动 / 并发 tick 都不会刷出重复话术。
 *
 * 重要：幂等的作用域是「某一局」。没有 round_id 时不做跨局去重，
 * 否则第一局用掉事件类型后，后面每一局的阶段播报都会被永久吞掉。
 */
async function claimEvent(eventType, roundId, o) {
  const opt = o || {};
  if (!roundId) return true;          // 无局上下文（例如房间级通知）：不去重，避免误伤后续对局
  const rid = String(roundId);
  try {
    const [ins] = await db.promise().query(
      'INSERT IGNORE INTO niu_bot_events (round_id, event_type, room_id, phase) VALUES (?, ?, ?, ?)',
      [rid, String(eventType), opt.room_id || null, opt.phase || null]);
    // 认领结果直接看 affectedRows：1 = 本次新插入（首次，允许发消息）；
    // 0 = 此前已认领过（重复，必须跳过）。
    // 注意不能用「再查一次 COUNT」判断：那样重复插入时 COUNT 仍然是 1，
    // 会把「已存在」误判成「首次」，导致重复启动 / 并发 tick 刷出重复话术。
    return Number(ins.affectedRows) === 1;
  } catch (e) {
    // 表不存在（未跑迁移）时退化为「总是发送」，不影响旧环境可用
    console.error('[niu-bot] 事件幂等写入失败（迁移 026 是否已执行？）:', e.message);
    return true;
  }
}

// ---------- 状态写回 ----------
async function patchState(fields, adminId) {
  const sets = [];
  const args = [];
  Object.keys(fields || {}).forEach(k => {
    if (fields[k] === undefined) return;
    // 阶段截止时间由 MySQL 现算，避开 JS Date → DATETIME 的时区字符串化问题
    if (k === '_endsInSeconds') {
      sets.push('phase_ends_at = DATE_ADD(NOW(), INTERVAL ? SECOND)');
      args.push(Number(fields[k]) || 1);
      return;
    }
    sets.push(k + ' = ?');
    args.push(fields[k]);
  });
  sets.push('updated_by = ?');
  args.push(adminId || null);
  try {
    await db.promise().query(
      'UPDATE niu_bot_state SET ' + sets.join(', ') + ', updated_at = NOW() WHERE id = ?',
      args.concat([STATE_ID]));
  } catch (e) {
    console.error('[niu-bot] 机器人状态写回失败:', e.message);
  }
}

/** 同步当前局 / 当前阶段到机器人状态（后台面板实时显示用），纯写入不影响任何判定 */
async function trackRound(o) {
  const opt = o || {};
  const patch = {
    room_key: opt.room_key,
    chat_channel: opt.chat_channel,
    current_round_id: opt.round_id,
    current_round_pk: opt.round_pk,
    current_phase: opt.phase
  };
  // 阶段截止时间同样交给 MySQL 计算（DATE_ADD），不把 JS Date 直接塞进 DATETIME，
  // 否则列里会留下 "Fri Oct 02 2026 05:27:13 GMT+0800 (...)" 这种无法解析的字符串。
  const secs = Number(opt.ends_in_seconds);
  if (secs > 0) patch._endsInSeconds = Math.round(secs);
  await patchState(patch, opt.admin_id || null);
}

// ---------- 启动 / 停止 ----------
/**
 * 启动机器人（后端权威）。
 * 幂等：连续点击「启动」多次只把 running 置 1，绝不重复开新局、绝不重复播报。
 */
async function start(adminId, o) {
  const opt = o || {};
  const prev = await readState();
  const roomKey = NG.roomByKey(opt.room_key) ? String(opt.room_key) : (prev.room_key || 'junior');
  await db.promise().query(
    `INSERT INTO niu_bot_state (id, running, auto_messages, room_key, chat_channel, started_at, started_by, stopped_at)
     VALUES (?, 1, 1, ?, ?, NOW(), ?, NULL)
     ON DUPLICATE KEY UPDATE
       running = 1, room_key = VALUES(room_key), chat_channel = VALUES(chat_channel),
       started_at = NOW(), started_by = VALUES(started_by), stopped_at = NULL,
       updated_by = VALUES(started_by), updated_at = NOW()`,
    [STATE_ID, roomKey, NG.CHAT.GROUP_CHANNEL, adminId || null]
  );
  // 只有「从停止 → 运行」这一次转换才播报，重复启动不刷屏
  if (Number(prev.running) !== 1) {
    const first = await claimEvent('bot_started', 'bot:global:run:' + Date.now().toString(36), {});
    if (first && await autoMessages()) {
      await broadcastSystem(await line('bot_started'), { kind: 'bot_started' });
    }
  }
  return status();
}

/**
 * 停止机器人：只停自动推进。
 * 不删房间、不删当前局、不删聊天记录、不删玩家、不删历史对局；再次启动即可继续。
 */
async function stop(adminId) {
  const prev = await readState();
  await db.promise().query(
    `UPDATE niu_bot_state
        SET running = 0, stopped_at = NOW(), updated_by = ?, updated_at = NOW()
      WHERE id = ?`,
    [adminId || null, STATE_ID]
  );
  if (Number(prev.running) === 1 && await autoMessages()) {
    await broadcastSystem(await line('bot_stopped'), { kind: 'bot_stopped' });
  }
  return status();
}

/** 开关自动播报（关闭后状态机照常维护，只是不发阶段提示消息） */
async function setAutoMessages(flag, adminId) {
  await db.promise().query(
    'UPDATE niu_bot_state SET auto_messages = ?, updated_by = ?, updated_at = NOW() WHERE id = ?',
    [flag ? 1 : 0, adminId || null, STATE_ID]);
  return status();
}

// ---------- 消息 ----------
/**
 * 由机器人向 26牛牛游戏群发一条 game 类型消息。
 * auto !== false 时受「自动播报」开关控制；带 event_type 时做幂等去重。
 */
async function botSay(o) {
  const opt = o || {};
  if (opt.auto !== false && !(await autoMessages())) return null;
  if (opt.event_type) {
    const first = await claimEvent(opt.event_type, opt.round_id, { room_id: opt.room_pk, phase: opt.phase });
    if (!first) return null;
  }
  return chat.postGameMessage({
    content: opt.content,
    round: { room_pk: opt.room_pk, round_pk: opt.round_pk, round_id: opt.round_id, phase: opt.phase },
    meta: Object.assign({
      source: NG.CHAT.SOURCE, bot: true,
      bot_name: NG.BOT.NAME, bot_avatar: NG.BOT.AVATAR_URL
    }, opt.meta || {}),
    io: opt.io || null
  });
}

/** 无 round 上下文的机器人播报（启动 / 停止提示等） */
async function broadcastSystem(content, meta) {
  return chat.postGameMessage({
    content: content,
    round: null,
    meta: Object.assign({
      source: NG.CHAT.SOURCE, bot: true, kind: 'bot_notice',
      bot_name: NG.BOT.NAME, bot_avatar: NG.BOT.AVATAR_URL
    }, meta || {})
  });
}

/**
 * 管理员手动发送系统消息。
 * 管理员专用接口（权限在路由层强制，普通用户 403）。
 * 机器人系统身份发送：user_id 为 NULL，绝不显示管理员用户名。
 */
async function adminSay(content, adminId, o) {
  const opt = o || {};
  const text = String(content || '').trim().slice(0, 300);
  if (!text) throw new Error('EMPTY_MESSAGE');
  const [res] = await db.promise().query(
    `INSERT INTO chat_messages
       (channel, user_id, message_type, content, meta, sender_role, room_id, round_id, phase)
     VALUES (?, NULL, ?, ?, ?, 'system', ?, ?, ?)`,
    [NG.CHAT.GROUP_CHANNEL,
      opt.message_type === 'game' ? 'game' : 'system',
      text,
      JSON.stringify({
        source: 'admin', kind: 'admin_notice',
        bot_name: NG.BOT.NAME, bot_avatar: NG.BOT.AVATAR_URL,
        admin_id: Number(adminId) || null
      }),
      opt.room_pk || null, opt.round_id || null, opt.phase || null]
  );
  return { id: Number(res.insertId), content: text };
}

/**
 * 保存话术模板（管理员专用）。
 * 写统一配置表 system_settings，键 = niu_bot_tpl_<key>（带前缀，绝不覆盖任何其它配置项）。
 * 模板键是自由文案，不走 siteSettings 的枚举白名单校验（那里只认固定类型的配置项）。
 */
async function saveTemplates(patch, adminId) {
  const values = {};
  TEMPLATE_KEYS.forEach(k => {
    if (patch[k] === undefined) return;
    const v = String(patch[k]).trim().slice(0, 300);
    if (!v) return;              // 空串视为「不改」，避免误清空导致群里没话术
    values[k] = v;
  });
  const keys = Object.keys(values);
  if (!keys.length) return { changed: [] };

  const conn = db.promise();
  const changed = [];
  for (const k of keys) {
    const settingKey = NG.BOT.TEMPLATE_KEY_PREFIX + k;
    const [rows] = await conn.query('SELECT setting_value FROM system_settings WHERE setting_key = ?', [settingKey]);
    const before = rows.length ? String(rows[0].setting_value) : null;
    // 与 siteSettings 一致的存法：JSON 字符串，读时回落默认
    if (before !== JSON.stringify(values[k])) changed.push(k);
    await conn.query(
      `INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
       VALUES (?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value),
                               updated_by = VALUES(updated_by),
                               updated_at = NOW()`,
      [settingKey, JSON.stringify(values[k]), adminId || null]
    );
  }
  siteSettings.invalidate();     // 立即生效
  return { changed };
}

// ---------- 对外状态 ----------
/** 后台面板 / API 用的完整机器人状态（真实数据库数据，绝不伪造） */
async function status() {
  const s = await readState();
  const running = Number(s.running) === 1;
  let rooms = [];
  try {
    const [rows] = await db.promise().query(
      `SELECT id, room_name, room_key FROM game_rooms
        WHERE chat_channel = ? AND room_key IS NOT NULL ORDER BY room_key`,
      [s.chat_channel || NG.CHAT.GROUP_CHANNEL]);
    rooms = rows;
  } catch (e) {
    console.error('[niu-bot] 读取场次列表失败:', e.message);
  }
  const cur = rooms.find(x => x.room_key === s.room_key) || null;
  return {
    name: NG.BOT.NAME,
    avatar_url: NG.BOT.AVATAR_URL,
    running: running,
    status_text: running ? '运行中' : '已停止',
    auto_messages: Number(s.auto_messages) === 1,
    room_key: s.room_key,
    room_id: cur ? Number(cur.id) : null,
    room_name: (cur && cur.room_name) || '26牛牛游戏群',
    chat_channel: s.chat_channel || NG.CHAT.GROUP_CHANNEL,
    current_round_id: s.current_round_id || null,
    current_round_pk: s.current_round_pk ? Number(s.current_round_pk) : null,
    current_phase: s.current_phase || null,
    current_phase_text: (NG.PHASE_TEXT || {})[s.current_phase] || '等待中',
    phase_ends_at: s.phase_ends_at || null,
    started_at: s.started_at || null,
    stopped_at: s.stopped_at || null,
    started_by: s.started_by ? Number(s.started_by) : null,
    updated_at: s.updated_at || null,
    rooms: rooms.map(x => ({ room_id: Number(x.id), key: x.room_key, name: x.room_name }))
  };
}

/** 公开给聊天页 / 游戏卡片的身份信息（不泄露任何控制能力） */
function identity() {
  return {
    name: NG.BOT.NAME,
    avatar_url: NG.BOT.AVATAR_URL,
    fallback_avatar_url: NG.BOT.FALLBACK_AVATAR_URL
  };
}

module.exports = {
  STATE_ID,
  TEMPLATE_KEYS,
  readState,
  isRunning,
  autoMessages,
  templates,
  saveTemplates,
  defaultTemplates,
  line,
  claimEvent,
  patchState,
  trackRound,
  start,
  stop,
  setAutoMessages,
  botSay,
  broadcastSystem,
  adminSay,
  status,
  identity
};