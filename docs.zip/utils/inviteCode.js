// 26牛牛 - 新账号使用安全随机数字邀请码；保留现有 UID 邀请码的输入兼容。

const crypto = require('crypto');

// 新注册使用八位随机数字，不从用户身份信息派生。
const CHARSET = '0123456789';
const CODE_LENGTH = 8;

/** 生成随机八位数字邀请码（作为字符串保留前导零）。 */
function generateInviteCode() {
  let out = '';
  for (let i = 0; i < CODE_LENGTH; i++) {
    out += CHARSET[crypto.randomInt(0, CHARSET.length)];
  }
  return out;
}

/**
 * 生成一个数据库中不重复的邀请码
 * @param {object} queryFn 可执行 SQL 的函数：(sql, params) => Promise<[rows]>
 *                          传入事务连接 conn.query 可保证与注册同事务
 * @param {number} maxRetry 最大重试次数
 */
async function generateUniqueInviteCode(queryFn, maxRetry = 12) {
  for (let i = 0; i < maxRetry; i++) {
    const code = generateInviteCode();
    const [rows] = await queryFn(
      'SELECT id FROM users WHERE invite_code = ? LIMIT 1',
      [code]
    );
    if (rows.length === 0) return code;
  }
  throw new Error('INVITE_CODE_GENERATION_EXHAUSTED');
}

/** 规范化用户输入的邀请码（去空格、转大写） */
function normalizeInviteCode(raw) {
  if (raw === null || raw === undefined) return '';
  return String(raw).replace(/[\s-]/g, '').toUpperCase();
}

/**
 * 支持的邀请码格式（必须与现有数据库数据兼容，不能拒绝历史邀请码）：
 *   1. 八位随机数字（含前导零）—— 当前新注册格式（utils/inviteCode.js）
 *   2. 八位大写十六进制 —— 历史账号已存在的邀请码（如 03EC0136），必须继续有效
 *   3. 正整数 UID —— 最早的 UID 形式邀请码
 * 有效性仍须查询数据库；本函数只做格式预筛。
 */
function isValidInviteCodeFormat(code) {
  if (/^[0-9]{8}$/.test(code)) return true;
  if (/^[0-9A-F]{8}$/.test(code)) return true;          // 历史十六进制码（normalize 已转大写）
  return /^[1-9][0-9]{0,9}$/.test(code) && Number(code) <= 4294967295;
}

module.exports = {
  generateInviteCode,
  generateUniqueInviteCode,
  normalizeInviteCode,
  isValidInviteCodeFormat,
  CODE_LENGTH
};