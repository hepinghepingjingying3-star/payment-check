// ============================================
// 26牛牛 - OTP（手机号验证码）工具
// ============================================
// 安全要求:
//   - 数据库不长期保存明文 OTP：只保存 HMAC-SHA256 哈希（otp_hash）
//   - 明文 OTP 仅在「等待管理员通过 WhatsApp 手动发送」期间临时保留，
//     管理员标记「已发送」后立即清空（otp_plain_tmp = NULL）
//   - 普通用户 API 绝不返回 OTP / otp_hash
//   - 日志表 (otp_audit_logs) 绝不写入 OTP 明文
// ============================================

const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { OTP_CONFIG } = require('../config/otp');

// 用于 HMAC 的密钥：复用 JWT_SECRET（不新增密钥、不修改现有密钥）
const OTP_HMAC_KEY = process.env.JWT_SECRET || '';

/** 生成 6 位随机数字 OTP（使用 crypto 强随机，非 Math.random） */
function generateOtp(len) {
  const n = len || OTP_CONFIG.LENGTH;
  let out = '';
  while (out.length < n) {
    const b = crypto.randomBytes(8);
    for (let i = 0; i < b.length && out.length < n; i++) {
      // 取模偏差可忽略（256 % 10），仅用于一次性短码
      out += String(b[i] % 10);
    }
  }
  return out;
}

/** OTP → 不可逆哈希（校验用） */
function hashOtp(phone, otp) {
  return crypto
    .createHmac('sha256', OTP_HMAC_KEY)
    .update(String(phone) + '|' + String(otp))
    .digest('hex');
}

/** 常量时间比较，避免时序侧信道 */
function safeEqualHex(a, b) {
  const ba = Buffer.from(String(a || ''), 'utf8');
  const bb = Buffer.from(String(b || ''), 'utf8');
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

/**
 * 验证成功后签发「注册凭证」：用户带着它继续注册，避免明文 OTP 出现在前端存储。
 *
 * 凭证里必须带 otp_id（registration_otp.id）：
 *   只有 phone 时，凭证无法证明「对应哪一条已验证的验证码记录」，
 *   同一枚凭证在 TTL 内可被反复重放，注册失败后也能无限次重试。
 * 带 otp_id 后，注册接口能定位到具体那一行，并在注册成功的同一事务里标记消费。
 */
function signRegisterToken(phone, otpId) {
  return jwt.sign(
    { phone: phone, otp_id: Number(otpId) || 0, purpose: 'register_otp' },
    process.env.JWT_SECRET,
    { expiresIn: OTP_CONFIG.REGISTER_TOKEN_TTL_SECONDS }
  );
}

/**
 * 校验注册凭证。
 * 返回 { phone, otpId } 或 null。
 * （旧版返回纯手机号字符串，已改为对象；调用方已同步更新）
 */
function verifyRegisterToken(token) {
  try {
    const d = jwt.verify(String(token || ''), process.env.JWT_SECRET);
    if (!d || d.purpose !== 'register_otp' || !d.phone) return null;
    return { phone: String(d.phone), otpId: Number(d.otp_id) || 0 };
  } catch (e) {
    return null;
  }
}

/** SQL 时间格式（本地时区）*/
function sqlDateTime(d) {
  const x = d instanceof Date ? d : new Date(d);
  const p = n => String(n).padStart(2, '0');
  return x.getFullYear() + '-' + p(x.getMonth() + 1) + '-' + p(x.getDate()) + ' ' +
    p(x.getHours()) + ':' + p(x.getMinutes()) + ':' + p(x.getSeconds());
}

/** 剩余秒数（用于后台倒计时显示） */
function secondsLeft(expiresAt) {
  const t = new Date(expiresAt).getTime();
  if (!Number.isFinite(t)) return 0;
  return Math.max(0, Math.floor((t - Date.now()) / 1000));
}

module.exports = {
  generateOtp,
  hashOtp,
  safeEqualHex,
  signRegisterToken,
  verifyRegisterToken,
  sqlDateTime,
  secondsLeft
};