'use strict';
// ============================================
// 26牛牛 - 聊天红包核心逻辑（群聊红包）
// ============================================
// 设计原则:
//   1. 金额一律用「分」为单位的整数运算，写库统一 DECIMAL(20,2)
//   2. 资产为平台内部【现金筹码】users.cash_chips，与真实支付无关
//   3. 发红包：事务 + 行锁(FOR UPDATE) + 余额校验，先扣发送者再生成红包
//   4. 抢红包：事务 + 红包行锁 + 领取唯一键(uk_chat_claim_user)，绝不超发
//   5. 过期未领完：懒清扫 + 定时任务，剩余金额原路退回发送者（写流水）
//   6. 每次余额变化都写 balance_transactions（含 before/after/type/reason）
// ============================================

const crypto = require('crypto');
const db = require('../config/db');
const RP = require('../config/redPacket');

const AMOUNT_MIN_CENTS = Math.round(RP.MIN_AMOUNT * 100);
const AMOUNT_MAX_CENTS = Math.round(RP.MAX_AMOUNT * 100);

function fail(code, status, message) {
  return { ok: false, code: code, status: status, message: message };
}

function cents(v) { return Math.round(Number(v) * 100); }
function toAmount(c) { return (Number(c) / 100).toFixed(2); }
function parseJson(raw) {
  if (!raw) return {};
  if (typeof raw === 'object') return raw;
  try { return JSON.parse(String(raw)); } catch (e) { return {}; }
}

/** 红包编号（RP + 时间 + 随机，唯一键兜底） */
function generatePacketNo() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) +
    pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  return 'RP' + stamp + crypto.randomBytes(3).toString('hex').toUpperCase();
}

/**
 * 随机拆分红包（微信「二倍均值」思路，crypto 安全随机）
 * 保证：每份 ≥ 1 分，且合计严格等于总额
 */
function splitAmounts(totalCents, count) {
  const out = [];
  let remaining = totalCents;
  for (let i = 0; i < count; i++) {
    const left = count - i;
    if (left === 1) { out.push(remaining); break; }
    const min = 1;
    const maxByMin = remaining - (left - 1) * min;          // 给后面每份至少留 1 分
    const avg = Math.floor(remaining / left);
    const upper = Math.min(avg * 2, maxByMin);
    const pick = min + crypto.randomInt(Math.max(1, upper - min + 1));
    out.push(pick);
    remaining -= pick;
  }
  return out;
}

/** 红包状态文案 */
function statusText(status) {
  if (status === 'EMPTY') return '已抢光';
  if (status === 'EXPIRED') return '已过期（未领部分已退回）';
  return '可领取';
}

/** 数据库行 → 前端安全结构 */
function toView(row, extra) {
  const total = cents(row.total_amount);
  const claimed = cents(row.claimed_amount);
  const view = {
    id: Number(row.id),
    packet_no: row.packet_no,
    channel: row.channel,
    sender_id: Number(row.sender_id),
    sender_name: row.sender_name || '玩家',
    blessing: row.blessing || '',
    currency_type: row.currency_type,
    asset_text: RP.ASSET_TEXT,
    total_amount: Number(row.total_amount),
    total_count: Number(row.total_count),
    claimed_count: Number(row.claimed_count),
    claimed_amount: Number(row.claimed_amount),
    remaining_count: Math.max(0, Number(row.total_count) - Number(row.claimed_count)),
    remaining_amount: Number(toAmount(Math.max(0, total - claimed))),
    status: row.status,
    status_text: statusText(row.status),
    expired_at: row.expired_at,
    created_at: row.created_at
  };
  return Object.assign(view, extra || {});
}

// ---------- 视图附加信息（能否领取 / 我的领取 / 提示） ----------
function viewExtras(row, userId, myClaim) {
  const uid = Number(userId);
  const isSender = Number(row.sender_id) === uid;
  const expired = new Date(row.expired_at).getTime() <= Date.now();
  let canClaim = true;
  let reason = '';
  if (row.status === 'EMPTY') { canClaim = false; reason = '红包已抢光'; }
  else if (row.status === 'EXPIRED' || expired) { canClaim = false; reason = '红包已过期'; }
  else if (myClaim) { canClaim = false; reason = '您已经抢过这个红包'; }
  else if (isSender && !RP.ALLOW_SENDER_CLAIM) { canClaim = false; reason = '不能抢自己发的红包'; }
  return {
    is_mine_sent: isSender,
    my_claim: myClaim ? { amount: Number(myClaim.amount), created_at: myClaim.created_at } : null,
    can_claim: canClaim,
    can_claim_text: canClaim ? '抢红包' : reason,
    notice: RP.NOTICE
  };
}

/** 红包消息 meta（聊天消息里存快照，前端点击时再拉最新状态） */
function messageMeta(packet) {
  return {
    packet_id: Number(packet.id),
    packet_no: packet.packet_no,
    blessing: packet.blessing || '',
    total_amount: Number(packet.total_amount),
    total_count: Number(packet.total_count),
    currency_type: packet.currency_type,
    status: packet.status
  };
}

// ============================================
// 1. 发红包（先扣发送者现金筹码，再生成红包与聊天消息）
// ============================================
async function createPacket(o) {
  const senderId = Number(o.senderId);
  const channel = String(o.channel || '');
  const amountCents = cents(o.amount);
  const count = Number(o.count);
  const blessing = String(o.blessing === null || o.blessing === undefined ? '' : o.blessing)
    .trim().slice(0, RP.BLESSING_MAX) || '恭喜发财，大吉大利';

  if (RP.CHANNELS.indexOf(channel) === -1) return fail('CHANNEL_NOT_ALLOWED', 400, '该频道暂不支持发红包');
  if (!Number.isFinite(Number(o.amount)) || amountCents < AMOUNT_MIN_CENTS || amountCents > AMOUNT_MAX_CENTS) {
    return fail('INVALID_AMOUNT', 422, '红包金额需在 RM' + RP.MIN_AMOUNT + ' – RM' + RP.MAX_AMOUNT + ' 之间');
  }
  if (!Number.isSafeInteger(count) || count < RP.MIN_COUNT || count > RP.MAX_COUNT) {
    return fail('INVALID_COUNT', 422, '红包个数需在 ' + RP.MIN_COUNT + ' – ' + RP.MAX_COUNT + ' 之间');
  }
  if (count > amountCents) return fail('AMOUNT_TOO_SMALL', 422, '金额太小，不够分成这么多个红包');

  const asset = RP.ASSET;
  const field = asset === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [uRows] = await conn.query(
      `SELECT id, username, ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [senderId]
    );
    const sender = uRows[0];
    if (!sender) { await conn.rollback(); return fail('USER_NOT_FOUND', 404, '用户不存在'); }
    const before = cents(sender.bal);
    if (before < amountCents) {
      await conn.rollback();
      return {
        ok: false, code: 'INSUFFICIENT_BALANCE', status: 409,
        message: '现金筹码不足，无法发出该红包', available: Number(toAmount(before))
      };
    }
    const after = before - amountCents;
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [toAmount(after), senderId]);

    const packetNo = generatePacketNo();
    const [ins] = await conn.query(
      `INSERT INTO chat_red_packets
        (packet_no, channel, sender_id, sender_name, blessing, currency_type, total_amount, total_count, expired_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? HOUR))`,
      [packetNo, channel, senderId, sender.username, blessing, asset, toAmount(amountCents), count, RP.EXPIRE_HOURS]
    );
    const packetId = Number(ins.insertId);

    await conn.query(
      `INSERT INTO balance_transactions
        (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, NULL)`,
      [senderId, asset, '-' + toAmount(amountCents), toAmount(before), toAmount(after),
        RP.TX.SEND, '聊天红包 ' + packetNo]
    );

    const [rows] = await conn.query('SELECT * FROM chat_red_packets WHERE id = ?', [packetId]);
    const meta = messageMeta(rows[0]);
    const [msg] = await conn.query(
      `INSERT INTO chat_messages (channel, user_id, message_type, content, meta)
       VALUES (?, ?, 'redpacket', ?, ?)`,
      [channel, senderId, blessing, JSON.stringify(meta)]
    );
    await conn.query('UPDATE chat_red_packets SET message_id = ? WHERE id = ?', [msg.insertId, packetId]);
    await conn.commit();

    const packetRow = rows[0];
    return {
      ok: true,
      packet: toView(packetRow, viewExtras(packetRow, senderId, null)),
      packet_id: packetId,
      message_id: Number(msg.insertId),
      message_meta: meta,
      balance_before: Number(toAmount(before)),
      balance_after: Number(toAmount(after))
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('发红包失败:', err.message);
    return fail('PACKET_CREATE_FAILED', 500, '红包发送失败，请稍后重试');
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 2. 过期处理（事务内调用）：剩余金额原路退回发送者
// ============================================
async function closeExpired(conn, packet) {
  const totalCents = cents(packet.total_amount);
  const claimedCents = cents(packet.claimed_amount);
  const remaining = totalCents - claimedCents;
  const asset = packet.currency_type === 'GAME_BALANCE' ? 'GAME_BALANCE' : 'CASH_CHIPS';
  const field = asset === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
  const status = (Number(packet.claimed_count) >= Number(packet.total_count) || remaining <= 0) ? 'EMPTY' : 'EXPIRED';

  if (status === 'EXPIRED') {
    const [uRows] = await conn.query(`SELECT ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [packet.sender_id]);
    const before = cents(uRows[0] ? uRows[0].bal : 0);
    const after = before + remaining;
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [toAmount(after), packet.sender_id]);
    await conn.query(
      `INSERT INTO balance_transactions
        (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, NULL)`,
      [packet.sender_id, asset, toAmount(remaining), toAmount(before), toAmount(after),
        RP.TX.REFUND, '聊天红包过期退回 ' + packet.packet_no]
    );
  }
  await conn.query(
    "UPDATE chat_red_packets SET status = ?, closed_at = NOW() WHERE id = ? AND status = 'OPEN'",
    [status, packet.id]
  );
  return status === 'EXPIRED' ? remaining : 0;
}

/**
 * 懒清扫 + 定时任务：把所有已过期但仍 OPEN 的红包结算掉
 * @returns {Promise<{scanned:number, closed:number, refunded:number}>}
 */
async function expirePackets(limit) {
  const n = Math.min(Math.max(Number(limit) || 20, 1), 200);
  let scanned = 0, closed = 0, refundedCents = 0;
  try {
    const [rows] = await db.promise().query(
      "SELECT id FROM chat_red_packets WHERE status = 'OPEN' AND expired_at <= NOW() ORDER BY id ASC LIMIT ?", [n]
    );
    for (const r of rows) {
      scanned++;
      const conn = await db.promise().getConnection();
      try {
        await conn.beginTransaction();
        const [pk] = await conn.query('SELECT * FROM chat_red_packets WHERE id = ? FOR UPDATE', [r.id]);
        if (!pk[0] || pk[0].status !== 'OPEN') { await conn.rollback(); continue; }
        refundedCents += await closeExpired(conn, pk[0]);
        await conn.commit();
        closed++;
      } catch (e) {
        await conn.rollback().catch(() => {});
        console.error('聊天红包过期结算失败:', e.message);
      } finally {
        conn.release();
      }
    }
    return { scanned: scanned, closed: closed, refunded: Number(toAmount(refundedCents)) };
  } catch (err) {
    console.error('聊天红包过期扫描失败:', err.message);
    return { scanned: scanned, closed: closed, refunded: Number(toAmount(refundedCents)) };
  }
}

// ============================================
// 3. 抢红包（事务 + 行锁，绝不超发）
// ============================================
async function claim(o) {
  const packetId = Number(o.packetId);
  const userId = Number(o.userId);
  const asset = RP.ASSET;
  const field = asset === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT * FROM chat_red_packets WHERE id = ? FOR UPDATE', [packetId]);
    const packet = rows[0];
    if (!packet) { await conn.rollback(); return fail('PACKET_NOT_FOUND', 404, '红包不存在'); }

    // 已过期：同一事务内把剩余金额退回发送者后再返回
    if (packet.status === 'OPEN' && new Date(packet.expired_at).getTime() <= Date.now()) {
      const refund = await closeExpired(conn, packet);
      await conn.commit();
      return {
        ok: false, code: 'PACKET_EXPIRED', status: 409,
        message: '红包已过期' + (refund > 0 ? '，未领取部分已退回发送者' : ''),
        refunded: Number(toAmount(refund))
      };
    }
    if (packet.status !== 'OPEN') {
      await conn.rollback();
      return fail('PACKET_CLOSED', 409, packet.status === 'EMPTY' ? '红包已抢光' : '红包已过期');
    }
    if (Number(packet.sender_id) === userId && !RP.ALLOW_SENDER_CLAIM) {
      await conn.rollback();
      return fail('CANNOT_CLAIM_OWN', 403, '不能抢自己发的红包');
    }
    const [mine] = await conn.query(
      'SELECT id, amount FROM chat_red_packet_claims WHERE packet_id = ? AND user_id = ? LIMIT 1', [packetId, userId]
    );
    if (mine.length) {
      await conn.rollback();
      return {
        ok: false, code: 'ALREADY_CLAIMED', status: 409,
        message: '您已经抢过这个红包', amount: Number(mine[0].amount)
      };
    }

    const totalCents = cents(packet.total_amount);
    const claimedCents = cents(packet.claimed_amount);
    const remaining = totalCents - claimedCents;
    const leftCount = Number(packet.total_count) - Number(packet.claimed_count);
    if (leftCount <= 0 || remaining <= 0) {
      await conn.rollback();
      return fail('PACKET_EMPTY', 409, '红包已抢光');
    }
    // 最后一份拿走全部剩余，保证不会超发
    let pick;
    if (leftCount === 1) {
      pick = remaining;
    } else {
      const avg = Math.floor(remaining / leftCount);
      const upper = Math.max(1, Math.min(avg * 2, remaining - (leftCount - 1)));
      pick = 1 + crypto.randomInt(Math.max(1, upper));
    }

    const [uRows] = await conn.query(`SELECT id, ${field} AS bal FROM users WHERE id = ? FOR UPDATE`, [userId]);
    if (!uRows[0]) { await conn.rollback(); return fail('USER_NOT_FOUND', 404, '用户不存在'); }
    const before = cents(uRows[0].bal);
    const after = before + pick;
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [toAmount(after), userId]);
    await conn.query(
      `INSERT INTO balance_transactions
        (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, NULL)`,
      [userId, asset, toAmount(pick), toAmount(before), toAmount(after), RP.TX.CLAIM, '抢到聊天红包 ' + packet.packet_no]
    );
    await conn.query(
      'INSERT INTO chat_red_packet_claims (packet_id, user_id, amount) VALUES (?, ?, ?)',
      [packetId, userId, toAmount(pick)]
    );

    const newCount = Number(packet.claimed_count) + 1;
    const newClaimed = claimedCents + pick;
    const finished = newCount >= Number(packet.total_count) || newClaimed >= totalCents;
    await conn.query(
      'UPDATE chat_red_packets SET claimed_count = ?, claimed_amount = ?, status = ?, closed_at = ? WHERE id = ?',
      [newCount, toAmount(newClaimed), finished ? 'EMPTY' : 'OPEN', finished ? new Date() : null, packetId]
    );
    const [fresh] = await conn.query('SELECT * FROM chat_red_packets WHERE id = ?', [packetId]);
    await conn.commit();

    return {
      ok: true,
      amount: Number(toAmount(pick)),
      balance_before: Number(toAmount(before)),
      balance_after: Number(toAmount(after)),
      finished: finished,
      sender_id: Number(packet.sender_id),
      sender_name: packet.sender_name || '玩家',
      packet: toView(fresh[0], viewExtras(fresh[0], userId, { amount: toAmount(pick) }))
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    // 唯一键冲突 = 并发重复领取：按业务错误返回，绝不重复加余额
    if (err && (err.code === 'ER_DUP_ENTRY' || err.errno === 1062)) {
      return fail('ALREADY_CLAIMED', 409, '您已经抢过这个红包');
    }
    console.error('抢红包失败:', err.message);
    return fail('PACKET_CLAIM_FAILED', 500, '抢红包失败，请稍后重试');
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 4. 红包详情（前端点击红包时读取最新状态）
// ============================================
async function getPacket(userId, packetId) {
  const id = Number(packetId);
  if (!Number.isSafeInteger(id) || id <= 0) return fail('INVALID_PACKET_ID', 422, '无效的红包ID');
  try {
    let [rows] = await db.promise().query('SELECT * FROM chat_red_packets WHERE id = ?', [id]);
    if (!rows[0]) return fail('PACKET_NOT_FOUND', 404, '红包不存在');

    // 打开详情时顺手补一次过期结算（懒清扫，避免依赖定时任务）
    if (rows[0].status === 'OPEN' && new Date(rows[0].expired_at).getTime() <= Date.now()) {
      await expirePackets(1);
      [rows] = await db.promise().query('SELECT * FROM chat_red_packets WHERE id = ?', [id]);
    }
    const packet = rows[0];

    const [claimRows] = await db.promise().query(
      `SELECT c.user_id, c.amount, c.created_at, u.username, u.nickname
       FROM chat_red_packet_claims c LEFT JOIN users u ON u.id = c.user_id
       WHERE c.packet_id = ? ORDER BY c.id ASC LIMIT ?`, [id, RP.CLAIM_LIST_LIMIT]
    );
    const mineRow = claimRows.find(c => Number(c.user_id) === Number(userId)) || null;
    const claims = claimRows.map(c => ({
      username: c.nickname || c.username || '玩家',
      amount: Number(c.amount),
      is_mine: Number(c.user_id) === Number(userId),
      created_at: c.created_at
    }));
    let best = null;
    claimRows.forEach(c => {
      if (!best || Number(c.amount) > Number(best.amount)) best = c;
    });

    const [cnt] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM chat_red_packet_claims WHERE packet_id = ?', [id]
    );
    const extra = viewExtras(packet, userId, mineRow);
    extra.claims = claims;
    extra.claims_total = Number(cnt[0] && cnt[0].c) || 0;
    extra.best = best ? { username: best.nickname || best.username || '玩家', amount: Number(best.amount) } : null;

    return { ok: true, packet: toView(packet, extra) };
  } catch (err) {
    console.error('读取红包详情失败:', err.message);
    return fail('PACKET_READ_FAILED', 500, '红包详情加载失败，请稍后重试');
  }
}

module.exports = {
  splitAmounts, generatePacketNo, toView, viewExtras, messageMeta, statusText,
  cents, toAmount, parseJson, fail, AMOUNT_MIN_CENTS, AMOUNT_MAX_CENTS,
  createPacket, claim, getPacket, expirePackets
};
