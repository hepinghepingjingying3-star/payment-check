'use strict';
// ============================================
// 26牛牛 - 页面会话票据（HttpOnly Cookie）
// 存在原因:
//   - 浏览器地址栏访问 / <a> 跳转无法携带 Authorization 头，管理后台页面如果只靠
//     前端 JS 判断角色，就会出现「普通用户也能打开后台外壳」的问题。
//   - 登录成功时下发一个 HttpOnly Cookie 承载同一份登录 JWT，只给「管理页面准入」
//     中间件读取；所有 /api/** 依然只认 Bearer JWT，绝不读取 Cookie。
// 安全:
//   - HttpOnly：页面 JS 读不到；SameSite=Lax：跨站请求不会带上
//   - secure 按请求自动判定（HTTPS 才标记），可用 COOKIE_SECURE=1 / =0 强制
//   - 退出登录调用 POST /api/auth/logout 立即清除
//   - Cookie 不参与任何 API 认证，因此不会带来数据层的 CSRF 风险
// ============================================

const COOKIE_NAME = 'nn_page';
const DEFAULT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

/** 与 JWT_EXPIRES_IN 对齐的 Cookie 有效期（支持 30s / 15m / 12h / 7d） */
function maxAgeMs() {
  const raw = String(process.env.JWT_EXPIRES_IN || '7d').trim();
  const m = /^(\d+)\s*([dhms])?$/i.exec(raw);
  if (!m) return DEFAULT_MAX_AGE_MS;
  const factor = { d: 86400000, h: 3600000, m: 60000, s: 1000 }[(m[2] || 's').toLowerCase()];
  const ms = Number(m[1]) * factor;
  return Number.isSafeInteger(ms) && ms > 0 ? ms : DEFAULT_MAX_AGE_MS;
}

/** 读取请求 Cookie（不引入 cookie-parser 依赖） */
function readCookie(req, name) {
  const header = req && req.headers ? req.headers.cookie : '';
  if (typeof header !== 'string' || !header) return '';
  const parts = header.split(';');
  for (let i = 0; i < parts.length; i++) {
    const idx = parts[i].indexOf('=');
    if (idx < 0) continue;
    if (parts[i].slice(0, idx).trim() === name) {
      try { return decodeURIComponent(parts[i].slice(idx + 1).trim()); } catch (_) { return ''; }
    }
  }
  return '';
}

function isSecure(req) {
  if (process.env.COOKIE_SECURE === '1') return true;
  if (process.env.COOKIE_SECURE === '0') return false;
  return !!(req && (req.secure || (req.headers && req.headers['x-forwarded-proto'] === 'https')));
}

function cookieOptions(req) {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: isSecure(req),
    path: '/',
    maxAge: maxAgeMs()
  };
}

/** 登录成功后下发页面票据 */
function setPageSession(res, token, req) {
  if (!token) return;
  res.cookie(COOKIE_NAME, token, cookieOptions(req || res.req));
}

/** 退出登录时清除页面票据 */
function clearPageSession(res, req) {
  const options = cookieOptions(req || res.req);
  delete options.maxAge;
  res.clearCookie(COOKIE_NAME, options);
}

/** 中间件读取页面票据（只接受 JWT 形态字符串） */
function readPageToken(req) {
  const value = readCookie(req, COOKIE_NAME);
  return /^[A-Za-z0-9._-]{20,4096}$/.test(value) ? value : '';
}

module.exports = { COOKIE_NAME, setPageSession, clearPageSession, readPageToken, maxAgeMs };
