'use strict';
// ============================================
// 26牛牛 - 6位数字支付密码（工具）
// ============================================
// 安全:
//   - 只存 bcrypt 哈希（users.pay_password_hash），绝不存明文
//   - 不写日志、不返回给前端、不出现在任何 API response
//   - 校验失败统一提示，不泄露「是否已设置」以外的信息
// ============================================

const bcrypt = require('bcryptjs');
const db = require('../config/db');

const PATTERN = /^\d{6}$/;

/** 格式校验（6位纯数字），返回中文错误或 null */
function validateFormat(raw) {
  const s = String(raw === null || raw === undefined ? '' : raw);
  if (!PATTERN.test(s)) return '支付密码必须为6位数字';
  return null;
}

/** 设置支付密码（写入 bcrypt 哈希） */
async function setPayPassword(userId, raw) {
  const fmtErr = validateFormat(raw);
  if (fmtErr) throw new Error(fmtErr);
  const hash = await bcrypt.hash(String(raw), 10);
  await db.promise().query(
    'UPDATE users SET pay_password_hash = ?, pay_password_set_at = NOW() WHERE id = ? LIMIT 1',
    [hash, userId]
  );
  return true;
}

/**
 * 校验支付密码
 * @returns {Promise<{ok:boolean, message?:string}>}
 */
async function verifyPayPassword(userId, raw) {
  const fmtErr = validateFormat(raw);
  if (fmtErr) return { ok: false, message: fmtErr };
  const [rows] = await db.promise().query(
    'SELECT pay_password_hash FROM users WHERE id = ? LIMIT 1',
    [userId]
  );
  const hash = rows[0] && rows[0].pay_password_hash;
  if (!hash) return { ok: false, message: '请先设置6位支付密码' };
  const match = await bcrypt.compare(String(raw), hash);
  if (!match) return { ok: false, message: '支付密码错误' };
  return { ok: true };
}

module.exports = { validateFormat, setPayPassword, verifyPayPassword };
