'use strict';
// ============================================
// 26牛牛 - 统一余额账本（ledger）
// ============================================
// 规则:
//   - 所有余额变化必须经 applyBalance()：事务内行锁 + 前后余额 + 写 balance_transactions
//   - 绝不出现负余额；金额必须是安全的正数（两位小数）
//   - 前端永远不能直接改余额：只有服务端计算后写入
//   - reference_no 记录业务引用号（充值订单号 / 转账号 / 提现单号），便于对账与幂等排查
// ============================================

const db = require('../config/db');
const CHIPS = require('../config/cashChips');

/** 金额安全解析：返回两位小数的正数，非法返回 null */
function parseAmount(raw, min, max) {
  if (raw === null || raw === undefined || typeof raw === 'object') return null;
  const s = String(raw).trim();
  if (!s || !/^\d{1,9}(\.\d{1,2})?$/.test(s)) return null;
  const n = Number(s);
  if (!Number.isFinite(n)) return null;
  const v = Number(n.toFixed(2));
  if (v < (min === undefined ? 0.01 : min)) return null;
  if (max !== undefined && v > max) return null;
  return v;
}

/**
 * 事务内变更余额并写入流水
 * @param {object} conn 事务连接（必须已在事务中）
 * @param {object} o { userId, delta(正=增加/负=减少), type, reason, referenceNo, operatorId, currencyType, relatedRequestId }
 * @returns {{balance_before:number, balance_after:number, ledger_id:number}}
 */
async function applyBalance(conn, o) {
  const currencyType = o.currencyType || CHIPS.ASSET;            // 默认现金筹码
  const delta = Number(Number(o.delta).toFixed(2));
  if (!Number.isFinite(delta) || delta === 0) throw new Error('INVALID_AMOUNT');

  // 资产 → 字段映射（GAME_POINTS = 26牛牛娱乐场游戏积分：不可充值 / 不可提现 / 不可转账）
  const ASSET_FIELD = {
    CASH_CHIPS: 'cash_chips',
    GAME_BALANCE: 'game_balance',
    GAME_POINTS: 'game_points'
  };
  const field = ASSET_FIELD[currencyType];
  if (!field) throw new Error('UNSUPPORTED_CURRENCY');
  const [rows] = await conn.query('SELECT id, cash_chips, game_balance, game_points FROM users WHERE id = ? FOR UPDATE', [o.userId]);
  if (!rows[0]) throw new Error('USER_NOT_FOUND');

  const before = Number(rows[0][field] || 0);
  const after = Number((before + delta).toFixed(2));
  if (after < 0) throw new Error('INSUFFICIENT_BALANCE');       // 绝不允许负余额

  await conn.query('UPDATE users SET ' + field + ' = ? WHERE id = ?', [after.toFixed(2), o.userId]);
  const [ins] = await conn.query(
    'INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason, reference_no, operator_id, related_request_id) ' +
    'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [o.userId, currencyType, delta.toFixed(2), before.toFixed(2), after.toFixed(2),
      String(o.type || 'ADJUSTMENT').slice(0, 30), o.reason ? String(o.reason).slice(0, 255) : null,
      o.referenceNo ? String(o.referenceNo).slice(0, 64) : null,
      o.operatorId || null, o.relatedRequestId || null]
  );
  return { balance_before: before, balance_after: after, ledger_id: Number(ins.insertId) };
}

/** 当日已转出现金筹码合计（用于单日转账上限校验） */
async function todayTransferred(userId, runner) {
  const query = runner || db.promise();
  const [rows] = await query.query(
    "SELECT COALESCE(SUM(amount),0) AS total FROM cash_transfers WHERE from_user_id = ? AND created_at >= CURDATE() AND created_at < CURDATE() + INTERVAL 1 DAY",
    [userId]
  );
  return Number((rows[0] && rows[0].total) || 0);
}

module.exports = { parseAmount, applyBalance, todayTransferred };
