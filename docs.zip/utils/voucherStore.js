// ============================================
// 26牛牛 - 凭证文件存储（非公开目录）
// ============================================
// 设计:
//   - 文件保存在项目根目录 storage/ 下（不在 public 内），不能被静态目录直接访问
//   - 文件名由服务器生成（随机 UUID + 由真实类型推导的扩展名），用户无法控制
//   - 读取时必须校验路径落在 storage 根目录内，防止路径穿越
//   - 只负责「存 / 取 / 删」，不做类型判定（由 utils/imageCheck 负责）
// ============================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const STORAGE_ROOT = path.join(__dirname, '..', 'storage');
const VOUCHER_DIR = path.join(STORAGE_ROOT, 'vouchers');

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

/**
 * 保存凭证
 * @param {Buffer} buffer 文件内容
 * @param {string} ext 服务器推导的扩展名（jpg/png/webp）
 * @param {number} userId 归属用户（仅用于目录隔离，不参与文件名信任）
 * @returns {string} 相对 storage 根的路径，如 'vouchers/12/xxxx.jpg'
 */
function saveVoucher(buffer, ext, userId) {
  const dir = path.join(VOUCHER_DIR, String(Number(userId) || 0));
  ensureDir(dir);
  const name = crypto.randomUUID() + '.' + ext;
  fs.writeFileSync(path.join(dir, name), buffer, { mode: 0o600 });
  return 'vouchers/' + (Number(userId) || 0) + '/' + name;
}

/** 相对路径 → 绝对路径（越界/非法一律返回 null） */
function resolveVoucher(relPath) {
  const s = String(relPath || '');
  if (!s || s.indexOf('\0') >= 0 || s.indexOf('..') >= 0) return null;
  if (!/^vouchers\/[0-9]+\/[a-f0-9-]{36}\.(jpg|png|webp)$/i.test(s)) return null;
  const abs = path.resolve(STORAGE_ROOT, s);
  if (abs !== STORAGE_ROOT && !abs.startsWith(STORAGE_ROOT + path.sep)) return null;
  return abs;
}

/** 文件是否存在 */
function voucherExists(relPath) {
  const abs = resolveVoucher(relPath);
  return Boolean(abs && fs.existsSync(abs));
}

module.exports = { STORAGE_ROOT, VOUCHER_DIR, saveVoucher, resolveVoucher, voucherExists };
