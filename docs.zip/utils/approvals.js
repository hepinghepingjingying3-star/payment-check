'use strict';
// ============================================
// 26牛牛 - 后台高风险动作「双人复核」
// ============================================
// 规则:
//   - 需要复核的动作见 config/moderation.js → DUAL_APPROVAL.ACTIONS
//   - 申请人提交 → PENDING（不立即生效）→ 另一名管理员通过后才真正执行
//   - 不能复核自己提交的请求；不能重复复核（原子占用，只有一人能通过）
//   - 系统仅剩一名活跃管理员时按配置降级为单人执行，并在审计中标注，避免后台被锁死
//   - 表不存在 / 功能关闭时保守降级为单人执行，不阻断后台可用性
//   - 复核全过程写 admin_logs 审计（admin_approval_request / approve / reject）
// ============================================

const db = require('../config/db');
const MOD = require('../config/moderation');
const { writeAdminLog } = require('./adminAudit');
const ops = require('./userAdminOps');

const DUAL = MOD.DUAL_APPROVAL;
const ACTION_LABEL = {
  user_status: '账号状态变更（封禁 / 解封）',
  user_role: '管理员权限变更',
  user_unmute: '解除禁言'
};
const EXECUTORS = {
  user_status: ops.applyUserStatus,
  user_role: ops.applyUserRole,
  user_unmute: ops.applyUnmute
};

let tableMissing = false;

function label(action) { return ACTION_LABEL[action] || action; }
function isDualAction(action) { return DUAL.ACTIONS.indexOf(action) >= 0; }
function available() { return !tableMissing; }
function actions() { return DUAL.ACTIONS.slice(); }
function actionLabels() {
  return DUAL.ACTIONS.map(function (a) { return { action: a, label: label(a) }; });
}
function parsePayload(raw) {
  if (!raw) return {};
  if (typeof raw === 'object') return raw;
  try { return JSON.parse(String(raw)); } catch (e) { return {}; }
}
function isMissingTableError(err) {
  return !!err && (err.code === 'ER_NO_SUCH_TABLE' || err.errno === 1146);
}

/** 除本人外的活跃管理员数量 */
async function otherActiveAdminCount(adminId) {
  const [rows] = await db.promise().query(
    "SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND status = 'active' AND id <> ?",
    [Number(adminId)]
  );
  return Number(rows[0] && rows[0].c) || 0;
}

/**
 * 判断某动作是否需要走双人复核
 * @returns {Promise<{dual:boolean, degraded:boolean, note:string|null, other_admins:number}>}
 */
async function gate(action, adminId) {
  if (!DUAL.ENABLED || tableMissing || !isDualAction(action)) {
    return { dual: false, degraded: false, note: null, other_admins: 0 };
  }
  const others = await otherActiveAdminCount(adminId);
  if (others > 0) return { dual: true, degraded: false, note: null, other_admins: others };
  if (DUAL.DEGRADE_WHEN_SINGLE_ADMIN) {
    return {
      dual: false, degraded: true, other_admins: 0,
      note: '系统仅剩一名活跃管理员，双人复核已自动降级为单人执行（审计已标注）'
    };
  }
  return { dual: true, degraded: false, other_admins: 0, note: '当前没有其他活跃管理员可以复核，请求将被挂起' };
}

/** 除指定用户外的活跃管理员数量 */
async function otherActiveAdminCountExcept(userId) {
  const [rows] = await db.promise().query(
    "SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND status = 'active' AND id <> ?",
    [Number(userId)]
  );
  return Number(rows[0] && rows[0].c) || 0;
}

/**
 * 提交复核前的只读预校验
 * 目的: 让「必然失败」的请求直接在提交时返回 4xx（权限/参数/状态类错误），
 *       只有真正合法、待人工判断的请求才进入复核队列，避免管理员误以为已提交成功。
 * @returns {Promise<{ok:boolean, code?:string, status?:number, message?:string}>}
 */
async function preflight(action, o) {
  o = o || {};
  const userId = Number(o.targetUserId);
  const adminId = Number(o.adminId);
  const payload = o.payload || {};
  const [rows] = await db.promise().query(
    'SELECT id, username, role, status, muted_until FROM users WHERE id = ? LIMIT 1', [userId]
  );
  const user = rows[0];
  if (!user) return { ok: false, code: 'USER_NOT_FOUND', status: 404, message: '用户不存在' };
  if (user.status === 'deleted') {
    return { ok: false, code: 'USER_DELETED', status: 409, message: '该账号已注销，无法执行该操作' };
  }

  if (action === 'user_status') {
    if (payload.status !== 'active' && payload.status !== 'banned') {
      return { ok: false, code: 'INVALID_STATUS', status: 422, message: '状态只能是 active 或 banned' };
    }
    if (userId === adminId) {
      return { ok: false, code: 'SELF_CHANGE_FORBIDDEN', status: 403, message: '不能修改自己的账号状态' };
    }
    if (payload.status === 'banned' && user.role === 'admin') {
      return { ok: false, code: 'ADMIN_TARGET_FORBIDDEN', status: 403, message: '管理员账号不能被封禁，请先取消其管理员权限' };
    }
    if (user.status === payload.status) {
      return { ok: false, code: 'STATUS_UNCHANGED', status: 409, message: '账号已经是该状态' };
    }
  } else if (action === 'user_role') {
    if (payload.role !== 'admin' && payload.role !== 'user') {
      return { ok: false, code: 'INVALID_ROLE', status: 422, message: '角色只能是 admin 或 user' };
    }
    if (userId === adminId) {
      return { ok: false, code: 'SELF_CHANGE_FORBIDDEN', status: 403, message: '不能修改自己的角色' };
    }
    if (user.role === payload.role) {
      return { ok: false, code: 'ROLE_UNCHANGED', status: 409, message: '账号已经是该角色' };
    }
    if (user.role === 'admin') {
      const others = await otherActiveAdminCountExcept(userId);
      if (others === 0) {
        return { ok: false, code: 'LAST_ADMIN', status: 409, message: '系统至少需要保留一个活跃管理员，无法取消最后一个管理员' };
      }
    }
  } else if (action === 'user_unmute') {
    if (!user.muted_until) {
      return { ok: false, code: 'NOT_MUTED', status: 409, message: '该账号当前未被禁言' };
    }
  } else {
    return { ok: false, code: 'ACTION_NOT_SUPPORTED', status: 422, message: '该动作不支持双人复核' };
  }
  return { ok: true };
}

/** 创建复核请求（不执行任何业务变更） */
async function createRequest(o) {
  const action = String(o.action || '');
  const adminId = Number(o.adminId);
  const targetUserId = Number(o.targetUserId);
  const reason = String(o.reason || '').trim().slice(0, 255);
  if (!isDualAction(action)) return { ok: false, code: 'ACTION_NOT_REVIEWABLE', status: 422, message: '该动作不需要双人复核' };
  if (reason.length < 2) return { ok: false, code: 'REASON_REQUIRED', status: 422, message: '请填写申请原因（至少 2 个字）' };
  try {
    const [cnt] = await db.promise().query(
      "SELECT COUNT(*) AS c FROM admin_approvals WHERE requested_by = ? AND status = 'PENDING'", [adminId]
    );
    if ((Number(cnt[0] && cnt[0].c) || 0) >= DUAL.MAX_PENDING_PER_ADMIN) {
      return {
        ok: false, code: 'TOO_MANY_PENDING', status: 429,
        message: '您有太多待复核请求（上限 ' + DUAL.MAX_PENDING_PER_ADMIN + ' 条），请等待其他管理员处理'
      };
    }
    const [ins] = await db.promise().query(
      `INSERT INTO admin_approvals (action, target_type, target_user_id, payload, reason, status, requested_by, requested_at)
       VALUES (?, 'user', ?, ?, ?, 'PENDING', ?, NOW())`,
      [action, targetUserId || null, JSON.stringify(o.payload || {}), reason, adminId]
    );
    await writeAdminLog({
      adminId: adminId, targetUserId: targetUserId || null, action: 'admin_approval_request',
      detail: 'approval=' + ins.insertId + ' action=' + action + ' reason=' + reason
    });
    return { ok: true, request: await findRequest(ins.insertId, adminId) };
  } catch (err) {
    if (isMissingTableError(err)) {
      tableMissing = true;
      console.error('admin_approvals 不存在，双人复核已降级为单人执行；请运行 node database/migrations/006-presence-approval.js');
      return { ok: false, code: 'APPROVAL_UNAVAILABLE', status: 503, message: '双人复核表不可用，已降级为单人执行' };
    }
    console.error('创建复核请求失败:', err.message);
    return { ok: false, code: 'APPROVAL_CREATE_FAILED', status: 500, message: '复核请求创建失败，请稍后重试' };
  }
}

/** 单条请求 → 前端结构 */
function toView(r, viewerId) {
  return {
    id: Number(r.id),
    action: r.action,
    action_label: label(r.action),
    target_user_id: r.target_user_id ? Number(r.target_user_id) : null,
    target_username: r.target_username || null,
    target_nickname: r.target_nickname || null,
    payload: parsePayload(r.payload),
    reason: r.reason || null,
    status: r.status,
    requested_by: { id: Number(r.requested_by), username: r.requester_username || null },
    requested_at: r.requested_at,
    reviewed_by: r.reviewed_by ? { id: Number(r.reviewed_by), username: r.reviewer_username || null } : null,
    reviewed_at: r.reviewed_at || null,
    review_note: r.review_note || null,
    apply_result: r.apply_result || null,
    // 只能复核别人提交的、仍在待处理的请求
    can_review: r.status === 'PENDING' && Number(r.requested_by) !== Number(viewerId)
  };
}

const SELECT_APPROVAL =
  `SELECT a.*, rq.username AS requester_username, rv.username AS reviewer_username,
          tu.username AS target_username, tu.nickname AS target_nickname
   FROM admin_approvals a
   LEFT JOIN users rq ON rq.id = a.requested_by
   LEFT JOIN users rv ON rv.id = a.reviewed_by
   LEFT JOIN users tu ON tu.id = a.target_user_id`;

/** 读取单条请求（viewerId 用于计算 can_review） */
async function findRequest(id, viewerId) {
  try {
    const [rows] = await db.promise().query(SELECT_APPROVAL + ' WHERE a.id = ?', [Number(id)]);
    return rows[0] ? toView(rows[0], viewerId) : null;
  } catch (err) {
    if (isMissingTableError(err)) { tableMissing = true; return null; }
    throw err;
  }
}

/** 复核列表 + 各状态计数 */
async function listRequests(o) {
  o = o || {};
  const limit = Math.min(Math.max(parseInt(o.limit, 10) || 20, 1), 100);
  const offset = Math.max(parseInt(o.offset, 10) || 0, 0);
  const status = String(o.status || '').toUpperCase();
  const where = (status === 'PENDING' || status === 'APPROVED' || status === 'REJECTED') ? 'WHERE a.status = ?' : '';
  const params = where ? [status] : [];
  try {
    const [rows] = await db.promise().query(
      SELECT_APPROVAL + ` ${where} ORDER BY a.id DESC LIMIT ? OFFSET ?`, params.concat([limit, offset])
    );
    const [cnt] = await db.promise().query('SELECT status, COUNT(*) AS c FROM admin_approvals GROUP BY status');
    const summary = { pending: 0, approved: 0, rejected: 0, total: 0 };
    cnt.forEach(r => {
      const key = String(r.status).toLowerCase();
      if (key in summary) summary[key] = Number(r.c) || 0;
      summary.total += Number(r.c) || 0;
    });
    return {
      list: rows.map(r => toView(r, o.viewerId)),
      summary: summary, limit: limit, offset: offset, status: status || null,
      action_labels: actionLabels(), enabled: DUAL.ENABLED && !tableMissing
    };
  } catch (err) {
    if (isMissingTableError(err)) {
      tableMissing = true;
      return {
        list: [], summary: { pending: 0, approved: 0, rejected: 0, total: 0 },
        limit: limit, offset: offset, status: status || null, action_labels: actionLabels(), enabled: false
      };
    }
    throw err;
  }
}

/** 待复核数量（后台概览用；不可用时返回 null） */
async function pendingCount() {
  if (tableMissing) return null;
  try {
    const [rows] = await db.promise().query("SELECT COUNT(*) AS c FROM admin_approvals WHERE status = 'PENDING'");
    return Number(rows[0] && rows[0].c) || 0;
  } catch (err) {
    if (isMissingTableError(err)) { tableMissing = true; return null; }
    return null;
  }
}

// ============================================
// 复核决议（批准 → 执行；拒绝 → 关闭）
// ============================================
async function decide(o) {
  const id = Number(o.id);
  const adminId = Number(o.adminId);
  const approve = o.decision === 'approve';
  const note = String(o.note || '').trim().slice(0, 255);
  if (!approve && note.length < 2) {
    return { ok: false, code: 'REASON_REQUIRED', status: 422, message: '拒绝必须填写原因' };
  }

  try {
    if (!approve) {
      const [r] = await db.promise().query(
        `UPDATE admin_approvals SET status = 'REJECTED', reviewed_by = ?, reviewed_at = NOW(), review_note = ?
         WHERE id = ? AND status = 'PENDING' AND requested_by <> ?`,
        [adminId, note, id, adminId]
      );
      if (!r || Number(r.affectedRows) !== 1) return await diagnose(id, adminId);
      const row = await findRequest(id, adminId);
      await writeAdminLog({
        adminId: adminId, targetUserId: row ? row.target_user_id : null, action: 'admin_approval_reject',
        detail: 'approval=' + id + '; note=' + note
      });
      return { ok: true, decision: 'REJECTED', approval: row };
    }

    // 批准：先用一条原子 UPDATE 占用请求，保证并发下只有一名复核人能执行
    const [claim] = await db.promise().query(
      `UPDATE admin_approvals
       SET status = 'APPROVED', reviewed_by = ?, reviewed_at = NOW(), review_note = ?, apply_result = '执行中'
       WHERE id = ? AND status = 'PENDING' AND requested_by <> ?`,
      [adminId, note || null, id, adminId]
    );
    if (!claim || Number(claim.affectedRows) !== 1) return await diagnose(id, adminId);

    const [rows] = await db.promise().query('SELECT * FROM admin_approvals WHERE id = ?', [id]);
    const row = rows[0];
    const executor = row ? EXECUTORS[row.action] : null;
    if (!executor) {
      await revertToPending(id, '不支持的动作：' + (row ? row.action : id));
      return {
        ok: false, code: 'ACTION_NOT_SUPPORTED', status: 422,
        message: '该复核请求的动作不受支持，已退回待复核', reverted: true
      };
    }

    const payload = parsePayload(row.payload);
    const res = await executor(Object.assign({}, payload, {
      adminId: adminId, userId: row.target_user_id, requestedBy: row.requested_by
    }));

    if (!res.ok) {
      // 执行失败（如目标状态已变化）：退回待复核，绝不留下「已通过但未生效」的假状态
      await revertToPending(id, '执行失败：' + (res.message || res.code || '未知原因'));
      return {
        ok: false, code: res.code || 'APPLY_FAILED', status: res.status || 409,
        message: '复核已通过，但执行失败：' + (res.message || '未知原因'), reverted: true,
        approval: await findRequest(id, adminId)
      };
    }

    const summary = ('action=' + row.action + ' target=' + row.target_user_id +
      '; requested_by=' + row.requested_by + '; approved_by=' + adminId).slice(0, 255);
    await db.promise().query('UPDATE admin_approvals SET apply_result = ? WHERE id = ?', [summary, id]);
    await writeAdminLog({
      adminId: adminId, targetUserId: row.target_user_id, action: 'admin_approval_approve',
      detail: 'approval=' + id + '; ' + summary
    });
    return { ok: true, decision: 'APPROVED', result: res.data, approval: await findRequest(id, adminId) };
  } catch (err) {
    console.error('复核决议失败:', err.message);
    return { ok: false, code: 'APPROVAL_DECIDE_FAILED', status: 500, message: '复核处理失败，请稍后重试' };
  }
}

/** 执行失败时把请求退回待复核（保留失败原因便于排查） */
async function revertToPending(id, note) {
  try {
    await db.promise().query(
      `UPDATE admin_approvals SET status = 'PENDING', reviewed_by = NULL, reviewed_at = NULL, apply_result = ?
       WHERE id = ? AND status = 'APPROVED'`,
      [String(note || '').slice(0, 255), id]
    );
  } catch (e) {
    console.error('退回待复核失败:', e.message);
  }
}

/** 占用/更新失败时的准确原因 */
async function diagnose(id, adminId) {
  const [rows] = await db.promise().query('SELECT id, status, requested_by FROM admin_approvals WHERE id = ?', [id]);
  const row = rows[0];
  if (!row) return { ok: false, code: 'APPROVAL_NOT_FOUND', status: 404, message: '复核请求不存在' };
  if (Number(row.requested_by) === adminId) {
    return { ok: false, code: 'SELF_REVIEW_FORBIDDEN', status: 403, message: '不能复核自己提交的请求，请由另一名管理员处理' };
  }
  return { ok: false, code: 'ALREADY_DECIDED', status: 409, message: '该复核请求已被处理（当前状态 ' + row.status + '）' };
}

module.exports = {
  gate, createRequest, listRequests, findRequest, pendingCount, decide, preflight,
  available, actions, actionLabels, otherActiveAdminCount, otherActiveAdminCountExcept, label
};
