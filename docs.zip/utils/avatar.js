'use strict';
// ============================================
// 26牛牛 - 官方头像解析
// 规则:
//   - 用户不能上传头像，也不能提交头像链接；唯一来源是后台「头像管理」发布的头像
//   - 真源是 users.avatar_id → avatars.image_path
//   - users.avatar_url 仅作为服务端计算的展示缓存（聊天等旧页面读取），不接受用户写入
//   - 没有任何头像时统一回退到官方默认头像，不会出现空白或占位 emoji
// ============================================

const db = require('../config/db');

/** 官方默认头像（public/assets/avatars/official.jpg） */
const DEFAULT_AVATAR = '/assets/avatars/official.jpg';

/** 统一成站内绝对路径；只接受站内相对路径，绝不接受外部 URL */
function toPublicPath(p) {
  const s = String(p == null ? '' : p).trim();
  if (!s) return '';
  if (/^[a-z][a-z0-9+.-]*:/i.test(s) || s.slice(0, 2) === '//') return '';
  let out = s.replace(/\\/g, '/');
  if (out.slice(0, 7) === 'public/') out = out.slice(6);
  if (out.charAt(0) !== '/') out = '/' + out;
  return out.replace(/\/{2,}/g, '/');
}

/** 头像在列表/聊天里的最小公开结构 */
function publicAvatar(row) {
  const path = toPublicPath(row && row.image_path);
  return {
    avatar_id: row && row.avatar_id ? Number(row.avatar_id) : null,
    avatar_url: path || DEFAULT_AVATAR,
    avatar_name: (row && row.avatar_name) || null,
    avatar_source: path ? 'library' : 'default'
  };
}

/**
 * 读取某个用户当前头像（带官方默认头像回退）
 * 异常时不抛错，直接回退默认头像，避免影响页面渲染
 */
async function getAvatarForUser(userId) {
  const id = Number(userId);
  if (!Number.isSafeInteger(id) || id <= 0) {
    return { avatar_id: null, avatar_url: DEFAULT_AVATAR, avatar_name: null, avatar_source: 'default' };
  }
  try {
    const [rows] = await db.promise().query(
      'SELECT u.avatar_id, a.image_path, a.name AS avatar_name, a.is_active ' +
      'FROM users u LEFT JOIN avatars a ON a.id = u.avatar_id WHERE u.id = ? LIMIT 1',
      [id]
    );
    const row = rows[0];
    if (!row) return { avatar_id: null, avatar_url: DEFAULT_AVATAR, avatar_name: null, avatar_source: 'default' };
    return publicAvatar(row);
  } catch (e) {
    console.error('[avatar] 解析用户头像失败:', e.message);
    return { avatar_id: null, avatar_url: DEFAULT_AVATAR, avatar_name: null, avatar_source: 'default' };
  }
}

module.exports = { DEFAULT_AVATAR, toPublicPath, publicAvatar, getAvatarForUser };
