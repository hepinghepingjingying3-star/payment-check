// ============================================
// 26牛牛 - 端口占用排查（零依赖，只读查询）
// 用途:
//   - server.js 启动遇到 EADDRINUSE 时，直接告诉站长是哪个进程占着端口
//   - scripts/restart.js 一键重启复用同一套检测逻辑
// 实现:
//   - Windows: netstat -ano 解析 LISTENING 行 + tasklist 取进程名
//   - macOS / Linux: lsof -ti tcp:<port> -sTCP:LISTEN
// 说明: 只执行只读命令；查询失败时返回空数组，绝不抛异常
// ============================================
const { execFile } = require('child_process');

/** 执行只读命令并返回 stdout（失败返回空字符串） */
function run(cmd, args) {
  return new Promise(resolve => {
    execFile(cmd, args, { windowsHide: true, timeout: 5000 }, (err, stdout) => {
      resolve(err ? '' : String(stdout || ''));
    });
  });
}

/** 解析 netstat -ano 输出，找出监听指定端口的 PID（TCP LISTENING） */
function parseNetstat(text, port) {
  const suffix = ':' + port;
  const pids = [];
  String(text).split(/\r?\n/).forEach(line => {
    const t = line.trim();
    if (!/LISTENING/i.test(t)) return;
    const cols = t.split(/\s+/);
    if (cols.length < 4 || !cols[1] || cols[1].indexOf(suffix, cols[1].length - suffix.length) < 0) return;
    const pid = Number(cols[cols.length - 1]);
    if (Number.isInteger(pid) && pid > 0 && pids.indexOf(pid) < 0) pids.push(pid);
  });
  return pids;
}

/** 解析 tasklist /FO CSV /NH 输出，取进程名（如 node.exe） */
function parseTasklist(text) {
  const first = String(text).split(/\r?\n/).find(l => l.trim());
  if (!first) return '';
  const m = first.match(/^"([^"]+)"/);
  return m ? m[1] : '';
}

/** 取 PID 的进程名（Windows 用 tasklist；其它平台用 ps） */
async function processName(pid) {
  if (process.platform === 'win32') {
    return parseTasklist(await run('tasklist', ['/FI', 'PID eq ' + pid, '/FO', 'CSV', '/NH']));
  }
  const out = await run('ps', ['-p', String(pid), '-o', 'comm=']);
  return out.trim().split(/\s+/)[0] || '';
}

/** 监听指定端口的进程列表 [{ pid, name }] */
async function findListeners(port) {
  const p = Number(port);
  if (!Number.isInteger(p) || p <= 0) return [];
  let pids = [];
  if (process.platform === 'win32') {
    pids = parseNetstat(await run('netstat', ['-ano', '-p', 'TCP']), p);
  } else {
    const out = await run('lsof', ['-ti', 'tcp:' + p, '-sTCP:LISTEN']);
    pids = out.split(/[\s,]+/).map(Number).filter(n => Number.isInteger(n) && n > 0);
  }
  const list = [];
  for (const pid of pids) list.push({ pid: pid, name: await processName(pid) });
  return list;
}

/** 结束进程的命令（给用户看的提示文本） */
function killCommand(pid) {
  return process.platform === 'win32'
    ? 'taskkill /F /PID ' + pid
    : 'kill -9 ' + pid;
}

/** 结束指定进程（失败返回 false，不抛异常） */
async function killProcess(pid) {
  const p = Number(pid);
  if (!Number.isInteger(p) || p <= 0 || p === process.pid) return false;
  if (process.platform === 'win32') {
    const out = await run('taskkill', ['/F', '/PID', String(p)]);
    return !/ERROR|错误/i.test(out);
  }
  try { process.kill(p, 'SIGKILL'); return true; } catch (e) { return false; }
}

/** 等待端口释放（返回是否已释放） */
async function waitPortFree(port, timeout = 6000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const list = await findListeners(port);
    if (!list.length) return true;
    await new Promise(r => setTimeout(r, 250));
  }
  return false;
}

module.exports = { findListeners, killProcess, waitPortFree, killCommand, parseNetstat, parseTasklist };
