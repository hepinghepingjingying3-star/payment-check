// ============================================
// 26牛牛 - 图片安全检查（凭证 / 头像 / 贴图 共用）
// ============================================
// 只依据文件「实际内容」判定类型与尺寸，绝不信任客户端提供的 MIME 或扩展名。
// 支持: JPEG / PNG / WEBP
//   - 魔数（签名）判定真实类型
//   - 解析真实宽高，拒绝伪造扩展名 / 畸形文件 / 超大尺寸
// 说明: 本文件不进行任何磁盘写入，也不依赖第三方库。
// ============================================

const FUNDS = require('../config/funds');

/** 识别真实图片类型（基于文件头） */
function sniffMime(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 16) return null;
  // JPEG: FF D8 FF
  if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return 'image/jpeg';
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47 &&
      buf[4] === 0x0D && buf[5] === 0x0A && buf[6] === 0x1A && buf[7] === 0x0A) return 'image/png';
  // WEBP: RIFF....WEBP
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

/** PNG 尺寸（IHDR） */
function pngSize(buf) {
  if (buf.length < 24) return null;
  if (buf.toString('ascii', 12, 16) !== 'IHDR') return null;
  return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
}

/** JPEG 尺寸（扫描 SOF 段） */
function jpegSize(buf) {
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xFF) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0xFF) { i++; continue; }                             // 填充字节
    if (marker === 0xD8 || marker === 0x01 || (marker >= 0xD0 && marker <= 0xD7)) { i += 2; continue; }
    if (marker === 0xD9 || marker === 0xDA) return null;               // EOI / SOS，未找到 SOF
    const len = buf.readUInt16BE(i + 2);
    if (len < 2) return null;
    const isSOF = (marker >= 0xC0 && marker <= 0xCF) && marker !== 0xC4 && marker !== 0xC8 && marker !== 0xCC;
    if (isSOF) {
      if (i + 9 >= buf.length) return null;
      return { height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
    }
    i += 2 + len;
  }
  return null;
}

/** WEBP 尺寸（VP8 / VP8L / VP8X） */
function webpSize(buf) {
  if (buf.length < 30) return null;
  const fmt = buf.toString('ascii', 12, 16);
  if (fmt === 'VP8X') {
    return {
      width: 1 + (buf[24] | (buf[25] << 8) | (buf[26] << 16)),
      height: 1 + (buf[27] | (buf[28] << 8) | (buf[29] << 16))
    };
  }
  if (fmt === 'VP8 ') {
    return { width: buf.readUInt16LE(26) & 0x3FFF, height: buf.readUInt16LE(28) & 0x3FFF };
  }
  if (fmt === 'VP8L') {
    const b0 = buf[21], b1 = buf[22], b2 = buf[23], b3 = buf[24];
    const width = 1 + (((b1 & 0x3F) << 8) | b0);
    const height = 1 + (((b3 & 0x0F) << 10) | (b2 << 2) | ((b1 & 0xC0) >> 6));
    return { width, height };
  }
  return null;
}

/** 解析真实尺寸 */
function imageSize(buf, mime) {
  try {
    if (mime === 'image/png') return pngSize(buf);
    if (mime === 'image/jpeg') return jpegSize(buf);
    if (mime === 'image/webp') return webpSize(buf);
  } catch (_) { return null; }
  return null;
}

/**
 * 校验上传图片
 * @param {Buffer} buf 文件内容
 * @param {object} [opts] { maxBytes, minBytes, maxWidth, maxHeight, minWidth, minHeight }
 * @returns {{ ok:boolean, code?:string, message?:string, mime?:string, ext?:string, width?:number, height?:number }}
 */
function checkImage(buf, opts) {
  opts = opts || {};
  const cfg = FUNDS.VOUCHER;
  const maxBytes = opts.maxBytes || cfg.MAX_BYTES;
  const minBytes = opts.minBytes || cfg.MIN_BYTES;
  const maxW = opts.maxWidth || cfg.MAX_WIDTH;
  const maxH = opts.maxHeight || cfg.MAX_HEIGHT;
  const minW = opts.minWidth || cfg.MIN_WIDTH;
  const minH = opts.minHeight || cfg.MIN_HEIGHT;
  const allowed = opts.mimeTypes || cfg.MIME_TYPES;

  if (!Buffer.isBuffer(buf) || buf.length === 0) {
    return { ok: false, code: 'FILE_EMPTY', message: '请选择要上传的图片文件' };
  }
  if (buf.length > maxBytes) {
    return { ok: false, code: 'FILE_TOO_LARGE', message: '图片过大，请压缩后重试（最大 ' + Math.round(maxBytes / 1024 / 1024) + 'MB）' };
  }
  if (buf.length < minBytes) {
    return { ok: false, code: 'FILE_TOO_SMALL', message: '文件内容过小，可能不是有效图片' };
  }
  const mime = sniffMime(buf);
  if (!mime || allowed.indexOf(mime) === -1) {
    return { ok: false, code: 'FILE_TYPE_INVALID', message: '仅支持 JPG / PNG / WEBP 图片' };
  }
  const size = imageSize(buf, mime);
  if (!size || !size.width || !size.height) {
    return { ok: false, code: 'FILE_CORRUPTED', message: '图片内容无法识别，请重新导出后再上传' };
  }
  if (size.width < minW || size.height < minH) {
    return { ok: false, code: 'IMAGE_TOO_SMALL', message: '图片尺寸过小（最小 ' + minW + '×' + minH + '）' };
  }
  if (size.width > maxW || size.height > maxH) {
    return { ok: false, code: 'IMAGE_TOO_LARGE', message: '图片尺寸过大（最大 ' + maxW + '×' + maxH + '）' };
  }
  return { ok: true, mime: mime, ext: cfg.EXT_BY_MIME[mime], width: size.width, height: size.height };
}

module.exports = { sniffMime, imageSize, checkImage };
