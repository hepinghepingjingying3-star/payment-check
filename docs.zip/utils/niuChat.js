'use strict';
// ============================================
// 26牛牛 - 游戏系统消息（写入「26牛牛游戏群」，永不丢失）
// ============================================
// 架构要点：26牛牛游戏就在「26牛牛游戏群」里进行，聊天系统本身就是游戏载体。
// 所以游戏阶段的每一条播报都必须：
//   1) 真的写进 chat_messages（message_type='game'），刷新页面仍然看得到
//   2) 带上 room_id + round_id + phase，聊天页才知道这条属于哪一间房、哪一局、哪个阶段
//   3) 推给 chat:group 频道（与普通聊天同一个频道、同一条消息流）
// 消息类型分工（不改动既有枚举）：
//   system = 普通系统通知（封禁 / 公告 / 维护…）
//   game   = 26牛牛游戏系统消息（本文件是唯一写入口）
// ============================================

const db = require('./../config/db');

const GAME_CHANNEL = 'group';   // 与 routes/chat.js 的 GROUP_CHANNEL 保持一致

/**
 * 写一条游戏消息到 26牛牛游戏群
 * @param {object} o
 *   content  必填，群里显示的正文（纯文本，绝不接受 HTML）
 *   round    可选，{ room_pk, round_pk, round_id, phase }，关联到具体房间与具体一局。
 *            也接受把这四个字段直接平铺在 o 上（room_pk / round_pk / round_id / phase），
 *            两种写法等价，历史调用方不必改。
 *   meta     可选，附加结构化数据（前端只按 meta.kind 渲染已知样式）
 *   io       可选，Socket.IO 实例；缺失时消息依然已入库
 * @returns {Promise<object>} 与普通聊天消息同构的 msg（可直接广播）
 */
async function postGameMessage(o) {
  const content = String((o && o.content) || '').trim();
  if (!content) throw new Error('EMPTY_GAME_MESSAGE');

  // 关联上下文：嵌套 round 优先，其次取平铺字段，两者都缺才是「与局无关」的系统消息
  const round = (o && o.round) || {
    room_pk: o && o.room_pk,
    round_pk: o && o.round_pk,
    round_id: o && o.round_id,
    phase: o && o.phase
  };
  const roomPk = round && round.room_pk ? Number(round.room_pk) : null;
  const roundPk = round && round.round_pk ? Number(round.round_pk) : null;
  const roundId = round && round.round_id ? String(round.round_id) : null;
  const phase = round && round.phase ? String(round.phase) : null;

  // meta.source 标明这是游戏系统消息（与普通 system 通知严格区分）
  const meta = Object.assign({ source: 'niu_game', kind: 'game' }, (o && o.meta) || {});

  // sender_role 固定为 system：游戏系统消息不是管理员发的，聊天页据此渲染成系统卡片
  const [res] = await db.promise().query(
    `INSERT INTO chat_messages
       (channel, user_id, message_type, content, meta, sender_role, room_id, round_id, phase, game_round_pk)
     VALUES (?, NULL, 'game', ?, ?, 'system', ?, ?, ?, ?)`,
    [GAME_CHANNEL, content.slice(0, 500), JSON.stringify(meta),
      Number.isSafeInteger(roomPk) && roomPk > 0 ? roomPk : null,
      roundId, phase,
      Number.isSafeInteger(roundPk) && roundPk > 0 ? roundPk : null]
  );

  const msg = {
    id: Number(res.insertId),
    channel: GAME_CHANNEL,
    message_type: 'game',
    content: content,
    meta: meta,
    is_recalled: false,
    sender_role: 'system',
    is_mine: false,
    is_system: false,
    is_game: true,
    username: '26牛牛',
    avatar_url: null,
    created_at: new Date().toISOString(),
    room_id: Number.isSafeInteger(roomPk) && roomPk > 0 ? roomPk : null,
    round_id: roundId,
    phase: phase
  };

  // 实时推送：与普通聊天同一个频道，群里的在线玩家立刻看到
  const io = o && o.io ? o.io : null;
  if (io) {
    try { io.to('chat:' + GAME_CHANNEL).emit('chat:message', msg); } catch (_) { /* 已入库，推送失败不影响 */ }
  }
  return msg;
}

/** 读取某一局的全部游戏消息（聊天页按局回看时使用） */
async function gameMessagesOfRound(roundId) {
  const [rows] = await db.promise().query(
    `SELECT id, channel, message_type, content, meta, created_at, room_id, round_id, phase
     FROM chat_messages
     WHERE channel = ? AND round_id = ? AND is_recalled = 0
     ORDER BY id ASC LIMIT 200`,
    [GAME_CHANNEL, String(roundId)]
  );
  return rows.map(r => ({
    id: Number(r.id),
    message_type: r.message_type,
    content: r.content,
    meta: r.meta || null,
    phase: r.phase || null,
    room_id: r.room_id == null ? null : Number(r.room_id),
    round_id: r.round_id || null,
    created_at: r.created_at
  }));
}

/** 游戏群当前是否有进行中的对局（聊天页顶部显示「游戏中」角标） */
async function activeRoundOfChannel(channel) {
  const [rows] = await db.promise().query(
    `SELECT r.id, r.round_id, r.room_key, r.status, r.player_count, r.base_stake,
            r.room_id, rm.room_name
     FROM game_rounds r LEFT JOIN game_rooms rm ON rm.id = r.room_id
     WHERE r.chat_channel = ? AND r.status NOT IN ('FINISHED','ENDED','ABORTED')
     ORDER BY r.id DESC LIMIT 1`,
    [channel || GAME_CHANNEL]
  );
  return rows.length ? rows[0] : null;
}

module.exports = { GAME_CHANNEL, postGameMessage, gameMessagesOfRound, activeRoundOfChannel };
