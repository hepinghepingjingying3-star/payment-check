'use strict';
// ============================================
// 26牛牛 - 账号治理核心操作（后台路由 / 双人复核执行器 共用）
// ============================================
// 说明:
//   - 高风险治理动作（封禁解封 / 管理员权限 / 解除禁言 / 禁言）只在这里实现一次，
//     保证「管理员直接执行」与「双人复核通过后执行」的行为完全一致
//   - 每个动作：事务 + 行锁(FOR UPDATE) + 状态二次校验 + 同事务审计
//   - 封禁成功后主动断开该账号的全部 Socket 连接（DB 状态始终是最终依据）
//   - 绝不删除账号、绝不改动密码与余额
// ============================================

const db = require('../config/db');
const { writeAdminLog } = require('./adminAudit');
const presence = require('./presence');
const MOD = require('../config/moderation');

const MUTE_MIN_MINUTES = MOD.MUTE.MIN_MINUTES;
const MUTE_MAX_MINUTES = MOD.MUTE.MAX_MINUTES;

function fail(code, status, message) {
  return { ok: false, code: code, status: status, message: message };
}

/** 审计补充：区分「直接执行」与「复核后执行」 */
function auditTail(adminId, requestedBy) {
  if (!requestedBy || Number(requestedBy) === Number(adminId)) return '';
  return '; requested_by=' + Number(requestedBy) + '; approved_by=' + Number(adminId);
}

// ============================================
// 1. 账号启用 / 封禁
// ============================================
async function applyUserStatus(o) {
  const userId = Number(o.userId);
  const adminId = Number(o.adminId);
  const status = String(o.status || '');
  const reason = String(o.reason || '').trim();
  if (status !== 'active' && status !== 'banned') return fail('INVALID_STATUS', 422, '状态只能是 active 或 banned');
  if (reason.length < 2) return fail('REASON_REQUIRED', 422, '请填写操作原因（至少 2 个字）');
  if (userId === adminId) return fail('SELF_CHANGE_FORBIDDEN', 403, '不能修改自己的账号状态');

  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, username, role, status FROM users WHERE id = ? FOR UPDATE', [userId]
    );
    const user = rows[0];
    if (!user) { await conn.rollback(); return fail('USER_NOT_FOUND', 404, '用户不存在'); }
    if (user.status === 'deleted') {
      await conn.rollback();
      return fail('USER_DELETED', 409, '该账号已注销，无法修改状态');
    }
    // 管理员账号不能被封禁：避免管理员之间互相封号导致后台失控（需先取消管理员权限）
    if (status === 'banned' && user.role === 'admin') {
      await conn.rollback();
      return fail('ADMIN_TARGET_FORBIDDEN', 403, '管理员账号不能被封禁，请先取消其管理员权限');
    }
    if (user.status === status) {
      await conn.rollback();
      return fail('STATUS_UNCHANGED', 409, '账号已经是该状态');
    }

    await conn.query('UPDATE users SET status = ? WHERE id = ?', [status, userId]);
    await writeAdminLog({
      adminId: adminId, targetUserId: userId, action: 'user_status', conn: conn,
      detail: 'status ' + user.status + ' -> ' + status + '; reason=' + reason + auditTail(adminId, o.requestedBy)
    });
    await conn.commit();

    // 封禁后主动断开该账号所有 Socket（账号不可用，连接不应继续持有）
    const closed = status === 'banned'
      ? presence.kickUser(userId, '账号已被管理员封禁，请联系客服')
      : 0;

    return {
      ok: true,
      data: {
        id: userId, username: user.username, previous_status: user.status, status: status,
        reason: reason, sockets_closed: closed
      }
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('修改用户状态失败:', err.message);
    return fail('STATUS_CHANGE_FAILED', 500, '修改用户状态失败，请稍后重试');
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 2. 管理员权限（admin / user）
// ============================================
async function applyUserRole(o) {
  const userId = Number(o.userId);
  const adminId = Number(o.adminId);
  const role = String(o.role || '');
  const reason = String(o.reason || '').trim();
  if (role !== 'admin' && role !== 'user') return fail('INVALID_ROLE', 422, '角色只能是 admin 或 user');
  if (reason.length < 2) return fail('REASON_REQUIRED', 422, '请填写操作原因（至少 2 个字）');
  if (userId === adminId) return fail('SELF_CHANGE_FORBIDDEN', 403, '不能修改自己的角色');

  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT id, username, role, status FROM users WHERE id = ? FOR UPDATE', [userId]);
    const user = rows[0];
    if (!user) { await conn.rollback(); return fail('USER_NOT_FOUND', 404, '用户不存在'); }
    if (user.status === 'deleted') {
      await conn.rollback();
      return fail('USER_DELETED', 409, '该账号已注销，无法修改角色');
    }
    if (user.role === role) {
      await conn.rollback();
      return fail('ROLE_UNCHANGED', 409, '账号已经是该角色');
    }
    if (user.role === 'admin') {
      // 取消管理员前确认系统里还有其它活跃管理员，避免把后台锁死
      const [cnt] = await conn.query(
        "SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND status = 'active' AND id <> ?", [userId]
      );
      if ((Number(cnt[0] && cnt[0].c) || 0) === 0) {
        await conn.rollback();
        return fail('LAST_ADMIN', 409, '系统至少需要保留一个活跃管理员，无法取消最后一个管理员');
      }
    }
    await conn.query('UPDATE users SET role = ? WHERE id = ?', [role, userId]);
    await writeAdminLog({
      adminId: adminId, targetUserId: userId, action: 'user_role', conn: conn,
      detail: 'role ' + user.role + ' -> ' + role + '; username=' + user.username +
        '; reason=' + reason + auditTail(adminId, o.requestedBy)
    });
    await conn.commit();
    return {
      ok: true,
      data: { id: userId, username: user.username, previous_role: user.role, role: role, reason: reason }
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('修改用户角色失败:', err.message);
    return fail('ROLE_CHANGE_FAILED', 500, '修改用户角色失败，请稍后重试');
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 3. 解除禁言
// ============================================
async function applyUnmute(o) {
  const userId = Number(o.userId);
  const adminId = Number(o.adminId);
  const reason = String(o.reason || '').trim() || '管理员解除禁言';

  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT id, username, muted_until FROM users WHERE id = ? FOR UPDATE', [userId]);
    const user = rows[0];
    if (!user) { await conn.rollback(); return fail('USER_NOT_FOUND', 404, '用户不存在'); }
    if (!user.muted_until) {
      await conn.rollback();
      return fail('NOT_MUTED', 409, '该账号当前未被禁言');
    }
    await conn.query('UPDATE users SET muted_until = NULL, mute_reason = NULL WHERE id = ?', [userId]);
    await writeAdminLog({
      adminId: adminId, targetUserId: userId, action: 'user_unmute', conn: conn,
      detail: 'unmute; username=' + user.username + '; reason=' + reason + auditTail(adminId, o.requestedBy)
    });
    await conn.commit();
    return { ok: true, data: { id: userId, username: user.username, muted_until: null, reason: reason } };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('解除禁言失败:', err.message);
    return fail('UNMUTE_FAILED', 500, '解除禁言失败，请稍后重试');
  } finally {
    if (conn) conn.release();
  }
}

// ============================================
// 4. 禁言（按分钟；由后台直接执行，不进入双人复核）
// ============================================
async function applyMute(o) {
  const userId = Number(o.userId);
  const adminId = Number(o.adminId);
  const minutes = Number(o.minutes);
  const reason = String(o.reason || '').trim();
  if (!Number.isSafeInteger(minutes) || minutes < MUTE_MIN_MINUTES || minutes > MUTE_MAX_MINUTES) {
    return fail('INVALID_MUTE_MINUTES', 422, '禁言时长需在 5 分钟到 30 天之间');
  }
  if (reason.length < 2) return fail('REASON_REQUIRED', 422, '请填写禁言原因（至少 2 个字）');
  if (userId === adminId) return fail('SELF_CHANGE_FORBIDDEN', 403, '不能禁言自己');

  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT id, username, role, status FROM users WHERE id = ? FOR UPDATE', [userId]);
    const user = rows[0];
    if (!user) { await conn.rollback(); return fail('USER_NOT_FOUND', 404, '用户不存在'); }
    if (user.status === 'deleted') {
      await conn.rollback();
      return fail('USER_DELETED', 409, '该账号已注销，无法禁言');
    }
    if (user.role === 'admin') {
      await conn.rollback();
      return fail('ADMIN_TARGET_FORBIDDEN', 403, '管理员账号不能被禁言，请先取消其管理员权限');
    }
    await conn.query(
      'UPDATE users SET muted_until = DATE_ADD(NOW(), INTERVAL ? MINUTE), mute_reason = ? WHERE id = ?',
      [minutes, reason, userId]
    );
    const [after] = await conn.query('SELECT muted_until FROM users WHERE id = ?', [userId]);
    await writeAdminLog({
      adminId: adminId, targetUserId: userId, action: 'user_mute', conn: conn,
      detail: 'mute ' + minutes + ' minutes; username=' + user.username + '; reason=' + reason
    });
    await conn.commit();
    return {
      ok: true,
      data: {
        id: userId, username: user.username, minutes: minutes,
        muted_until: after[0] ? after[0].muted_until : null, reason: reason
      }
    };
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('禁言失败:', err.message);
    return fail('MUTE_FAILED', 500, '禁言失败，请稍后重试');
  } finally {
    if (conn) conn.release();
  }
}

module.exports = { applyUserStatus, applyUserRole, applyUnmute, applyMute };
