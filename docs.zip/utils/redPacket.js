// ============================================
// 26牛牛 - 红包对战核心逻辑
// 包含:
//   - 安全随机红包金额生成 (crypto)
//   - 金额识别（点数计算）
//   - 牌型识别
//   - 倍率计算
//   - 庄闲比较
// ============================================

const crypto = require('crypto');

// ============================================
// 1. 安全随机金额生成
// ============================================

/**
 * 生成安全随机红包金额
 * 使用 crypto.randomBytes 而非 Math.random
 * 金额范围: 0.01 ~ 9.99
 * 保留 2 位小数
 */
function generateRandomAmount() {
  // 生成 0-9999 的随机整数
  const rand = crypto.randomInt(1, 10000);
  // 转换为 0.01 ~ 9.99
  const amount = rand / 1000;
  return Number(amount.toFixed(2));
}

/**
 * 生成虚拟红包金额列表
 * @param {number} count - 红包个数
 * @param {number} totalAmount - 总金额
 * @returns {number[]} 金额数组
 */
function generateRedPacketAmounts(count, totalAmount) {
  const amounts = [];
  let remaining = Number(totalAmount);
  let remainingCount = count;

  for (let i = 0; i < count; i++) {
    remainingCount--;
    if (remainingCount === 0) {
      // 最后一个红包拿走所有剩余
      amounts.push(Number(remaining.toFixed(2)));
    } else {
      // 随机分配，确保每个红包至少 0.01
      const min = 0.01;
      const max = remaining - (remainingCount * min);
      if (max <= min) {
        amounts.push(Number(min.toFixed(2)));
      } else {
        const rand = crypto.randomInt(1, Math.floor(max * 100) + 1);
        const amount = rand / 100;
        amounts.push(Number(amount.toFixed(2)));
      }
      remaining = Number((remaining - amounts[i]).toFixed(2));
    }
  }

  return amounts;
}

// ============================================
// 2. 金额识别（点数计算）
// ============================================

/**
 * 从红包金额计算点数
 * 规则: 取金额的每一位数字相加，然后 % 10
 * 例如: 3.42 -> 3+4+2=9 -> 9点
 *       2.80 -> 2+8+0=10 -> 10%10=0 -> 10点
 *       0.00 -> 0 -> 10点
 */
function calculatePointValue(amount) {
  // 转换为字符串，去掉小数点
  const str = Number(amount).toFixed(2);
  const digits = str.replace('.', '').split('').map(d => parseInt(d, 10));
  const sum = digits.reduce((a, b) => a + b, 0);
  const point = sum % 10;
  // 0 点显示为 10 点
  return point === 0 ? 10 : point;
}

// ============================================
// 3. 牌型识别
// ============================================

/**
 * 获取牌型等级（数字越大等级越高）
 */
const CARD_TYPE_RANK = {
  '普通': 1,
  '金牛': 2,
  '对子': 3,
  '顺子': 4,
  '反顺': 5,
  '满牛': 6,
  '豹子': 7
};

/**
 * 获取牌型倍率
 */
const CARD_TYPE_MULTIPLIER = {
  '普通': null,  // 普通按点数倍率
  '金牛': 11,
  '对子': 12,
  '顺子': 13,
  '反顺': 14,
  '满牛': 15,
  '豹子': 17
};

/**
 * 识别牌型
 * @param {number} amount - 红包金额
 * @returns {{type: string, multiplier: number, point: number}}
 */
function identifyCardType(amount) {
  const str = Number(amount).toFixed(2);
  const digits = str.replace('.', '').split('').map(d => parseInt(d, 10));
  const point = calculatePointValue(amount);

  // 检查豹子：三个非零数字相同
  // 金额格式: X.YY -> 数字为 [X, Y, Y]
  // 豹子: X==Y 且 X!=0
  if (digits[0] === digits[1] && digits[1] === digits[2] && digits[0] !== 0) {
    return { type: '豹子', multiplier: 17, point };
  }

  // 检查满牛：总和 >= 20 且为 10 的倍数
  const sum = digits.reduce((a, b) => a + b, 0);
  if (sum >= 20 && sum % 10 === 0) {
    return { type: '满牛', multiplier: 15, point: 10 };
  }

  // 检查反顺：三位数字严格递减
  if (digits[0] > digits[1] && digits[1] > digits[2]) {
    return { type: '反顺', multiplier: 14, point };
  }

  // 检查顺子：三位数字严格递增
  if (digits[0] < digits[1] && digits[1] < digits[2]) {
    return { type: '顺子', multiplier: 13, point };
  }

  // 检查对子：末两位相同且非零
  if (digits[1] === digits[2] && digits[1] !== 0) {
    return { type: '对子', multiplier: 12, point };
  }

  // 检查金牛：仅一位非零数字
  const nonZeroCount = digits.filter(d => d !== 0).length;
  if (nonZeroCount === 1) {
    return { type: '金牛', multiplier: 11, point };
  }

  // 普通：按点数倍率
  return { type: '普通', multiplier: point, point };
}

// ============================================
// 4. 庄闲比较
// ============================================

/**
 * 比较庄家和闲家的牌型
 * @param {object} bankerResult - 庄家结果 {type, multiplier, point, amount}
 * @param {object} playerResult - 闲家结果 {type, multiplier, point, amount}
 * @returns {string} 'WIN' | 'LOSE' | 'TIE'
 */
function compareResults(bankerResult, playerResult) {
  const bankerRank = CARD_TYPE_RANK[bankerResult.type];
  const playerRank = CARD_TYPE_RANK[playerResult.type];

  // 比较牌型等级
  if (bankerRank > playerRank) return 'LOSE';  // 闲家输
  if (bankerRank < playerRank) return 'WIN';  // 闲家赢

  // 牌型相同，比较点数
  if (bankerResult.point > playerResult.point) return 'LOSE';
  if (bankerResult.point < playerResult.point) return 'WIN';

  // 点数相同，比较红包金额
  if (bankerResult.amount > playerResult.amount) return 'LOSE';
  if (bankerResult.amount < playerResult.amount) return 'WIN';

  // 完全相同，平局
  return 'TIE';
}

// ============================================
// 5. 红包生成
// ============================================

/**
 * 生成虚拟红包
 * @param {string} roundId - 游戏局ID
 * @param {string} packetType - 'TNG_SIMULATED' | 'PLATFORM'
 * @param {number} playerCount - 玩家人数
 * @returns {object} 红包对象
 */
function generateRedPacket(roundId, packetType, playerCount) {
  const packetId = crypto.randomUUID();
  const count = Math.max(playerCount, 1);

  // 总金额: 每人至少 1.00，最多 9.99 * 人数
  const minTotal = count * 1.00;
  const maxTotal = count * 9.99;
  const totalAmount = Number((crypto.randomInt(Math.floor(minTotal * 100), Math.floor(maxTotal * 100) + 1) / 100).toFixed(2));

  const amounts = generateRedPacketAmounts(count, totalAmount);

  return {
    packet_id: packetId,
    round_id: roundId,
    type: packetType,
    total_amount: totalAmount,
    remaining_amount: totalAmount,
    packet_count: count,
    amounts: amounts,  // 内部使用，不存入数据库
    status: 'ACTIVE',
    expired_at: new Date(Date.now() + 60000)  // 60秒后过期
  };
}

// ============================================
// 6. 结算计算
// ============================================

/**
 * 计算结算结果
 * @param {object} bankerResult - 庄家牌面结果
 * @param {Array} playerResults - 闲家牌面结果数组
 * @param {number} bankerPool - 庄池总额
 * @param {number} feeRate - 抽水比例 (0-1)
 * @returns {Array} 结算结果数组
 */
function calculateSettlement(bankerResult, playerResults, bankerPool, feeRate = 0.05) {
  const settlements = [];
  let remainingPool = Number(bankerPool);

  for (const player of playerResults) {
    const comparison = compareResults(bankerResult, player);
    let payout = 0;
    let fee = 0;
    let netPayout = 0;

    if (comparison === 'WIN') {
      // 闲家赢：获得庄家下注 * 倍率
      const grossWin = Number(player.bet_amount) * Number(player.multiplier);
      fee = Number((grossWin * feeRate).toFixed(2));
      netPayout = Number((grossWin - fee).toFixed(2));
      payout = netPayout;
    } else if (comparison === 'LOSE') {
      // 闲家输：庄家获得闲家下注 * 倍率
      const grossWin = Number(player.bet_amount) * Number(player.multiplier);
      fee = Number((grossWin * feeRate).toFixed(2));
      netPayout = Number((grossWin - fee).toFixed(2));
      payout = -netPayout;  // 负数表示庄家赚
    }
    // TIE: 不赚不输

    settlements.push({
      user_id: player.user_id,
      role: 'PLAYER',
      comparison: comparison,
      bet_amount: player.bet_amount,
      multiplier: player.multiplier,
      gross_payout: comparison === 'WIN' ? Number(player.bet_amount) * Number(player.multiplier) : 0,
      fee: fee,
      net_payout: payout,
      pool_contribution: comparison === 'LOSE' ? Number(player.bet_amount) * Number(player.multiplier) : 0
    });
  }

  return settlements;
}

// ============================================
// 7. 庄池结算（处理喝水机制）
// ============================================

/**
 * 结算庄家收益（处理庄池不足喝水机制）
 * @param {Array} settlements - 闲家结算结果
 * @param {number} bankerPool - 庄池总额
 * @returns {object} 庄家结算结果
 */
function settleBanker(settlements, bankerPool) {
  let remainingPool = Number(bankerPool);
  let totalFee = 0;
  let totalNet = 0;

  // 按固定顺序结算闲家赔付给庄家
  for (const s of settlements) {
    if (s.comparison === 'LOSE') {
      // 闲家输，庄家赚 pool_contribution
      const available = Math.min(s.pool_contribution, remainingPool);
      s.actual_payout = available;
      remainingPool = Number((remainingPool - available).toFixed(2));
      totalNet += available;
    } else if (s.comparison === 'WIN') {
      // 闲家赢，庄家输 net_payout
      const payout = Math.min(s.net_payout, remainingPool);
      s.actual_payout = -payout;
      remainingPool = Number((remainingPool - payout).toFixed(2));
      totalNet -= payout;
    } else {
      s.actual_payout = 0;
    }
    totalFee += s.fee;
  }

  return {
    banker_net: Number(totalNet.toFixed(2)),
    banker_fee: Number(totalFee.toFixed(2)),
    remaining_pool: Number(remainingPool.toFixed(2))
  };
}

// ============================================
// 导出
// ============================================

module.exports = {
  generateRandomAmount,
  generateRedPacketAmounts,
  calculatePointValue,
  identifyCardType,
  compareResults,
  generateRedPacket,
  calculateSettlement,
  settleBanker,
  CARD_TYPE_RANK,
  CARD_TYPE_MULTIPLIER
};
