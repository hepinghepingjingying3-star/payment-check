// ============================================
// 26牛牛 - 管理员操作审计（阶段 8.11）
// 说明:
//   - 统一写入 admin_logs 表（已存在），字段: admin_id / target_user_id / action / detail / created_at
//   - 绝不记录密码、密码哈希、OTP 明文、JWT、API Secret
//   - 写入失败只记录到服务端日志，不影响主流程（但调用方需据此决定是否回滚关键操作）
// ============================================

const db = require('../config/db');

// detail 列是 TEXT；这里统一截断，避免超长写入失败
const MAX_DETAIL = 2000;

/** detail 的安全化：去掉明显的敏感字段，只保留可审计信息 */
function sanitizeDetail(detail) {
  if (detail === null || detail === undefined) return null;
  const text = typeof detail === 'string' ? detail : JSON.stringify(detail);
  return text
    .replace(/("?(password|password_hash|otp|otp_hash|otp_plain|token|jwt|secret)"?\s*[:=]\s*)"?[^",}\s]+"?/gi, '$1"[redacted]"')
    .slice(0, MAX_DETAIL);
}

/**
 * 写入一条管理操作审计
 * @param {object} o { adminId, targetUserId, action, detail, conn }
 *   conn: 可选，传入事务连接可实现「操作 + 审计」同事务
 */
async function writeAdminLog(o) {
  const runner = (o && o.conn) ? o.conn : db.promise();
  const params = [
    (o && o.adminId) || null,
    (o && o.targetUserId) || null,
    String((o && o.action) || 'unknown').slice(0, 50),
    sanitizeDetail(o && o.detail)
  ];
  try {
    await runner.query(
      `INSERT INTO admin_logs (admin_id, target_user_id, action, detail) VALUES (?, ?, ?, ?)`,
      params
    );
    return true;
  } catch (e) {
    console.error('管理审计写入失败:', e.message);
    return false;
  }
}

/** 读取审计日志（不含任何敏感字段） */
async function listAdminLogs(limit, offset, action) {
  const params = [];
  let where = '';
  if (action) { where = 'WHERE l.action = ?'; params.push(String(action).slice(0, 50)); }
  params.push(limit, offset);
  const [rows] = await db.promise().query(
    `SELECT l.id, l.admin_id, a.username AS admin_username, a.role AS admin_role,
            l.target_user_id, t.username AS target_username, t.nickname AS target_nickname,
            l.action, l.detail, l.created_at
     FROM admin_logs l
     LEFT JOIN users a ON a.id = l.admin_id
     LEFT JOIN users t ON t.id = l.target_user_id
     ${where}
     ORDER BY l.id DESC LIMIT ? OFFSET ?`,
    params
  );
  return rows.map(r => ({
    id: Number(r.id),
    admin: r.admin_id ? { id: Number(r.admin_id), username: r.admin_username || null, role: r.admin_role || null } : null,
    target: r.target_user_id ? {
      id: Number(r.target_user_id),
      username: r.target_username || null,
      nickname: r.target_nickname || null
    } : null,
    action: r.action,
    detail: r.detail || null,
    created_at: r.created_at
  }));
}

module.exports = { writeAdminLog, listAdminLogs, sanitizeDetail };