// Shared visibility policy for REST conversation previews, paging and unread counts.
// Support is currently a private leave-a-message channel, not a shared staff inbox.
function visibleMessages(userId, alias = 'm') {
  return {
    sql: `(${alias}.channel = 'group' OR (${alias}.channel = 'support' AND ${alias}.user_id = ?))`,
    params: [userId]
  };
}

async function unreadCounts(db, userId) {
  const visible = visibleMessages(userId);
  const [rows] = await db.promise().query(
    `SELECT m.channel, COUNT(*) AS c FROM chat_messages m
     LEFT JOIN chat_read_state r ON r.user_id = ? AND r.channel = m.channel
     WHERE ${visible.sql} AND m.id > COALESCE(r.last_read_id, 0)
       AND (m.user_id IS NULL OR m.user_id <> ?) AND m.is_recalled = 0
     GROUP BY m.channel`,
    [userId, ...visible.params, userId]
  );
  const counts = { group: 0, support: 0, total: 0 };
  rows.forEach(row => {
    if (row.channel === 'group' || row.channel === 'support') {
      counts[row.channel] = Number(row.c) || 0;
    }
  });
  counts.total = counts.group + counts.support;
  return counts;
}

function chatRoom(channel, userId) {
  return channel === 'support' ? 'chat:support:' + userId : 'chat:group';
}

module.exports = { visibleMessages, unreadCounts, chatRoom };
