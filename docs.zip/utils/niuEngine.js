'use strict';
// ============================================
// 26牛牛 - 牌局纯逻辑引擎（零依赖、无数据库、可单元测试）
// ============================================
// 规则要点（唯一实现处，前端不参与计算）:
//   - 5 张牌：A=1，2~9 = 面值，10/J/Q/K = 10
//   - 任意三张相加为 10 的倍数 → 「有牛」，剩余两张之和的个位为点数，0 记「牛牛」
//   - 特殊牌型（优先级从高到低）：五小牛 > 炸弹牛 > 五花牛 > 同花牛 > 牛牛 > 牛9..牛1 > 无牛
//   - 无牛时按最大单牌比较，仍相同依次比较后续单牌与花色，保证结果确定
//   - 随机性全部来自服务器 crypto（安全随机），洗牌使用 Fisher-Yates
// ============================================

const crypto = require('crypto');
const NG = require('../config/niuGame');

const SUITS = [
  { code: 'S', label: '黑桃', order: 4 },
  { code: 'H', label: '红心', order: 3 },
  { code: 'C', label: '梅花', order: 2 },
  { code: 'D', label: '方块', order: 1 }
];
const RANK_LABEL = {
  1: 'A', 2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7',
  8: '8', 9: '9', 10: '10', 11: 'J', 12: 'Q', 13: 'K'
};

/** 单张牌的点数（10/J/Q/K 记 10） */
function pointValue(rank) {
  const r = Number(rank);
  return r >= 10 ? 10 : r;
}

/** 生成一副标准 52 张扑克 */
function buildDeck() {
  const deck = [];
  for (let s = 0; s < SUITS.length; s++) {
    for (let r = 1; r <= 13; r++) {
      deck.push({
        id: SUITS[s].code + RANK_LABEL[r],
        rank: r,
        suit: s,
        suit_code: SUITS[s].code,
        suit_label: SUITS[s].label,
        rank_label: RANK_LABEL[r],
        point: pointValue(r)
      });
    }
  }
  return deck;
}

/** 服务器安全随机整数 [0, n) */
function secureInt(n) {
  return crypto.randomInt(0, n);
}

/** Fisher-Yates 洗牌（服务器端安全随机） */
function shuffle(deck, intFn) {
  const rnd = intFn || secureInt;
  const arr = deck.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = rnd(i + 1);
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr;
}

/**
 * 发牌：每人 5 张
 * @param {Array} deck 完整牌堆
 * @param {Array<number>} userIds 参与者（顺序决定牌序，服务端内部使用）
 * @returns {{hands: object, shuffled: Array}}
 */
function deal(deck, userIds) {
  const ids = userIds.map(uid => String(uid));
  if (!ids.length || ids.length * 5 > deck.length) throw new Error('DEAL_CAPACITY');
  const shuffled = shuffle(deck);
  const hands = {};
  ids.forEach(uid => { hands[uid] = []; });
  for (let i = 0; i < 5; i++) {
    for (let p = 0; p < ids.length; p++) {
      hands[ids[p]].push(shuffled[i * ids.length + p]);
    }
  }
  return { hands: hands, shuffled: shuffled };
}

// ---------- 牌型判定 ----------

function sameRankCount(cards) {
  const map = {};
  cards.forEach(c => { map[c.rank] = (map[c.rank] || 0) + 1; });
  return Math.max.apply(null, Object.keys(map).map(k => map[k]));
}

function allSameSuit(cards) {
  return cards.every(c => c.suit === cards[0].suit);
}

/** 是否存在「三张之和为 10 的倍数」，返回最优点数（0 表示牛牛），没有返回 null */
function bestNiu(cards) {
  const vals = cards.map(c => c.point);
  let best = -1;
  for (let a = 0; a < 5; a++) {
    for (let b = a + 1; b < 5; b++) {
      for (let c = b + 1; c < 5; c++) {
        if ((vals[a] + vals[b] + vals[c]) % 10 !== 0) continue;
        let rest = 0;
        for (let i = 0; i < 5; i++) if (i !== a && i !== b && i !== c) rest += vals[i];
        const score = (rest % 10) === 0 ? 10 : (rest % 10);
        if (score > best) best = score;
      }
    }
  }
  if (best < 0) return null;
  return best === 10 ? 0 : best;                 // 0 = 牛牛
}

function tiebreakValue(cards) {
  return cards.slice()
    .sort((a, b) => (b.rank - a.rank) || (SUITS[b.suit].order - SUITS[a.suit].order))
    .reduce((acc, c) => acc * 100 + c.rank * 5 + SUITS[c.suit].order, 0);
}

/**
 * 判定一手牌（5 张）
 * @returns {{key,name,multiplier,order,niu,point_value,high_rank,tiebreak}}
 */
function identifyHand(cards) {
  if (!Array.isArray(cards) || cards.length !== 5) throw new Error('HAND_NEED_5_CARDS');
  const vals = cards.map(c => c.point);
  const sum = vals.reduce((a, b) => a + b, 0);
  const niu = bestNiu(cards);
  const hasNiu = niu !== null;
  const high = Math.max.apply(null, cards.map(c => c.rank));

  let key = 'NO_NIU';
  if (cards.every(c => c.rank <= 4) && sum <= 10) key = 'WU_XIAO';
  else if (sameRankCount(cards) === 4) key = 'ZHA_DAN';
  else if (cards.every(c => c.rank >= 11)) key = 'WU_HUA';
  else if (hasNiu && allSameSuit(cards)) key = 'TONG_HUA';
  else if (hasNiu) key = niu === 0 ? 'NIU_NIU' : ('NIU_' + niu);

  const type = NG.HAND_TYPES[key] || NG.HAND_TYPES.NO_NIU;
  return {
    key: type.key,
    name: type.name,
    multiplier: type.multiplier,
    order: type.order,
    niu: hasNiu ? niu : null,
    point_value: hasNiu ? (niu === 0 ? 10 : niu) : 0,
    high_rank: high,
    tiebreak: tiebreakValue(cards)
  };
}

/** 比牌：> 0 表示 a 赢，< 0 表示 b 赢，0 = 完全相同（平局） */
function compareHands(a, b) {
  if (a.order !== b.order) return a.order - b.order;
  if (a.tiebreak !== b.tiebreak) return a.tiebreak - b.tiebreak;
  return 0;
}

/** 校验一手牌是否合法（服务端复用，防止前端伪造牌面） */
function validateCards(cards) {
  if (!Array.isArray(cards) || cards.length !== 5) return false;
  const ids = {};
  return cards.every(c => {
    if (!c || !RANK_LABEL[c.rank] || !SUITS[c.suit]) return false;
    if (ids[c.id]) return false;
    ids[c.id] = true;
    return true;
  });
}

/**
 * 结算一局：庄家与每个闲家逐家比牌（全部使用游戏积分，不涉及真实资金）
 * @param {number} baseStake 底分（游戏积分）
 * @param {object} banker  { user_id, hand, points }
 * @param {Array}  players [{ user_id, hand, bet_level, points }]
 * @returns {Array} 结算明细，delta 正=获得积分，负=失去积分；庄家不足时按剩余封顶
 */
function settle(baseStake, banker, players) {
  const base = Number(baseStake);
  if (!Number.isFinite(base) || base <= 0) throw new Error('INVALID_BASE_STAKE');
  const out = [];
  let bankerRemaining = Math.max(0, Number(banker.points || 0));
  let bankerDelta = 0;

  const ordered = players.slice().sort((x, y) => Number(x.user_id) - Number(y.user_id));
  ordered.forEach(p => {
    const level = NG.isValidBetLevel(p.bet_level) ? Number(p.bet_level) : NG.BET_DEFAULT_LEVEL;
    const cmp = compareHands(p.hand, banker.hand);
    const winner = cmp > 0 ? 'PLAYER' : (cmp < 0 ? 'BANKER' : 'DRAW');
    const winnerHand = winner === 'PLAYER' ? p.hand : banker.hand;
    const raw = Number((base * level * (winnerHand.multiplier || 1)).toFixed(2));

    let playerDelta = 0;
    let capped = false;
    if (winner === 'PLAYER') {
      const pay = Math.min(raw, bankerRemaining);
      if (pay < raw) capped = true;
      bankerRemaining = Number((bankerRemaining - pay).toFixed(2));
      playerDelta = pay;
    } else if (winner === 'BANKER') {
      const own = Math.max(0, Number(p.points || 0));
      const pay = Math.min(raw, own);
      if (pay < raw) capped = true;
      playerDelta = -pay;
    }
    bankerDelta = Number((bankerDelta - playerDelta).toFixed(2));

    out.push({
      user_id: Number(p.user_id),
      role: 'PLAYER',
      hand: p.hand,
      hand_key: p.hand.key,
      point_value: p.hand.point_value,
      multiplier: winnerHand.multiplier || 1,
      bet_level: level,
      expect_amount: raw,
      amount: Math.abs(playerDelta),
      delta: playerDelta,
      is_winner: winner === 'PLAYER',
      is_draw: winner === 'DRAW',
      is_capped: capped,
      result: winner
    });
  });

  out.unshift({
    user_id: Number(banker.user_id),
    role: 'BANKER',
    hand: banker.hand,
    hand_key: banker.hand.key,
    point_value: banker.hand.point_value,
    multiplier: 1,
    bet_level: 1,
    expect_amount: Number(out.reduce((s, r) => s + r.expect_amount, 0).toFixed(2)),
    amount: Math.abs(bankerDelta),
    delta: bankerDelta,
    is_winner: bankerDelta > 0,
    is_draw: bankerDelta === 0,
    is_capped: out.some(r => r.is_capped),
    result: bankerDelta > 0 ? 'BANKER' : (bankerDelta < 0 ? 'PLAYER' : 'DRAW')
  });
  return out;
}

module.exports = {
  SUITS,
  RANK_LABEL,
  pointValue,
  buildDeck,
  secureInt,
  shuffle,
  deal,
  bestNiu,
  identifyHand,
  compareHands,
  validateCards,
  settle
};

