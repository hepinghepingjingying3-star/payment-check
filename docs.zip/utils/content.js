// ============================================
// 26牛牛 - 内容聚合工具（公告 / 通知未读数）
// 说明:
//   - 公告来自三处并合并排序: config/announcements.js 内置 + announcements 表 + 旧 system_notices 表
//   - 统一过滤: status=active 且处于 start_at ~ end_at 有效期内
//   - 对外的公告对象绝不包含任何用户敏感信息
// ============================================

const db = require('../config/db');
const A = require('../config/announcements');

/** 读取 announcements 表（表不存在时静默返回空数组） */
async function loadDbAnnouncements() {
  try {
    const [rows] = await db.promise().query(
      `SELECT id, type, title, summary, content, image, status, pinned, sort, start_at, end_at, created_at
       FROM announcements ORDER BY id DESC LIMIT 200`
    );
    return rows.map(r => ({
      id: 'a' + r.id,
      type: r.type,
      title: r.title,
      summary: r.summary || '',
      content: r.content || '',
      image: r.image || null,
      status: r.status,
      pinned: !!r.pinned,
      sort: Number(r.sort) || 0,
      start_at: r.start_at,
      end_at: r.end_at,
      created_at: r.created_at
    }));
  } catch (e) {
    if (e && e.code !== 'ER_NO_SUCH_TABLE') console.error('读取公告表失败:', e.message);
    return [];
  }
}

/** 读取旧 system_notices 表并映射为文字公告 */
async function loadLegacyNotices() {
  try {
    const [rows] = await db.promise().query(
      `SELECT id, title, content, status, created_at FROM system_notices
       ORDER BY id DESC LIMIT 100`
    );
    return rows.map(r => ({
      id: 's' + r.id,
      type: 'system',
      title: r.title,
      summary: String(r.content || '').replace(/\s+/g, ' ').slice(0, 60),
      content: r.content || '',
      image: null,
      status: r.status,
      pinned: false,
      sort: 0,
      start_at: null,
      end_at: null,
      created_at: r.created_at
    }));
  } catch (e) {
    if (e && e.code !== 'ER_NO_SUCH_TABLE') console.error('读取旧公告表失败:', e.message);
    return [];
  }
}

/** 合并 + 过滤 + 排序后的有效公告列表 */
async function loadAnnouncements() {
  const [dbList, legacy] = await Promise.all([loadDbAnnouncements(), loadLegacyNotices()]);
  const merged = A.FALLBACK_ANNOUNCEMENTS.concat(dbList, legacy);
  const now = new Date();
  return A.sortAnnouncements(merged.filter(a => A.isEffective(a, now)));
}

/** 按 id 取单条公告（含正文） */
async function getAnnouncement(id) {
  const list = await loadAnnouncements();
  return list.find(a => String(a.id) === String(id)) || null;
}

/** 未读通知数（供大厅 / 我的 红点） */
async function unreadNotificationCount(userId) {
  try {
    const [rows] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0', [userId]
    );
    return Number(rows[0].c) || 0;
  } catch (e) {
    return 0;
  }
}

/** 实时推送挂钩：server.js 启动时注入（content.setNotifyPush(fn)） */
let notifyPush = null;
function setNotifyPush(fn) { notifyPush = typeof fn === 'function' ? fn : null; }

/** 给用户生成一条通知（尽力而为，失败不影响主流程） */
async function pushNotification(userId, category, title, content, link) {
  let insertId = null;
  try {
    const [rs] = await db.promise().query(
      `INSERT INTO notifications (user_id, category, title, content, link)
       VALUES (?, ?, ?, ?, ?)`,
      [userId, category, String(title).slice(0, 120), content || null, link || null]
    );
    insertId = rs && rs.insertId;
    return true;
  } catch (e) {
    console.error('写入通知失败:', e.message);
    return false;
  } finally {
    // 入库后立即实时推送（Socket.IO 在线用户秒收；离线用户下次打开自动拉取）
    if (insertId && typeof notifyPush === 'function') {
      try {
        notifyPush(userId, {
          id: insertId, category, title: String(title).slice(0, 120),
          content: content || null, link: link || null, created_at: new Date().toISOString()
        });
      } catch (e) { /* 推送失败不影响业务 */ }
    }
  }
}

module.exports = {
  loadAnnouncements,
  getAnnouncement,
  unreadNotificationCount,
  pushNotification,
  setNotifyPush,
  loadDbAnnouncements,
  loadLegacyNotices
};