// ============================================
// 26牛牛 - 极简内存限流（按用户/IP + 动作）
// ============================================
// 用途: 充值/提款下单、凭证上传等写操作防刷；单进程内存计数，重启即清空。
// 说明: 仅作为第一道闸门，数据库层仍有状态机与唯一约束兜底。
// ============================================

const buckets = new Map();

/**
 * @param {string} key 维度键（如 'deposit:user:12'）
 * @param {number} limit 窗口内最大次数
 * @param {number} windowMs 窗口毫秒
 * @returns {{ allowed:boolean, retry_after:number }}
 */
function hit(key, limit, windowMs) {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= limit) {
    buckets.set(key, arr);
    return { allowed: false, retry_after: Math.ceil((windowMs - (now - arr[0])) / 1000) };
  }
  arr.push(now);
  buckets.set(key, arr);
  if (buckets.size > 5000) {   // 简单防内存膨胀
    for (const [k, v] of buckets) {
      if (!v.length || now - v[v.length - 1] > windowMs) buckets.delete(k);
      if (buckets.size <= 2500) break;
    }
  }
  return { allowed: true, retry_after: 0 };
}

/** Express 中间件工厂 */
function limiter(prefix, limit, windowMs) {
  return (req, res, next) => {
    const who = (req.user && req.user.id) ? ('u' + req.user.id) : ('ip' + (req.ip || ''));
    const r = hit(prefix + ':' + who, limit, windowMs);
    if (!r.allowed) {
      res.set('Retry-After', String(r.retry_after));
      return res.status(429).json({ success: false, message: '操作过于频繁，请稍后再试', code: 'RATE_LIMITED' });
    }
    next();
  };
}

module.exports = { hit, limiter };
