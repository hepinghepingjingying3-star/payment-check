'use strict';
// ============================================
// 26牛牛 - 在线状态与 Socket 注册表
// ============================================
// 说明:
//   - 在线 = 最近 ONLINE_WINDOW_SECONDS 秒内活跃（Socket 连接 或 聊天轮询心跳）
//   - 全部数据来自真实连接/心跳，绝不使用「账号总数」冒充在线人数
//   - user_presence 表不存在时降级为「在线人数不可用」（返回 null），不编造数字
//   - 只记录用户ID与时间，不记录 IP / 设备指纹
//   - Socket 注册表保存在进程内存中，用于：
//       · 封禁后主动断开该用户所有连接（admin 操作 → kickUser）
//       · 统计「当前连接数」（服务端真实数据）
// ============================================

const db = require('../config/db');
const MOD = require('../config/moderation');

const WINDOW = MOD.PRESENCE.ONLINE_WINDOW_SECONDS;
const THROTTLE_MS = MOD.PRESENCE.TOUCH_THROTTLE_SECONDS * 1000;
const LIST_LIMIT = MOD.PRESENCE.ONLINE_LIST_LIMIT;

let tableMissing = false;             // 表缺失后不再反复查询
let ioRef = null;                     // Socket.IO 实例
const lastTouch = new Map();          // userId -> 上次写库时间（内存节流）
const socketsByUser = new Map();      // userId -> Set<socket>

/** 注入 Socket.IO 实例（server.js 启动时调用） */
function init(io) {
  ioRef = io || null;
}

function isMissingTableError(err) {
  return !!err && (err.code === 'ER_NO_SUCH_TABLE' || err.errno === 1146);
}

function missingNotice() {
  console.error('user_presence 不存在，在线人数统计已跳过；请运行 node database/migrations/006-presence-approval.js');
}

/**
 * 写一次活跃心跳
 * @param {number} userId
 * @param {object} opts { sockets: +1|-1|0, force: boolean }
 * @returns {Promise<boolean>} 是否写入成功（表缺失时 false）
 */
async function touch(userId, opts) {
  opts = opts || {};
  if (tableMissing) return false;
  const id = Number(userId);
  if (!Number.isSafeInteger(id) || id <= 0) return false;
  const delta = Number(opts.sockets) || 0;
  const now = Date.now();
  const last = lastTouch.get(id) || 0;
  // 无连接数变化时按用户节流，避免聊天轮询把库打满
  if (!opts.force && now - last < THROTTLE_MS) return false;
  lastTouch.set(id, now);
  try {
    await db.promise().query(
      `INSERT INTO user_presence (user_id, last_seen, sockets, first_seen)
       VALUES (?, NOW(), ?, NOW())
       ON DUPLICATE KEY UPDATE last_seen = NOW(), sockets = GREATEST(0, sockets + ?)`,
      [id, Math.max(0, delta), delta]
    );
    return true;
  } catch (err) {
    if (isMissingTableError(err)) { tableMissing = true; missingNotice(); return false; }
    console.error('更新在线状态失败:', err.message);
    return false;
  }
}

/** 当前在线人数（null = 无法统计，绝不返回假数字） */
async function onlineCount() {
  if (tableMissing) return null;
  try {
    const [rows] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM user_presence p
       JOIN users u ON u.id = p.user_id
       WHERE p.last_seen >= DATE_SUB(NOW(), INTERVAL ? SECOND) AND u.status = 'active'`,
      [WINDOW]
    );
    return Number(rows[0] && rows[0].c) || 0;
  } catch (err) {
    if (isMissingTableError(err)) { tableMissing = true; missingNotice(); return null; }
    console.error('统计在线人数失败:', err.message);
    return null;
  }
}

/** 在线用户列表（后台用；返回用户名等非敏感字段） */
async function onlineList(limit) {
  if (tableMissing) return null;
  const n = Math.min(Math.max(Number(limit) || LIST_LIMIT, 1), LIST_LIMIT);
  try {
    const [rows] = await db.promise().query(
      `SELECT p.user_id, p.last_seen, p.sockets, u.username, u.nickname, u.role
       FROM user_presence p JOIN users u ON u.id = p.user_id
       WHERE p.last_seen >= DATE_SUB(NOW(), INTERVAL ? SECOND) AND u.status = 'active'
       ORDER BY p.last_seen DESC LIMIT ?`,
      [WINDOW, n]
    );
    return rows.map(r => ({
      id: Number(r.user_id),
      username: r.username || null,
      nickname: r.nickname || null,
      role: r.role || null,
      last_seen: r.last_seen,
      sockets: Number(r.sockets) || 0
    }));
  } catch (err) {
    if (isMissingTableError(err)) { tableMissing = true; return null; }
    console.error('读取在线用户失败:', err.message);
    return null;
  }
}

/** 某个用户是否在线（null = 未知） */
async function isOnline(userId) {
  if (tableMissing) return null;
  try {
    const [rows] = await db.promise().query(
      `SELECT 1 AS ok FROM user_presence
       WHERE user_id = ? AND last_seen >= DATE_SUB(NOW(), INTERVAL ? SECOND) LIMIT 1`,
      [Number(userId), WINDOW]
    );
    return rows.length > 0;
  } catch (err) {
    if (isMissingTableError(err)) { tableMissing = true; return null; }
    return null;
  }
}

// ---------- Socket 注册表（进程内存） ----------
/** Socket 连接建立后登记（由 socket/gameSocket.js 调用） */
function registerSocket(socket) {
  const id = socket && socket.user ? Number(socket.user.id) : NaN;
  if (!Number.isSafeInteger(id) || id <= 0) return;
  if (!socketsByUser.has(id)) socketsByUser.set(id, new Set());
  socketsByUser.get(id).add(socket);
  touch(id, { sockets: 1, force: true }).catch(() => {});
}

/** Socket 断开后注销 */
function unregisterSocket(socket) {
  const id = socket && socket.user ? Number(socket.user.id) : NaN;
  if (!Number.isSafeInteger(id) || id <= 0) return;
  const set = socketsByUser.get(id);
  if (set) {
    set.delete(socket);
    if (!set.size) socketsByUser.delete(id);
  }
  touch(id, { sockets: -1, force: true }).catch(() => {});
}

/** 服务端当前持有的 Socket 连接数（进程真实数据） */
function socketCount() {
  let n = 0;
  socketsByUser.forEach(set => { n += set.size; });
  return n;
}

/** 服务端当前有 Socket 连接的去重用户数 */
function socketUserCount() {
  return socketsByUser.size;
}

/** 某用户当前的 Socket 连接数 */
function socketsOfUser(userId) {
  const set = socketsByUser.get(Number(userId));
  return set ? set.size : 0;
}

/**
 * 主动断开某用户的所有 Socket 连接（封禁 / 权限回收后调用）
 * 先推送 account:revoked（前端立即提示并跳登录页），再断开连接
 * @returns {number} 断开的连接数
 */
function kickUser(userId, reason) {
  const set = socketsByUser.get(Number(userId));
  const message = reason || '账号状态已变更，请重新登录';
  if (!set || !set.size) return 0;
  let n = 0;
  Array.from(set).forEach(socket => {
    try { socket.emit('account:revoked', { reason: message }); } catch (e) { /* 忽略 */ }
    try {
      setTimeout(function () { try { socket.disconnect(true); } catch (e) { /* 忽略 */ } }, 60);
    } catch (e) { /* 忽略 */ }
    n++;
  });
  return n;
}

/** 表是否可用（后台展示用，不发起查询） */
function available() { return !tableMissing; }

module.exports = {
  init, touch, onlineCount, onlineList, isOnline,
  registerSocket, unregisterSocket, socketCount, socketUserCount, socketsOfUser,
  kickUser, available, WINDOW
};
