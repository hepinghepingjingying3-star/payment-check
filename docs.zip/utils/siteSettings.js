// ============================================
// 26牛牛 - 系统配置中心（读取 / 写入 / 校验 / 缓存）
// 数据来源:
//   - 默认值: config/site.js（代码内集中管理，前端不再硬编码）
//   - 覆盖值: 数据库 system_settings（只存管理员改过的项）
// 设计:
//   - 表不存在或读取失败时一律回退默认值，绝不让站点因配置模块故障而白屏
//   - 写入前按 config/site.js 的定义逐项校验（类型 / 范围 / 长度）
//   - 写入后立即失效缓存，并返回「变化的键」供审计日志记录
// 安全:
//   - 公开接口只暴露 PUBLIC_KEYS（站点名称 / 客服名称 / 充值区间 / 维护模式等），
//     绝不返回任何密钥、数据库信息或内部开关
// ============================================

const db = require('../config/db');
const { SETTINGS, BY_KEY, DEFAULTS, PUBLIC_KEYS } = require('../config/site');

const CACHE_MS = 30 * 1000;
let cache = null;
let cacheAt = 0;

/** 按定义把数据库里的字符串还原成正确类型 */
function castValue(def, raw) {
  if (raw === null || raw === undefined) return def.default;
  let v;
  try { v = JSON.parse(raw); } catch (e) { v = raw; }
  if (def.type === 'number') {
    const n = Number(v);
    return Number.isFinite(n) ? n : def.default;
  }
  if (def.type === 'boolean') return v === true || v === 'true' || v === 1 || v === '1';
  return String(v === null || v === undefined ? '' : v);
}

/**
 * 全部配置（默认值 + 数据库覆盖）
 * 表不可用时返回纯默认值（不抛异常）
 */
async function getAll() {
  const now = Date.now();
  if (cache && now - cacheAt < CACHE_MS) return cache;

  const out = Object.assign({}, DEFAULTS);
  try {
    const [rows] = await db.promise().query('SELECT setting_key, setting_value FROM system_settings');
    rows.forEach(r => {
      const def = BY_KEY[r.setting_key];
      if (def) out[r.setting_key] = castValue(def, r.setting_value);
    });
  } catch (e) {
    // 表不存在 / 数据库异常：使用默认值，并记录一次服务端日志
    console.error('系统配置读取失败（使用默认值）:', e.message);
  }
  cache = out;
  cacheAt = now;
  return out;
}

/** 单项读取 */
async function get(key) {
  const all = await getAll();
  if (Object.prototype.hasOwnProperty.call(all, key)) return all[key];
  return DEFAULTS[key];
}

/** 公开配置（未登录用户可读） */
async function getPublic() {
  const all = await getAll();
  const out = {};
  PUBLIC_KEYS.forEach(k => { out[k] = all[k]; });
  return out;
}

/** 手动失效缓存 */
function invalidate() { cache = null; cacheAt = 0; }

/** 单值校验：返回 { ok, value, message } */
function validateOne(def, raw) {
  if (def.type === 'number') {
    const n = Number(raw);
    if (!Number.isFinite(n)) return { ok: false, message: def.label + '必须是数字' };
    if (def.min !== undefined && n < def.min) return { ok: false, message: def.label + '不能小于 ' + def.min };
    if (def.max !== undefined && n > def.max) return { ok: false, message: def.label + '不能大于 ' + def.max };
    return { ok: true, value: n };
  }
  if (def.type === 'boolean') {
    return { ok: true, value: raw === true || raw === 'true' || raw === 1 || raw === '1' };
  }
  const s = String(raw === null || raw === undefined ? '' : raw).trim();
  if (def.max !== undefined && s.length > def.max) {
    return { ok: false, message: def.label + '最多 ' + def.max + ' 个字符' };
  }
  // Logo 地址：只允许站内相对路径或 https，禁止 javascript: / data: 等可执行协议
  if (def.key === 'logo_url' && s) {
    if (!/^(\/assets\/|\/uploads\/|https:\/\/)/i.test(s)) {
      return { ok: false, message: 'Logo 只允许站内路径（/assets/...）或 https 图片地址' };
    }
  }
  return { ok: true, value: s };
}

/**
 * 批量校验（不写库）：返回 { values, errors }
 * 用于「先校验全部，再统一写入」，避免只写一半
 */
async function validateAll(patch) {
  const values = {};
  const errors = [];
  const current = await getAll();

  Object.keys(patch || {}).forEach(k => {
    const def = BY_KEY[k];
    if (!def) { errors.push('不支持的配置项: ' + k); return; }
    const r = validateOne(def, patch[k]);
    if (!r.ok) { errors.push(r.message); return; }
    values[k] = r.value;
  });

  // 充值区间联动校验：不能出现「最低 > 最高」
  const minKey = 'deposit_min', maxKey = 'deposit_max';
  const min = values[minKey] !== undefined ? values[minKey] : current[minKey];
  const max = values[maxKey] !== undefined ? values[maxKey] : current[maxKey];
  if (Number(min) > Number(max)) errors.push('最低充值金额不能大于最高充值金额');

  return { values, errors };
}

/**
 * 写入配置（管理员）
 * @returns { changed: [key], values }
 */
async function save(patch, adminId) {
  const { values, errors } = await validateAll(patch);
  if (errors.length) {
    const err = new Error(errors.join('；'));
    err.validation = true;
    throw err;
  }
  const keys = Object.keys(values);
  if (!keys.length) return { changed: [], values: {} };

  const current = await getAll();
  const changed = keys.filter(k => String(current[k]) !== String(values[k]));

  const conn = db.promise();
  for (const k of keys) {
    await conn.query(
      `INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
       VALUES (?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value),
                               updated_by = VALUES(updated_by),
                               updated_at = NOW()`,
      [k, JSON.stringify(values[k]), adminId || null]
    );
  }
  invalidate();
  return { changed, values };
}

/** 配置项定义（后台表单渲染用，不含任何敏感默认值） */
function definitions() {
  return SETTINGS.map(s => ({
    key: s.key, label: s.label, type: s.type, group: s.group,
    min: s.min, max: s.max, step: s.step, note: s.note || '', default: s.default
  }));
}

module.exports = { getAll, get, getPublic, save, validateAll, definitions, invalidate, PUBLIC_KEYS };
