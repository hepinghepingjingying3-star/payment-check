'use strict';
// ============================================
// 26牛牛 - 房间状态引擎（后端唯一状态来源，游戏在「26牛牛游戏群」内进行）
// ============================================
// 架构（重要）：聊天群 = 游戏进行场所
//   1. 游戏系统消息写入 chat_messages，channel = 'group'（就是 26牛牛游戏群），
//      并带 room_id / round_id / phase / game_round_pk，所以聊天页知道
//      「这是哪个房间、哪一局、什么阶段」。
//   2. 对局数据复用现有游戏表：game_rooms / game_rounds / room_players / game_results，
//      不新建第二套游戏数据库。
//   3. 状态机只由服务端推进（tick 每秒检查阶段截止时间），前端提交的状态一律忽略。
//   4. 牌堆 / 发牌 / 牌型 / 结算全部由服务端用 crypto 随机 + utils/niuEngine 计算。
//   5. 积分变动一律走 utils/ledger（事务 + 行锁 + 前后余额 + 流水），绝不出现负积分。
//   6. 结算幂等：game_rounds 状态 SETTLEMENT → FINISHED 的 UPDATE 只有一个能成功，
//      且 game_results 有 UNIQUE(round_id, user_id)，重复结算必然失败回滚。
// ============================================

const db = require('../config/db');
const NG = require('../config/niuGame');
const E = require('./niuEngine');
const ledger = require('./ledger');
const siteSettings = require('./siteSettings');
const niuChat = require('./niuChat');
// 26牛牛游戏机器人：消息播报 / 运行总闸门 / 事件幂等 / 话术模板
// （机器人权威在数据库 niu_bot_state，不是管理员浏览器）
const bot = require('./niuBot');

/** 场次 key → 房间运行时状态 */
const rooms = new Map();
/** userId → { roomKey, seat } 单进程内的座位登记（断线重连按此恢复） */
const seatIndex = new Map();

let io = null;
let tickTimer = null;
let tickFails = 0;

function nowMs() { return Date.now(); }

/** 游戏是否开启（读取系统设置中心，30 秒缓存；数据库异常时按关闭处理更安全） */
async function isEnabled() {
  try {
    const v = await siteSettings.get(NG.SWITCHES.DB_KEY);
    return v === true;
  } catch (_) {
    return !!NG.SWITCHES.DEFAULT_ENABLED;
  }
}

function roomOf(key) {
  const cfg = NG.roomByKey(key);
  if (!cfg) return null;
  let r = rooms.get(cfg.key);
  if (!r) {
    r = {
      key: cfg.key,
      cfg: cfg,
      phase: NG.PHASE.WAITING,
      phaseEndsAt: nowMs() + NG.TIMERS.WAITING * 1000,
      players: new Map(),
      seatSeq: 0,
      bankerId: 0,
      rotation: 0,
      round: null,          // { rowId, roundNo, results, participants }
      notices: [],
      lastActiveAt: nowMs(),
      settling: false
    };
    rooms.set(cfg.key, r);
  }
  return r;
}

/** Socket 内部推送房间名（聊天频道是 'chat:group'，两者互不混淆） */
function channel(r) { return NG.CHAT.SOCKET_ROOM_PREFIX + r.key; }

/** 广播给房间内所有连接（Socket 房间名 = niu:<roomKey>） */
function emitRoom(r, event, payload) {
  if (!io) return;
  try { io.to(channel(r)).emit(event, payload); } catch (_) { /* 推送失败不影响状态机 */ }
}

/** 只发给某个人（手牌、积分等隐私数据） */
function emitUser(r, userId, event, payload) {
  if (!io) return;
  try { io.to('niu:u' + Number(userId)).emit(event, payload); } catch (_) {}
}

/** 游戏群频道：与 routes/chat.js 的 GROUP_CHANNEL 完全一致（聊天群 = 游戏场所） */
const GROUP_CHANNEL = 'group';

/** 场次 key → game_rooms.id（延迟加载，启动后首次访问时读库） */
const roomIdCache = new Map();

/** 取（并缓存）场次对应的 game_rooms.id */
async function gameRoomId(r) {
  if (r.dbRoomId) return r.dbRoomId;
  const cached = roomIdCache.get(r.key);
  if (cached) { r.dbRoomId = cached; return cached; }
  const [rows] = await db.promise().query(
    'SELECT id FROM game_rooms WHERE room_key = ? LIMIT 1', [r.key]
  );
  const id = rows.length ? Number(rows[0].id) : 0;
  if (id) roomIdCache.set(r.key, id);
  r.dbRoomId = id;
  return id;
}

/**
 * 写入一条 26牛牛游戏系统消息到「26牛牛游戏群」
 * 唯一写入口：utils/niuChat.postGameMessage（严禁在别处再写 message_type='game'）
 * 因此每条游戏消息必然：
 *   1) 真的落库 chat_messages（message_type='game'），刷新页面仍然看得到
 *   2) 带 room_id / round_id / phase，聊天页据此判断属于哪间房、哪一局、哪个阶段
 *   3) 推给 chat:group（与普通聊天同一条消息流）
 * 失败只记录日志，绝不影响状态机推进。
 */
async function say(r, text, opts) {
  const o = opts || {};
  const content = String(text || '').slice(0, NG.LIMITS.CHAT_NOTICE_MAX);
  const phase = o.phase || r.phase;
  const roomId = await gameRoomId(r).catch(() => 0);
  const round = r.round;

  const meta = {
    game: '26niuniu',
    room_key: r.key,
    room_name: r.cfg.name,
    phase: phase,
    phase_text: NG.PHASE_TEXT[phase] || phase,
    kind: o.kind || 'phase'
  };

  let msg = null;
  try {
    // 走机器人通道：受「自动播报」开关控制 + 事件幂等（同局同事件只发一次）。
    // o.auto === false 时即使自动播报关闭也强制发（例如管理员手动播报）。
    msg = await bot.botSay({
      content: content,
      room_pk: roomId,
      round_pk: round ? round.rowId : null,
      round_id: round ? String(round.roundNo || '') : null,
      phase: phase,
      event_type: o.event_type || null,
      auto: o.auto !== false,
      meta: meta,
      io: io
    });
    if (o.event_type) {
      // 阶段播报落库结果：机器人关闭 / 事件已幂等认领时 msg 为 null，属正常静默，
      // 打一条 DEBUG 级日志便于线上排查「群里为什么没播报」。
      console.log('[niu] 播报 ' + o.event_type + ' → ' + (msg ? ('已发 msg#' + msg.id) : '已跳过（幂等或自动播报关闭）') +
        ' phase=' + phase + ' round=' + (round ? round.roundNo : '-'));
    }
  } catch (e) {
    console.error('[niu] 游戏消息入库失败:', e.message);
  }
  // 额外推给订阅了本场次的 Socket（带完整阶段信息，供操作卡片刷新）
  emitRoom(r, 'niu:chat', msg || { content: content, meta: meta });
  return msg;
}

/**
 * 机器人状态是「自动推进」的唯一总闸门。
 * 管理员在后台停止机器人后：不再开新局、不再推进阶段，
 * 但聊天群照常可用、历史消息保留、当前状态保留，再次启动即可继续。
 * 注意：结算中的一次性收尾（settleRound）不受此闸门影响，
 * 否则会出现「已发牌但永不结算」的悬挂积分。
 */
async function botRunning() {
  try {
    return await bot.isRunning();
  } catch (_) {
    return false;
  }
}

/** 取一条机器人话术模板（后台可改；失败时回落代码默认值，绝不因配置问题中断状态机） */
async function botLine(key, vars) {
  try {
    return await bot.line(key, vars || {});
  } catch (_) {
    return NG.CHAT.LINES[key] || '';
  }
}

/** 简短同步提示（不发群消息，只广播给本场次订阅者） */
function notice(r, text) {
  const item = { text: String(text || '').slice(0, NG.LIMITS.CHAT_NOTICE_MAX), at: new Date().toISOString() };
  r.notices.push(item);
  if (r.notices.length > 30) r.notices.shift();
  emitRoom(r, 'niu:notice', item);
}


/** 座位公开视图（不含手牌） */
function seatView(r, p) {
  return {
    user_id: p.userId,
    username: p.username,
    nickname: p.nickname || p.username,
    avatar_id: p.avatarId || null,
    seat_no: p.seat,
    points: p.points,
    grab: p.grab,
    bet_level: p.bet_level,
    online: p.sockets.size > 0,
    role: r.bankerId === p.userId ? 'BANKER' : 'PLAYER',
    ready: p.ready
  };
}

/** 个人视角快照：只有自己的手牌，其它人在 RESULT 之后才公开 */
function snapshot(r, userId) {
  const me = r.players.get(Number(userId));
  const open = r.phase === NG.PHASE.RESULT || r.phase === NG.PHASE.SETTLEMENT || r.phase === NG.PHASE.FINISHED;
  const list = Array.from(r.players.values()).sort((a, b) => a.seat - b.seat).map(p => {
    const v = seatView(r, p);
    if (open && p.hand) {
      v.cards = p.cards;
      v.hand_key = p.hand.key;
      v.hand_name = p.hand.name;
      v.point_value = p.hand.point_value;
    }
    return v;
  });
  return {
    room_key: r.key,
    room_name: r.cfg.name,
    base_stake: r.cfg.base_stake,
    seat_limit: seatLimit(r),
    min_players: NG.PLAYERS.MIN,
    phase: r.phase,
    phase_text: NG.PHASE_TEXT[r.phase],
    phase_ends_at: new Date(r.phaseEndsAt).toISOString(),
    server_now: new Date().toISOString(),
    round_no: r.round ? r.round.roundNo : null,
    banker_id: r.bankerId || null,
    players: list,
    notices: r.notices.slice(-10),
    my: me ? {
      seat_no: me.seat,
      points: me.points,
      grab: me.grab,
      grab_locked: !!me.grabLocked,
      bet_level: me.bet_level,
      cards: me.cards || null,
      hand_key: me.hand ? me.hand.key : null,
      hand_name: me.hand ? me.hand.name : null,
      point_value: me.hand ? me.hand.point_value : null
    } : null,
    bet_levels: NG.BET_LEVELS.slice(),
    phase_seconds: Object.assign({}, NG.TIMERS)
  };
}

function seatLimit(r) {
  return Math.min(NG.PLAYERS.HARD_MAX, Number(r.cfg.seat_limit) || NG.PLAYERS.DEFAULT_MAX);
}

/** 推送全房间：座位 + 阶段（前端只需渲染，不做任何判断） */
function broadcast(r, userIdForPrivate) {
  emitRoom(r, 'niu:state', { phase: r.phase, phase_text: NG.PHASE_TEXT[r.phase], seats: Array.from(r.players.values()).sort((a, b) => a.seat - b.seat).map(p => seatView(r, p)), banker_id: r.bankerId || null, round_no: r.round ? r.round.roundNo : null });
  emitRoom(r, 'niu:phase', {
    phase: r.phase, phase_text: NG.PHASE_TEXT[r.phase],
    ends_at: new Date(r.phaseEndsAt).toISOString(), server_now: new Date().toISOString()
  });
  if (userIdForPrivate) {
    const one = r.players.get(Number(userIdForPrivate));
    if (one) emitUser(r, one.userId, 'niu:private', { cards: one.cards || null, hand: one.hand || null });
  }
}


// ============================================
// 玩家资料 / 每日免费积分
// ============================================

/** 读取玩家展示资料与当前游戏积分（每次都读库，避免内存积分过期） */
async function loadProfile(userId) {
  const [rows] = await db.promise().query(
    `SELECT id, username, nickname, avatar_id, game_points FROM users WHERE id = ? AND status = 'active' LIMIT 1`,
    [Number(userId)]
  );
  if (!rows.length) return null;
  const u = rows[0];
  return {
    userId: Number(u.id),
    username: String(u.username || ''),
    nickname: u.nickname ? String(u.nickname) : String(u.username || ''),
    avatarId: u.avatar_id ? Number(u.avatar_id) : null,
    points: Number(u.game_points || 0)
  };
}

/**
 * 每日免费游戏积分：积分低于下限才补发，同一天只发一次（靠 daily_free_date 判断）
 * 幂等：用一条 INSERT ... ON DUPLICATE KEY UPDATE 原子认领当天名额
 * （affectedRows: 1=首次建行 2=当天名额认领成功 0=当天已领过）
 */
async function grantDailyFree(userId) {
  const uid = Number(userId);
  const conn = await db.promise().getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT game_points FROM users WHERE id = ? FOR UPDATE', [uid]);
    if (!rows.length) { await conn.rollback(); return { granted: 0, points: 0 }; }
    const points = Number(rows[0].game_points || 0);
    if (points >= NG.POINTS.DAILY_FREE.TRIGGER_BELOW) { await conn.rollback(); return { granted: 0, points: points }; }
    await conn.query(
      `INSERT INTO niu_user_stats (user_id, daily_free_date) VALUES (?, '1970-01-01')
       ON DUPLICATE KEY UPDATE user_id = user_id`, [uid]);
    const [claim] = await conn.query(
      `UPDATE niu_user_stats SET daily_free_date = CURDATE()
       WHERE user_id = ? AND (daily_free_date IS NULL OR daily_free_date < CURDATE())`, [uid]);
    if (!claim.affectedRows) { await conn.rollback(); return { granted: 0, points: points }; }
    const r = await ledger.applyBalance(conn, {
      userId: uid,
      delta: NG.POINTS.DAILY_FREE.AMOUNT,
      type: NG.POINTS.LEDGER_TYPES.DAILY_FREE,
      reason: NG.POINTS.LEDGER_TYPE_TEXT.POINTS_DAILY,
      currencyType: NG.POINTS.ASSET
    });
    await conn.commit();
    return { granted: NG.POINTS.DAILY_FREE.AMOUNT, points: r.balance_after };
  } catch (err) {
    await conn.rollback().catch(() => {});
    console.error('[niu] 每日免费积分发放失败:', err.message);
    return { granted: 0, points: 0, error: true };
  } finally {
    conn.release();
  }
}

// ============================================
// 加入座位
// ============================================

/** 加入座位（返回 { ok, message, snapshot }；不把异常抛到路由外） */
async function join(key, userId) {
  const r = roomOf(key);
  if (!r) return { ok: false, code: 'ROOM_NOT_FOUND', message: '场次不存在' };
  if (!(await isEnabled())) return { ok: false, code: 'GAME_DISABLED', message: NG.SWITCHES.DISABLED_MESSAGE };

  const uid = Number(userId);
  const prof = await loadProfile(uid);
  if (!prof) return { ok: false, code: 'ACCOUNT_UNAVAILABLE', message: '账号不可用' };

  // 同一账号只能占一个座位；已在房间内则直接返回当前状态（刷新 / 重连场景）
  const holder = seatIndex.get(uid);
  if (holder && holder.roomKey !== r.key) {
    const other = rooms.get(holder.roomKey);
    if (other && other.players.has(uid)) {
      return { ok: false, code: 'IN_OTHER_ROOM', message: '你已在「' + other.cfg.name + '」，请先离开' };
    }
    seatIndex.delete(uid);
  }

  let p = r.players.get(uid);
  if (!p) {
    if (r.players.size >= seatLimit(r)) return { ok: false, code: 'ROOM_FULL', message: '座位已满' };
    if (r.round && r.round.participants.length >= seatLimit(r)) return { ok: false, code: 'ROUND_FULL', message: '本局人数已满，请下一局加入' };
    // 进入门槛只看游戏积分（没有充值入口：只有每日免费积分与管理员发放）
    const need = Number(r.cfg.base_stake) * NG.BET_DEFAULT_LEVEL;
    const gate = Math.max(Number(r.cfg.min_points) || 0, need);
    if (gate > 0 && prof.points < gate) {
      return {
        ok: false, code: 'NEED_POINTS',
        message: '进入' + r.cfg.name + '需要至少 ' + gate + ' 游戏积分，当前 ' + prof.points.toFixed(2) +
          '（积分不足时可在大厅领取每日免费积分）'
      };
    }
    r.seatSeq = (r.seatSeq || 0) + 1;
    p = {
      userId: uid, username: prof.username, nickname: prof.nickname, avatarId: prof.avatarId,
      seat: r.seatSeq % seatLimit(r), points: prof.points,
      grab: NG.GRAB.NO, bet_level: NG.BET_DEFAULT_LEVEL,
      cards: null, hand: null, sockets: new Set(), ready: false, left: false
    };
    r.players.set(uid, p);
    seatIndex.set(uid, { roomKey: r.key, seat: p.seat });
    r.lastActiveAt = nowMs();
    notice(r, prof.nickname + ' 进入' + r.cfg.name);
  } else {
    p.username = prof.username; p.nickname = prof.nickname; p.avatarId = prof.avatarId;
    p.points = prof.points; p.left = false;
    seatIndex.set(uid, { roomKey: r.key, seat: p.seat });
  }
  broadcast(r, uid);
  return { ok: true, snapshot: snapshot(r, uid) };
}

// ============================================
// 离开 / 抢庄 / 倍数
// ============================================

function playerName(r, uid) {
  const p = r.players.get(Number(uid));
  return p ? p.nickname : null;
}

/** 离开座位：对局进行中则退出本局（人数不足时本局作废，不产生任何积分变动） */
async function leave(key, userId) {
  const r = roomOf(key);
  if (!r) return { ok: false, code: 'ROOM_NOT_FOUND', message: '场次不存在' };
  const uid = Number(userId);
  const p = r.players.get(uid);
  if (!p) return { ok: true, message: '已离开' };

  if (r.round && r.round.participants.indexOf(uid) !== -1) {
    r.round.participants = r.round.participants.filter(x => x !== uid);
    p.left = true;
    if (r.round.participants.length < NG.PLAYERS.MIN) {
      await abortRound(r, '玩家离开导致人数不足，本局作废（不结算积分）');
    } else if (r.bankerId === uid) {
      const rest = r.round.participants.filter(x => x !== uid);
      r.bankerId = rest.length ? rest[0] : 0;
      notice(r, '庄家离开，本局庄家改为 ' + (playerName(r, r.bankerId) || '-'));
    }
  }
  r.players.delete(uid);
  seatIndex.delete(uid);
  r.lastActiveAt = nowMs();
  notice(r, p.nickname + ' 离开' + r.cfg.name);
  broadcast(r);
  return { ok: true, message: '已离开' };
}

/** 抢庄（只在 GRABBING 阶段有效，重复提交以第一次为准） */
function setGrab(key, userId, flag) {
  const r = roomOf(key);
  if (!r) return { ok: false, code: 'ROOM_NOT_FOUND', message: '场次不存在' };
  if (r.phase !== NG.PHASE.GRABBING) return { ok: false, code: 'WRONG_PHASE', message: '当前不是抢庄阶段' };
  const p = r.players.get(Number(userId));
  if (!p) return { ok: false, code: 'NOT_IN_ROOM', message: '你不在该场次' };
  if (p.grabLocked) return { ok: false, code: 'ALREADY_SUBMITTED', message: '本局已提交抢庄选择' };
  p.grab = flag ? NG.GRAB.YES : NG.GRAB.NO;
  p.grabLocked = true;
  emitRoom(r, 'niu:grab_update', { user_id: p.userId, grab: p.grab });
  return { ok: true, grab: p.grab };
}

/** 选择倍数（只在 BETTING 阶段有效，可修改，服务端白名单校验） */
function setBet(key, userId, level) {
  const r = roomOf(key);
  if (!r) return { ok: false, code: 'ROOM_NOT_FOUND', message: '场次不存在' };
  if (r.phase !== NG.PHASE.BETTING) return { ok: false, code: 'WRONG_PHASE', message: '当前不是选择倍数阶段' };
  const p = r.players.get(Number(userId));
  if (!p) return { ok: false, code: 'NOT_IN_ROOM', message: '你不在该场次' };
  if (!NG.isValidBetLevel(level)) return { ok: false, code: 'INVALID_BET', message: '倍数不合法' };
  const lv = Number(level);
  if (!Number.isFinite(lv) || lv < 0 || lv > 99) return { ok: false, code: 'INVALID_BET', message: '倍数不合法' };
  p.bet_level = lv;
  p.ready = true;
  emitRoom(r, 'niu:bet_update', { user_id: p.userId, bet_level: lv });
  // 全部闲家都选完 → 立即进入发牌，不必等倒计时结束
  const waiting = r.round && r.round.participants.filter(uid => uid !== r.bankerId)
    .map(uid => r.players.get(uid)).filter(x => x && !x.ready);
  if (r.round && !waiting.length) {
    r.phaseEndsAt = nowMs() + 600;
  }
  return { ok: true, bet_level: lv };
}

/** 座位 socket 登记（个人定向推送 + 在线状态） */
function attachSocket(key, userId, socketId) {
  const r = roomOf(key);
  const p = r && r.players.get(Number(userId));
  if (!r || !p) return false;
  p.sockets.add(String(socketId));
  return true;
}

function detachSocket(key, userId, socketId) {
  const r = roomOf(key);
  const p = r && r.players.get(Number(userId));
  if (!r || !p) return false;
  p.sockets.delete(String(socketId));
  return true;
}

/** 个人视角（路由在 REST 里也要能取到） */
function stateFor(key, userId) {
  const r = roomOf(key);
  if (!r) return null;
  return snapshot(r, userId);
}

function isSeated(userId) {
  const h = seatIndex.get(Number(userId));
  if (!h) return null;
  const r = rooms.get(h.roomKey);
  return r && r.players.has(Number(userId)) ? h.roomKey : null;
}


// ============================================
// 状态机（服务端推进）
// ============================================

function setPhase(r, phase, seconds) {
  // 注意：这里必须先把参数落成一个常量再复用，否则下面 catch 分支里再声明同名
  // const 会形成暂时性死区（Cannot access 'seconds' before initialization），
  // 导致每次 setPhase 都抛错、状态机推进被中断（表现为群内只有第一条消息）。
  const secs = Math.max(1, Number(seconds) || 1);
  r.phase = phase;
  r.phaseEndsAt = nowMs() + secs * 1000;
  broadcast(r);
  // 数据库同步记录真实阶段 + 阶段截止时间（服务器重启后据此恢复，绝不重新开局）
  // 注意：截止时间用 MySQL 侧 NOW() + 秒数 计算，避免 JS Date 对象被驱动按本地时区字符串化，
  // 导致重启恢复时无法解析、阶段被反复重置。
  if (r.round && !r.round.settled) {
    db.promise().query(
      `UPDATE game_rounds
          SET phase = ?, status = ?, phase_ends_at = DATE_ADD(NOW(), INTERVAL ? SECOND),
              started_at = COALESCE(started_at, NOW())
        WHERE id = ? AND status NOT IN ('FINISHED','ABORTED')`,
      [phase, phase, secs, r.round.rowId]
    ).catch(e => console.error('[niu] 阶段写入失败:', e.message));
  }
  // 机器人状态（后台面板实时显示「当前阶段 / 预计结束时间」）
  bot.trackRound({
    room_key: r.key,
    chat_channel: GROUP_CHANNEL,
    round_id: r.round ? String(r.round.roundNo || '') : null,
    round_pk: r.round ? r.round.rowId : null,
    phase: phase,
    ends_in_seconds: secs
  }).catch(() => {});
}

/**
 * 能参与本局的最低积分（底分 × 最小倍数）
 * 结算时若某方积分不足会按实际积分封顶（不会变负数），但如果所有人都付不起
 * 就会出现「一局全 0 结算」的空对局，所以开局前先在 WAITING 阶段挡住。
 */
function affordableCount(r) {
  const need = Number(r.cfg.base_stake) * NG.BET_DEFAULT_LEVEL;
  let n = 0;
  r.players.forEach(p => { if (Number(p.points || 0) >= need) n++; });
  return n;
}

/** 开局：写入现有 game_rounds + room_players 座位（不新建第二套游戏表） */
async function startRound(r) {
  const participants = Array.from(r.players.keys()).sort((a, b) => a - b);
  if (participants.length < NG.PLAYERS.MIN) {
    setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
    return;
  }
  const roomPk = await gameRoomId(r);
  if (!roomPk) {
    // 没有 game_rooms 记录就绝不开局（避免产生无法追溯的野对局）
    setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
    notice(r, '游戏房间尚未初始化，请联系管理员');
    return;
  }
  const roundNo = 'NIU' + Date.now().toString(36).toUpperCase() + '-' + String(E.secureInt(900) + 100);
  let rowId = 0;
  try {
    // uq_game_rounds_active 是数据库层闸门：同一房间同一时间只允许一个进行中的局。
    // 重复启动 / 并发 tick / 多实例部署都在这里被挡住，绝不会开出第二局。
    const [ins] = await db.promise().query(
      `INSERT INTO game_rounds
         (round_id, room_id, room_key, base_stake, player_count, chat_channel, status, phase,
          packet_type, started_at, phase_ends_at)
       VALUES (?, ?, ?, ?, ?, ?, 'GRABBING', 'GRABBING', 'PLATFORM', NOW(), ?)`,
      [roundNo, roomPk, r.key, r.cfg.base_stake, participants.length, GROUP_CHANNEL,
        new Date(nowMs() + NG.TIMERS.GRABBING * 1000)]
    );
    rowId = Number(ins.insertId);
  } catch (e) {
    // 唯一闸门命中（该场次已有进行中的局）：不重复开局，等现有局结束后自然进入下一轮
    if (e && e.code === 'ER_DUP_ENTRY') {
      console.log('[niu] 已有进行中的局（' + r.key + '），跳过重复开局');
      r.phaseEndsAt = nowMs() + NG.TIMERS.WAITING * 1000;
      return;
    }
    throw e;
  }
  if (!rowId) {
    setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
    return;
  }
  // 座位写入现有 room_players（UNIQUE(room_id,user_id) 保证一人一座位）
  for (const uid of participants) {
    const p = r.players.get(uid);
    // eslint-disable-next-line no-await-in-loop
    await db.promise().query(
      `INSERT INTO room_players (room_id, round_id, user_id, role, bet_level, grab_flag, status)
       VALUES (?, ?, ?, 'PLAYER', ?, 0, 'ACTIVE')
       ON DUPLICATE KEY UPDATE round_id = VALUES(round_id), role = 'PLAYER',
         bet_level = VALUES(bet_level), grab_flag = 0, status = 'ACTIVE', left_at = NULL`,
      [roomPk, roundNo, uid, p ? p.bet_level : NG.BET_DEFAULT_LEVEL]
    );
  }
  r.round = { rowId: rowId, roomPk: roomPk, roundNo: roundNo, participants: participants, settled: false, reveal: null };
  r.roundStartedAt = nowMs();
  r.bankerId = 0;
  participants.forEach(uid => {
    const p = r.players.get(uid);
    if (!p) return;
    p.grab = NG.GRAB.NO; p.grabLocked = false;
    p.bet_level = NG.BET_DEFAULT_LEVEL; p.ready = false;
    p.cards = null; p.hand = null;
  });
  notice(r, '第 ' + roundNo + ' 局开始，请选择是否抢庄');
  setPhase(r, NG.PHASE.GRABBING, NG.TIMERS.GRABBING);

  // ===== 游戏在聊天群里进行：机器人播报「新一局开始」→「开始抢庄」=====
  // event_type 由 round_id 参与唯一键，重启 / 重复启动都不会重复播报
  await say(r, await botLine('round_start', { room: r.cfg.name, players: String(participants.length) }),
    { phase: NG.PHASE.GRABBING, kind: 'round_start', event_type: 'round_start' });
  await say(r, await botLine('grab_start'),
    { phase: NG.PHASE.GRABBING, kind: 'grab_start', event_type: 'grab_start' });
}

/** 定庄：抢庄者中随机（服务器安全随机）；无人抢庄则按座位轮换 */
function pickBanker(r) {
  const grabbers = r.round.participants.filter(uid => {
    const p = r.players.get(uid);
    return p && p.grab === NG.GRAB.YES;
  });
  let banker = 0;
  if (grabbers.length) banker = grabbers[E.secureInt(grabbers.length)];
  else {
    banker = r.round.participants[r.rotation % r.round.participants.length];
    r.rotation = (r.rotation + 1) % Math.max(1, r.round.participants.length);
  }
  r.bankerId = Number(banker);
  return r.bankerId;
}

/** 发牌：服务器洗牌 + 只有本人能看到自己的牌 */
function dealCards(r) {
  const ids = r.round.participants.slice();
  const d = E.deal(E.buildDeck(), ids);
  ids.forEach(uid => {
    const p = r.players.get(uid);
    if (!p) return;
    p.cards = d.hands[String(uid)] || [];
    p.hand = E.identifyHand(p.cards);
  });
}

/** 公开亮牌（含牌型与点数），仍然按「与庄家比牌」的结果排序展示 */
function revealHands(r) {
  const list = r.round.participants.map(uid => {
    const p = r.players.get(uid);
    if (!p || !p.hand) return null;
    return {
      user_id: p.userId, nickname: p.nickname, avatar_id: p.avatarId,
      role: r.bankerId === p.userId ? 'BANKER' : 'PLAYER',
      cards: p.cards, hand_key: p.hand.key, hand_name: p.hand.name,
      point_value: p.hand.point_value, multiplier: p.hand.multiplier, bet_level: p.bet_level
    };
  }).filter(Boolean);
  r.round.reveal = list;
  emitRoom(r, 'niu:reveal', { round_no: r.round.roundNo, list: list });
  return list;
}

/** 本局作废：不产生任何积分变动，只做状态标记 */
async function abortRound(r, reason) {
  if (r.round && !r.round.settled) {
    await db.promise().query(
      `UPDATE game_rounds SET status = 'ABORTED'
       WHERE id = ? AND status NOT IN ('FINISHED','ABORTED')`,
      [r.round.rowId]
    ).catch(e => console.error('[niu] 作废对局失败:', e.message));
    await db.promise().query(
      `UPDATE room_players SET status = 'LEFT', left_at = NOW()
       WHERE room_id = ? AND round_id = ? AND status = 'ACTIVE'`,
      [r.round.roomPk, r.round.roundNo]
    ).catch(() => {});
    await say(r, reason, { phase: NG.PHASE.WAITING, kind: 'abort' });
  }
  r.round = null;
  r.bankerId = 0;
  r.players.forEach(p => { p.cards = null; p.hand = null; p.ready = false; p.grabLocked = false; });
  setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
}

/** 推进一个阶段（唯一入口） */
async function advance(r) {
  switch (r.phase) {
    case NG.PHASE.WAITING: {
      // 机器人已停止：不自动开局。聊天群继续可用，已有状态与历史全部保留。
      if (!(await botRunning())) { r.phaseEndsAt = nowMs() + NG.TIMERS.WAITING * 1000; return; }
      if (!io) return;
      const need = Number(r.cfg.base_stake) * NG.BET_DEFAULT_LEVEL;
      const shortPoints = r.players.size >= NG.PLAYERS.MIN && affordableCount(r) < NG.PLAYERS.MIN;
      if (r.players.size < NG.PLAYERS.MIN || shortPoints) {
        // 人不够 / 积分不够开一局：继续等待，把倒计时重新拉满，绝不空转出 0 结算的对局
        r.phaseEndsAt = nowMs() + NG.TIMERS.WAITING * 1000;
        emitRoom(r, 'niu:phase', {
          phase: r.phase, phase_text: NG.PHASE_TEXT[r.phase],
          ends_at: new Date(r.phaseEndsAt).toISOString(), server_now: new Date().toISOString(),
          need: r.players.size < NG.PLAYERS.MIN ? NG.PLAYERS.MIN - r.players.size : 0,
          need_points: shortPoints ? need : 0,
          blocked_reason: shortPoints ? ('至少需要 ' + NG.PLAYERS.MIN + ' 位积分不少于 ' + need + ' 的玩家') : null
        });
        // 积分可能已被领走：每 30 秒从数据库刷新一次，避免玩家领到积分后还要干等
        if (shortPoints && (!r.lastPointsCheckAt || nowMs() - r.lastPointsCheckAt > 30000)) {
          r.lastPointsCheckAt = nowMs();
          await refreshPoints(r).catch(() => {});
        }
        return;
      }
      await startRound(r);
      return;
    }
    case NG.PHASE.GRABBING: {
      const banker = pickBanker(r);
      notice(r, (playerName(r, banker) || '-') + ' 成为本局庄家');
      setPhase(r, NG.PHASE.BETTING, NG.TIMERS.BETTING);
      // ===== 抢庄结束 → 定庄 → 选择倍数 =====
      // 每条都带 event_type：同局同事件只会发一次，重启 / 重复启动都不会刷屏
      await say(r, await botLine('grab_end'),
        { phase: NG.PHASE.GRABBING, kind: 'grab_end', event_type: 'grab_end' });
      await say(r, (await botLine('banker_is', { name: playerName(r, banker) || '-' })),
        { phase: NG.PHASE.BETTING, kind: 'banker', event_type: 'banker' });
      await say(r, (await botLine('bet_start')) + '（可用倍数：' + NG.betLevelsText() + '）',
        { phase: NG.PHASE.BETTING, kind: 'bet_start', event_type: 'bet_start' });
      return;
    }
    case NG.PHASE.BETTING: {
      // 未提交的玩家按默认倍数（服务端兜底，绝不因前端掉线卡住）
      r.round.participants.forEach(uid => {
        const p = r.players.get(uid);
        if (!p) return;
        if (!NG.isValidBetLevel(p.bet_level)) p.bet_level = NG.BET_DEFAULT_LEVEL;
      });
      dealCards(r);
      notice(r, '庄家已发牌，各闲家已完成倍数选择');
      setPhase(r, NG.PHASE.DEALING, NG.TIMERS.DEALING);
      // ===== 后端发牌（牌型与结果仍全部由服务端计算）=====
      await say(r, await botLine('deal_done'),
        { phase: NG.PHASE.DEALING, kind: 'deal', event_type: 'deal_done' });
      return;
    }
    case NG.PHASE.DEALING: {
      const list = revealHands(r);
      setPhase(r, NG.PHASE.RESULT, NG.TIMERS.RESULT);
      // ===== 在群里公布每个人的牌型与点数（先公布牌型，手牌细节仍按人私下可见）=====
      await say(r, await botLine('result'),
        { phase: NG.PHASE.RESULT, kind: 'result', event_type: 'result' });
      for (const x of list) {
        const who = (x.role === 'BANKER' ? '庄家 ' : '') + (x.nickname || x.user_id);
        await say(r, '　' + who + '：' + x.hand_name + ' · 点数 ' + x.point_value +
          ' · ' + x.multiplier + ' 倍', { phase: NG.PHASE.RESULT, kind: 'reveal_row' });
      }
      return;
    }
    case NG.PHASE.RESULT:
      // 先把数据库状态推到 SETTLEMENT，再交给 settleRound 用状态闸门保证只结算一次
      await db.promise().query(
        `UPDATE game_rounds SET status = 'SETTLEMENT' WHERE id = ? AND status NOT IN ('FINISHED','ABORTED')`,
        [r.round.rowId]
      );
      r.phase = NG.PHASE.SETTLEMENT;
      r.phaseEndsAt = nowMs() + NG.TIMERS.SETTLEMENT * 1000;
      broadcast(r);
      await settleRound(r);
      return;
    case NG.PHASE.SETTLEMENT:
      setPhase(r, NG.PHASE.FINISHED, NG.TIMERS.FINISHED);
      return;
    case NG.PHASE.FINISHED:
      await refreshPoints(r);
      // ===== 本局游戏结束（聊天群）→ 下一局预告 → 等待新一局 =====
      await say(r, await botLine('round_end'),
        { phase: NG.PHASE.FINISHED, kind: 'round_end', event_type: 'round_end' });
      await say(r, await botLine('next_round'),
        { phase: NG.PHASE.FINISHED, kind: 'next_round', event_type: 'next_round' });
      r.round = null;
      r.bankerId = 0;
      r.players.forEach(p => { p.cards = null; p.hand = null; p.ready = false; p.grabLocked = false; p.grab = NG.GRAB.NO; });

      setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
      return;
    default:
      setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
  }
}


// ============================================
// 结算（事务 + 幂等闸门 + 统一流水）
// ============================================

async function settleRound(r) {
  const round = r.round;
  if (!round || round.settled || r.settling) return;
  const ids = round.participants.filter(uid => {
    const p = r.players.get(uid);
    return !!(p && p.hand);                 // 只结算真正拿到牌的玩家，绝不凭空产生积分
  }).sort((a, b) => a - b);
  if (ids.length < NG.PLAYERS.MIN || ids.indexOf(r.bankerId) === -1) {
    await abortRound(r, '参与人数不足，本局作废（不结算积分）');
    return;
  }
  r.settling = true;
  const conn = await db.promise().getConnection();
  try {
    await conn.beginTransaction();
    // 幂等闸门：只有把本局从 SETTLEMENT 推到 FINISHED 的执行才能写积分
    const [gate] = await conn.query(
      `UPDATE game_rounds SET status = 'FINISHED', banker_id = ?, updated_at = NOW()
       WHERE id = ? AND status = 'SETTLEMENT'`, [r.bankerId, round.rowId]);
    if (!gate.affectedRows) {
      await conn.rollback();
      round.settled = true;                       // 已结算（或已作废）：不再重复
      return;
    }
    // 按 user_id 升序加行锁，避免交叉死锁
    const [urows] = await conn.query('SELECT id, game_points FROM users WHERE id IN (?) FOR UPDATE', [ids]);
    const pts = new Map(urows.map(u => [Number(u.id), Number(u.game_points || 0)]));

    const banker = r.players.get(r.bankerId);
    if (!banker || !banker.hand) throw new Error('BANKER_HAND_MISSING');
    const players = ids.filter(uid => uid !== r.bankerId).map(uid => {
      const p = r.players.get(uid);
      if (!p || !p.hand) return null;
      return { user_id: uid, hand: p.hand, bet_level: p.bet_level, points: pts.get(uid) || 0 };
    }).filter(Boolean);
    if (!players.length) throw new Error('PLAYER_HAND_MISSING');

    const results = E.settle(r.cfg.base_stake,
      { user_id: r.bankerId, hand: banker.hand, points: pts.get(r.bankerId) || 0 }, players);

    const push = [];
    for (const row of results) {
      const p = r.players.get(row.user_id);
      let before = pts.get(row.user_id) || 0;
      let after = before;
      if (row.delta !== 0) {
        const led = await ledger.applyBalance(conn, {
          userId: row.user_id,
          delta: row.delta,
          type: NG.POINTS.LEDGER_TYPES.GAME_SETTLE,
          reason: NG.POINTS.LEDGER_TYPE_TEXT.POINTS_GAME,
          referenceNo: round.roundNo,
          currencyType: NG.POINTS.ASSET
        });
        before = led.balance_before; after = led.balance_after;
        pts.set(row.user_id, after);
      }
      // 结算明细写入现有 game_results（UNIQUE(round_id,user_id) 防重复结算）
      // 旧红包对战字段（packet_amount / card_type / payout / fee / net_payout / is_winner）填 0，
      // 26牛牛只用 delta / compare_result 这组字段，历史红包对战记录不受影响。
      await conn.query(
        `INSERT INTO game_results
           (round_id, user_id, role, seat_no, grab_flag, bet_level, cards, hand_key, card_type,
            point_value, multiplier, expect_amount, delta, balance_before, balance_after,
            compare_result, is_winner, is_capped, packet_amount, payout, fee, net_payout)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 0, 0)
         ON DUPLICATE KEY UPDATE
           role = VALUES(role), grab_flag = VALUES(grab_flag), bet_level = VALUES(bet_level),
           cards = VALUES(cards), hand_key = VALUES(hand_key), point_value = VALUES(point_value),
           multiplier = VALUES(multiplier), expect_amount = VALUES(expect_amount), delta = VALUES(delta),
           balance_before = VALUES(balance_before), balance_after = VALUES(balance_after),
           compare_result = VALUES(compare_result), is_winner = VALUES(is_winner),
           is_capped = VALUES(is_capped), payout = VALUES(payout)`,
        [round.roundNo, row.user_id, row.role, p ? p.seat : 0,
          p && p.grab === NG.GRAB.YES ? 1 : 0, row.bet_level,
          JSON.stringify((p && p.cards) || []), row.hand_key, row.hand_key,
          row.point_value, row.multiplier,
          row.expect_amount.toFixed(2), row.delta.toFixed(2),
          before.toFixed(2), after.toFixed(2),
          row.result, row.delta > 0 ? 1 : 0, row.is_capped ? 1 : 0,
          row.amount.toFixed(2)]
      );
      await conn.query(
        `INSERT INTO niu_user_stats
           (user_id, total_rounds, win_rounds, banker_rounds, grab_rounds, total_delta, best_multiplier)
         VALUES (?, 1, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           total_rounds = total_rounds + 1,
           win_rounds = win_rounds + VALUES(win_rounds),
           banker_rounds = banker_rounds + VALUES(banker_rounds),
           grab_rounds = grab_rounds + VALUES(grab_rounds),
           total_delta = total_delta + VALUES(total_delta),
           best_multiplier = GREATEST(best_multiplier, VALUES(best_multiplier))`,
        [row.user_id, row.delta > 0 ? 1 : 0, row.role === 'BANKER' ? 1 : 0,
          p && p.grab === NG.GRAB.YES ? 1 : 0, row.delta.toFixed(2), row.multiplier]
      );
      if (p) p.points = after;
      push.push({
        user_id: row.user_id, role: row.role, delta: row.delta, balance_after: after,
        nickname: (p && p.nickname) || String(row.user_id),
        hand_key: row.hand_key, hand_name: (NG.HAND_TYPES[row.hand_key] || {}).name || row.hand_key,
        point_value: row.point_value, multiplier: row.multiplier,
        bet_level: row.bet_level, result: row.result, is_capped: !!row.is_capped
      });
    }
    await conn.commit();
    round.settled = true;

    emitRoom(r, 'niu:settled', { round_no: round.roundNo, list: push });
    push.forEach(x => emitUser(r, x.user_id, 'niu:points', { game_points: x.balance_after, asset: NG.POINTS.ASSET, delta: x.delta }));
    const win = push.filter(x => x.delta > 0).map(x => x.nickname);
    notice(r, win.length ? '本局积分增加：' + win.join('、') : '本局无人增加积分');
    broadcast(r);

    // ===== 在聊天群里公布结算明细（游戏结果与结算都在群里完成）=====
    // 带 event_type：结算事务重试时不会把同一局的明细重复发进群
    await say(r, await botLine('settle_head'),
      { phase: NG.PHASE.SETTLEMENT, kind: 'settle', event_type: 'settle' });
    for (const x of push) {
      const tag = x.role === 'BANKER' ? '庄家' : '闲家';
      const sign = x.delta > 0 ? '+' : (x.delta < 0 ? '' : '±');
      const cap = x.is_capped ? '（积分不足，已按实际封顶）' : '';
      await say(r, '　' + tag + ' ' + x.nickname + '：' + x.hand_name +
        ' → ' + sign + Math.abs(x.delta).toFixed(2) + ' ' + NG.POINTS.TEXT + cap +
        '（现有 ' + x.balance_after.toFixed(2) + '）',
        { phase: NG.PHASE.SETTLEMENT, kind: 'settle_row' });
    }
  } catch (err) {
    await conn.rollback().catch(() => {});
    console.error('[niu] 结算失败（已回滚，等待下一轮重试）:', err.message);
    // 状态闸门已回滚为 SETTLEMENT，下一 tick 会自动重试；超过上限则由清扫任务作废
    r.phaseEndsAt = nowMs() + 4000;
  } finally {
    conn.release();
    r.settling = false;
  }
}

/** 每局结束后用数据库真实积分刷新内存（内存只是展示缓存） */
async function refreshPoints(r) {
  const ids = Array.from(r.players.keys());
  if (!ids.length) return;
  const [rows] = await db.promise().query('SELECT id, game_points FROM users WHERE id IN (?)', [ids]);
  const m = new Map(rows.map(u => [Number(u.id), Number(u.game_points || 0)]));
  ids.forEach(uid => {
    const p = r.players.get(uid);
    if (!p) return;
    p.points = m.has(uid) ? m.get(uid) : p.points;
    emitUser(r, uid, 'niu:points', { game_points: p.points, asset: NG.POINTS.ASSET });
  });
}


// ============================================
// 心跳 / 清扫（断线、重启、卡局的安全兜底）
// ============================================

let sweeping = false;

/** 机器人运行态缓存（后端权威；管理员浏览器关掉也不影响） */
let botRunningCache = false;

/** 读取机器人运行态（DB 权威）。启动/停止时同步更新缓存，tick 每轮最多 5 秒校准一次。 */
let botLastSync = 0;
async function syncBotState() {
  if (nowMs() - botLastSync < 5000) return botRunningCache;
  botLastSync = nowMs();
  try {
    botRunningCache = await bot.isRunning();
  } catch (e) {
    console.error('[niu] 机器人状态读取失败:', e.message);
  }
  return botRunningCache;
}

async function tick() {
  if (sweeping) return;
  sweeping = true;
  try {
    const enabled = await isEnabled();
    const botOn = await syncBotState();
    for (const r of rooms.values()) {
      // 游戏关闭：未完成的一局安全作废，不产生任何积分变动
      if (!enabled) {
        if (r.round) await abortRound(r, '游戏已关闭，本局作废（不结算积分）');
        else if (r.phase !== NG.PHASE.WAITING) setPhase(r, NG.PHASE.WAITING, NG.TIMERS.WAITING);
        continue;
      }
      // 对局进行中但人已走光 → 作废
      // 注意：机器人「已停止」时不执行任何破坏性作废（第十条要求保留当前局），
      //      管理员重新启动后会自动继续，或由超时兜底安全收尾。
      if (botOn && r.round && r.round.participants.filter(uid => r.players.has(uid)).length < NG.PLAYERS.MIN) {
        await abortRound(r, '房间内人数不足，本局作废（不结算积分）');
        continue;
      }
      // 超时兜底：结算反复失败或阶段长时间未推进
      if (r.round && nowMs() - r.roundStartedAt > NG.TIMERS.ROUND_MAX_LIVE_SECONDS * 1000) {
        // 结算重试不属于「自动推进新阶段」，机器人停止时仍允许完成，
        // 避免玩家积分卡在未结算状态（状态闸门保证绝不重复结算）
        if (r.phase === NG.PHASE.SETTLEMENT) await settleRound(r);
        if (botOn && r.round && !r.round.settled) {
          await abortRound(r, '本局超时，已安全作废（不结算积分）');
        }
        continue;
      }
      if (nowMs() < r.phaseEndsAt) continue;
      // ---- 机器人总闸门（第十 / 二十六条）----
      // 机器人「已停止」时：绝不自动推进新阶段，也不新开局。
      // 当前局、聊天记录、玩家座位、历史对局一律原样保留在数据库里，
      // 管理员在聊天页仍能看到当前阶段；再次点「启动」立即接着跑。
      if (!botOn) continue;
      await advance(r);
    }
    await closeIdleRooms();
    tickFails = 0;
  } catch (err) {
    tickFails += 1;
    console.error('[niu] tick 异常（第 ' + tickFails + ' 次）:', err.message);
    if (tickFails >= 5) {
      // 连续异常：把进行中的局安全作废，避免内存与数据库积分不一致
      rooms.forEach(r => { if (r.round && !r.round.settled) abortRound(r, '服务器状态异常，本局作废（不结算积分）'); });
      tickFails = 0;
    }
  } finally {
    sweeping = false;
  }
}

/** 空闲房间回收（无人且长时间无对局） */
async function closeIdleRooms() {
  for (const [key, r] of rooms.entries()) {
    if (r.players.size || r.round) continue;
    if (nowMs() - r.lastActiveAt < NG.TIMERS.ROOM_IDLE_CLOSE_SECONDS * 1000) continue;
    rooms.delete(key);
    console.log('[niu] 回收空闲房间 ' + key);
  }
}

// ============================================
// 查询（真实数据库，无数据即 0 / 空列表）
// ============================================

/** 场次列表：配置 + 实时人数 + 我的座位 */
async function listRooms(userId) {
  const enabled = await isEnabled();
  const uid = Number(userId) || 0;
  const list = NG.ROOMS.slice().sort((a, b) => a.order - b.order).map(cfg => {
    const r = rooms.get(cfg.key);
    return {
      key: cfg.key, name: cfg.name, base_stake: cfg.base_stake,
      seat_limit: Math.min(NG.PLAYERS.HARD_MAX, Number(cfg.seat_limit) || NG.PLAYERS.DEFAULT_MAX),
      min_points: cfg.min_points, desc: cfg.desc,
      phase: r ? r.phase : NG.PHASE.WAITING,
      phase_text: r ? NG.PHASE_TEXT[r.phase] : NG.PHASE_TEXT[NG.PHASE.WAITING],
      online: r ? r.players.size : 0,
      player_count: r ? r.players.size : 0,       // 与 online 同源（当前在座人数），便于前端 / 后台统一读取
      playing: !!(r && r.round),
      seated: !!(r && uid && r.players.has(uid))
    };
  });
  return { enabled: enabled, asset: { code: NG.POINTS.ASSET, text: NG.POINTS.TEXT }, rooms: list };
}


/** 我的对局记录（分页，真实数据） */
async function myRecords(userId, opts) {
  const page = Math.max(1, Number((opts && opts.page) || 1));
  const size = Math.min(NG.LIMITS.RECORDS_MAX_PAGE_SIZE,
    Math.max(1, Number((opts && opts.size) || NG.LIMITS.RECORDS_PAGE_SIZE)));
  const days = Math.max(0, Number((opts && opts.days) || 0));
  const where = ['rp.user_id = ?', "rd.packet_type = 'PLATFORM'"];
  const args = [Number(userId)];
  if (days > 0) { where.push('rp.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)'); args.push(days); }
  const cond = where.join(' AND ');
  const [cnt] = await db.promise().query(
    'SELECT COUNT(*) AS n FROM game_results rp JOIN game_rounds rd ON rd.round_id = rp.round_id WHERE ' + cond, args);
  const [rows] = await db.promise().query(
    `SELECT rp.role, rp.bet_level, rp.hand_key, rp.point_value, rp.multiplier,
            rp.delta, rp.balance_after, rp.compare_result, rp.created_at,
            rd.round_id, rd.room_key, rd.base_stake
     FROM game_results rp
     JOIN game_rounds rd ON rd.round_id = rp.round_id
     WHERE ${cond}
     ORDER BY rp.id DESC LIMIT ${size} OFFSET ${(page - 1) * size}`, args);
  const hands = {};
  Object.keys(NG.HAND_TYPES).forEach(k => { hands[NG.HAND_TYPES[k].key] = NG.HAND_TYPES[k].name; });
  return {
    total: Number(cnt[0] ? cnt[0].n : 0), page: page, size: size,
    list: rows.map(x => {
      const cfg = NG.roomByKey(x.room_key) || {};
      return {
        round_no: x.round_id, room_key: x.room_key, room_name: cfg.name || x.room_key,
        base_stake: Number(x.base_stake), role: x.role, bet_level: Number(x.bet_level),
        hand_key: x.hand_key, hand_name: hands[x.hand_key] || x.hand_key,
        point_value: Number(x.point_value), multiplier: Number(x.multiplier),
        delta: Number(x.delta), balance_after: Number(x.balance_after),
        result: x.compare_result, created_at: x.created_at
      };
    })
  };
}

/** 我的统计（真实统计，无数据返回 0） */
async function myStats(userId) {
  const uid = Number(userId);
  const [u] = await db.promise().query('SELECT game_points FROM users WHERE id = ? LIMIT 1', [uid]);
  const [s] = await db.promise().query(
    `SELECT total_rounds, win_rounds, banker_rounds, grab_rounds, total_delta, best_multiplier, daily_free_date
     FROM niu_user_stats WHERE user_id = ? LIMIT 1`, [uid]);
  const st = s[0] || {};
  const total = Number(st.total_rounds || 0);
  return {
    game_points: Number(u[0] ? u[0].game_points : 0),
    asset: { code: NG.POINTS.ASSET, text: NG.POINTS.TEXT, cashable: false },
    total_rounds: total,
    win_rounds: Number(st.win_rounds || 0),
    banker_rounds: Number(st.banker_rounds || 0),
    grab_rounds: Number(st.grab_rounds || 0),
    total_delta: Number(st.total_delta || 0),
    best_multiplier: Number(st.best_multiplier || 0),
    daily_free_date: st.daily_free_date || null,
    win_rate: total > 0 ? Number((Number(st.win_rounds || 0) / total * 100).toFixed(1)) : 0
  };
}

/** 娱乐积分排行榜（不可提现，无任何现金含义） */
async function leaderboard(opts) {
  const limit = Math.min(NG.LEADERBOARD.MAX_LIMIT,
    Math.max(1, Number((opts && opts.limit) || NG.LEADERBOARD.DEFAULT_LIMIT)));
  const days = Math.max(0, Number((opts && opts.days) || NG.LEADERBOARD.DEFAULT_DAYS));
  const window = days > 0 ? 'rp.created_at >= DATE_SUB(NOW(), INTERVAL ' + days + ' DAY)' : 'rp.id > 0';
  const [rows] = await db.promise().query(
    `SELECT rp.user_id, u.username, u.nickname, u.avatar_id,
            COUNT(*) AS rounds,
            SUM(CASE WHEN rp.delta > 0 THEN 1 ELSE 0 END) AS wins,
            SUM(rp.delta) AS net
     FROM game_results rp
     JOIN game_rounds rd ON rd.round_id = rp.round_id
     JOIN users u ON u.id = rp.user_id
     WHERE rd.packet_type = 'PLATFORM' AND ${window}
     GROUP BY rp.user_id, u.username, u.nickname, u.avatar_id
     ORDER BY net DESC, rounds DESC
     LIMIT ${limit}`);
  return {
    days: days, asset: { code: NG.POINTS.ASSET, text: NG.POINTS.TEXT },
    list: rows.map((x, i) => ({
      rank: i + 1, user_id: Number(x.user_id),
      nickname: x.nickname || x.username, avatar_id: x.avatar_id ? Number(x.avatar_id) : null,
      rounds: Number(x.rounds), wins: Number(x.wins), net: Number(x.net || 0)
    }))
  };
}


/** 管理后台：游戏运行状态（真实数据，绝不伪造） */
async function adminStatus() {
  const enabled = await isEnabled();
  const [agg] = await db.promise().query(
    `SELECT COUNT(*) AS rounds,
            COALESCE(SUM(CASE WHEN status = 'FINISHED' THEN 1 ELSE 0 END), 0) AS finished,
            COALESCE(SUM(CASE WHEN status = 'ABORTED' THEN 1 ELSE 0 END), 0) AS aborted
     FROM game_rounds
     WHERE packet_type = 'PLATFORM' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)`);
  const [today] = await db.promise().query(
    `SELECT COUNT(*) AS rounds FROM game_rounds
     WHERE packet_type = 'PLATFORM' AND created_at >= CURDATE()`);
  const a = agg[0] || {};
  return {
    enabled: enabled,
    switch_key: NG.SWITCHES.DB_KEY,
    live_rooms: Array.from(rooms.values()).map(r => ({
      key: r.key, name: r.cfg.name, phase: r.phase, seats: r.players.size, playing: !!r.round
    })),
    week: {
      rounds: Number(a.rounds || 0),
      finished: Number(a.finished || 0),
      aborted: Number(a.aborted || 0)
    },
    today_rounds: Number((today[0] || {}).rounds || 0),
    asset: { code: NG.POINTS.ASSET, text: NG.POINTS.TEXT, cashable: false }
  };
}

/** 管理员开关游戏（写入统一配置中心；关闭时进行中的局安全作废，不退不结积分） */
async function setEnabled(flag, adminId) {
  await siteSettings.save({ [NG.SWITCHES.DB_KEY]: !!flag }, adminId || null);
  if (!flag) {
    for (const r of rooms.values()) {
      if (r.round && !r.round.settled) await abortRound(r, '管理员已关闭游戏，本局作废（不结算积分）');
    }
  }
  return { enabled: !!flag };
}

// ============================================
// 启动 / 停止
// ============================================

/**
 * 初始化（服务器重启恢复）
 *
 * 恢复策略（绝不重建局、绝不重复发消息）：
 *   1. 先读机器人状态行。机器人是「已停止」→ 只清理进行中的局（不发积分变动），不自动开局。
 *   2. 机器人是「运行中」且存在进行中的局 → 按 game_rounds 的真实 phase / phase_ends_at 重建
 *      内存房间并接着跑；阶段已超时的直接推进，绝不新开一局、绝不重发开局话术。
 *   3. 无论哪种情况都不删聊天记录、不删玩家、不删历史对局。
 */
async function init(serverIo) {
  io = serverIo || null;
  let botRunningNow = false;
  try {
    botRunningNow = await bot.isRunning();
  } catch (_) {
    botRunningNow = false;
  }

  if (!botRunningNow) {
    // 机器人已停止：把遗留的进行中局安全作废（积分只在结算事务里变动，作废不会余额漂移）
    try {
      const [res] = await db.promise().query(
        `UPDATE game_rounds SET status = 'ABORTED', updated_at = NOW()
          WHERE packet_type = 'PLATFORM' AND status NOT IN ('FINISHED','ABORTED')`);
      if (res.affectedRows) console.log('[niu] 机器人已停止，已作废重启遗留对局 ' + res.affectedRows + ' 局（无积分变动）');
    } catch (err) {
      console.error('[niu] 启动清理失败（025 迁移是否已执行？）:', err.message);
    }
  } else {
    await recoverActiveRounds();
  }

  if (!tickTimer) {
    tickTimer = setInterval(() => { tick(); }, NG.TIMERS.TICK_MS);
    console.log('[niu] 26牛牛娱乐场引擎已启动（状态机 + 结算事务 + 服务器安全随机）；机器人状态：' +
      (botRunningNow ? '运行中' : '已停止'));
  }
}

/**
 * 服务器重启恢复：把数据库里「进行中」的局按真实阶段载入内存。
 * 恢复的是同一局（同一个 round_id），因此不会重复开局，也不会重发开局话术。
 */
async function recoverActiveRounds() {
  try {
    const [rows] = await db.promise().query(
      `SELECT id, round_id, room_key, room_id, phase, phase_ends_at, banker_id, player_count
         FROM game_rounds
        WHERE packet_type = 'PLATFORM'
          AND status NOT IN ('FINISHED','ABORTED')
        ORDER BY id ASC LIMIT 20`);
    if (!rows.length) return;

    for (const row of rows) {
      const cfg = NG.roomByKey(row.room_key);
      if (!cfg) {
        // 场次已下线：安全作废，绝不产生无法追溯的悬挂局
        await db.promise().query(
          "UPDATE game_rounds SET status = 'ABORTED', updated_at = NOW() WHERE id = ?", [row.id]);
        continue;
      }
      const r = roomOf(cfg.key);
      // 注意：room_players 没有 seat_no 列（座位号只是内存中的展示顺序，不持久化）
      const [players] = await db.promise().query(
        'SELECT user_id, bet_level, grab_flag FROM room_players WHERE round_id = ? AND status = ?',
        [row.round_id, 'ACTIVE']);

      r.players.clear();
      let seat = 0;
      for (const p of players) {
        seat += 1;
        const prof = await loadProfile(p.user_id).catch(() => null);
        if (!prof) continue;
        r.players.set(Number(p.user_id), {
          userId: Number(p.user_id), seat: seat, nickname: prof.nickname,
          avatarId: prof.avatarId, points: prof.points,
          grab: Number(p.grab_flag) ? NG.GRAB.YES : NG.GRAB.NO,
          grabLocked: true,
          bet_level: NG.isValidBetLevel(Number(p.bet_level)) ? Number(p.bet_level) : NG.BET_DEFAULT_LEVEL,
          ready: false, cards: null, hand: null
        });
        seatIndex.set(Number(p.user_id), { roomKey: r.key, seat: seat });
      }
      r.round = {
        rowId: Number(row.id), roomPk: Number(row.room_id),
        roundNo: String(row.round_id),
        participants: Array.from(r.players.keys()),
        settled: row.status === 'SETTLEMENT' || row.status === 'FINISHED',
        reveal: null
      };
      r.roundStartedAt = nowMs();
      r.bankerId = row.banker_id ? Number(row.banker_id) : 0;

      // 阶段以数据库为准；已超时的让下一次 tick 立刻推进，绝不重新开局
      const phase = String(row.phase || NG.PHASE.GRABBING);
      r.phase = Object.keys(NG.PHASE).map(k => NG.PHASE[k]).indexOf(phase) >= 0 ? phase : NG.PHASE.GRABBING;
      const ends = parseDbTime(row.phase_ends_at);
      r.phaseEndsAt = ends > nowMs() ? ends : nowMs() + 1000;

      console.log('[niu] 已恢复进行中的对局 ' + row.round_id + '（阶段 ' + r.phase + '，参与 ' + r.players.size + ' 人）');
    }

    // 恢复时静默同步一次机器人状态行，后台面板立即显示真实阶段
    for (const r of rooms.values()) {
      if (!r.round) continue;
      await bot.trackRound({
        room_key: r.key, chat_channel: GROUP_CHANNEL,
        round_id: r.round.roundNo, round_pk: r.round.rowId,
        phase: r.phase, phase_ends_at: new Date(r.phaseEndsAt)
      }).catch(() => {});
    }
  } catch (err) {
    console.error('[niu] 重启恢复失败（026 迁移是否已执行？）:', err.message);
  }
}

function stop() {
  if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
}

module.exports = {
  init,
  stop,
  isEnabled,
  setEnabled,
  join,
  leave,
  setGrab,
  setBet,
  attachSocket,
  detachSocket,
  stateFor,
  isSeated,
  listRooms,
  myRecords,
  myStats,
  leaderboard,
  adminStatus,
  grantDailyFree,
  loadProfile,
  // 26牛牛游戏机器人（后端权威；管理员后台控制用）
  botRunning,
  recoverActiveRounds,
  roomKeys: () => Array.from(rooms.keys())
};

