// ============================================
// 26牛牛 - 维护模式中间件（阶段 36）
// 行为:
//   - 读取数据库 system_settings 的 maintenance_mode（utils/siteSettings 带 30 秒缓存）
//   - 关闭时：直接放行，零额外开销（一次内存判断）
//   - 开启时:
//       · 管理员 / 客服（Bearer JWT 或登录页面票据）仍然可以正常使用
//       · 普通用户访问页面 → 302 到 /maintenance.html
//       · 普通用户访问 /api/** → 503 JSON（含 code:MAINTENANCE）
//   - 白名单：维护页与它需要的最小资源、登录接口（管理员需要登录才能进后台）
// 挂载位置: server.js 中，静态资源之前、业务路由之前
// ============================================

const jwt = require('jsonwebtoken');
const db = require('../config/db');
const siteSettings = require('../utils/siteSettings');
const { readPageToken } = require('../utils/pageSession');

// 维护期间仍可访问的路径（页面 + 接口）
const ALLOWED = [
  '/maintenance.html',
  '/login.html',
  '/app.css',
  '/favicon.ico',
  '/api/settings',
  '/api/auth/login',
  '/api/auth/logout'
];
const ALLOWED_PREFIX = ['/assets/', '/js/', '/assets', '/storage/'];

function isAllowedPath(p) {
  if (ALLOWED.indexOf(p) !== -1) return true;
  return ALLOWED_PREFIX.some(pre => p.indexOf(pre) === 0);
}

/** 通过 Bearer JWT 判断是否为 admin / support（只读一次数据库） */
async function staffByBearer(req) {
  const header = req.headers.authorization;
  const m = typeof header === 'string' && /^Bearer ([^\s]+)$/.exec(header);
  if (!m) return false;
  let decoded;
  try {
    decoded = jwt.verify(m[1], process.env.JWT_SECRET, { algorithms: ['HS256'] });
  } catch (e) { return false; }
  if (!decoded || !Number.isSafeInteger(decoded.id) || decoded.id <= 0) return false;
  const [rows] = await db.promise().query('SELECT role, status FROM users WHERE id = ? LIMIT 1', [decoded.id]);
  const u = rows[0];
  return !!(u && u.status === 'active' && (u.role === 'admin' || u.role === 'support'));
}

/** 通过登录页面票据（HttpOnly Cookie）判断是否为 admin / support */
async function staffByCookie(req) {
  const token = readPageToken(req);
  if (!token) return false;
  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
  } catch (e) { return false; }
  if (!decoded || !Number.isSafeInteger(decoded.id) || decoded.id <= 0) return false;
  const [rows] = await db.promise().query('SELECT role, status FROM users WHERE id = ? LIMIT 1', [decoded.id]);
  const u = rows[0];
  return !!(u && u.status === 'active' && (u.role === 'admin' || u.role === 'support'));
}

module.exports = function mountMaintenance(app) {
  app.use(async (req, res, next) => {
    try {
      // 静态资源与白名单永远放行，避免维护页自身打不开
      if (isAllowedPath(req.path)) return next();

      const on = await siteSettings.get('maintenance_mode');
      if (on !== true) return next();

      // 管理员 / 客服不受维护影响（数据库角色为准，不信任前端缓存）
      if (await staffByBearer(req)) return next();
      if (await staffByCookie(req)) return next();

      const notice = await siteSettings.get('maintenance_notice');

      // API：返回明确的维护状态，前端据此显示维护提示（不暴露内部信息）
      if (req.path.indexOf('/api/') === 0) {
        return res.status(503).json({
          success: false,
          code: 'MAINTENANCE',
          message: notice || '系统维护中，请稍后再回来。'
        });
      }

      // 页面：跳转到维护页（GET/HEAD 才跳转，其它方法保持原语义）
      if (req.method === 'GET' || req.method === 'HEAD') {
        return res.redirect(302, '/maintenance.html');
      }
      return res.status(503).type('html')
        .send('<!DOCTYPE html><meta charset="utf-8"><p>系统维护中，请稍后再回来。</p>');
    } catch (err) {
      // 配置模块故障不应该把站点变成「维护中」，放行并记录服务端日志
      console.error('维护模式检查失败（已放行）:', err.message);
      return next();
    }
  });
};
