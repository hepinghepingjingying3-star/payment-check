// ============================================
// 26牛牛 - 服务端错误兜底（阶段 41 / 45）
// 作用:
//   - 未匹配的 /api/** 返回统一 JSON 404，不让前端拿到 HTML 而解析失败
//   - 未捕获异常 / 未处理 Promise 拒绝 → 记录服务端日志，返回统一 JSON 500
//   - 生产环境绝不把 SQL / 堆栈 / 内部路径返回给客户端
// 说明:
//   - 只在 /api 前缀生效，不影响静态页面与 Socket.IO
// ============================================

function wantsJson(req) {
  return req.path.indexOf('/api/') === 0 || req.path.indexOf('/api') === 0;
}

module.exports = function mountErrorHandler(app) {
  // 1) /api 404（放在所有业务路由之后）
  app.use((req, res, next) => {
    if (!wantsJson(req)) return next();
    return res.status(404).json({ success: false, code: 'NOT_FOUND', message: '接口不存在' });
  });

  // 2) 统一错误处理（Express 需要 4 个参数才会识别为错误中间件）
  app.use((err, req, res, next) => {
    const status = err && Number.isInteger(err.status) && err.status >= 400 && err.status < 600 ? err.status : 500;
    // 服务端详细日志（仅开发/运维可见，不返回给客户端）
    console.error('请求处理失败 [' + req.method + ' ' + req.originalUrl + ']:', err && err.message ? err.message : err);

    if (res.headersSent) return next(err);
    const message = status === 500
      ? '服务器内部错误，请稍后重试'
      : (err && err.expose && err.message ? err.message : '请求失败，请稍后重试');
    if (wantsJson(req)) {
      return res.status(status).json({ success: false, message: message });
    }
    return res.status(status).type('html')
      .send('<!DOCTYPE html><meta charset="utf-8"><p>页面暂时无法加载，请重新尝试。</p>');
  });
};
