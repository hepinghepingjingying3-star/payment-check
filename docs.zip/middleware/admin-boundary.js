'use strict';
// ============================================
// 26牛牛 - 管理员边界（API + 管理页面）
// 保护范围:
//   1) /api/admin/**            Bearer JWT + 当前数据库角色 admin；客服/普通用户 403，匿名 401
//   2) /admin.html /admin-otp.html
//      这两个页面是 public 下的静态文件，必须在下发 HTML 之前就挡住普通用户，
//      否则任何登录用户（甚至未登录）直接输入 URL 都能看到后台外壳。
//      浏览器顶层导航无法携带 Authorization 头，因此这里用登录时下发的
//      HttpOnly 页面票据（utils/pageSession）判断；该 Cookie 只用于页面准入，
//      /api/** 一律不读 Cookie，因此不会给数据层带来 CSRF 风险。
//   非管理员访问管理页面 → 302 回 /me.html?admin=denied，绝不下发后台 HTML。
// 挂载位置: server.js 中必须早于 express.static 与业务路由。
// ============================================

const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { auth, requireRole } = require('./auth');
const { readPageToken } = require('../utils/pageSession');

const ADMIN_PAGES = ['/admin.html', '/admin-otp.html'];
// 客服（support）可进入的页面：仅 OTP 管理台（不包含总后台 /admin.html）
const STAFF_PAGES = ['/admin-otp.html'];

/** 校验页面票据：返回当前数据库中的「活跃管理员」用户ID，否则 null */
async function activeAdminId(req) {
  return activeStaffId(req, ['admin']);
}

/** 校验页面票据：返回当前数据库中的活跃 staff 用户ID（角色在 allow 内） */
async function activeStaffId(req, allow) {
  const token = readPageToken(req);
  if (!token) return null;
  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
  } catch (_) {
    return null;
  }
  if (!decoded || typeof decoded !== 'object' || !Number.isSafeInteger(decoded.id) || decoded.id <= 0) return null;
  const [rows] = await db.promise().query('SELECT role, status, token_version FROM users WHERE id = ? LIMIT 1', [decoded.id]);
  const user = rows[0];
  if (!user || allow.indexOf(user.role) === -1 || user.status !== 'active') return null;
  const tokenVersion = Number.isSafeInteger(decoded.tv) && decoded.tv >= 0 ? decoded.tv : 0;
  if (tokenVersion !== Number(user.token_version || 0)) return null;
  return decoded.id;
}

module.exports = function mountAdminBoundary(app) {
  // ---------- 0. 客服（support）可用范围 ----------
  // OTP 与客服线程管理允许 support；其余 /api/admin/** 仅 admin。
  // 这里的放行只是「不拦」，OTP 路由自身仍有 auth + requireRole('admin','support')。
  // 使用 originalUrl，而非挂载中间件后的 req.path；Express 版本/中间件组合下
  // req.path 可能已变为 '/'，会误把客服人员拦成普通用户。
  const isSupportAllowed = (req) => {
    const fullPath = String(req.originalUrl || req.url || '').split('?')[0];
    return /^\/api\/admin\/(otp|support\/threads)(\/|$)/.test(fullPath);
  };

  // ---------- 1. 管理 API 边界（绝不信任客户端缓存的角色） ----------
  app.use('/api/admin', (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  }, (req, res, next) => {
    if (isSupportAllowed(req)) {
      return auth(req, res, () => requireRole('admin', 'support')(req, res, next));
    }
    return auth(req, res, () => requireRole('admin')(req, res, next));
  });

  // ---------- 2. 管理页面边界（页面 HTML 本身也要鉴权） ----------
  app.use(async (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    const isAdminPage = ADMIN_PAGES.indexOf(req.path) !== -1;
    const isStaffPage = STAFF_PAGES.indexOf(req.path) !== -1;
    if (!isAdminPage && !isStaffPage) return next();
    const allow = isStaffPage ? ['admin', 'support'] : ['admin'];
    try {
      if (await activeStaffId(req, allow)) {
        // 管理页面禁止被浏览器/中间层缓存，避免退出登录后仍可回退看到内容
        res.set('Cache-Control', 'no-store');
        return next();
      }
      return res.redirect(302, '/me.html?admin=denied');
    } catch (err) {
      console.error('管理页面权限校验失败:', err.message);
      return res.status(503).type('html')
        .send('<!DOCTYPE html><meta charset="utf-8"><p>权限校验服务暂不可用，请稍后重试。</p>');
    }
  });
};

module.exports.activeAdminId = activeAdminId;
module.exports.activeStaffId = activeStaffId;
module.exports.ADMIN_PAGES = ADMIN_PAGES;
module.exports.STAFF_PAGES = STAFF_PAGES;
