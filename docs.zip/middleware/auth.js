// ============================================
// 26牛牛 - JWT 认证中间件
// 作用: 验证请求中的 JWT Token，保护需要登录的 API
// 使用方式:
//   - 需要登录的接口: router.get('/profile', auth, handler)
//   - 需要管理员权限: router.get('/admin', auth, requireRole('admin'), handler)
//   - 需要客服/管理员权限: router.get('/support', auth, requireRole('support', 'admin'), handler)
// ============================================

// 引入 jsonwebtoken 库
const jwt = require('jsonwebtoken');
const db = require('../config/db');

// 从 .env 读取 JWT Secret（禁止硬编码）
const JWT_SECRET = process.env.JWT_SECRET;

/**
 * JWT 验证中间件
 * 验证请求头中的 Authorization: Bearer <token>
 * 验证通过后，将用户信息挂载到 req.user
 */
async function auth(req, res, next) {
  const header = req.headers.authorization;
  const match = typeof header === 'string' && /^Bearer ([^\s]+)$/.exec(header);
  const denied = () => res.status(401).json({ success: false, message: '未登录或登录已过期，请重新登录' });
  if (!match) return denied();
  let decoded;
  try {
    decoded = jwt.verify(match[1], JWT_SECRET, { algorithms: ['HS256'] });
    // Existing login tokens have no purpose; only explicit login purpose is also accepted.
    if (!decoded || typeof decoded !== 'object' ||
        (decoded.purpose !== undefined && decoded.purpose !== 'login') ||
        !Number.isSafeInteger(decoded.id) || decoded.id <= 0) return denied();
  } catch (_) { return denied(); }
  try {
    const [rows] = await db.promise().query(
      'SELECT id, username, role, status, token_version FROM users WHERE id = ? LIMIT 1', [decoded.id]
    );
    const user = rows[0];
    if (!user) return denied();
    if (user.status !== 'active') return res.status(403).json({ success: false, message: '账号不可用，请联系客服' });
    // 历史令牌没有 tv 时按 0 处理，兼容迁移前已登录的旧用户；
    // 用户执行「退出其他设备」后 token_version 递增，所有旧令牌立即失效。
    const tokenVersion = Number.isSafeInteger(decoded.tv) && decoded.tv >= 0 ? decoded.tv : 0;
    if (tokenVersion !== Number(user.token_version || 0)) return denied();
    req.user = { id: user.id, username: user.username, role: user.role };
  } catch (_) {
    return res.status(500).json({ success: false, message: '认证服务暂不可用，请稍后重试' });
  }
  return next();
}

/**
 * 角色权限中间件工厂函数
 * 用法: requireRole('admin') 或 requireRole('support', 'admin')
 * 只有指定角色才能访问
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    // 检查用户是否已通过 auth 中间件
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: '未登录或登录已过期，请重新登录'
      });
    }

    // 检查用户角色是否在允许列表中
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: '没有权限执行此操作'
      });
    }

    next();
  };
}

// 导出中间件
module.exports = { auth, requireRole };