'use strict';
(function () {
  if (!App.requireLogin()) return; App.mountNetBanner();
  var $ = function (id) { return document.getElementById(id); };
  var id = new URLSearchParams(location.search).get('id');
  var order = null, file = null, objectUrl = null, busy = false;
  function money(v) { return 'RM' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function paintPreview() {
    if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; }
    if (!file) { $('preview').innerHTML = ''; $('removeBtn').hidden = true; return; }
    objectUrl = URL.createObjectURL(file);
    $('preview').innerHTML = '<div class="voucher-preview"><img src="' + objectUrl + '" alt="凭证预览"></div><p class="field-hint">' + App.escapeHtml(file.name) + '</p>';
    $('removeBtn').hidden = false;
  }
  async function load() {
    if (!/^\d+$/.test(id || '')) { $('voucherBox').innerHTML = App.stateBox('error', '订单不存在', '链接参数无效'); return; }
    var r = await App.api('/api/recharge/orders/' + id);
    if (!r.success) { $('voucherBox').innerHTML = App.stateBox('error', '订单加载失败', r.message || '请稍后重试'); return; }
    order = r.data.order; if (order.status !== 'PENDING') { window.location.href = '/recharge-detail.html?id=' + order.id; return; }
    var acc = order.receiving_account || null;
    var accHtml = acc
      ? '<div class="copy-line"><span class="k">收款方式</span><span class="v">' + App.escapeHtml(acc.type_text || acc.type || '') + '</span></div>' +
        '<div class="copy-line"><span class="k">' + App.escapeHtml(acc.type === 'EWALLET' ? '电子钱包' : '收款银行') + '</span><span class="v">' + App.escapeHtml(acc.name) + '</span></div>' +
        '<div class="copy-line"><span class="k">收款账号</span><span class="v">' + App.escapeHtml(acc.account_no) + '</span></div>' +
        '<div class="copy-line"><span class="k">收款户名</span><span class="v">' + App.escapeHtml(acc.holder) + '</span></div>'
      : '<div class="warning-box">该订单未分配收款账户，请联系客服</div>';
    var refHtml = order.payment_reference ? '<div class="copy-line"><span class="k">付款参考编号</span><span class="v">' + App.escapeHtml(order.payment_reference) + '</span></div>' : '';
    $('voucherBox').innerHTML = '<div class="card"><div class="copy-line"><span class="k">订单号</span><span class="v">' + App.escapeHtml(order.order_id) + '</span></div><div class="copy-line"><span class="k">充值金额</span><span class="v num-gold">' + money(order.amount) + '</span></div><div class="copy-line"><span class="k">订单状态</span><span class="v">' + App.escapeHtml(order.status_text) + '</span></div></div>' +
      '<div class="card"><div class="card-title">本订单收款资料</div>' + accHtml + refHtml + '<p class="card-note">请先按以上资料转账，再上传付款证明。账户在订单创建后固定，不会因刷新而改变。</p></div>' +
      '<div class="card"><div class="card-title">上传付款证明</div><div class="voucher-drop"><input id="fileInput" type="file" accept="image/jpeg,image/png,image/webp"><p class="field-hint mt-8">仅支持 1 张图片：JPG / JPEG / PNG / WEBP，最大 5MB</p></div><div id="preview"></div><button class="btn btn-ghost btn-block mt-8" id="removeBtn" hidden type="button">删除重新上传</button></div><div class="info-box">凭证提交后订单进入「待审核」，余额不会在提交时自动增加。</div><button class="btn btn-gold btn-block mt-12" id="submitBtn" type="button">提交充值审核</button><p id="status" class="text-secondary mt-8" role="status"></p>';
    $('fileInput').addEventListener('change', function () { var f = this.files && this.files[0]; if (!f) return; if (!/^image\/(jpeg|png|webp)$/.test(f.type) || f.size > 5 * 1024 * 1024) { this.value = ''; App.toast('仅支持 JPG / PNG / WEBP，最大 5MB', 'err'); return; } file = f; objectUrl = URL.createObjectURL(f); paintPreview(); });
    $('removeBtn').addEventListener('click', function () { file = null; $('fileInput').value = ''; paintPreview(); });
    $('submitBtn').addEventListener('click', submit);
  }
  async function submit() {
    if (busy) return; if (!file) { App.toast('请先上传转账凭证', 'err'); return; }
    busy = true; $('submitBtn').disabled = true; $('status').textContent = '正在上传凭证…';
    var fd = new FormData(); fd.append('file', file);
    var up = await fetch('/api/recharge/orders/' + order.id + '/receipt', { method: 'POST', headers: { Authorization: 'Bearer ' + App.getToken() }, body: fd });
    var uj = null; try { uj = await up.json(); } catch (e) {}
    if (!up.ok || !uj || uj.success === false) { busy = false; $('submitBtn').disabled = false; $('status').textContent = (uj && uj.message) || '凭证上传失败，请重试'; return; }
    $('status').textContent = '凭证已上传，正在提交订单…';
    var r = await App.api('/api/recharge/orders/' + order.id + '/submit', { method: 'POST' });
    if (!r.success) { busy = false; $('submitBtn').disabled = false; $('status').textContent = r.message || '提交失败，请重试'; return; }
    App.toast('充值订单已提交，请等待管理员审核', 'ok'); window.location.href = '/recharge-detail.html?id=' + order.id;
  }
  load();
})();
