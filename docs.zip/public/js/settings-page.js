// ============================================
// 26牛牛 - 设置页
// 只显示当前项目真实存在的功能；未实现的入口不显示
// ============================================
(function () {
  'use strict';

  function $(id) { return document.getElementById(id); }

  function bindNav() {
    document.addEventListener('click', function (ev) {
      var el = ev.target.closest ? ev.target.closest('[data-go]') : null;
      if (!el) return;
      var to = el.getAttribute('data-go');
      if (to) window.location.href = to;
    });
  }

  async function loadInvite() {
    var box = $('stInvite');
    var res = await App.api('/api/auth/me');
    if (!res.success || !res.data) {
      if (box) box.textContent = '--';
      return;
    }
    var code = res.data.invite_code || '';
    if (box) box.textContent = code || '暂未生成';
    var btn = $('stCopyInvite');
    if (btn) {
      btn.addEventListener('click', async function () {
        if (!code) { App.toast('暂未生成邀请码', 'err'); return; }
        var ok = await App.copyText(code);
        App.toast(ok ? '已复制' : '复制失败，请长按手动复制', ok ? 'ok' : 'err');
      });
    }
  }

  function bindLogout() {
    var btn = $('stLogout');
    if (!btn) return;
    btn.addEventListener('click', async function () {
      var yes = await App.confirmDialog({
        title: '退出登录',
        text: '确定要退出登录吗？',
        okText: '退出',
        danger: true
      });
      if (!yes) return;
      App.logout();
    });
  }

  /**
   * 管理员入口可见性
   * 判定完全来自后端 /api/auth/me 返回的 role（数据库 users.role），
   * 绝不比较 username 字符串，也不在前端写死任何管理员用户名。
   * 前端隐藏只是体验优化；真正的拦截在 middleware/admin-boundary.js 与各路由守卫。
   */
  async function showAdminEntry() {
    var sec = $('stAdminSec');
    if (!sec) return;
    var res = await App.api('/api/auth/me');
    if (!res.success || !res.data) { sec.hidden = true; return; }
    var role = String(res.data.role || '');
    sec.hidden = !(role === 'admin' || role === 'support');
  }

  /**
   * 对局音效开关（真实生效）
   * 存储：localStorage['nn_niu_sound'] = '1' / '0'，游戏页读取同一键
   */
  function bindSoundToggle() {
    var row = $('stSound');
    var label = $('stSoundV');
    if (!row || !label) return;
    function current() {
      var v = localStorage.getItem('nn_niu_sound');
      return v === null ? true : v === '1';
    }
    function paint() { label.textContent = current() ? '已开启' : '已关闭'; }
    paint();
    row.addEventListener('click', function () {
      var next = !current();
      localStorage.setItem('nn_niu_sound', next ? '1' : '0');
      paint();
      App.toast(next ? '已开启对局音效' : '已关闭对局音效', 'ok');
    });
  }

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(function () {
    if (!App.requireLogin()) return;
    var holder = $('pageHeader');
    if (holder) holder.innerHTML = App.headerHtml({ title: '设置', back: '/me.html' });
    App.mountNav('me');
    bindNav();
    bindLogout();
    bindSoundToggle();
    loadInvite();
    showAdminEntry();
  });
})();
