// 26牛牛 - 管理后台「收款账户」面板（自包含）
// 数据源：/api/admin/receiving-accounts（仅管理员；参数化 SQL；最多 100 个）
// 页面提供 <div id="adminReceivingMount"></div> 即自动挂载
(function () {
  'use strict';
  var mount = null, listEl = null, busy = false, filter = '', editingId = 0, MAX = 100;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function toast(m, t) { if (window.App && App.toast) App.toast(m, t || 'info'); else console.log('[receiving]', m); }
  async function api(p, o) { return (window.App && App.api) ? App.api(p, o) : { success: false, message: '未登录或网络异常' }; }
  function val(id) { var el = document.getElementById(id); return el ? String(el.value || '').trim() : ''; }
  function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v == null ? '' : v; }

  function accountRow(a) {
    return '<div style="border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px 12px;margin-bottom:8px">' +
      '<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:flex-start">' +
      '<div style="min-width:0;flex:1">' +
      '<div style="font-weight:600;word-break:break-all">#' + esc(a.id) + ' · ' + esc(a.account_type_text || a.account_type) + ' · ' + esc(a.account_name) + '</div>' +
      '<div style="font-size:12px;opacity:.75;margin-top:3px">户名 ' + esc(a.holder_name) + ' · 账号 ' + esc(a.account_no) + ' · 排序 ' + esc(a.sort_order) + '</div>' +
      (a.remark ? '<div style="font-size:12px;opacity:.6;margin-top:2px">备注：' + esc(a.remark) + '</div>' : '') +
      '<div style="font-size:11px;opacity:.6;margin-top:2px">更新 ' + esc(a.updated_at || a.created_at || '-') + '</div>' +
      '</div><div style="display:flex;gap:8px;flex-wrap:wrap">' +
      '<button type="button" class="btn btn-ghost btn-sm" data-ra-edit="' + esc(a.id) + '">编辑</button>' +
      '<button type="button" class="btn btn-dark btn-sm" data-ra-toggle="' + esc(a.id) + '" data-active="' + esc(a.is_active) + '">' + (a.is_active ? '停用' : '启用') + '</button>' +
      '</div></div></div>';
  }
  function paintForm(info) {
    var box = document.getElementById('raForm');
    if (!box) return;
    box.innerHTML =
      '<div class="group-title">' + (editingId ? '编辑收款账户 #' + esc(editingId) : '新增收款账户') + '</div>' +
      '<div class="card">' +
      '<label for="raType">账户类型</label>' +
      '<select class="input" id="raType"><option value="BANK">银行</option><option value="EWALLET">电子钱包</option></select>' +
      '<label for="raName">银行或电子钱包名称</label>' +
      '<input class="input" id="raName" type="text" maxlength="100" placeholder="例如：Maybank">' +
      '<label for="raHolder">户名</label>' +
      '<input class="input" id="raHolder" type="text" maxlength="100" placeholder="账户户名">' +
      '<label for="raNo">账号 / 钱包号码</label>' +
      '<input class="input" id="raNo" type="text" maxlength="40" placeholder="4-40 位数字或字母" autocomplete="off">' +
      '<label for="raRemark">备注（仅管理员可见）</label>' +
      '<input class="input" id="raRemark" type="text" maxlength="255" placeholder="可选">' +
      '<label for="raSort">排序（越小越优先分配）</label>' +
      '<input class="input" id="raSort" type="number" value="0" step="1">' +
      '<label class="admin-check"><input type="checkbox" id="raActive" checked> 启用（停用后不会被新订单分配，历史订单不变）</label>' +
      '<div class="admin-tools"><button type="button" class="btn btn-gold" id="raSave">' + (editingId ? '保存修改' : '添加账户') + '</button>' +
      (editingId ? '<button type="button" class="btn btn-dark" id="raCancel">取消编辑</button>' : '') + '</div>' +
      '<p class="admin-note" id="raStatus" role="status" aria-live="polite"></p>' +
      '<p class="admin-note">最多支持 ' + esc(MAX) + ' 个收款账户；账户资料仅管理员可见，用户只会在自己的充值订单里看到被分配的那一个。没有启用账户时用户无法创建充值订单。</p>' +
      '</div>';
    document.getElementById('raSave').addEventListener('click', save);
    var cancel = document.getElementById('raCancel');
    if (cancel) cancel.addEventListener('click', function () { editingId = 0; paintForm(info); });
  }

  function fillForm(a) {
    editingId = Number(a.id) || 0;
    paintForm();
    setVal('raType', a.account_type); setVal('raName', a.account_name);
    setVal('raHolder', a.holder_name); setVal('raNo', a.account_no);
    setVal('raRemark', a.remark); setVal('raSort', a.sort_order);
    var cb = document.getElementById('raActive'); if (cb) cb.checked = !!Number(a.is_active);
  }

  async function save(btn) {
    if (btn) btn.disabled = true;
    var body = {
      account_type: val('raType'), account_name: val('raName'), holder_name: val('raHolder'),
      account_no: val('raNo'), remark: val('raRemark'), sort_order: val('raSort') || 0,
      is_active: (document.getElementById('raActive') && document.getElementById('raActive').checked) ? 1 : 0
    };
    var st = document.getElementById('raStatus');
    var r = editingId
      ? await api('/api/admin/receiving-accounts/' + editingId, { method: 'PUT', body: body })
      : await api('/api/admin/receiving-accounts', { method: 'POST', body: body });
    if (st) st.textContent = r.success ? '已保存' : (r.message || '保存失败');
    if (btn) btn.disabled = false;
    if (!r.success) { toast(r.message || '保存失败', 'err'); return; }
    toast(r.message || '已保存', 'ok');
    editingId = 0; paintForm(); load();
  }

  async function toggle(id, active, btn) {
    if (btn) btn.disabled = true;
    var r = await api('/api/admin/receiving-accounts/' + id + '/status', { method: 'POST', body: { is_active: active ? 0 : 1 } });
    if (!r.success) { toast(r.message || '操作失败', 'err'); if (btn) btn.disabled = false; return; }
    toast(r.message || '已更新', 'ok'); load();
  }
  async function load() {
    if (!listEl || busy) return;
    busy = true; listEl.innerHTML = '<div style="opacity:.7;padding:14px">加载中…</div>';
    var r = await api('/api/admin/receiving-accounts' + (filter ? '?status=' + encodeURIComponent(filter) : ''));
    busy = false;
    if (!r.success) { listEl.innerHTML = '<div style="color:#f87171;padding:14px">' + esc(r.message || '收款账户加载失败') + '</div>'; return; }
    var d = r.data || {};
    MAX = Number(d.max_accounts) || 100;
    var list = d.list || [];
    listEl._data = list;
    var head = '<div style="font-size:12px;opacity:.75;margin-bottom:8px">共 ' + esc(d.total || 0) + ' 个 · 启用中 ' + esc(d.active_count || 0) + ' 个 · 上限 ' + esc(MAX) + ' 个</div>';
    listEl.innerHTML = head + (list.length ? list.map(accountRow).join('') : '<div style="opacity:.7;padding:14px">还没有收款账户，请先在上方添加；没有启用账户时用户无法创建充值订单。</div>');
  }

  function mountPanel(el) {
    mount = el;
    el.innerHTML = '<div class="ra-f" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">' +
      '<button type="button" data-raf="" class="btn btn-gold">全部</button>' +
      '<button type="button" data-raf="active" class="btn btn-dark">启用中</button>' +
      '<button type="button" data-raf="disabled" class="btn btn-dark">已停用</button></div>' +
      '<div class="ra-form"><div id="raForm"></div></div><div class="ra-l"></div>';
    listEl = el.querySelector('.ra-l');
    paintForm();
    el.querySelector('.ra-f').addEventListener('click', function (e) {
      var b = e.target.closest('[data-raf]'); if (!b) return;
      filter = b.getAttribute('data-raf'); load();
    });
    listEl.addEventListener('click', function (e) {
      var ed = e.target.closest('[data-ra-edit]');
      if (ed) {
        var id = Number(ed.getAttribute('data-ra-edit'));
        var a = (listEl._data || []).filter(function (x) { return Number(x.id) === id; })[0];
        if (a) { fillForm(a); window.scrollTo({ top: 0, behavior: 'smooth' }); }
        return;
      }
      var tg = e.target.closest('[data-ra-toggle]');
      if (tg) toggle(Number(tg.getAttribute('data-ra-toggle')), tg.getAttribute('data-active') === '1', tg);
    });
    load();
  }

  function ready(fn) { document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn) : fn(); }
  ready(function () {
    var el = document.getElementById('adminReceivingMount');
    if (el && !el.dataset.rap) { el.dataset.rap = '1'; mountPanel(el); }
  });
  window.AdminReceivingPanel = { mount: mountPanel, refresh: load };
})();