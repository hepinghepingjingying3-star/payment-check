// 26牛牛 - 提款申请页
(function () {
  'use strict'; if (!App.requireLogin()) return; App.mountNetBanner();
  var $ = function (id) { return document.getElementById(id); }, summary = null, submitting = false, preparing = false, requestKey = '', pending = null, boxes = [];
  var STATUS = { PENDING: '待审核', APPROVED: '审核通过', REJECTED: '审核拒绝', CANCELLED: '已取消' };
  function esc(v) { return App.escapeHtml(v); }
  function amount() {
    var s = ($('amount').value || '').trim();
    if (!s) { $('amountHint').textContent = '请输入提款金额'; $('amountHint').className = 'field-hint err'; return null; }
    if (!/^\d{1,9}(\.\d{1,2})?$/.test(s)) { $('amountHint').textContent = '提款金额必须大于0，且最多两位小数'; $('amountHint').className = 'field-hint err'; return null; }
    var n = Number(s); if (!isFinite(n) || n <= 0) { $('amountHint').textContent = '提款金额必须大于0'; $('amountHint').className = 'field-hint err'; return null; }
    if (summary && n > Number(summary.available || 0)) { $('amountHint').textContent = '余额不足'; $('amountHint').className = 'field-hint err'; return null; }
    $('amountHint').textContent = '金额有效：RM ' + App.fmtMoney(n); $('amountHint').className = 'field-hint ok'; return n;
  }
  function paint() {
    var a = summary.account || {}, st = String(a.review_status || 'NONE').toUpperCase();
    $('availChips').textContent = App.fmtMoney(summary.available || 0); $('acctName').textContent = a.recipient_name || '未填写'; $('recipientName').value = a.recipient_name || ''; $('recipientName').readOnly = st === 'APPROVED';
    $('bankName').value = a.bank_name || ''; $('acctStatus').textContent = ({ NONE: '未提交', PENDING: '审核中', APPROVED: '已通过', REJECTED: '审核未通过' }[st] || st); $('acctStatus').className = 'v ' + (st === 'APPROVED' ? 'num-green' : st === 'REJECTED' ? 'num-red' : ''); $('acctHint').textContent = st === 'APPROVED' ? '姓名已通过账户资料审核，提交时不可修改。' : '请先完成账户资料审核。'; $('acctHint').className = 'field-hint' + (st === 'APPROVED' ? '' : ' err');
  }
  async function loadSummary() { var r = await App.api('/api/withdrawals/summary'); if (!r.success) { $('errorBox').style.display = 'block'; return App.showError($('errorBox'), r.message || '加载失败', loadSummary); } summary = r.data; $('skeleton').style.display = 'none'; $('content').style.display = 'block'; paint(); }
  async function loadRecords() { var r = await App.api('/api/withdrawals'); if (!r.success) return App.showError($('recordList'), r.message || '记录加载失败', loadRecords); var list = r.data.list || []; $('recordList').innerHTML = list.length ? list.map(function (o) { return '<a class="list-row" href="/withdraw-detail.html?id=' + Number(o.id) + '" style="text-decoration:none;color:inherit"><span class="lr-icon"><span class="ic i-record"></span></span><div class="lr-main"><div class="lr-title">' + esc(STATUS[o.status] || o.status) + '</div><div class="tx-sub">' + esc(o.order_no) + ' · RM ' + App.fmtMoney(o.amount) + ' · ' + App.fmtDateTime(o.created_at) + '</div></div><span class="ic i-next"></span></a>'; }).join('') : App.stateBox('empty', '暂无记录', '还没有提款申请'); }
  function openPwd() { $('pwdBoxes').querySelectorAll('input').forEach(function (x, i) { x.value = ''; if (i === 0) x.focus(); }); $('pwdError').textContent = ''; $('pwdMask').classList.add('show'); }
  function closePwd() { $('pwdMask').classList.remove('show'); }
  boxes = Array.prototype.slice.call($('pwdBoxes').querySelectorAll('input')); boxes.forEach(function (b, i) { b.addEventListener('input', function () { b.value = b.value.replace(/\D/g, '').slice(0, 1); if (b.value && boxes[i + 1]) boxes[i + 1].focus(); }); });
  $('amount').addEventListener('input', amount); $('pwdCancel').addEventListener('click', closePwd);
  $('submitBtn').addEventListener('click', async function () {
    if (preparing || submitting) return;
    var btn = this; preparing = true; btn.disabled = true;
    try {
      var n = amount(); if (n === null) return; var r = ($('recipientName').value || '').trim(), bank = ($('bankName').value || '').trim(), a = ($('bankAccount').value || '').trim(), c = ($('confirmBankAccount').value || '').trim();
    if (!r) return $('payeeHint').textContent = '请输入收款人姓名'; if (!bank) return $('payeeHint').textContent = '请输入银行名称'; if (!/^\d{6,24}$/.test(a)) return $('payeeHint').textContent = '请输入6至24位数字银行账号'; if (a !== c) return $('payeeHint').textContent = '两次银行账号不一致'; $('payeeHint').textContent = ''; $('payeeHint').className = 'field-hint';
    if (summary.account.review_status !== 'APPROVED') return $('formStatus').textContent = '账户资料审核通过后方可提交提款申请';
    var yes = await App.confirmDialog({ title: '确认提款', text: '提款金额：RM ' + App.fmtMoney(n) + '\n收款人：' + r + '\n银行：' + bank + '\n银行账号：' + a + '\n请确认以上资料无误。', okText: '确认提款' }); if (!yes) return;
    if (!requestKey) requestKey = App.newRequestId('wd');
    pending = { amount: n, recipient_name: r, bank_name: bank, bank_account: a, confirm_bank_account: c, idempotency_key: requestKey }; openPwd();
    } finally { preparing = false; btn.disabled = false; }
  });
  $('pwdSubmit').addEventListener('click', async function () { if (submitting || !pending) return; var pwd = boxes.map(function (x) { return x.value; }).join(''); if (!/^\d{6}$/.test(pwd)) return $('pwdError').textContent = '请输入6位支付密码'; submitting = true; this.disabled = true; var r = await App.api('/api/withdrawals', { method: 'POST', body: Object.assign({}, pending, { pay_password: pwd }) }); if (r.success) { closePwd(); requestKey = ''; pending = null; $('formStatus').textContent = '提款申请已提交，等待审核'; $('amount').value = ''; $('confirmBankAccount').value = ''; loadSummary(); loadRecords(); } else $('pwdError').textContent = r.message || '提交失败，请重试'; submitting = false; this.disabled = false; });
  loadSummary(); loadRecords();
})();
