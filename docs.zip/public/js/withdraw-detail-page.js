// 提款详情页：普通用户仅能读取自己的订单，银行账号始终脱敏
(function () {
  'use strict'; if (!App.requireLogin()) return;
  var id = Number(new URLSearchParams(location.search).get('id')); if (!id) { document.getElementById('detail').textContent = '无效的提款订单'; return; }
  App.api('/api/withdrawals/' + id).then(function (r) {
    if (!r.success) { document.getElementById('detail').innerHTML = App.stateBox('error', r.message || '提款详情加载失败'); return; }
    var o = r.data.order, e = App.escapeHtml;
    document.getElementById('detail').innerHTML = '<div class="card-title">提款详情</div>' +
      '<div class="profile-row"><span class="k">提款金额</span><span class="v num-gold">RM ' + App.fmtMoney(o.amount) + '</span></div>' +
      '<div class="profile-row"><span class="k">收款人</span><span class="v">' + e(o.recipient_name || '--') + '</span></div>' +
      '<div class="profile-row"><span class="k">银行</span><span class="v">' + e(o.bank_name || '--') + '</span></div>' +
      '<div class="profile-row"><span class="k">银行账号</span><span class="v">' + e(o.bank_account_masked || '****') + '</span></div>' +
      '<div class="profile-row"><span class="k">提交时间</span><span class="v">' + e(App.fmtDateTime(o.created_at)) + '</span></div>' +
      '<div class="profile-row"><span class="k">状态</span><span class="v">' + e(o.status_text || o.status) + '</span></div>' +
      (o.admin_remark ? '<p class="field-hint err">管理员备注：' + e(o.admin_remark) + '</p>' : '');
  });
})();