// ============================================
// 26牛牛 - 管理后台「26牛牛娱乐场」面板（自包含）
// 数据源：/api/admin/niu/*（仅管理员，后端叠加 auth + requireRole('admin') 二次校验）
// 页面提供 #panel-niu 中的固定 DOM 即自动挂载
// ============================================
(function () {
  'use strict';
  if (!window.App) return;

  var $ = function (id) { return document.getElementById(id); };
  var esc = App.escapeHtml;
  var state = { loaded: false, offset: 0, limit: 20, total: 0, busy: false };

  function num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
  function dt(v) { return v ? App.fmtDateTime(v) : '--'; }

  function statCard(label, value, sub) {
    return '<div class="stat-card"><div class="stat-k">' + esc(label) + '</div>' +
      '<div class="stat-v">' + esc(String(value)) + '</div>' +
      '<div class="stat-s">' + esc(sub || '') + '</div></div>';
  }

  async function writeAction(button, run) {
    if (state.busy) return null;
    state.busy = true;
    if (button) button.disabled = true;
    try {
      return await run();
    } finally {
      state.busy = false;
      if (button) button.disabled = false;
    }
  }

  // ---------- 运行状态 ----------
  async function loadStatus() {
    var box = $('niuStatus');
    if (box) box.innerHTML = App.stateBox('loading', '加载运行状态…');
    var res = await App.api('/api/admin/niu/status');
    if (!res.success || !res.data) {
      if (box) App.showError(box, res.message || '状态加载失败', loadStatus);
      return;
    }
    var d = res.data;
    if (box) {
      box.innerHTML = '当前状态：<b>' + (d.enabled ? '已开启' : '已关闭') + '</b>　资产：' +
        esc((d.asset && d.asset.text) || '游戏积分') + '（不可充值 / 不可提现 / 不可兑换现金）';
    }
    var grid = $('niuStatGrid');
    if (grid) {
      grid.innerHTML =
        statCard('进行中的房间', (d.live_rooms || []).length, '实时在线房间数') +
        statCard('今日对局', num(d.today_rounds), '真实对局记录') +
        statCard('近 7 天对局', num(d.week && d.week.rounds), '含已结算 / 结算中 / 作废') +
        statCard('近 7 天已结算', num(d.week && d.week.finished), '已写入积分与流水') +
        statCard('近 7 天作废', num(d.week && d.week.aborted), '不产生任何积分变动');
    }
    var live = (d.live_rooms || []).map(function (r) {
      return r.name + '（' + r.phase + '，' + r.seats + ' 人' + (r.playing ? '，对局中' : '') + '）';
    }).join('；');
    var liveBox = $('niuLive');
    if (liveBox) liveBox.textContent = live || '当前没有在线房间';
  }

  // ---------- 场次选项（真实配置，来自后端） ----------
  async function loadRooms() {
    var sel = $('niuRoomFilter');
    if (!sel || sel.dataset.ready === '1') return;
    var res = await App.api('/api/game/niu/config');
    if (!res.success || !res.data) return;
    (res.data.rooms || []).forEach(function (r) {
      var o = document.createElement('option');
      o.value = r.key;
      o.textContent = r.name + '（底分 ' + r.base_stake + '）';
      sel.appendChild(o);
    });
    sel.dataset.ready = '1';
  }

  // ---------- 对局列表（真实数据，只读） ----------
  async function loadRounds() {
    var box = $('niuRounds');
    if (box) box.innerHTML = App.stateBox('loading', '加载对局记录…');
    var qs = 'limit=' + state.limit + '&offset=' + state.offset;
    var room = $('niuRoomFilter') && $('niuRoomFilter').value;
    var status = $('niuRoundStatus') && $('niuRoundStatus').value;
    var uid = $('niuUserId') && String($('niuUserId').value || '').trim();
    if (room) qs += '&room=' + encodeURIComponent(room);
    if (status) qs += '&status=' + encodeURIComponent(status);
    if (uid) qs += '&user_id=' + encodeURIComponent(uid);

    var res = await App.api('/api/admin/niu/rounds?' + qs);
    if (!res.success || !res.data) {
      if (box) App.showError(box, res.message || '对局记录加载失败', loadRounds);
      return;
    }
    state.total = num(res.data.total);
    var list = res.data.list || [];
    if (box) {
      if (!list.length) {
        box.innerHTML = App.stateBox('empty', '暂无对局记录', '还没有真实对局数据。');
      } else {
        box.innerHTML = list.map(function (r) {
          return '<div class="card" style="padding:12px;margin-bottom:8px">' +
            '<div class="admin-tools" style="justify-content:space-between">' +
            '<b>#' + num(r.id) + ' · ' + esc(r.round_no || '') + '</b>' +
            '<span class="tag">' + esc(r.status) + '</span></div>' +
            '<div class="admin-note">场次：' + esc(r.room_key) + ' · 底分：' + esc(r.base_stake) +
            ' · 人数：' + num(r.player_count) + ' · 庄家：' + esc(r.banker_user_id || '--') + '</div>' +
            '<div class="admin-note">开局：' + dt(r.started_at) + ' · 结算：' + dt(r.ended_at) + '</div>' +
            '<div class="admin-tools"><button class="btn btn-dark btn-sm" type="button" data-niu-round="' + num(r.id) + '">查看明细</button></div>' +
            '<div id="niuRoundDetail' + num(r.id) + '"></div>' +
            '</div>';
        }).join('');
      }
    }
    var sum = $('niuRoundsSummary');
    if (sum) {
      sum.textContent = state.total
        ? '共 ' + state.total + ' 条，当前显示第 ' + (state.offset + 1) + ' - ' +
          Math.min(state.offset + state.limit, state.total) + ' 条'
        : '共 0 条';
    }
    if ($('niuPrev')) $('niuPrev').disabled = state.offset <= 0;
    if ($('niuNext')) $('niuNext').disabled = state.offset + state.limit >= state.total;
  }

  // ---------- 对局明细（服务端已落库的牌型 / 积分，只读） ----------
  async function showRoundDetail(id, mount) {
    if (!mount) return;
    mount.innerHTML = App.stateBox('loading', '加载对局明细…');
    var res = await App.api('/api/admin/niu/rounds/' + num(id));
    if (!res.success || !res.data) {
      App.showError(mount, res.message || '明细加载失败', function () { showRoundDetail(id, mount); });
      return;
    }
    var d = res.data;
    mount.innerHTML = '<div class="admin-note">牌型与积分全部由服务端计算并落库，此处只读，不可修改历史结果。</div>' +
      (d.players || []).map(function (p) {
        var cards = (p.cards || []).map(function (c) { return (c.rank_label || '') + (c.suit_code || ''); }).join(' ');
        return '<div class="admin-note">' +
          esc(p.nickname) + '（ID ' + num(p.user_id) + '）· ' + esc(p.role) +
          ' · 抢庄：' + (num(p.grab_flag) ? '是' : '否') +
          ' · 倍数：x' + num(p.bet_level) +
          ' · 牌：' + esc(cards) +
          ' · 牌型：' + esc(p.hand_name || p.hand_key || '--') + '（' + num(p.point_value) + ' 点）' +
          ' · 结算：' + (num(p.delta) >= 0 ? '+' : '') + num(p.delta) +
          ' · 结算前后：' + num(p.balance_before) + ' → ' + num(p.balance_after) +
          (p.is_capped ? '（积分不足封顶）' : '') +
          '</div>';
      }).join('');
  }

  // ---------- 开关游戏（写审计日志） ----------
  async function toggleGame(enabled, button) {
    var res = await writeAction(button, function () {
      return App.api('/api/admin/niu/switch', {
        method: 'POST',
        body: { enabled: enabled, reason: enabled ? '管理员开启 26牛牛娱乐场' : '管理员关闭 26牛牛娱乐场' }
      });
    });
    if (!res) return;
    if (!res.success) { App.toast(res.message || '操作失败', 'err'); return; }
    App.toast(res.message || '已完成', 'ok');
    await loadStatus();
  }

  // ---------- 发放游戏积分（必填原因，写流水 + 审计） ----------
  async function grantPoints(button) {
    var uid = num($('niuGrantUser') && $('niuGrantUser').value);
    var amount = num($('niuGrantAmount') && $('niuGrantAmount').value);
    var reason = String(($('niuGrantReason') && $('niuGrantReason').value) || '').trim();
    if (!uid) { App.toast('请填写用户 ID', 'err'); return; }
    if (!(amount > 0)) { App.toast('发放数量必须大于 0', 'err'); return; }
    if (reason.length < 2) { App.toast('必须填写发放原因', 'err'); return; }
    var res = await writeAction(button, function () {
      return App.api('/api/admin/niu/grant-points', {
        method: 'POST', body: { user_id: uid, amount: amount, reason: reason }
      });
    });
    if (!res) return;
    if (!res.success) { App.toast(res.message || '发放失败', 'err'); return; }
    App.toast(res.message || '已发放', 'ok');
    if ($('niuGrantAmount')) $('niuGrantAmount').value = '';
    if ($('niuGrantReason')) $('niuGrantReason').value = '';
  }

  // ============================================
  // 游戏机器人（后端权威）
  // 说明：状态与操作全部走 /api/admin/niu/bot/*，后端叠加 auth + requireRole('admin')。
  //   - 启动 / 停止都幂等，绝不会因为连点而开出第二局或重复播报
  //   - 所有写操作都由后端写审计日志，前端不伪造任何状态
  // ============================================

  var botTpl = { list: [] };

  function fmtCountdown(endsAt) {
    var t = new Date(endsAt).getTime();
    if (!endsAt || !isFinite(t)) return '--';
    var left = Math.max(0, Math.round((t - Date.now()) / 1000));
    if (left <= 0) return '已到时（等待下一次心跳推进）';
    var m = Math.floor(left / 60), s = left % 60;
    return m > 0 ? (m + ' 分 ' + s + ' 秒后自动推进') : (s + ' 秒后自动推进');
  }

  async function loadBot() {
    var box = $('niuBotStatus');
    if (box) box.textContent = '加载机器人状态…';
    var res = await App.api('/api/admin/niu/bot/status');
    var auto = $('niuBotAuto');
    if (!res.success || !res.data) {
      if (box) App.showError(box, res.message || '机器人状态加载失败', loadBot);
      return;
    }
    var d = res.data;
    var running = !!d.running;
    if (box) {
      box.innerHTML = '机器人状态：<b>' + (running ? '运行中' : '已停止') + '</b>　' +
        '场次：' + esc(d.room_name || d.room_key || '--') +
        '　自动游戏消息：' + (d.auto_messages ? '开' : '关') +
        (running ? '' : '（已停止时不会自动开局 / 不推进新阶段）') + '<br>当前对局：' +
        (d.current_round_id ? esc(d.current_round_id) : '无') +
        '　当前阶段：' + esc(d.current_phase || '--') +
        '　' + esc(fmtCountdown(d.phase_ends_at)) +
        '<br>最近更新：' + esc(dt(d.updated_at));
    }
    if (auto) {
      auto.checked = !!d.auto_messages;
      // 机器人已停止时自动消息开关无意义，禁用避免误解
      auto.disabled = !running;
      auto.title = running ? '' : '请先启动机器人';
    }
    var bs = $('niuBotStart'), bp = $('niuBotStop');
    if (bs) bs.disabled = running;    // 运行中禁用「启动」，从界面层面避免重复点击
    if (bp) bp.disabled = !running;
  }

  async function botAction(action, body) {
    var res = await writeAction(null, function () {
      return App.api('/api/admin/niu/bot/' + action, { method: 'POST', body: body || {} });
    });
    if (!res) return null;
    if (!res.success) { App.toast(res.message || '操作失败', 'err'); return null; }
    App.toast(res.message || '已完成', 'ok');
    await loadBot();
    return res;
  }

  async function startBot() {
    var room = $('niuBotRoom') ? $('niuBotRoom').value : '';
    var res = await botAction('start', room ? { room_key: room } : {});
    // 启动后立刻刷一次对局列表，好看到新开出来的局
    if (res) { state.offset = 0; await loadRounds(); }
  }

  async function toggleAutoMessages(enabled) {
    var res = await botAction('auto-messages', { enabled: enabled });
    if (!res) await loadBot();   // 失败时把开关状态还原成后端真实值
  }
// ---------- 话术模板（默认文案来自后端，前端不硬编码） ----------
  function renderTemplates() {
    var box = $('niuBotTemplates');
    if (!box) return;
    if (box.dataset.rendered !== '1') {
      box.innerHTML = botTpl.list.map(function (t) {
        return '<label for="niuTpl_' + esc(t.key) + '">' + esc(t.label) + '</label>' +
          '<input class="input" id="niuTpl_' + esc(t.key) + '" type="text" maxlength="300" ' +
          'data-tpl="' + esc(t.key) + '">';
      }).join('');
      box.dataset.rendered = '1';
    }
    botTpl.list.forEach(function (t) {
      var el = $('niuTpl_' + t.key);
      // 正在编辑的输入框不覆盖，避免轮询刷新时把管理员输入的内容冲掉
      if (el && document.activeElement !== el) el.value = t.value || '';
    });
  }

  async function loadTemplates() {
    var box = $('niuBotTemplates');
    if (box && !box.dataset.rendered) box.innerHTML = App.stateBox('loading', '加载话术模板…');
    var res = await App.api('/api/admin/niu/bot/templates');
    if (!res.success || !res.data) {
      if (box) App.showError(box, res.message || '话术模板加载失败', loadTemplates);
      return;
    }
    botTpl.list = res.data.templates || [];
    renderTemplates();
  }

  async function saveTemplates(onlyDefaults) {
    var body = {};
    if (onlyDefaults) {
      botTpl.list.forEach(function (t) { body[t.key] = t.default_value; });
    } else {
      var empty = null;
      botTpl.list.forEach(function (t) {
        var el = $('niuTpl_' + t.key);
        var v = el ? String(el.value || '').trim() : '';
        if (!v) { if (empty === null) empty = t.label; return; }
        if (v === t.value) return;         // 没改就不提交
        body[t.key] = v;
      });
      if (empty) { App.toast('「' + empty + '」不能为空（留空会清空话术）', 'err'); return; }
      if (!Object.keys(body).length) { App.toast('没有需要保存的修改', 'err'); return; }
    }
    var res = await writeAction(null, function () {
      return App.api('/api/admin/niu/bot/templates', { method: 'POST', body: { templates: body } });
    });
    if (!res) return;
    if (!res.success) { App.toast(res.message || '保存失败', 'err'); return; }
    App.toast(res.message || '话术已保存并立即生效', 'ok');
    if (res.data && res.data.templates) botTpl.list = res.data.templates;
    renderTemplates();
  }

  // ---------- 管理员手动发消息（机器人系统身份） ----------
  async function adminSay(button) {
    var text = String(($('niuBotSayText') && $('niuBotSayText').value) || '').trim();
    if (!text) { App.toast('请填写消息内容', 'err'); return; }
    if (text.length > 300) { App.toast('消息最多 300 字', 'err'); return; }
    var type = ($('niuBotSayType') && $('niuBotSayType').value) === 'game' ? 'game' : 'system';
    var res = await writeAction(button, function () {
      return App.api('/api/admin/niu/bot/say', {
        method: 'POST', body: { content: text, message_type: type }
      });
    });
    if (!res) return;
    if (!res.success) { App.toast(res.message || '发送失败', 'err'); return; }
    App.toast(res.message || '已发送', 'ok');
    if ($('niuBotSayText')) $('niuBotSayText').value = '';
  }

  function bindBot() {
    if (bindBot.done) return;
    bindBot.done = true;
    if ($('niuBotStart')) $('niuBotStart').addEventListener('click', startBot);
    if ($('niuBotStop')) $('niuBotStop').addEventListener('click', function () {
      botAction('stop', { reason: '管理员在后台手动停止机器人' });
    });
    if ($('niuBotRefresh')) $('niuBotRefresh').addEventListener('click', loadBot);
    if ($('niuBotAuto')) $('niuBotAuto').addEventListener('change', function () {
      toggleAutoMessages(this.checked);
    });
    if ($('niuBotTplSave')) $('niuBotTplSave').addEventListener('click', function () { saveTemplates(false); });
    if ($('niuBotTplReset')) $('niuBotTplReset').addEventListener('click', function () { saveTemplates(true); });
    if ($('niuBotSayBtn')) $('niuBotSayBtn').addEventListener('click', function () { adminSay(this); });
  }

  // 娱乐场主区（开关 / 对局列表 / 积分发放）事件绑定
  function bind() {
    if (bind.done) return;
    bind.done = true;
    if ($('niuEnable')) $('niuEnable').addEventListener('click', function () { toggleGame(true, this); });
    if ($('niuDisable')) $('niuDisable').addEventListener('click', function () { toggleGame(false, this); });
    if ($('niuRefresh')) $('niuRefresh').addEventListener('click', function () { loadStatus(); loadRounds(); });
    if ($('niuRoundsSearch')) $('niuRoundsSearch').addEventListener('click', function () { state.offset = 0; loadRounds(); });
    if ($('niuPrev')) $('niuPrev').addEventListener('click', function () {
      state.offset = Math.max(0, state.offset - state.limit); loadRounds();
    });
    if ($('niuNext')) $('niuNext').addEventListener('click', function () {
      if (state.offset + state.limit < state.total) { state.offset += state.limit; loadRounds(); }
    });
    if ($('niuGrantBtn')) $('niuGrantBtn').addEventListener('click', function () { grantPoints(this); });
    var panel = $('panel-niu');
    if (panel) {
      panel.addEventListener('click', function (ev) {
        var btn = ev.target.closest ? ev.target.closest('[data-niu-round]') : null;
        if (!btn) return;
        var id = num(btn.getAttribute('data-niu-round'));
        showRoundDetail(id, $('niuRoundDetail' + id));
      });
    }
  }

  async function refresh(tab) {
    if (tab && tab !== 'niu') return;
    bind();
    bindBot();
    // 机器人状态与话术模板也必须在切到本页时立即加载，
    // 否则状态区会一直停在「加载机器人状态…」的占位文案上。
    await loadRooms();
    await Promise.all([
      loadStatus(),
      loadRounds(),
      loadBot(),
      loadTemplates()
    ]);
    state.loaded = true;
  }

  window.AdminNiuPanel = { refresh: refresh };
})();
