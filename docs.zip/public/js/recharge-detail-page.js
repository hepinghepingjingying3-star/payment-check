// ============================================
// 26牛牛 - 充值订单详情页（现金筹码）
// 状态: 待审核 / 已完成 / 已拒绝 / 已取消 / 已过期
// ============================================
(function () {
  'use strict';
  if (!App.requireLogin()) return;
  App.mountNetBanner();

  var $ = function (id) { return document.getElementById(id); };
  var esc = App.escapeHtml;
  var orderId = new URLSearchParams(window.location.search).get('id');
  var STATUS_CLS = { PENDING: 'pending', COMPLETED: 'ok', REJECTED: 'fail', CANCELLED: 'fail', EXPIRED: 'fail' };
  var STATUS_TEXT = { PENDING: '待审核', COMPLETED: '审核通过', REJECTED: '审核拒绝', CANCELLED: '已取消', EXPIRED: '已过期' };

  async function load() {
    var box = $('detailBox');
    if (!orderId || !/^\d+$/.test(orderId)) {
      box.innerHTML = App.stateBox('error', '订单不存在', '链接参数无效');
      return;
    }
    var res = await App.api('/api/recharge/orders/' + orderId);
    if (!res.success) {
      box.innerHTML = App.stateBox('error', '订单加载失败', res.message || '请稍后重试');
      return;
    }
    paint(res.data.order);
  }

  function paint(o) {
    var cls = STATUS_CLS[o.status] || 'pending';
    var stText = STATUS_TEXT[o.status] || o.status_text || o.status;
    var acc = o.receiving_account || null;
    // 订单绑定的收款账户来自订单快照，后台后来停用/修改账户也不会改变历史订单
    var accHtml = acc
      ? '<div class="profile-row"><span class="k">收款方式</span><span class="v">' + esc(acc.type_text || acc.type || '') + '</span></div>' +
        '<div class="profile-row"><span class="k">' + esc(acc.type === 'EWALLET' ? '电子钱包' : '收款银行') + '</span><span class="v">' + esc(acc.name) + '</span></div>' +
        '<div class="profile-row"><span class="k">收款账号</span><span class="v">' + esc(acc.account_no) + '</span></div>' +
        '<div class="profile-row"><span class="k">收款户名</span><span class="v">' + esc(acc.holder) + '</span></div>'
      : '<div class="profile-row"><span class="k">收款账户</span><span class="v">未分配</span></div>';
    var refHtml = o.payment_reference
      ? '<div class="profile-row"><span class="k">付款参考编号</span><span class="v">' + esc(o.payment_reference) + '</span></div>' : '';
    var pendingTip = o.status === 'PENDING'
      ? '<div class="card" style="margin-top:12px;"><div class="flex-row" style="align-items:flex-start;">' +
        '<span class="ic i-info" style="flex-shrink:0;margin-top:2px;"></span>' +
        '<div class="tx-sub">平台未接入任何真实支付渠道，订单需由管理员人工审核后现金筹码才会到账。审核前不会产生任何余额变化。</div></div></div>'
      : '';
    var rejectTip = (o.status === 'REJECTED' && (o.reject_reason || o.admin_remark))
      ? '<div class="card" style="margin-top:12px;"><div class="tx-sub">拒绝原因：' + esc(o.reject_reason || '') +
        (o.admin_remark ? '<br>管理员备注：' + esc(o.admin_remark) : '') + '</div></div>'
      : (o.admin_remark ? '<div class="card" style="margin-top:12px;"><div class="tx-sub">管理员备注：' + esc(o.admin_remark) + '</div></div>' : '');

    var cancelBtn = o.status === 'PENDING'
      ? '<button class="btn btn-dark btn-block mt-12" id="cancelBtn" type="button">取消订单</button>'
      : '';

    $('detailBox').innerHTML =
      '<div class="card card-gold">' +
        '<div class="flex-row" style="justify-content:space-between;">' +
          '<div class="card-title">充值订单</div>' +
          '<span class="order-tag ' + cls + '">' + esc(stText) + '</span>' +
        '</div>' +
        '<div class="asset-value num-gold mt-8" style="font-size:28px;">' +
          Number(o.amount).toLocaleString('en-US') + ' <span style="font-size:14px;">现金筹码</span></div>' +
      '</div>' +
      '<div class="card mt-12">' +
        '<div class="profile-row"><span class="k">订单号</span><span class="v">' + esc(o.order_id) + '</span></div>' +
        '<div class="profile-row"><span class="k">充值数量</span><span class="v">' + Number(o.amount).toLocaleString('en-US') + ' 现金筹码</span></div>' +
        refHtml +
        '<div class="profile-row"><span class="k">状态</span><span class="v">' + esc(stText) + '</span></div>' +
        '<div class="profile-row"><span class="k">创建时间</span><span class="v">' + esc(App.fmtDateTime(o.created_at)) + '</span></div>' +
        (o.completed_at
          ? '<div class="profile-row"><span class="k">' + (o.status === 'COMPLETED' ? '完成时间' : '处理时间') + '</span><span class="v">' + esc(App.fmtDateTime(o.completed_at)) + '</span></div>'
          : '') +
      '</div>' +
      '<div class="card mt-12"><div class="card-title">本订单收款资料</div>' + accHtml + '</div>' +
      (o.has_receipt || o.receipt_url
        ? '<div class="card mt-12"><div class="card-title">充值凭证</div><img src="' + esc(o.receipt_url || ('/api/recharge/orders/' + Number(o.id) + '/receipt')) + '" alt="充值凭证" style="max-width:100%;border-radius:8px;margin-top:8px;" loading="lazy"></div>'
        : '') +
      pendingTip + rejectTip + cancelBtn;

    var btn = document.getElementById('cancelBtn');
    if (btn) {
      btn.addEventListener('click', async function () {
        var okGo = await App.confirmDialog({ title: '取消充值订单', text: '确定取消该充值订单吗？', okText: '取消订单', danger: true });
        if (!okGo) return;
        btn.disabled = true;
        var r = await App.api('/api/recharge/orders/' + orderId + '/cancel', { method: 'POST' });
        if (!r.success) {
          btn.disabled = false;
          App.toast(r.message || '取消失败，请稍后重试', 'err');
          return;
        }
        App.toast('订单已取消', 'ok');
        paint(r.data.order);
      });
    }
  }

  load();
})();
