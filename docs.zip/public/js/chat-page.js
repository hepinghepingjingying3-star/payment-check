// ============================================
// 26牛牛 - 聊天页公共模块（游戏群 / 在线客服共用）
// 职责:
//   - 消息分页加载（首屏最近 30 条，向上翻页加载更旧，cursor=before）
//   - 消息渲染: text / image / sticker / system / game / redpacket 分开渲染
//   - 每条消息都显示说话人名字（自己=我 + 用户名，别人=对方用户名，系统/游戏=来源）
//   - 发送: 发送中 → 成功 / 失败可重试，防止重复发送
//   - 长按消息: 自己(复制/撤回) 别人(复制/举报)
//   - 贴图面板: 官方贴图(站长真实素材) + 我的贴图(上传/删除)
//   - 轻量轮询拉新消息（REST 架构，消息结构可无痛升级 WebSocket）
//   - 页面离开清理 timer，避免无限 setInterval
// ============================================
(function () {
  'use strict';

  var CH = {
    channel: '',
    lastId: 0,          // 已加载的最大消息 id
    oldestId: 0,        // 已加载的最小消息 id（向上翻页用）
    hasMore: true,
    loading: false,
    pollTimer: null,
    seenIds: {},        // 已渲染消息 id 去重（REST 响应与 Socket 推送可能同达）
    sockActive: false,  // Socket 实时模式是否在线（在线时停用轮询）
    stickerPanelOpen: false,
    sending: false,
    rpState: {},        // packet_id -> 最新红包数据（点击/领取后刷新气泡）
    redPacket: null,    // 红包配置（来自 /api/chat/channels）
    myMute: null,       // 我的禁言状态（来自 /api/chat/channels）
    el: {}
  };

  function $(id) { return document.getElementById(id); }
  function esc(s) { return App.escapeHtml(s); }

  // ---------- 消息渲染 ----------
  function stickerImg(url) {
    return '<img class="sticker-img" src="' + esc(url) + '" alt="贴图" loading="lazy">';
  }
  function bubbleContent(m) {
    if (m.is_recalled) return '<span class="msg-recalled">消息已撤回</span>';
    var meta = m.meta || {};
    if (m.message_type === 'sticker') return stickerImg(meta.url || '');
    if (m.message_type === 'image') return '<img class="photo-img" src="' + esc(meta.url || '') + '" alt="图片" loading="lazy">';
    if (m.message_type === 'redpacket') return rpCardHtml(m);
    return esc(m.content || '');
  }
  /**
   * 说话人显示名（每条消息都要能看出是谁在讲话，绝不出现「没有名字的气泡」）:
   *   - 别人的消息 → 对方用户名
   *   - 自己的消息 → 我 · 我的用户名（右对齐）
   *   - 系统 / 游戏消息 → 系统 / 游戏助手（居中提示）
   * 用户名取不到时兜底为「玩家」/「我」，避免界面出现空白名字。
   */
  function speakerName(m) {
    if (m.message_type === 'system') return { text: '系统', mine: false };
    if (m.message_type === 'game') return { text: '游戏助手', mine: false };
    if (m.sender_role === 'admin') return { text: '客服', mine: false };
    var mine = !!m.is_mine;
    var me = App.getUser() || {};
    var raw = String(m.username || '').trim() || (mine ? String(me.username || '').trim() : '');
    if (!raw) raw = mine ? '我' : '玩家';
    return { text: (mine && raw !== '我') ? '我 · ' + raw : raw, mine: mine };
  }

  function nameHtml(m) {
    var sp = speakerName(m);
    return '<div class="m-name' + (sp.mine ? ' mine' : '') + '" title="' + esc(sp.text) + '">' +
      esc(sp.text) + '</div>';
  }

  function msgHtml(m) {
    if (m.message_type === 'system') {
      return '<div class="sys-line"><span class="sys-name">' + esc(speakerName(m).text) + '</span>' +
        '<span class="sys-bubble">' + esc(m.content || '') + '</span></div>';
    }
    if (m.message_type === 'game') {
      return '<div class="game-line"><span class="game-name">' + esc(speakerName(m).text) + '</span>' +
        '<span class="game-bubble"><span class="ic i-game"></span>' + esc(m.content || '') + '</span></div>';
    }
    var mine = !!m.is_mine;
    var av = (/^\/assets\/avatars\/users\/[a-zA-Z0-9-]+\.(jpg|png|webp)$/.test(m.avatar_url || ''))
      ? '<img src="' + esc(m.avatar_url) + '" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" onerror="this.remove();">'
      : esc((mine
        ? String((App.getUser() || {}).username || '?')
        : String(m.username || '?')).slice(0, 1).toUpperCase() || '?');
    var name = nameHtml(m);
    var recalled = m.is_recalled;
    var isRp = m.message_type === 'redpacket' && !recalled;
    return '<div class="msg' + (mine ? ' me' : '') + '">' +
      '<div class="msg-row">' +
      '<div class="m-avatar">' + av + '</div>' +
      '<div class="m-body">' + name +
      '<div class="bubble' + (isRp ? ' rp' : '') + (recalled ? ' recalled' : '') + '" data-id="' + m.id + '" data-mine="' + (mine ? 1 : 0) + '"' +
      (isRp ? ' data-packet="' + Number((m.meta || {}).packet_id || 0) + '"' : '') + '>' +
      (recalled ? '消息已撤回' : bubbleContent(m)) + '</div>' +
      '<div class="m-time">' + App.fmtTime(m.created_at) + '</div>' +
      (mine ? '<div class="m-status" id="st-' + m.id + '"></div>' : '') +
      '</div></div></div>';
  }

  // ---------- 聊天红包（平台现金筹码，非真实资金） ----------
  /**
   * 红包配置：页面传入（/api/chat/channels）优先；
   * 若页面没传（脚本顺序 / 接口偶发失败）则这里自行补拉一次，
   * 保证「发红包」入口不会因为一次请求失败而消失。
   */
  async function ensureRedPacketConfig() {
    if (CH.redPacket) return CH.redPacket;
    var res = await App.api('/api/chat/channels');
    if (res.success && res.data) {
      CH.redPacket = res.data.red_packet || null;
      if (!CH.myMute) CH.myMute = res.data.my_mute || null;
    }
    return CH.redPacket;
  }

  /** 红包气泡卡片；状态优先取「本地已拉取的最新数据」（CH.rpState） */
  function rpCardHtml(m) {
    var meta = m.meta || {};
    var pid = Number(meta.packet_id || 0);
    var live = CH.rpState[pid] || null;
    var status = (live && live.status) || meta.status || 'OPEN';
    var claimedCount = live ? live.claimed_count : 0;
    var totalCount = live ? live.total_count : Number(meta.total_count || 0);
    var mineAmount = live && live.my_claim ? Number(live.my_claim.amount) : null;
    var done = status !== 'OPEN' || mineAmount !== null;
    var stateText = mineAmount !== null ? '已抢 ' + mineAmount.toFixed(2)
      : (status === 'EMPTY' ? '已抢光' : (status === 'EXPIRED' ? '已过期' : '待领取'));
    var sub = '已领 ' + (claimedCount || 0) + '/' + (totalCount || 0) + ' 个 · 现金筹码';
    return '<button type="button" class="rp-card' + (done ? ' done' : '') +
      (mineAmount !== null ? ' mine-claimed' : '') + '" data-packet="' + pid + '">' +
      '<span class="rp-ic"><span class="ic i-packet"></span></span>' +
      '<span class="rp-main">' +
      '<span class="rp-bless">' + esc(meta.blessing || '恭喜发财，大吉大利') + '</span>' +
      '<span class="rp-sub">' + esc(sub) + '</span>' +
      '</span>' +
      '<span class="rp-state">' + esc(stateText) + '</span>' +
      '</button>';
  }

  /** 用最新红包数据刷新气泡（不重新渲染整条消息） */
  function updateRpBubble(packet) {
    if (!packet || !packet.id) return;
    CH.rpState[packet.id] = packet;
    var bubble = CH.el.list.querySelector('.bubble.rp[data-packet="' + Number(packet.id) + '"]');
    if (!bubble) return;
    bubble.innerHTML = rpCardHtml({
      meta: {
        packet_id: packet.id, blessing: packet.blessing,
        total_count: packet.total_count, status: packet.status
      }
    });
  }

  function rpDetailHtml(p, myAmount) {
    var html = '';
    if (myAmount !== null && myAmount !== undefined) {
      html += '<div class="rp-detail-amount"><span class="amt">' + Number(myAmount).toFixed(2) +
        '</span><span class="unit">RM</span></div>' +
        '<div class="rp-detail-sub">已存入' + esc(p.asset_text || '现金筹码') + '</div>';
    }
    html += '<div class="rp-detail-meta">' + esc(p.sender_name || '玩家') + ' 发出 · ' + esc(p.blessing || '') + '</div>' +
      '<div class="rp-detail-meta">' + esc(p.status_text) + ' · 已领 ' + p.claimed_count + '/' + p.total_count +
      ' 个 · 共 RM' + Number(p.total_amount).toFixed(2) + '</div>';
    if (p.best) {
      html += '<div class="rp-detail-meta">手气最佳：' + esc(p.best.username) + ' RM' + Number(p.best.amount).toFixed(2) + '</div>';
    }
    // 兜底：任何来源的 packet 都不能让界面出现「undefined 人」
    var claimList = p.claims || [];
    var claimTotal = (p.claims_total === undefined || p.claims_total === null)
      ? claimList.length : Number(p.claims_total);
    html += '<div class="rp-claims"><div class="rp-claims-title">领取记录（' + claimTotal + ' 人）</div>';
    if (!claimList.length) {
      html += '<div class="rp-claim-empty">还没有人领取</div>';
    } else {
      html += claimList.map(function (c) {
        return '<div class="rp-claim-row"><span class="who">' + esc(c.username) +
          (c.is_mine ? '<span class="me">我</span>' : '') + '</span><span class="amt">' +
          Number(c.amount).toFixed(2) + '</span></div>';
      }).join('');
      if (claimTotal > claimList.length) {
        html += '<div class="rp-claim-empty">仅显示最早 ' + claimList.length + ' 条</div>';
      }
    }
    html += '</div><div class="rp-note">' + esc(p.notice || '') + '</div>';
    return html;
  }

  function showRedPacketDetail(p, myAmount) {
    return App.openFormSheet({
      title: (myAmount === null || myAmount === undefined) ? '红包详情' : '已抢到红包',
      fields: [],
      extraHtml: rpDetailHtml(p, myAmount),
      okText: '知道了'
    });
  }

  async function fetchRedPacket(pid) {
    var res = await App.api('/api/chat/redpackets/' + Number(pid));
    if (!res.success || !res.data || !res.data.packet) {
      App.toast(res.message || '红包加载失败', 'err');
      return null;
    }
    updateRpBubble(res.data.packet);
    return res.data.packet;
  }

  async function claimRedPacket(pid) {
    var res = await App.api('/api/chat/redpackets/' + Number(pid) + '/claim', { method: 'POST' });
    var packet = res.data && res.data.packet ? res.data.packet : null;
    if (packet) updateRpBubble(packet);
    if (!res.success) {
      App.toast(res.message || '抢红包失败', 'err');
      return { ok: false, packet: packet };
    }
    App.toast('已抢到 RM' + Number(res.data.amount).toFixed(2), 'ok');
    return { ok: true, packet: packet, amount: res.data.amount };
  }

  /** 点击红包气泡：能领则先确认再抢，否则直接看详情 */
  async function openRedPacket(pid) {
    var p = await fetchRedPacket(pid);
    if (!p) return;
    if (p.can_claim) {
      var okk = await App.confirmDialog({
        title: '抢红包',
        text: (p.sender_name || '玩家') + ' 发出的现金筹码红包：' + (p.blessing || '恭喜发财'),
        okText: '抢红包'
      });
      if (!okk) return;
      var claimed = await claimRedPacket(p.id);
      if (claimed.ok && claimed.packet) {
        showRedPacketDetail(claimed.packet, claimed.amount);
        return;
      }
      var latest = claimed.packet || await fetchRedPacket(p.id);
      if (latest) showRedPacketDetail(latest, latest.my_claim ? latest.my_claim.amount : null);
      return;
    }
    showRedPacketDetail(p, p.my_claim ? p.my_claim.amount : null);
  }

  /** 发红包：金额 / 个数 / 祝福语（现金筹码，参数来自 /api/chat/channels） */
  async function sendRedPacket() {
    var cfg = CH.redPacket;
    if (!cfg || !cfg.enabled) { App.toast('当前不支持发红包', 'err'); return; }
    if (CH.myMute && CH.myMute.muted) { App.toast(CH.myMute.notice || '您已被禁言', 'err'); return; }

    var values = await App.openFormSheet({
      title: '发红包',
      okText: '塞钱进红包',
      fields: [
        {
          key: 'amount', label: '总金额（RM）', type: 'number',
          min: cfg.min_amount, max: cfg.max_amount, step: '0.01',
          placeholder: '例如 10.00',
          hint: '可发 ' + cfg.min_amount + '–' + cfg.max_amount + ' RM · ' + (cfg.asset_text || '')
        },
        {
          key: 'count', label: '红包个数', type: 'number',
          min: cfg.min_count, max: cfg.max_count, step: '1', value: '5',
          hint: '每人随机金额，' + cfg.min_count + '–' + cfg.max_count + ' 个'
        },
        {
          key: 'blessing', label: '祝福语（可选）', type: 'text', maxlength: cfg.blessing_max,
          placeholder: '恭喜发财，大吉大利'
        }
      ],
      extraHtml: '<div class="rp-note">' + esc(cfg.notice || '') +
        ' 未领取部分将在 ' + Number(cfg.expire_hours) + ' 小时后自动退回。</div>',
      onSubmit: function (v) {
        var amount = Number(v.amount);
        var count = Math.floor(Number(v.count));
        if (!isFinite(amount) || amount < cfg.min_amount || amount > cfg.max_amount) {
          App.toast('金额需在 ' + cfg.min_amount + '–' + cfg.max_amount + ' RM 之间', 'err');
          return false;
        }
        if (!isFinite(count) || count < cfg.min_count || count > cfg.max_count) {
          App.toast('个数需在 ' + cfg.min_count + '–' + cfg.max_count + ' 之间', 'err');
          return false;
        }
        if (count > Math.round(amount * 100)) {
          App.toast('金额太小，不够分成这么多个红包', 'err');
          return false;
        }
        return true;
      }
    });
    if (!values) return;

    CH.sending = true;
    var res = await App.api('/api/chat/redpackets', {
      method: 'POST',
      body: {
        channel: CH.channel,
        amount: Number(values.amount),
        count: Math.floor(Number(values.count)),
        blessing: values.blessing
      }
    });
    CH.sending = false;
    if (!res.success || !res.data) { App.toast(res.message || '红包发送失败', 'err'); return; }
    if (res.data.message) appendMsgs([res.data.message], false);
    updateRpBubble(res.data.packet);
    App.toast('红包已发出 · 余额 RM' + Number(res.data.balance_after).toFixed(2), 'ok');
  }

  /** 禁言横幅：被禁言时显示解禁时间与原因（仍可查看消息） */
  function renderMuteBanner() {
    var host = $('muteBanner');
    if (!host) return;
    if (!CH.myMute || !CH.myMute.muted) { host.hidden = true; host.innerHTML = ''; return; }
    host.hidden = false;
    host.className = 'mute-banner warn';
    host.innerHTML = '<span class="ic i-warning"></span><span class="mb-text">' +
      esc(CH.myMute.notice || '您已被禁言') + '</span>';
  }

  function appendMsgs(list, toTop) {
    var listEl = CH.el.list;
    // 渲染层去重：同一条消息可能同时从 REST 响应与 Socket 推送到达
    list = list.filter(function (m) {
      var id = Number(m && m.id);
      if (!id) return true;           // 本地占位消息（id 形如 p123...）不去重
      if (CH.seenIds[id]) return false;
      CH.seenIds[id] = true;
      return true;
    });
    if (!list.length) return;
    var html = list.map(msgHtml).join('');
    if (!toTop) {
      // 追加新消息时清掉可能存在的空态/错误占位
      var stale = listEl.querySelector('.state-box');
      if (stale) stale.remove();
      listEl.insertAdjacentHTML('beforeend', html);
      var msgs = list.filter(function (m) { return m.id > CH.lastId; });
      if (msgs.length) CH.lastId = msgs[msgs.length - 1].id;
      if (!CH.oldestId && list.length) CH.oldestId = list[0].id;
      scrollToBottom(false);
    } else {
      var body = CH.el.body;
      var prevH = body.scrollHeight;
      listEl.insertAdjacentHTML('afterbegin', html);
      CH.oldestId = list[0].id;
      body.scrollTop = body.scrollHeight - prevH;  // 保持阅读位置
    }
  }

  function scrollToBottom(smooth) {
    var body = CH.el.body;
    body.scrollTo({ top: body.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  }

  // ---------- 加载 ----------
  async function loadFirst() {
    CH.loading = true;
    CH.seenIds = {};
    CH.el.list.innerHTML = '<div class="state-box" style="padding:40px 0;"><div class="spinner"></div></div>';
    var res = await App.api('/api/chat/messages?channel=' + CH.channel + '&limit=30');
    CH.loading = false;
    if (!res.success) {
      CH.el.list.innerHTML = '';
      CH.el.list.appendChild(stateEl(res.message || '消息加载失败'));
      setupSocket();          // 即使首轮失败也进入实时模式，新消息到达仍可渲染
      startPolling();
      return;
    }
    var list = res.data.list || [];
    CH.hasMore = !!res.data.has_more;
    CH.el.list.innerHTML = '';
    if (!list.length) {
      CH.el.list.innerHTML = '<div class="state-box" style="padding:60px 20px 30px;">' + esc(CH.emptyText) + '</div>';
      setupSocket();          // 空频道同样等待实时推送（第一条消息即时出现）
      startPolling();
      return;
    }
    appendMsgs(list, false);
    scrollToBottom(false);
    if (CH.hasMore) showLoadMore(true);
    markRead();
    setupSocket();
    startPolling();
  }

  function stateEl(msg) {
    var div = document.createElement('div');
    div.className = 'state-box';
    div.innerHTML = '<div>' + esc(msg) + '</div><button class="btn btn-dark btn-sm" id="__reload__">重新加载</button>';
    div.querySelector('#__reload__').addEventListener('click', function () { loadFirst(); });
    return div;
  }

  function showLoadMore(show) {
    var tip = CH.el.loadTip;
    if (!tip) return;
    tip.style.display = show ? 'block' : 'none';
    tip.textContent = CH.loadingOld ? '加载中...' : '查看更早的消息';
  }

  async function loadOlder() {
    if (CH.loadingOld || !CH.hasMore || !CH.oldestId) return;
    CH.loadingOld = true;
    showLoadMore(true);
    var res = await App.api('/api/chat/messages?channel=' + CH.channel + '&before=' + CH.oldestId + '&limit=30');
    CH.loadingOld = false;
    if (!res.success) { showLoadMore(CH.hasMore); App.toast(res.message || '加载失败', 'err'); return; }
    var list = res.data.list || [];
    if (!list.length) { CH.hasMore = false; showLoadMore(false); return; }
    CH.hasMore = !!res.data.has_more;
    appendMsgs(list, true);
    showLoadMore(CH.hasMore);
  }
  // ---------- 实时推送（Socket.IO）+ 轮询兜底 ----------
  /**
   * Socket 推送回调：新消息 / 撤回同步。
   * 在线时消息即时到达；断线时自动回退轮询。
   */
    function onSockMsg(m) {
    // 撤回事件：服务端 chat:recall → 这里同步已渲染气泡
    if (m && m.__recall) { markRecalled(Number(m.id)); return; }
    // 已读事件：服务端 chat:read → 同步已读状态
    if (m && m.__read) {
      markOtherRead(Number(m.user_id), Number(m.last_read_id || 0));
      return;
    }
    if (!m || m.channel !== CH.channel) return;
    var id = Number(m.id) || 0;
    if (!id || id <= CH.lastId) return;   // 去重由 appendMsgs 双保险
    var body = CH.el.body;
    var nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 120;
    appendMsgs([m], false);
    if (nearBottom) { scrollToBottom(true); markRead(); }
  }

  /** 标记其他用户的消息为已读（实时同步） */
  function markOtherRead(userId, lastReadId) {
    if (!userId) return;
    var bubbles = CH.el.list.querySelectorAll('.bubble[data-user="' + userId + '"]');
    bubbles.forEach(function(b) {
      var status = b.querySelector('.m-status');
      if (status && !b.classList.contains('mine')) {
        status.textContent = '已读';
        status.className = 'm-status read';
      }
    });
  }

  /** 服务端撤回广播 → 同步本地气泡（不破坏聊天滚动位置） */
  function markRecalled(id) {
    if (!id) return;
    var b = CH.el.list.querySelector('.bubble[data-id="' + id + '"]');
    if (!b) return;
    b.classList.add('recalled');
    b.removeAttribute('data-packet');     // 已撤回的红包卡片不可再点击领取
    b.innerHTML = '<span class="msg-recalled">消息已撤回</span>';
  }

  /** 连接状态：在线停轮询，离线自动恢复轮询 */
  function onSockStatus(s) {
    if (s === 'online') {
      CH.sockActive = true;
      stopPolling();
    } else if (s === 'offline') {
      CH.sockActive = false;
      if (CH.lastId && !document.hidden) startPolling();
    }
  }

  /** 首次进入或频道加载后建立实时连接；失败时保持轮询兜底 */
  function setupSocket() {
    if (typeof App.socketJoinChat !== 'function') return;
    App.socketJoinChat(CH.channel, onSockMsg, onSockStatus).then(function (online) {
      if (online && !CH.sockActive) { CH.sockActive = true; stopPolling(); }
    });
  }

  function pollOnce() {
    if (document.hidden || CH.loading || CH.sending) return;
    App.api('/api/chat/messages?channel=' + CH.channel + '&limit=10').then(function (res) {
      if (!res.success) return;
      var fresh = (res.data.list || []).filter(function (m) { return m.id > CH.lastId; });
      if (fresh.length) {
        // 如果当前没有向上翻阅（接近底部）才自动滚到底
        var body = CH.el.body;
        var nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 120;
        appendMsgs(fresh, false);
        if (nearBottom) { scrollToBottom(true); markRead(); }
      }
    });
  }

  function startPolling() {
    if (CH.sockActive) return;            // Socket 在线时无需轮询
    stopPolling();
    CH.pollTimer = setInterval(pollOnce, 5000);
  }
  function stopPolling() {
    if (CH.pollTimer) { clearInterval(CH.pollTimer); CH.pollTimer = null; }
  }

  // ---------- 已读 ----------
  async function markRead() {
    try { await App.api('/api/chat/read', { method: 'POST', body: { channel: CH.channel } }); } catch (e) { /* 忽略 */ }
  }

  // ---------- 发送 ----------
  async function sendText() {
    var input = CH.el.input;
    var text = (input.value || '').trim();
    if (!text || CH.sending) return;
    if (text.length > 500) { App.toast('消息最多 500 字', 'err'); return; }

    CH.sending = true;
    input.value = '';
    autoGrow();
    var pending = document.createElement('div');
    pending.innerHTML = msgHtml({
      id: 'p' + Date.now(), message_type: 'text', content: text,
      is_mine: true, is_recalled: false, created_at: new Date(),
      username: (App.getUser() || {}).username || ''
    });
    var node = pending.firstChild;
    node.id = 'pending-msg';
    CH.el.list.appendChild(node);
    var st = node.querySelector('.m-status');
    if (st) { st.className = 'm-status sending'; st.textContent = '发送中...'; }
    scrollToBottom(true);

    var res = await App.api('/api/chat/messages', {
      method: 'POST',
      body: { channel: CH.channel, message_type: 'text', content: text }
    });

    if (res.success) {
      node.remove();
      appendMsgs([res.data], false);
      scrollToBottom(true);
      CH.sending = false;
      startPolling();
    } else {
      CH.sending = false;
      if (st) {
        st.className = 'm-status fail';
        st.textContent = '发送失败，点击重试';
        st.addEventListener('click', function () {
          node.remove();
          CH.el.input.value = text;
          sendText();
        });
      } else {
        App.toast(res.message || '发送失败', 'err');
      }
    }
  }

  async function sendSticker(url) {
    if (CH.sending) return;
    CH.sending = true;
    var res = await App.api('/api/chat/messages', {
      method: 'POST',
      body: { channel: CH.channel, message_type: 'sticker', meta: { url: url } }
    });
    CH.sending = false;
    if (res.success) {
      appendMsgs([res.data], false);
      scrollToBottom(true);
      toggleStickerPanel(false);
    } else {
      App.toast(res.message || '发送失败', 'err');
    }
  }

  // ---------- 贴图面板 ----------
  function toggleStickerPanel(force) {
    var p = CH.el.stickerPanel;
    var open = force !== undefined ? force : !p.classList.contains('show');
    p.classList.toggle('show', open);
    CH.el.stickerBtn.classList.toggle('active', open);
    CH.stickerPanelOpen = open;
    if (open && !CH.stickersLoaded) loadStickers();
  }

  async function loadStickers() {
    CH.stickersLoaded = true;
    var res = await App.api('/api/chat/stickers');
    var grid = $('stickerGrid');
    if (!res.success) { grid.innerHTML = '<div class="sticker-empty">贴图加载失败</div>'; return; }
    var official = res.data.can_use_official ? (res.data.official || []) : [];
    var mine = res.data.mine || [];
    var html = official.map(function (s) {
      return '<div class="sticker-item" data-url="' + esc(s.url) + '">' + stickerImg(s.url) + '</div>';
    }).join('');
    if (mine.length) {
      html += '<div class="sticker-cat">我的贴图</div>' + mine.map(function (s) {
        return '<div class="sticker-item" data-url="' + esc(s.url) + '" data-mine-id="' + s.id + '">' + stickerImg(s.url) + '</div>';
      }).join('');
    }
    html += '<div class="sticker-item sticker-add" id="stickerUpload"><span class="ic i-plus"></span></div>';
    grid.innerHTML = html || '<div class="sticker-empty">官方贴图即将上线，可先上传自己的图片</div>';
  }
  // ---------- 上传自定义贴图 ----------
  function uploadSticker(file) {
    if (!file) return;
    var okType = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'].indexOf(file.type) >= 0;
    if (!okType) { App.toast('只支持 PNG / JPG / GIF / WebP 图片', 'err'); return; }
    if (file.size > 2 * 1024 * 1024) { App.toast('图片最大 2MB', 'err'); return; }

    var fd = new FormData();
    fd.append('file', file);
    var t = App.getToken();
    fetch('/api/chat/stickers', {
      method: 'POST',
      headers: t ? { 'Authorization': 'Bearer ' + t } : {},
      body: fd
    }).then(function (r) { return r.json(); }).then(function (json) {
      if (json.success) {
        App.toast('贴图已保存，点击即可发送', 'ok');
        loadStickers();
      } else {
        App.toast(json.message || '上传失败', 'err');
      }
    }).catch(function () { App.toast('网络错误，上传失败', 'err'); });
  }

  // ---------- 消息操作（长按 ActionSheet） ----------
  function msgTextOf(id) {
    var bubble = CH.el.body.querySelector('.bubble[data-id="' + id + '"]');
    return bubble ? bubble.textContent : '';
  }
  async function recallMsg(id) {
    var res = await App.api('/api/chat/recall/' + id, { method: 'POST' });
    if (!res.success) { App.toast(res.message || '撤回失败', 'err'); return; }
    var bubble = CH.el.body.querySelector('.bubble[data-id="' + id + '"]');
    if (bubble) {
      bubble.classList.add('recalled');
      bubble.innerHTML = '消息已撤回';
    }
    App.toast('已撤回', 'ok');
  }
  async function reportMsg(id) {
    var okk = await App.confirmDialog({ title: '举报消息', text: '确定要举报这条消息吗？管理员会进行核查。', okText: '举报' });
    if (!okk) return;
    var res = await App.api('/api/chat/report', { method: 'POST', body: { message_id: id, reason: '用户举报' } });
    App.toast(res.success ? '举报已提交，感谢反馈' : (res.message || '举报失败'), res.success ? 'ok' : 'err');
  }
  function bindLongPress() {
    var timer = null, longFired = false;
    var body = CH.el.body;
    function clear() { if (timer) { clearTimeout(timer); timer = null; } }
    body.addEventListener('touchstart', function (e) {
      var bubble = e.target.closest('.bubble');
      if (!bubble || bubble.dataset.mine === undefined) return;
      longFired = false;
      timer = setTimeout(function () {
        longFired = true;
        openMsgSheet(bubble);
      }, 480);
    }, { passive: true });
    body.addEventListener('touchmove', clear, { passive: true });
    body.addEventListener('touchend', clear, { passive: true });
    body.addEventListener('touchcancel', clear, { passive: true });
    // 桌面右键
    body.addEventListener('contextmenu', function (e) {
      var bubble = e.target.closest('.bubble');
      if (!bubble) return;
      e.preventDefault();
      openMsgSheet(bubble);
    });
  }
  function openMsgSheet(bubble) {
    var id = bubble.dataset.id;
    var mine = bubble.dataset.mine === '1';
    var recalled = bubble.classList.contains('recalled');
    if (recalled) return;
    var isMedia = !!bubble.querySelector('img');
    var items = [];
    if (!isMedia) {
      items.push({ label: '复制', icon: 'i-copy', onClick: function () {
        App.copyText(msgTextOf(id)).then(function (okk) {
          App.toast(okk ? '已复制' : '复制失败', okk ? 'ok' : 'err');
        });
      } });
    }
    if (mine) {
      items.push({ label: '撤回', icon: 'i-trash', danger: true, onClick: function () { recallMsg(id); } });
    } else {
      items.push({ label: '举报', icon: 'i-warning', danger: true, onClick: function () { reportMsg(id); } });
    }
    App.openSheet({ title: '消息操作', items: items });
  }
  // ---------- 输入框 ----------
  function autoGrow() {
    var input = CH.el.input;
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 104) + 'px';
    var n = (input.value || '').length;
    if (CH.el.charCount) {
      CH.el.charCount.textContent = n ? (n + '/500') : '';
    }
  }

  // ---------- 初始化 ----------
  /**
   * ChatPage.init({
   *   channel: 'group'|'support',
   *   emptyText, onlineText
   * })
   * 页面需包含: #msgBody #chatInput #sendBtn #stickerBtn #stickerPanel #stickerGrid
   *             #loadMoreTip #charCount (可选) #chatTitleSub
   */
  function init(opt) {
    opt = opt || {};
    CH.channel = opt.channel;
    CH.emptyText = opt.emptyText || '还没有消息，打个招呼吧';
    CH.redPacket = opt.redPacket || null;
    CH.myMute = opt.myMute || null;
    CH.el.body = $('chatScroll');   // 滚动容器
    CH.el.list = $('msgList');      // 消息列表（内部）
    CH.el.input = $('chatInput');
    CH.el.loadTip = $('loadMoreTip');
    CH.el.charCount = $('charCount');
    CH.el.stickerPanel = $('stickerPanel');
    CH.el.stickerBtn = $('stickerBtn');
    CH.el.sendBtn = $('sendBtn');
    if (!CH.el.body || !CH.el.input || !CH.el.list) return;

    // 顶部在线状态
    if (opt.onlineText && $('chatTitleSub')) $('chatTitleSub').textContent = opt.onlineText;

    // 输入
    CH.el.input.addEventListener('input', autoGrow);
    CH.el.input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendText();
      }
    });
    CH.el.sendBtn.addEventListener('click', function () { sendText(); });

    // 贴图
    CH.el.stickerBtn.addEventListener('click', function () { toggleStickerPanel(); });

    // 红包（仅游戏群开放；配置来自 /api/chat/channels，页面没传时自行补拉）
    var rpBtn = $('rpBtn');
    if (rpBtn) {
      ensureRedPacketConfig().then(function (cfg) {
        if (!cfg || !cfg.enabled) { rpBtn.hidden = true; return; }
        rpBtn.hidden = false;
        rpBtn.addEventListener('click', function () { sendRedPacket(); });
      });
    }
    // 点击红包气泡 → 抢红包 / 查看详情
    CH.el.list.addEventListener('click', function (ev) {
      var card = ev.target.closest('.rp-card');
      if (!card) return;
      ev.preventDefault();
      var pid = Number(card.dataset.packet || 0);
      if (pid) openRedPacket(pid);
    });
    renderMuteBanner();
    $('stickerGrid').addEventListener('click', function (e) {
      var up = e.target.closest('#stickerUpload');
      if (up) {
        var fi = $('stickerFile');
        if (!fi) {
          fi = document.createElement('input');
          fi.type = 'file'; fi.accept = 'image/*'; fi.id = 'stickerFile'; fi.style.display = 'none';
          document.body.appendChild(fi);
          fi.addEventListener('change', function () { uploadSticker(fi.files[0]); fi.value = ''; });
        }
        fi.click();
        return;
      }
      var item = e.target.closest('.sticker-item');
      if (!item || !item.dataset.url) return;
      if (item.dataset.mineId) {
        // 自己的贴图：点击发送，长按弹删除
        sendSticker(item.dataset.url);
        return;
      }
      sendSticker(item.dataset.url);
    });
    $('stickerGrid').addEventListener('contextmenu', function (e) {
      var item = e.target.closest('.sticker-item[data-mine-id]');
      if (!item) return;
      e.preventDefault();
      var sid = item.dataset.mineId;
      App.openSheet({
        title: '我的贴图',
        items: [{ label: '删除贴图', icon: 'i-trash', danger: true, onClick: async function () {
          var res = await App.api('/api/chat/stickers/' + sid, { method: 'DELETE' });
          if (res.success) { App.toast('已删除', 'ok'); loadStickers(); }
          else App.toast(res.message || '删除失败', 'err');
        } }]
      });
    });

    // 向上翻页
    if (CH.el.loadTip) CH.el.loadTip.addEventListener('click', loadOlder);

    bindLongPress();
    App.mountNetBanner();
    loadFirst();

    // 离开页面：清理轮询 timer 与 Socket 订阅，避免无限 setInterval / 空连接
    window.addEventListener('pagehide', function () {
      stopPolling();
      if (typeof App.socketLeaveChat === 'function') App.socketLeaveChat(CH.channel, onSockMsg);
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { stopPolling(); }
      else if (CH.lastId) {
        if (CH.sockActive) pollOnce();   // Socket 在线：补拉一次隐藏期间可能漏掉的消息
        else startPolling();
      }
    });
  }

  window.ChatPage = { init: init };
})();