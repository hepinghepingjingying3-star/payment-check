// ============================================
// 26牛牛 - App 公共前端层 (V3)
// 职责:
//   - 登录态守卫 / API 封装 / Toast / 状态块
//   - 底部导航渲染（真 SVG 图标，无 emoji）
//   - 金额、日期、脱敏格式化
// 说明: 虚拟现金筹码，不涉及任何真实资金
// ============================================
(function () {
  'use strict';

  var TOKEN_KEY = 'token';
  var USER_KEY = 'user';

  // ---------- 登录态 ----------
  function getToken() { return localStorage.getItem(TOKEN_KEY) || ''; }
  function getUser() {
    try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch (e) { return null; }
  }
  function setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user || {}));
  }
  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }
  function toLogin() { window.location.replace('/login.html'); }

  /** 需要登录的页面调用：无 token 时跳登录页 */
  function requireLogin() {
    if (!getToken()) { toLogin(); return false; }
    return true;
  }
  /**
   * 退出登录
   * 除了清本地登录态，还要请求后端清除「页面会话票据」（HttpOnly Cookie），
   * 否则退出后同一浏览器仍能打开管理后台页面。keepalive 保证跳转前请求发出。
   */
  function logout() {
    var token = getToken();
    if (token) {
      try {
        fetch('/api/auth/logout', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + token },
          credentials: 'same-origin',
          keepalive: true
        }).catch(function () {});
      } catch (e) { /* 忽略：后端清理失败不影响本地退出 */ }
    }
    clearSession();
    toLogin();
  }

  // ---------- API 封装 ----------
  /**
   * 统一请求。始终返回 { success, data, message }，绝不抛异常。
   * opts: { method, body, auth(默认true), redirectOn401 }
   */
  async function api(path, opts) {
    opts = opts || {};
    var headers = {};
    if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
    if (opts.auth !== false) {
      var t = getToken();
      if (t) headers['Authorization'] = 'Bearer ' + t;
    }

    var res;
    try {
      res = await fetch(path, {
        method: opts.method || 'GET',
        headers: headers,
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
        credentials: 'same-origin'
      });
    } catch (e) {
      return { success: false, message: '网络错误，请稍后重试', network: true };
    }

    if (res.status === 401) {
      clearSession();
      if (opts.redirectOn401 !== false) { toLogin(); }
      return { success: false, message: '登录已过期，请重新登录', unauthorized: true };
    }

    var json = null;
    try { json = await res.json(); } catch (e) { json = null; }

    if (!json || typeof json !== 'object') {
      return { success: false, message: res.ok ? '服务器返回数据异常' : ('请求失败 (' + res.status + ')') };
    }
    if (json.success === undefined) json.success = res.ok;
    if (!json.message && !res.ok) json.message = '请求失败 (' + res.status + ')';
    return json;
  }

  // ---------- Toast ----------
  function toastWrap() {
    var w = document.getElementById('toast-wrap');
    if (!w) {
      w = document.createElement('div');
      w.id = 'toast-wrap';
      document.body.appendChild(w);
    }
    return w;
  }
  /** type: 'info' | 'ok' | 'err' */
  function toast(msg, type, ms) {
    msg = (msg === null || msg === undefined) ? '' : String(msg);
    if (!msg) return;
    if (msg === 'undefined' || msg === 'null' || msg === 'NaN' || msg === '[object Object]') msg = '操作失败，请稍后重试';
    var w = toastWrap();
    var el = document.createElement('div');
    el.className = 'toast' + (type ? ' ' + type : '');
    var icName = type === 'ok' ? 'check' : (type === 'err' ? 'warning' : 'notice');
    el.innerHTML = '<span class="ic i-' + icName + '"></span><span class="tt"></span>';
    el.querySelector('.tt').textContent = msg;
    w.appendChild(el);
    var life = ms || (type === 'err' ? 2600 : 1900);
    setTimeout(function () {
      el.classList.add('hide');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 220);
    }, life);
  }

  // ---------- 状态块 ----------
  function stateBox(type, title, sub, actionsHtml) {
    var icon = type === 'error' ? 'warning' : (type === 'empty' ? 'record' : 'refresh');
    var head = type === 'loading'
      ? '<div class="spinner"></div>'
      : '<span class="ic i-' + icon + ' si"></span>';
    return '<div class="state-box">' + head +
      (title ? '<div class="state-title">' + escapeHtml(title) + '</div>' : '') +
      (sub ? '<div class="state-desc">' + escapeHtml(sub) + '</div>' : '') +
      (actionsHtml ? '<div>' + actionsHtml + '</div>' : '') +
      '</div>';
  }
  function showLoading(el, text) { if (el) el.innerHTML = stateBox('loading', text || '加载中...'); }
  function showEmpty(el, title, sub) { if (el) el.innerHTML = stateBox('empty', title || '暂无数据', sub || ''); }
  function showError(el, msg, retryFn) {
    if (!el) return;
    var act = retryFn ? '<button class="btn btn-dark btn-sm" id="__retry__">重试</button>' : '';
    el.innerHTML = stateBox('error', msg || '加载失败，请稍后重试', '', act);
    var b = el.querySelector('#__retry__');
    if (b && retryFn) b.addEventListener('click', retryFn);
  }

  // ---------- 格式化 ----------
  function fmtMoney(v, digits) {
    var n = Number(v);
    if (!isFinite(n)) n = 0;
    return n.toFixed(digits === undefined ? 2 : digits);
  }
  function toDate(ts) {
    if (!ts) return null;
    var d = (ts instanceof Date) ? ts : new Date(typeof ts === 'string' ? ts.replace(' ', 'T') : ts);
    return isNaN(d.getTime()) ? null : d;
  }
  function pad(n) { return String(n).padStart(2, '0'); }
  function fmtDateTime(ts) {
    var d = toDate(ts); if (!d) return '--';
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function fmtDate(ts) {
    var d = toDate(ts); if (!d) return '--';
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function fmtTime(ts) {
    var d = toDate(ts); if (!d) return '--';
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  /** 相对时间：刚刚 / 5分钟前 / 昨天 HH:mm / MM-DD */
  function fmtAgo(ts) {
    var d = toDate(ts); if (!d) return '';
    var diff = Date.now() - d.getTime();
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前';
    var today = new Date(); today.setHours(0, 0, 0, 0);
    if (d.getTime() >= today.getTime()) return fmtTime(d);
    if (d.getTime() >= today.getTime() - 86400000) return '昨天 ' + fmtTime(d);
    return (d.getMonth() + 1) + '-' + d.getDate();
  }
  function fmtPhone(p) {
    p = String(p || '');
    if (!p) return '--';
    if (p.length < 6) return p.slice(0, 1) + '***';
    return p.slice(0, 2) + '******' + p.slice(-2);
  }
  function fmtEmail(e) {
    e = String(e || '');
    if (!e) return '--';
    var at = e.indexOf('@');
    if (at < 1) return e.slice(0, 2) + '***';
    var name = e.slice(0, at), domain = e.slice(at);
    var keep = name.length <= 3 ? 1 : 3;
    return name.slice(0, keep) + '***' + domain;
  }
  function escapeHtml(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // ---------- 复制 ----------
  async function copyText(text) {
    text = String(text || '');
    if (!text) { toast('没有可复制的内容', 'err'); return false; }
    try {
      if (navigator.clipboard) { await navigator.clipboard.writeText(text); return true; }
      throw new Error('fallback');
    } catch (e) {
      try {
        var ta = document.createElement('textarea');
        ta.value = text; ta.setAttribute('readonly', '');
        ta.style.position = 'fixed'; ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return ok;
      } catch (e2) { return false; }
    }
  }

  // ---------- 底部导航 ----------
  var NAV = [
    { key: 'lobby',   href: '/lobby.html',    icon: 'i-lobby',   label: '大厅' },
    { key: 'wallet',  href: '/wallet.html',   icon: 'i-wallet',  label: '钱包' },
    { key: 'promote', href: '/promote.html',  icon: 'i-promote', label: '推广' },
    { key: 'chat',    href: '/messages.html', icon: 'i-chat',    label: '聊天' },
    { key: 'me',      href: '/me.html',       icon: 'i-me',      label: '我的' }
  ];
  /** 在当前页面注入底部导航；activeKey 高亮项 */
  function mountNav(activeKey) {
    if (document.querySelector('.bottom-nav')) return;
    var nav = document.createElement('nav');
    nav.className = 'bottom-nav';
    nav.innerHTML = NAV.map(function (n) {
      return '<a class="nav-item' + (n.key === activeKey ? ' active' : '') + '" href="' + n.href + '" data-key="' + n.key + '">' +
        '<span class="ic ' + n.icon + '"></span><span>' + n.label + '</span></a>';
    }).join('');
    document.body.appendChild(nav);
    nav.addEventListener('click', function (ev) {
      var a = ev.target.closest ? ev.target.closest('.nav-item') : null;
      if (!a) return;
      if (!getToken()) { ev.preventDefault(); toLogin(); }
    });
  }

  // ---------- 页面骨架 ----------
  /** 顶部栏：{ title, back:'/lobby.html'|true, action:{icon,id} } */
  function headerHtml(o) {
    o = o || {};
    var left = o.back
      ? '<a class="h-back" href="' + (typeof o.back === 'string' ? o.back : '/lobby.html') + '"><span class="ic i-back"></span></a>'
      : '<span class="h-side"></span>';
    var right = o.action
      ? '<button class="h-action" id="' + (o.action.id || 'hAction') + '"><span class="ic ' + (o.action.icon || 'i-more') + '"></span></button>'
      : '<span class="h-side"></span>';
    return '<header class="app-header"><div class="h-row">' + left +
      '<div class="h-title">' + escapeHtml(o.title || '') + '</div>' + right + '</div></header>';
  }
  /** 顶部栏（自定义左/中/右 HTML 片段） */
  function headerRaw(leftHtml, titleHtml, rightHtml) {
    return '<header class="app-header"><div class="h-row">' +
      (leftHtml || '<span class="h-side"></span>') +
      (titleHtml || '') +
      (rightHtml || '<span class="h-side"></span>') +
      '</div></header>';
  }

  // ---------- 网络状态 ----------
  function mountNetBanner() {
    if (document.getElementById('net-banner')) return;
    var b = document.createElement('div');
    b.className = 'net-banner'; b.id = 'net-banner';
    b.innerHTML = '<span class="ic i-wifi-off"></span><span class="nt">网络连接异常</span>';
    document.body.insertBefore(b, document.body.firstChild);
    var hideTimer = null;
    function show(cls, text, autoHide) {
      b.className = 'net-banner show ' + (cls || '');
      b.querySelector('.nt').textContent = text;
      if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
      if (autoHide) hideTimer = setTimeout(function () { b.className = 'net-banner'; }, 2600);
    }
    window.addEventListener('offline', function () { show('', '网络连接异常'); });
    window.addEventListener('online', function () {
      if (b.classList.contains('show') && !b.classList.contains('ok')) show('ok', '网络已恢复', true);
    });
  }

  // ---------- 底部导航红点 ----------
  function navBadge(key, count) {
    var item = document.querySelector('.nav-item[data-key="' + key + '"]');
    if (!item) return;
    var dot = item.querySelector('.nav-dot');
    var n = Math.max(0, Number(count) || 0);
    if (n <= 0) { if (dot) dot.remove(); return; }
    if (!dot) {
      dot = document.createElement('span');
      dot.className = 'nav-dot';
      item.appendChild(dot);
    }
    dot.textContent = n > 99 ? '99+' : String(n);
  }

  // ---------- ActionSheet ----------
  var sheetEl = null;
  function closeSheet() {
    if (!sheetEl) return;
    var el = sheetEl; sheetEl = null;
    el.classList.remove('show');
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 200);
  }
  /** openSheet({ title, items: [{ label, danger, icon, onClick }] }) */
  function openSheet(opt) {
    opt = opt || {};
    closeSheet();
    var mask = document.createElement('div');
    mask.className = 'sheet-mask';
    var items = (opt.items || []).map(function (it, i) {
      return '<button class="sheet-item' + (it.danger ? ' danger' : '') + '" data-i="' + i + '">' +
        '<span class="ic ' + (it.icon || 'i-more') + '"></span><span>' + escapeHtml(it.label || '') + '</span></button>';
    }).join('');
    mask.innerHTML = '<div class="sheet">' +
      (opt.title ? '<div class="sheet-head"><div class="sheet-title">' + escapeHtml(opt.title) + '</div>' +
        '<button class="sheet-close" id="sheetClose"><span class="ic i-close"></span></button></div>' : '') +
      items +
      '<button class="sheet-item" style="justify-content:center;color:var(--text-secondary)" data-cancel="1">取消</button>' +
      '</div>';
    document.body.appendChild(mask);
    sheetEl = mask;
    requestAnimationFrame(function () { mask.classList.add('show'); });
    mask.addEventListener('click', function (ev) {
      if (ev.target === mask) { closeSheet(); return; }
      var btn = ev.target.closest('button');
      if (!btn) return;
      if (btn.dataset.cancel !== undefined || btn.id === 'sheetClose') { closeSheet(); return; }
      var i = Number(btn.dataset.i);
      closeSheet();
      var it = (opt.items || [])[i];
      if (it && typeof it.onClick === 'function') setTimeout(it.onClick, 60);
    });
  }

  // ---------- 表单弹层（发红包 / 其它自定义输入） ----------
  /**
   * openFormSheet({
   *   title, okText, extraHtml,
   *   fields: [{ key, label, type:'text'|'number'|'textarea', value, placeholder, maxlength, min, max, step, hint }]
   * }) → Promise<{ [key]: string } | null>   取消返回 null
   * 说明: 只负责收集输入，业务校验一律由调用方（页面 / 后端）负责
   */
  function openFormSheet(opt) {
    opt = opt || {};
    var fields = opt.fields || [];
    return new Promise(function (resolve) {
      var mask = document.createElement('div');
      mask.className = 'sheet-mask';
      var fieldsHtml = fields.map(function (f) {
        var id = 'fs-' + f.key;
        var attrs = '';
        if (f.min !== undefined && f.min !== null) attrs += ' min="' + escapeHtml(String(f.min)) + '"';
        if (f.max !== undefined && f.max !== null) attrs += ' max="' + escapeHtml(String(f.max)) + '"';
        if (f.step !== undefined && f.step !== null) attrs += ' step="' + escapeHtml(String(f.step)) + '"';
        if (f.maxlength) attrs += ' maxlength="' + Number(f.maxlength) + '"';
        var input = f.type === 'textarea'
          ? '<textarea class="input" id="' + id + '" rows="2"' + attrs + '>' + escapeHtml(f.value || '') + '</textarea>'
          : '<input class="input" id="' + id + '" type="' + (f.type === 'number' ? 'number' : 'text') + '"' +
            ' inputmode="' + (f.type === 'number' ? 'decimal' : 'text') + '"' +
            ' placeholder="' + escapeHtml(f.placeholder || '') + '"' +
            ' value="' + escapeHtml(f.value === undefined || f.value === null ? '' : String(f.value)) + '"' + attrs + '>';
        return '<label class="fs-label" for="' + id + '">' + escapeHtml(f.label || f.key) + '</label>' + input +
          (f.hint ? '<div class="fs-hint">' + escapeHtml(f.hint) + '</div>' : '');
      }).join('');
      mask.innerHTML = '<div class="sheet sheet-form">' +
        '<div class="sheet-head"><div class="sheet-title">' + escapeHtml(opt.title || '') + '</div>' +
        '<button class="sheet-close" id="fsClose" type="button"><span class="ic i-close"></span></button></div>' +
        (opt.extraHtml || '') + fieldsHtml +
        '<div class="fs-actions">' +
        '<button class="btn btn-dark" type="button" data-fs-cancel>取消</button>' +
        '<button class="btn btn-gold" type="button" data-fs-ok>' + escapeHtml(opt.okText || '确定') + '</button>' +
        '</div></div>';
      document.body.appendChild(mask);
      requestAnimationFrame(function () { mask.classList.add('show'); });

      function close(result) {
        mask.classList.remove('show');
        setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 180);
        resolve(result);
      }
      function collect() {
        var out = {};
        fields.forEach(function (f) {
          var el = mask.querySelector('#fs-' + f.key);
          out[f.key] = el ? String(el.value) : '';
        });
        return out;
      }
      mask.addEventListener('click', function (ev) {
        if (ev.target === mask || ev.target.closest('[data-fs-cancel]') || ev.target.closest('#fsClose')) {
          return close(null);
        }
        if (ev.target.closest('[data-fs-ok]')) {
          var values = collect();
          // onSubmit 返回 false 表示校验未通过，弹层保持打开
          if (typeof opt.onSubmit === 'function' && opt.onSubmit(values, close) === false) return;
          return close(values);
        }
      });
      var first = mask.querySelector('.sheet-form input, .sheet-form textarea');
      if (first) setTimeout(function () { try { first.focus(); } catch (e) { /* 忽略 */ } }, 240);
    });
  }

  // ---------- Confirm 对话框 ----------
  var dlgEl = null;
  function closeDialog() {
    if (!dlgEl) return;
    var el = dlgEl; dlgEl = null;
    el.classList.remove('show');
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 180);
  }
  /** confirmDialog({ title, text, okText, danger }) → Promise<boolean> */
  function confirmDialog(opt) {
    return new Promise(function (resolve) {
      closeDialog();
      var mask = document.createElement('div');
      mask.className = 'dialog-mask';
      mask.innerHTML = '<div class="dialog">' +
        '<div class="dialog-title">' + escapeHtml((opt && opt.title) || '提示') + '</div>' +
        '<div class="dialog-text">' + escapeHtml((opt && opt.text) || '') + '</div>' +
        '<div class="dialog-actions">' +
        '<button class="btn btn-ghost" data-no>取消</button>' +
        '<button class="btn ' + ((opt && opt.danger) ? 'btn-danger' : 'btn-gold') + '" data-yes>' + escapeHtml((opt && opt.okText) || '确定') + '</button>' +
        '</div></div>';
      document.body.appendChild(mask);
      dlgEl = mask;
      requestAnimationFrame(function () { mask.classList.add('show'); });
      function done(v) { closeDialog(); resolve(v); }
      mask.addEventListener('click', function (ev) {
        if (ev.target === mask) return done(false);
        if (ev.target.closest('[data-no]')) return done(false);
        if (ev.target.closest('[data-yes]')) return done(true);
      });
    });
  }

  // ---------- 倒计时按钮（OTP 冷却） ----------
  function cooldown(btn, seconds, prefix) {
    if (!btn) return;
    if (btn._cdTimer) { clearInterval(btn._cdTimer); btn._cdTimer = null; }
    var left = Number(seconds) || 0;
    var orig = btn._origText || btn.textContent;
    btn._origText = orig;
    btn.disabled = true;
    function tick() {
      if (left <= 0) {
        clearInterval(btn._cdTimer); btn._cdTimer = null;
        btn.disabled = false; btn.textContent = orig;
        return;
      }
      btn.textContent = (prefix || '') + left + 's';
      left--;
    }
    tick();
    btn._cdTimer = setInterval(tick, 1000);
  }
  // ---------- Socket.IO 实时推送层（懒加载，失败自动回退轮询） ----------
  // 页面调用 App.socketJoinChat(channel, onMessage) 即可：
  //   - 首次调用时动态加载 /socket.io/socket.io.js（服务端自动提供）
  //   - 用 JWT 握手认证，与服务端保持同一套账号权限
  //   - 断线重连后自动重新加入频道
  //   - 连不上时 onStatus('offline')，页面继续用轮询兜底
  var sockState = {
    lib: null,           // 缓存的 <script> 加载 Promise
    socket: null,        // Socket.IO 实例
    authToken: '',       // 建立连接用的 token（换账号时重建连接）
    channels: {},        // { channel: [handler, ...] }
    joined: {},          // { channel: true } 已在服务端加入
    status: 'idle'       // idle | loading | online | offline
  };

  function sockLoadLib() {
    if (sockState.lib) return sockState.lib;
    sockState.status = 'loading';
    sockState.lib = new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = '/socket.io/socket.io.js';
      s.async = true;
      s.onload = function () { resolve(window.io); };
      s.onerror = function () { sockState.lib = null; reject(new Error('socket.io 客户端加载失败')); };
      document.head.appendChild(s);
      // 8 秒加载不出来视为失败，走轮询兜底
      setTimeout(function () { reject(new Error('socket.io 客户端加载超时')); }, 8000);
    });
    return sockState.lib;
  }

  function sockConnect() {
    var io = window.io;
    if (!io) throw new Error('io 未就绪');
    var token = getToken();
    if (!token) throw new Error('未登录');
    // token 变了要重建连接（退出/换账号）
    if (sockState.socket && sockState.authToken && sockState.authToken !== token) {
      try { sockState.socket.disconnect(); } catch (e) { /* 忽略 */ }
      sockState.socket = null;
      sockState.joined = {};
    }
    if (sockState.socket) return sockState.socket;
    sockState.authToken = token;
    sockState.status = 'loading';
    var sk = io({ auth: { token: token }, transports: ['websocket', 'polling'], reconnection: true });
    sockState.socket = sk;
    sk.on('connect', function () {
      sockState.status = 'online';
      // 重连后把所有需要的频道重新加入
      Object.keys(sockState.channels).forEach(function (ch) { sk.emit('chat:join', ch); sockState.joined[ch] = true; });
      notifyStatus();
    });
    sk.on('disconnect', function () {
      sockState.status = 'offline';
      sockState.joined = {};
      notifyStatus();
    });
    sk.on('connect_error', function () {
      sockState.status = 'offline';
      notifyStatus();
    });
    // 服务端推送：把消息分发给该频道的所有订阅者
    sk.on('chat:message', function (msg) {
      var ch = msg && msg.channel;
      var hs = sockState.channels[ch];
      if (!hs) return;
      hs.forEach(function (h) { try { h(msg); } catch (e) { /* 单个页面回调异常不影响其他 */ } });
    });
        sk.on('chat:recall', function (p) {
      var hs = (p && p.channel && sockState.channels[p.channel]) ||
               // 兜底：服务端旧版本不带 channel 时，广播给本连接所有订阅者
               // （recall 本身按房间发送，收到的连接必然在目标频道内）
               Object.keys(sockState.channels).map(function (c) { return sockState.channels[c]; }).flat();
      if (!hs) return;
      hs.forEach(function (h) { try { h({ __recall: true, id: p.id }); } catch (e) { /* 忽略 */ } });
    });
    // 服务端已读事件 → 同步订阅者已读状态
    sk.on('chat:read', function (p) {
      if (!p) return;
      var hs = (p.channel && sockState.channels[p.channel]) ||
               Object.keys(sockState.channels).map(function (c) { return sockState.channels[c]; }).flat();
      if (!hs) return;
      hs.forEach(function (h) { try { h({ __read: true, user_id: p.user_id, last_read_id: p.last_read_id, channel: p.channel }); } catch (e) { /* 忽略 */ } });
    });
    sk.on('chat:joined', function (p) { if (p && p.channel) sockState.joined[p.channel] = true; });
    // 服务端实时通知（充值/提款审核结果、实名、公告、系统消息等）→ 分发给订阅者
    sk.on('notify:new', function (p) {
      notifyHandlers.slice().forEach(function (h) { try { h(p || {}); } catch (e) { /* 单个回调异常不影响其他 */ } });
    });
    return sk;
  }

  function notifyStatus() {
    Object.keys(sockState.channels).forEach(function (ch) {
      var hs = sockState.channels[ch] || [];
      hs.forEach(function (h) {
        if (h.onStatus) { try { h.onStatus(sockState.status); } catch (e) { /* 忽略 */ } }
      });
    });
  }

  /**
   * 订阅聊天频道实时推送。
   * @param {string} channel - 'group' | 'support'
   * @param {function} onMessage - 收到新消息回调 (msg)
   * @param {function} [onStatus] - 连接状态回调 ('loading'|'online'|'offline')
   * @returns {Promise<boolean>} 是否成功进入实时模式（false = 用轮询兜底）
   */
  async function socketJoinChat(channel, onMessage, onStatus) {
    var ch = String(channel || '');
    if (ch !== 'group' && ch !== 'support' || typeof onMessage !== 'function') return false;
    var entry = onMessage;
    entry.onStatus = onStatus;
    var list = sockState.channels[ch];
    if (!list) { list = []; sockState.channels[ch] = list; }
    if (list.indexOf(entry) === -1) list.push(entry);
    try {
      await sockLoadLib();
      sockConnect().emit('chat:join', ch);
      return sockState.status === 'online';
    } catch (e) {
      sockState.status = 'offline';
      if (onStatus) { try { onStatus('offline'); } catch (e2) { /* 忽略 */ } }
      return false;
    }
  }

  /** 取消订阅（页面卸载时调用；所有页面都退订后断开连接） */
  function socketLeaveChat(channel, onMessage) {
    var ch = String(channel || '');
    var list = sockState.channels[ch];
    if (!list) return;
    var i = list.indexOf(onMessage);
    if (i >= 0) list.splice(i, 1);
    if (!list.length) {
      delete sockState.channels[ch];
      if (sockState.socket && sockState.joined[ch]) {
        try { sockState.socket.emit('chat:leave', ch); } catch (e) { /* 忽略 */ }
        delete sockState.joined[ch];
      }
      // 没有任何订阅者时断开，避免后台空连接
      if (!Object.keys(sockState.channels).length && sockState.socket) {
        try { sockState.socket.disconnect(); } catch (e) { /* 忽略 */ }
        sockState.socket = null;
        sockState.joined = {};
        sockState.status = 'idle';
      }
    }
  }

  /** 通知订阅者列表（notify:new 事件分发） */
  var notifyHandlers = [];

  /**
   * 确保socket连接建立（不加入任何聊天频道）。用于仅需实时通知的页面。
   * @returns {Promise<boolean>} 是否在线
   */
  async function socketEnsure() {
    try {
      await sockLoadLib();
      sockConnect();
      return sockState.status === 'online';
    } catch (e) {
      sockState.status = 'offline';
      return false;
    }
  }

  /**
   * 订阅实时通知（服务端 notify:new）。
   * @param {function} onEvent - 收到通知回调 ({ id, category, title, content, link, created_at })
   * @returns {function} 取消订阅函数
   */
  function onNotify(onEvent) {
    if (typeof onEvent !== 'function') return function () {};
    if (notifyHandlers.indexOf(onEvent) === -1) notifyHandlers.push(onEvent);
    socketEnsure();
    return function off() {
      var i = notifyHandlers.indexOf(onEvent);
      if (i >= 0) notifyHandlers.splice(i, 1);
    };
  }

  /**
   * 通用 Socket 事件订阅（非聊天频道，例如 26牛牛娱乐场房间）
   * @param {string} event 事件名
   * @param {function} handler 处理函数
   * @returns {Promise<function>} 取消订阅函数（连接未建立时返回空函数）
   */
  async function socketOn(event, handler) {
    if (!event || typeof handler !== 'function') return function () {};
    var ok = await socketEnsure();
    var sk = sockState.socket;
    if (!ok || !sk) return function () {};
    sk.on(event, handler);
    return function off() {
      try { sk.off(event, handler); } catch (e) { /* 忽略 */ }
    };
  }

  /** 通用 Socket 发送（连接未建立时返回 false，由调用方走 REST 兜底） */
  function socketEmit(event, payload) {
    var sk = sockState.socket;
    if (!sk || !event) return false;
    try { sk.emit(event, payload); return true; } catch (e) { return false; }
  }

  /** 页面离开时调用：没有聊天订阅者时断开连接，避免空转 */
  function socketDisconnect() {
    if (Object.keys(sockState.channels).length) return; // 仍有聊天订阅，保持连接
    if (sockState.socket) {
      try { sockState.socket.disconnect(); } catch (e) { /* 忽略 */ }
      sockState.socket = null;
      sockState.joined = {};
      sockState.status = 'idle';
    }
  }

  // 暴露到全局
  window.App = {
    getToken: getToken, getUser: getUser, setSession: setSession,
    clearSession: clearSession, requireLogin: requireLogin, logout: logout, toLogin: toLogin,
    api: api,
    toast: toast, stateBox: stateBox,
    showLoading: showLoading, showEmpty: showEmpty, showError: showError,
    fmtMoney: fmtMoney, fmtDateTime: fmtDateTime, fmtDate: fmtDate, fmtTime: fmtTime,
    fmtAgo: fmtAgo, fmtPhone: fmtPhone, fmtEmail: fmtEmail, escapeHtml: escapeHtml,
    copyText: copyText,
    mountNav: mountNav, headerHtml: headerHtml, headerRaw: headerRaw,
    mountNetBanner: mountNetBanner, navBadge: navBadge,
    openSheet: openSheet, closeSheet: closeSheet, openFormSheet: openFormSheet,
    confirmDialog: confirmDialog, cooldown: cooldown,
    socketJoinChat: socketJoinChat, socketLeaveChat: socketLeaveChat,
    socketEnsure: socketEnsure, onNotify: onNotify, socketDisconnect: socketDisconnect,
    socketOn: socketOn, socketEmit: socketEmit,
    NAV: NAV
  };
})();