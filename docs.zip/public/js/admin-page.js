// Admin console: dashboard, read-only user lookup, status control, real-name review,
// announcements and audit logs. Never stores or displays credentials.
(function () {
  'use strict';
  if (!App.requireLogin()) return;
  App.mountNav('me');
  App.mountNetBanner();
  var $ = function (id) { return document.getElementById(id); };
  var esc = App.escapeHtml;
  var loading = false;
  var offset = 0;
  var limit = 20;
  var total = 0;
  var query = '';
  var muteFilter = '';
  var rnFilter = 'pending';
  var auditAction = '';
  var apFilter = 'PENDING';
  var loaded = {};

  function resetLoaded() {
    loaded = {
      overview: false, users: false, funds: false, ledger: false, realname: false,
      announce: false, audit: false, deposits: false, withdrawals: false, referrals: false,
      approvals: false
    };
  }

  // ---------- 通用渲染 ----------
  // 统计卡：传 opts.go 时渲染成按钮，点击进入对应 Tab（如「注册人数」→ 用户列表）
  function tile(label, value, sub, opts) {
    var inner = '<div class="stat-label">' + esc(label) + '</div>' +
      '<div class="stat-value">' + esc(value) + '</div>' +
      (sub ? '<div class="stat-sub">' + esc(sub) + '</div>' : '') +
      (opts && opts.go ? '<div class="stat-tip">点击查看用户</div>' : '');
    if (opts && opts.go) {
      return '<button type="button" class="stat-card stat-link" data-go="' + esc(opts.go) + '">' + inner + '</button>';
    }
    return '<div class="stat-card">' + inner + '</div>';
  }
  function num(value, fallback) {
    return value === null || value === undefined ? (fallback || '--') : String(value);
  }
  function tag(label, cls) {
    return '<span class="admin-tag ' + (cls || '') + '">' + esc(label) + '</span>';
  }
  function row(title, subLines) {
    return '<div class="list-row"><div class="lr-main"><div class="lr-title">' + title + '</div>' +
      '<div class="tx-sub">' + subLines.join('<br>') + '</div></div></div>';
  }
  function dt(value) { return esc(value ? App.fmtDateTime(value) : '--'); }

  // ---------- 概览 ----------
  function renderStats(d) {
    var rn = d.real_name || {};
    var on = d.online || {};
    var mod = d.moderation || {};
    var ap = d.approvals || {};
    $('statGrid').innerHTML = [
      tile('用户总数', num(d.users.total), '正常 ' + num(d.users.active, 0) + ' · 封禁 ' + num(d.users.banned, 0), { go: 'users' }),
      tile('今日注册', num(d.users.today, 0), '有效公告 ' + num(d.announcements && d.announcements.active), { go: 'users' }),
      tile('在线人数', num(on.count, '不可用'), on.available
        ? ('最近 ' + num(on.window_seconds, 90) + ' 秒活跃 · Socket ' + num(on.sockets, 0))
        : '在线状态表不可用（不编造数字）'),
      tile('待复核', num(ap.pending, '不可用'), ap.enabled ? '高风险动作需第二名管理员复核' : '复核功能未启用'),
      tile('禁言中', num(mod.muted_now, '不可用'), '24 小时内解禁 ' + num(mod.expiring_24h, 0) + ' 人'),
      tile('待处理 OTP', num(d.otp.pending, 0), '今日申请 ' + num(d.otp.created_today, 0)),
      tile('待审核实名', num(rn.pending), '已通过 ' + num(rn.approved, 0)),
      tile('推广关系', num(d.referrals.total, 0), '直属 ' + num(d.referrals.direct, 0) + ' · 二级 ' + num(d.referrals.second, 0)),
      tile('今日新增推广', num(d.referrals.today, 0), '本月 ' + num(d.referrals.month, 0)),
      tile('客服会话', num(d.support.threads, 0), '24 小时消息 ' + num(d.support.messages_24h, 0)),
      tile('24 小时登录', num(d.login.success_24h, 0), '失败 ' + num(d.login.failed_24h, 0))
    ].join('');
    $('unsupported').innerHTML = (d.unsupported && d.unsupported.length)
      ? d.unsupported.map(function (item) { return row(esc(item.label), [esc(item.note)]); }).join('')
      : '<p>暂无</p>';

    // 治理提醒：禁言到期（到期后自动失效，管理员可决定是否续期）
    var expiring = (mod.expiring_users || []);
    var scopeText = (mod.scope || []).filter(function (s) { return s.blocked; })
      .map(function (s) { return s.label; }).join('、');
    var html = '<div>禁言联动范围：' + esc(scopeText || '--') + '</div>' +
      '<div>到期提醒窗口：' + esc(fmtMinutes(mod.expiring_remind_minutes || 0)) + ' · 到期自动解禁，无需人工操作</div>';
    if (!expiring.length) {
      html += '<div>暂无即将解禁的账号</div>';
    } else {
      html += expiring.map(function (u) {
        return row(esc(u.nickname || u.username || ('#' + u.id)), [
          '解禁时间 ' + dt(u.muted_until) + ' · 剩余 ' + esc(fmtMinutes(u.minutes_left)),
          '禁言原因 ' + esc(u.mute_reason || '--')
        ]);
      }).join('');
    }
    $('muteExpiring').innerHTML = html;
  }
  async function loadOverview(force) {
    if (loaded.overview && !force) return;
    App.showLoading($('statGrid'), '正在加载概览...');
    var res = await App.api('/api/admin/dashboard');
    if (!res.success || !res.data) {
      App.showError($('statGrid'), res.message || '后台统计加载失败', function () { loadOverview(true); });
      return;
    }
    loaded.overview = true;
    renderStats(res.data);
  }


// ---------- 用户 ----------
  var userById = {};
  var ROLE_LABEL = { admin: '管理员', support: '客服', user: '普通用户' };
  var STATUS_LABEL = { active: '正常', banned: '已封禁', deleted: '已注销' };
  // 禁言时长选项（分钟）：与后端 5 分钟 ~ 30 天限制一致
  var MUTE_OPTIONS = [
    { minutes: 60, label: '禁言 1 小时' },
    { minutes: 60 * 24, label: '禁言 1 天' },
    { minutes: 60 * 24 * 7, label: '禁言 7 天' },
    { minutes: 60 * 24 * 30, label: '禁言 30 天' }
  ];

  function muteTag(u) {
    if (!u.muted) return '';
    // 到期提醒：24 小时内即将解禁的账号单独标出来，方便管理员决定是否续期
    var label = '禁言至 ' + App.fmtDateTime(u.muted_until);
    if (u.mute_expiring && typeof u.mute_minutes_left === 'number') {
      return tag(label + '（' + fmtMinutes(u.mute_minutes_left) + '后解禁）', 'muted');
    }
    return tag(label, 'muted');
  }

  /** 分钟数 → 中文（后台提醒文案） */
  function fmtMinutes(m) {
    var n = Math.max(0, Math.round(Number(m) || 0));
    if (n < 60) return n + ' 分钟';
    if (n < 60 * 24) return Math.round(n / 60) + ' 小时';
    return Math.round((n / 1440) * 10) / 10 + ' 天';
  }

  function renderUsers(list, res) {
    userById = {};
    if (!list.length) {
      $('userList').innerHTML = App.stateBox('empty', res.q ? '没有匹配的用户' : '暂无可显示的用户');
      return;
    }
    $('userList').innerHTML = list.map(function (u) {
      userById[Number(u.id)] = u;
      var lines = [
        '注册 ' + dt(u.created_at) + ' · 最后登录 ' + dt(u.last_login_at),
        '邀请码 ' + esc(u.invite_code || '--') + ' · 邀请人 ' +
          esc(u.invited_by ? (u.invited_by.username || '#' + u.invited_by.id) : '无'),
        '直属 ' + num(u.direct_count, 0) + ' · 二级 ' + num(u.second_count, 0)
      ];
      if (u.phone_masked) lines.push('手机号 ' + esc(u.phone_masked));
      if (u.email) lines.push('邮箱 ' + esc(u.email));
      if (u.real_name) lines.push('注册姓名 ' + esc(u.real_name));
      if (u.muted && u.mute_reason) lines.push('禁言原因 ' + esc(u.mute_reason));

      var tools = '<button class="btn btn-gold" data-user="' + Number(u.id) + '">管理账号</button>';
      if (u.status === 'banned') {
        tools += '<button class="btn btn-dark" data-status="active" data-id="' + Number(u.id) + '">解除封禁</button>';
      } else if (u.status === 'active') {
        tools += '<button class="btn btn-dark" data-status="banned" data-id="' + Number(u.id) + '">封禁账号</button>';
      }

      return '<section class="card"><div class="card-title">' + esc(u.nickname || u.username) +
        ' ' + tag(ROLE_LABEL[u.role] || u.role, u.role === 'admin' ? 'admin' : '') +
        ' ' + tag(STATUS_LABEL[u.status] || u.status, u.status) +
        ' ' + muteTag(u) + '</div>' +
        row('<button type="button" class="user-name" data-user="' + Number(u.id) +
          '" title="点击管理该账号">' + esc(u.username) + '</button>' +
          '<span class="tx-sub">#' + Number(u.id) + '</span>', lines) +
        '<div class="admin-tools">' + tools + '</div></section>';
    }).join('');
  }
  async function searchUsers(force) {
    if (loading || (loaded.users && !force)) return;
    loading = true;
    $('searchUsers').disabled = true;
    App.showLoading($('userList'), '正在查询用户...');
    try {
      var res = await App.api('/api/admin/users?limit=' + limit + '&offset=' + offset +
        '&q=' + encodeURIComponent(query) + '&mute=' + encodeURIComponent(muteFilter));
      if (!res.success || !res.data) {
        App.showError($('userList'), res.message || '用户查询失败', function () { searchUsers(true); });
        return;
      }
      loaded.users = true;
      total = res.data.total;
      renderUsers(res.data.list || [], res.data);
      $('prevPage').hidden = offset <= 0;
      $('nextPage').hidden = offset + limit >= total;
    } finally {
      loading = false;
      $('searchUsers').disabled = false;
    }
  }
  /** 用户相关变更后的统一刷新（列表 / 概览 / 审计缓存） */
  async function refreshAfterUserChange() {
    loaded.audit = false;
    await searchUsers(true);
    await loadOverview(true);
  }

  /** 必填原因输入：所有账号治理操作的共同入口（原因会写入审计日志） */
  function askReason(label) {
    var value = window.prompt(label + '：请填写原因（必填，会写入审计日志）', '');
    if (value === null) return '';
    var reason = String(value).trim();
    if (reason.length < 2) { App.toast('请填写至少 2 个字的原因', 'err'); return ''; }
    return reason;
  }

  /** 治理动作结果提示（含双人复核：202 = 已提交待复核，尚未生效） */
  function governanceResult(res, doneText) {
    if (res.success && res.data && res.data.pending_approval) {
      App.toast('已提交复核申请 #' + Number(res.data.approval.id) + '：需另一名管理员复核后生效', 'ok');
      loaded.approvals = false;
      return 'pending';
    }
    if (res.success) {
      App.toast(doneText + (res.data && res.data.approval_note ? '（' + res.data.approval_note + '）' : ''), 'ok');
      return 'done';
    }
    App.toast(res.message || '操作失败', 'err');
    return 'fail';
  }

  async function changeStatus(id, status) {
    var label = status === 'banned' ? '封禁账号' : '解除封禁';
    var reason = askReason(label);
    if (!reason) return;
    var res = await App.api('/api/admin/users/' + Number(id) + '/status', {
      method: 'POST', body: { status: status, reason: reason }
    });
    var out = governanceResult(res, status === 'banned'
      ? '账号已封禁，该账号的实时连接已断开'
      : '账号已解封');
    if (out !== 'fail') await refreshAfterUserChange();
  }

  // ---------- 用户治理：管理员权限 / 禁言 / 封禁 ----------
  async function setUserRole(id, role) {
    var reason = askReason(role === 'admin' ? '授予管理员权限' : '取消管理员权限');
    if (!reason) return;
    var res = await App.api('/api/admin/users/' + Number(id) + '/role', {
      method: 'POST', body: { role: role, reason: reason }
    });
    var out = governanceResult(res, role === 'admin' ? '已授予管理员权限' : '已取消管理员权限');
    if (out !== 'fail') await refreshAfterUserChange();
  }

  function muteMinutesLabel(minutes) {
    if (minutes % 1440 === 0) return (minutes / 1440) + ' 天';
    if (minutes % 60 === 0) return (minutes / 60) + ' 小时';
    return minutes + ' 分钟';
  }

  async function muteUser(id, minutes) {
    var reason = askReason('禁言 ' + muteMinutesLabel(minutes));
    if (!reason) return;
    var res = await App.api('/api/admin/users/' + Number(id) + '/mute', {
      method: 'POST', body: { minutes: minutes, reason: reason }
    });
    if (res.success) {
      var scope = (res.data && res.data.scope_note) ? '（' + res.data.scope_note + '）' : '';
      App.toast('该账号已被禁言' + scope, 'ok');
    } else {
      App.toast(res.message || '禁言失败', 'err');
    }
    if (res.success) await refreshAfterUserChange();
  }

  async function unmuteUser(id) {
    var res = await App.api('/api/admin/users/' + Number(id) + '/unmute', {
      method: 'POST', body: { reason: '管理员解除禁言' }
    });
    var out = governanceResult(res, '已解除禁言');
    if (out !== 'fail') await refreshAfterUserChange();
  }

  /** 禁言时长选择（第二步） */
  function openMuteSheet(u) {
    App.openSheet({
      title: '禁言 ' + u.username,
      items: MUTE_OPTIONS.map(function (opt) {
        return { label: opt.label, icon: 'i-warning', onClick: function () { muteUser(u.id, opt.minutes); } };
      })
    });
  }

  /** 点击用户名 / 管理账号 → 用户管理面板 */
  function openUserSheet(id) {
    var u = userById[Number(id)];
    if (!u) return;
    var items = [];
    if (u.role === 'admin') {
      items.push({ label: '取消管理员权限', icon: 'i-shield', danger: true, onClick: function () { setUserRole(u.id, 'user'); } });
    } else {
      items.push({ label: '设为管理员（授予后台权限）', icon: 'i-shield', onClick: function () { setUserRole(u.id, 'admin'); } });
    }
    // 管理员账号由后端禁止禁言 / 封禁：只提供「取消管理员权限」，不给出必然失败的入口
    if (u.role !== 'admin') {
      if (u.muted) {
        items.push({
          label: '解除禁言（当前禁言至 ' + App.fmtDateTime(u.muted_until) + '）',
          icon: 'i-check', onClick: function () { unmuteUser(u.id); }
        });
      } else {
        items.push({ label: '禁言该账号…', icon: 'i-warning', onClick: function () { openMuteSheet(u); } });
      }
      if (u.status === 'banned') {
        items.push({ label: '解除封禁（恢复登录）', icon: 'i-check', onClick: function () { changeStatus(u.id, 'active'); } });
      } else if (u.status === 'active') {
        items.push({ label: '封禁账号（禁止登录）', icon: 'i-warning', danger: true, onClick: function () { changeStatus(u.id, 'banned'); } });
      }
    }
    App.openSheet({
      title: '管理 ' + (u.nickname || u.username) + '（' + (ROLE_LABEL[u.role] || u.role) + '）',
      items: items
    });
  }

  // ---------- 实名审核 ----------
  function renderRealName(data) {
    var s = data.summary || {};
    $('realNameSummary').textContent = '待审核 ' + num(s.pending, 0) + ' · 已通过 ' + num(s.approved, 0) +
      ' · 已拒绝 ' + num(s.rejected, 0) + ' · 合计 ' + num(s.total, 0);
    if (!data.list.length) {
      $('realNameList').innerHTML = App.stateBox('empty', '暂无实名审核记录');
      return;
    }
    $('realNameList').innerHTML = data.list.map(function (r) {
      var actions = r.status === 'pending'
        ? '<div class="admin-tools">' +
          '<button class="btn btn-gold" data-review="approved" data-id="' + Number(r.id) + '">通过</button>' +
          '<button class="btn btn-dark" data-review="rejected" data-id="' + Number(r.id) + '">拒绝</button></div>'
        : '';
      var lines = [
        '账号 ' + esc(r.username || ('#' + r.user_id)) + ' · 提交 ' + dt(r.created_at),
        '审核 ' + dt(r.reviewed_at) + ' · 审核人 ' +
          esc(r.reviewed_by ? (r.reviewed_by.username || '#' + r.reviewed_by.id) : '--')
      ];
      if (r.remark) lines.push('备注 ' + esc(r.remark));
      return '<section class="card"><div class="card-title">' + esc(r.real_name) + ' ' +
        tag(r.status, '') + '</div>' + row('#' + Number(r.id), lines) + actions + '</section>';
    }).join('');
  }
  async function loadRealName(force) {
    if (loaded.realname && !force) return;
    App.showLoading($('realNameList'), '正在加载实名审核...');
    var res = await App.api('/api/admin/real-name-reviews?status=' + encodeURIComponent(rnFilter));
    if (!res.success || !res.data) {
      App.showError($('realNameList'), res.message || '实名审核加载失败', function () { loadRealName(true); });
      return;
    }
    loaded.realname = true;
    renderRealName(res.data);
  }
  async function reviewRealName(id, decision) {
    var remark = '';
    if (decision === 'rejected') {
      remark = window.prompt('拒绝原因（必填）', '') || '';
      if (remark.trim().length < 2) { App.toast('请填写至少 2 个字的拒绝原因', 'err'); return; }
    }
    var res = await App.api('/api/admin/real-name-reviews/' + Number(id) + '/review', {
      method: 'POST', body: { decision: decision, remark: remark.trim() }
    });
    App.toast(res.success ? '审核已提交' : (res.message || '审核失败'), res.success ? 'ok' : 'err');
    if (res.success) {
      loaded.audit = false;
      await loadRealName(true);
      await loadOverview(true);
    }
  }
// ---------- 公告 ----------
  function renderAnnouncements(data) {
    if (!data.list.length) {
      $('announceList').innerHTML = App.stateBox('empty', '暂无公告');
      return;
    }
    $('announceList').innerHTML = data.list.map(function (a) {
      var toggle = a.status === 'active'
        ? '<button class="btn btn-dark" data-announce="hidden" data-id="' + Number(a.id) + '">下线</button>'
        : '<button class="btn btn-gold" data-announce="active" data-id="' + Number(a.id) + '">发布</button>';
      var lines = [
        esc(a.type) + ' · 排序 ' + num(a.sort, 0) + ' · ' + (a.pinned ? '置顶' : '不置顶'),
        '创建 ' + dt(a.created_at) + ' · 更新 ' + dt(a.updated_at),
        '时间 ' + esc(a.start_at || '立即') + ' ~ ' + esc(a.end_at || '长期')
      ];
      if (a.content) lines.push(esc(a.content.slice(0, 120)));
      return '<section class="card"><div class="card-title">' + esc(a.title) + ' ' +
        tag(a.status, a.status) + '</div>' + row('#' + Number(a.id), lines) +
        '<div class="admin-tools">' + toggle + '</div></section>';
    }).join('');
  }
  async function loadAnnouncements(force) {
    if (loaded.announce && !force) return;
    App.showLoading($('announceList'), '正在加载公告...');
    var res = await App.api('/api/admin/announcements?limit=30&offset=0');
    if (!res.success || !res.data) {
      App.showError($('announceList'), res.message || '公告加载失败', function () { loadAnnouncements(true); });
      return;
    }
    loaded.announce = true;
    renderAnnouncements(res.data);
  }
  async function setAnnouncementStatus(id, status) {
    var res = await App.api('/api/admin/announcements/' + Number(id), { method: 'PATCH', body: { status: status } });
    App.toast(res.success ? (status === 'active' ? '公告已发布' : '公告已下线') : (res.message || '操作失败'),
      res.success ? 'ok' : 'err');
    if (res.success) {
      loaded.audit = false;
      await loadAnnouncements(true);
      await loadOverview(true);
    }
  }
  async function createAnnouncement(event) {
    event.preventDefault();
    var body = {
      title: $('anTitle').value.trim(),
      summary: $('anSummary').value.trim(),
      content: $('anContent').value.trim(),
      type: $('anType').value,
      image: $('anImage').value.trim(),
      start_at: $('anStart').value.trim(),
      end_at: $('anEnd').value.trim(),
      pinned: $('anPinned').checked,
      sort: Number($('anSort').value) || 0
    };
    if (body.title.length < 2) { App.toast('标题至少 2 个字', 'err'); return; }
    $('createAnnounce').disabled = true;
    try {
      var res = await App.api('/api/admin/announcements', { method: 'POST', body: body });
      if (!res.success) { App.toast(res.message || '公告创建失败', 'err'); return; }
      $('announceForm').reset();
      $('announceStatus').textContent = '公告 #' + res.data.id + ' 已创建';
      App.toast('公告已创建', 'ok');
      loaded.audit = false;
      await loadAnnouncements(true);
      await loadOverview(true);
    } finally {
      $('createAnnounce').disabled = false;
    }
  }

  // ---------- 审计日志 ----------
  async function loadAudit(force) {
    if (loaded.audit && !force) return;
    App.showLoading($('auditList'), '正在加载审计日志...');
    var res = await App.api('/api/admin/audit-logs?limit=50&action=' + encodeURIComponent(auditAction));
    if (!res.success || !res.data) {
      App.showError($('auditList'), res.message || '审计日志加载失败', function () { loadAudit(true); });
      return;
    }
    loaded.audit = true;
    if (!res.data.list.length) {
      $('auditList').innerHTML = App.stateBox('empty', '暂无审计记录');
      return;
    }
    $('auditList').innerHTML = res.data.list.map(function (l) {
      var who = l.admin ? (l.admin.username || '#' + l.admin.id) : '系统';
      var target = l.target ? (l.target.nickname || l.target.username || '#' + l.target.id) : '--';
      return '<section class="card"><div class="card-title">' + esc(l.action) + '</div>' +
        row('#' + Number(l.id) + ' ' + esc(who), [
          '目标 ' + esc(target) + ' · ' + dt(l.created_at),
          esc(l.detail || '无详情')
        ]) + '</section>';
    }).join('');
  }

  // ---------- 资金审核（阶段 12/13） ----------
  var fundsType = '';
  var fundsStatus = 'PENDING';
  var ORDER_STATUS_TEXT = {
    PENDING_PAYMENT: '待付款', PENDING_REVIEW: '待审核', PENDING: '待审核',
    PROCESSING: '处理中', APPROVED: '已通过', COMPLETED: '已通过',
    REJECTED: '已拒绝', CANCELLED: '已取消'
  };
  function renderFunds(data) {
    var s = data.summary || {};
    $('fundsSummary').textContent = '充值 待审 ' + num((s.deposit || {}).PENDING, 0) + ' / 通过 ' + num((s.deposit || {}).COMPLETED, 0) +
      ' ｜ 提现 待审 ' + num((s.withdraw || {}).PENDING, 0) + ' / 通过 ' + num((s.withdraw || {}).COMPLETED, 0);
    var list = data.list || [];
    if (!list.length) { $('fundsList').innerHTML = App.stateBox('empty', '没有符合条件的申请'); return; }
    $('fundsList').innerHTML = list.map(function (o) {
      var sub = [
        esc(o.user && (o.user.username || '#' + o.user.id)) + ' · ' + dt(o.created_at),
        '单号 ' + esc(o.order_no) + (o.account ? ' · 账号 ' + esc(o.account) : '') +
          (o.voucher_path ? ' · 凭证已上传' : ''),
        (o.status === 'REJECTED' && o.reject_reason ? '拒绝原因：' + esc(o.reject_reason) : '') +
        (o.reviewer ? ' · 审核人 ' + esc(o.reviewer.username || '#' + o.reviewer.id) + ' ' + dt(o.reviewed_at) : '')
      ].filter(Boolean);
      var actions = ['PENDING', 'PENDING_REVIEW', 'PROCESSING'].indexOf(o.status) >= 0
        ? '<button class="btn btn-gold" data-order="approved" data-type="' + esc(o.order_type) + '" data-id="' + o.id + '" type="button">通过</button>' +
          '<button class="btn btn-dark" data-order="rejected" data-type="' + esc(o.order_type) + '" data-id="' + o.id + '" type="button">拒绝</button>'
        : '';
      return '<section class="card"><div class="card-title">' + esc(o.order_type === 'DEPOSIT' ? '充值' : '提款') +
        ' RM' + esc(Number(o.amount).toFixed(2)) + ' ' +
        tag(ORDER_STATUS_TEXT[o.status] || o.status, (o.status === 'COMPLETED' || o.status === 'APPROVED') ? 'active' : (o.status === 'REJECTED' ? 'banned' : '')) +
        '</div><div class="tx-sub">' + sub.join('<br>') + '</div>' +
        (actions ? '<div class="admin-tools">' + actions + '</div>' : '') + '</section>';
    }).join('');
  }
  async function loadFunds(force) {
    if (loaded.funds && !force) return;
    App.showLoading($('fundsList'), '正在加载申请...');
    var res = await App.api('/api/admin/wallet/orders?type=' + encodeURIComponent(fundsType) + '&status=' + encodeURIComponent(fundsStatus) + '&limit=30');
    if (!res.success) { App.showError($('fundsList'), res.message || '申请加载失败', function () { loadFunds(true); }); return; }
    loaded.funds = true;
    renderFunds(res.data);
  }
  async function reviewOrder(id, decision, orderType) {
    var kind = orderType === 'WITHDRAW' ? 'withdrawals' : 'deposits';
    var body = { decision: decision === 'approved' ? 'approve' : 'reject', note: '' };
    if (decision === 'rejected') {
      var reason = (window.prompt('请输入拒绝原因（至少 2 个字符）：') || '').trim();
      if (reason.length < 2) { App.toast('必须填写拒绝原因', 'err'); return; }
      if (!await App.confirmDialog({ title: '拒绝申请', text: '拒绝后不改动用户余额。确定拒绝该申请吗？' })) return;
      body = { decision: 'reject', reason: reason };
    } else {
      if (!await App.confirmDialog({ title: '通过申请', text: '通过后将立即变更用户现金筹码余额（充值入账 / 提款扣款），并写入流水与审计。确定继续吗？' })) return;
    }
    var res = await App.api('/api/admin/' + kind + '/' + id + '/review', { method: 'POST', body: body });
    App.toast(res.success ? '审核完成' : (res.message || '审核失败'), res.success ? 'ok' : 'err');
    if (res.success) { loadFunds(true); if (loaded.deposits || loaded.withdrawals) loadOrderList(kind, true); }
  }

  // ---------- 余额流水 + 调整（阶段 15/16） ----------
  var TX_TYPE_TEXT = { DEPOSIT: '充值', WITHDRAW: '提现', ADMIN_GRANT: '管理员发放', ADJUST: '管理员调整', GAME_BET: '游戏下注', GAME_WIN: '游戏赢', GAME_LOSE: '游戏输', EXCHANGE: '兑换' };
  function rm(n) { return 'RM' + Number(n || 0).toFixed(2); }
  function renderLedger(data) {
    var list = data.list || [];
    if (!list.length) { $('ledgerList').innerHTML = App.stateBox('empty', '暂无流水记录'); return; }
    $('ledgerList').innerHTML = list.map(function (t) {
      var a = Number(t.amount);
      return '<div class="list-row"><div class="lr-main"><div class="lr-title">' +
        esc((t.user.username || '#' + t.user.id) + ' · ' + (TX_TYPE_TEXT[t.type] || t.type)) +
        ' <span style="color:' + (a >= 0 ? 'var(--success)' : 'var(--danger)') + '">' + (a >= 0 ? '+' : '') + rm(a) + '</span></div>' +
        '<div class="tx-sub">' + esc(App.fmtDateTime(t.created_at)) + ' · 余额 ' + esc(t.balance_before) + ' → ' + esc(t.balance_after) +
        (t.related_request_id ? ' · 申请#' + t.related_request_id : '') +
        (t.operator ? ' · 操作人 ' + esc(t.operator.username || '#' + t.operator.id) : '') +
        (t.reason ? '<br>' + esc(t.reason) : '') + '</div></div>';
    }).join('');
  }
  async function loadLedger(force) {
    if (loaded.ledger && !force) return;
    App.showLoading($('ledgerList'), '正在加载流水...');
    var uid = $('ledgerUser').value.trim();
    var res = await App.api('/api/admin/wallet/transactions' + (uid ? '?user_id=' + encodeURIComponent(uid) : '') + '&limit=30');
    if (!res.success) { App.showError($('ledgerList'), res.message || '流水加载失败', function () { loadLedger(true); }); return; }
    loaded.ledger = true;
    renderLedger(res.data);
  }
  async function submitAdjust() {
    var uid = Number($('adjustUserId').value);
    var currency = $('adjustCurrency').value;
    var amount = Number($('adjustAmount').value);
    var reason = $('adjustReason').value.trim();
    if (!uid) { App.toast('请输入用户ID', 'err'); return; }
    if (!amount) { App.toast('调整金额不能为 0', 'err'); return; }
    if (reason.length < 2) { App.toast('必须填写调整原因', 'err'); return; }
    if (!await App.confirmDialog({ title: '余额调整', text: '确定调整用户 #' + uid + ' 的' + (currency === 'CASH_CHIPS' ? '现金筹码' : '游戏余额') + ' ' + (amount > 0 ? '+' : '') + amount + ' 吗？' })) return;
    var res = await App.api('/api/admin/users/' + uid + '/adjust', { method: 'POST', body: { currency_type: currency, amount: amount, reason: reason } });
    App.toast(res.success ? '调整成功' : (res.message || '调整失败'), res.success ? 'ok' : 'err');
    if (res.success) { $('adjustReason').value = ''; $('adjustAmount').value = ''; loadLedger(true); }
  }

  // ============================================
  // 充值管理 / 提款管理（V5 状态机）
  // ============================================
  var ORDER_STATUS_TEXT_V5 = {
    PENDING_PAYMENT: '待付款', PENDING_REVIEW: '待审核', PENDING: '待审核',
    PROCESSING: '处理中', APPROVED: '已通过', COMPLETED: '已通过',
    REJECTED: '已拒绝', CANCELLED: '已取消'
  };
  var WITHDRAW_STATUS_TEXT = {
    PENDING: '待审核', APPROVED: '审核通过', REJECTED: '审核拒绝', CANCELLED: '已取消'
  };
  var depState = { status: '', q: '', offset: 0, limit: 20, total: 0 };
  var wdState = { status: '', q: '', offset: 0, limit: 20, total: 0 };
  var withdrawalOrderCache = {};

  function statusCls(s) {
    if (s === 'APPROVED' || s === 'COMPLETED') return 'active';
    if (s === 'REJECTED') return 'banned';
    if (s === 'PENDING_PAYMENT' || s === 'PENDING_REVIEW' || s === 'PENDING') return 'muted';
    return '';
  }

  /** 充值/提款订单卡（含凭证与审核入口） */
  function orderCard(o, kind) {
    var sub = [
      esc((o.user && (o.user.username || '#' + o.user.id)) || '--') + ' · ' + dt(o.created_at),
      '单号 ' + esc(o.order_no) + ' · ' + esc(o.asset_text || o.asset_type || '') +
        ' · 方式 ' + esc(o.payment_method || ''),
      kind === 'withdrawals'
        ? '收款人：' + esc(o.recipient_name || '--') + ' · 银行：' + esc(o.bank_name || '--') + ' · 账号：' + esc(o.account_reference || '--')
        : '',
      o.has_voucher ? '凭证：已上传 ' + dt(o.voucher_uploaded_at) : (kind === 'deposits' ? '凭证：未上传' : ''),
      o.operator_username ? '审核人 ' + esc(o.operator_username) + ' ' + dt(o.reviewed_at) : '',
      o.reject_reason ? '拒绝原因：' + esc(o.reject_reason) : '',
      o.operator_remark ? '备注：' + esc(o.operator_remark) : '',
      o.before_balance !== null && o.before_balance !== undefined && o.after_balance !== null && o.after_balance !== undefined
        ? '余额 ' + esc(o.before_balance.toFixed(2)) + ' → ' + esc(o.after_balance.toFixed(2)) : ''
    ].filter(Boolean);
    var reviewable = kind === 'withdrawals' ? o.status === 'PENDING' : ['PENDING_REVIEW', 'PENDING', 'PROCESSING'].indexOf(o.status) >= 0;
    var actions = '';
    if (o.has_voucher) {
      actions += '<button class="btn btn-dark" data-voucher="' + o.id + '" data-kind="' + kind + '" type="button">查看凭证</button>';
    }
    if (reviewable) {
      actions += '<button class="btn btn-gold" data-approve="' + o.id + '" data-kind="' + kind + '" type="button">批准</button>' +
        '<button class="btn btn-dark" data-reject="' + o.id + '" data-kind="' + kind + '" type="button">拒绝</button>';
    }
    if (kind === 'deposits' && (o.status === 'APPROVED' || o.status === 'COMPLETED')) {
      actions += '<button class="btn btn-dark" data-settle="' + o.id + '" type="button">补结算奖励</button>';
    }
    return '<section class="card"><div class="card-title">' +
      esc(kind === 'deposits' ? '充值' : '提款') + ' RM' + esc(Number(o.amount).toFixed(2)) + ' ' +
      tag(kind === 'withdrawals' ? (WITHDRAW_STATUS_TEXT[o.status] || o.status) : (ORDER_STATUS_TEXT_V5[o.status] || o.status), statusCls(o.status)) + '</div><div class="tx-sub">' + sub.join('<br>') + '</div>' +
      (kind === 'withdrawals' ? '<details class="admin-note" style="margin-top:10px"><summary>提款详情</summary><div>订单号：' + esc(o.order_no) + '</div><div>用户ID：' + esc(o.user_id) + '</div><div>收款人：' + esc(o.recipient_name || '--') + '</div><div>银行：' + esc(o.bank_name || '--') + '</div><div>银行账号：' + esc(o.account_reference || '--') + '</div><div>提交时间：' + dt(o.created_at) + '</div></details>' : '') +
      (actions ? '<div class="admin-tools">' + actions + '</div>' : '') + '</section>';
  }

  function renderOrderList(kind, data) {
    var list = data.list || [];
    if (kind === 'withdrawals') list.forEach(function (o) { withdrawalOrderCache[o.id] = o; });
    var flag = kind === 'deposits' ? 'dep' : 'wd';
    var sum = data.summary || {};
    var target = kind === 'deposits' ? (sum.deposit || {}) : sum;
    $(flag + 'Summary').textContent = kind === 'deposits'
      ? ('待付款 ' + num(target.pending_payment, 0) + ' · 待审核 ' + num(target.pending_review, 0) +
         ' · 已通过 ' + num(target.approved, 0) + ' · 已拒绝 ' + num(target.rejected, 0) + ' · 共 ' + num(target.total, 0))
      : ('待审核 ' + num(target.pending, 0) + ' · 已通过 ' + num(target.approved, 0) +
         ' · 审核拒绝 ' + num(target.rejected, 0) + ' · 已取消 ' + num(target.cancelled, 0) + ' · 共 ' + num(data.total, 0));
    var box = $(flag + 'List');
    box.innerHTML = list.length
      ? list.map(function (o) { return orderCard(o, kind); }).join('')
      : App.stateBox('empty', kind === 'deposits' ? '没有符合条件的充值订单' : '没有符合条件的提款订单');
    var state = kind === 'deposits' ? depState : wdState;
    state.total = Number(data.total) || 0;
    var prev = $(flag + 'Prev'), next = $(flag + 'Next');
    prev.hidden = state.offset <= 0;
    next.hidden = state.offset + state.limit >= state.total;
  }

  async function loadOrderList(kind, force) {
    var flag = kind === 'deposits' ? 'dep' : 'wd';
    var key = kind === 'deposits' ? 'deposits' : 'withdrawals';
    var state = kind === 'deposits' ? depState : wdState;
    if (loaded[key] && !force) return;
    App.showLoading($(flag + 'List'), '正在加载订单...');
    var res = await App.api('/api/admin/' + kind + '?status=' + encodeURIComponent(state.status) +
      '&q=' + encodeURIComponent(state.q) + '&limit=' + state.limit + '&offset=' + state.offset);
    if (!res.success) {
      App.showError($(flag + 'List'), res.message || '订单加载失败', function () { loadOrderList(kind, true); });
      return;
    }
    loaded[key] = true;
    renderOrderList(kind, res.data);
  }

  /** 批准 / 拒绝（批准前端只提示，最终以事务结果为准） */
  async function reviewFundsOrder(kind, id, decision) {
    var label = kind === 'deposits' ? '充值' : '提款';
    var body = { decision: decision };
    if (decision === 'reject') {
      var reason = (window.prompt('请输入拒绝原因（至少 2 个字符）：') || '').trim();
      if (reason.length < 2) { App.toast('必须填写拒绝原因', 'err'); return; }
      if (!await App.confirmDialog({ title: '拒绝' + label + '申请', text: label + '申请冻结的金额将退回用户余额。确定拒绝吗？' })) return;
      body = { decision: 'reject', reason: reason };
    } else {
      var confirmText = kind === 'deposits'
        ? '批准后将在同一事务内增加现金筹码余额、写入流水与审计（重复批准会被拒绝）。确定继续吗？'
        : '提款金额：RM ' + App.fmtMoney((withdrawalOrderCache[id] || {}).amount || 0) + '\n收款人：' + ((withdrawalOrderCache[id] || {}).recipient_name || '--') + '\n银行：' + ((withdrawalOrderCache[id] || {}).bank_name || '--') + '\n确认后订单将标记为审核通过。';
      if (!await App.confirmDialog({ title: kind === 'deposits' ? '批准充值申请' : '确认审核通过？', text: confirmText, okText: kind === 'deposits' ? '确定' : '确认审核通过' })) return;
    }
    var endpoint = kind === 'withdrawals' ? '/api/admin/withdrawals/' + id + (decision === 'approve' ? '/approve' : '/reject') : '/api/admin/' + kind + '/' + id + '/review';
    var res = await App.api(endpoint, { method: 'POST', body: body });
    App.toast(res.success ? '审核完成' : (res.message || '审核失败'), res.success ? 'ok' : 'err');
    if (res.success) loadOrderList(kind, true);
  }

  function openVoucher(kind, id) {
    window.open('/api/admin/' + kind + '/' + id + '/voucher', '_blank', 'noopener');
  }

  // ============================================
  // 推广管理（邀请关系 + 奖励台账 + 补结算）
  // ============================================
  var refState = { q: '', offset: 0, limit: 20, total: 0 };

  function renderReferrals(data) {
    var s = data.rewards_summary || {};
    var rates = data.rates || {};
    $('refSummary').textContent = '直属 ' + (rates.direct === undefined ? '--' : rates.direct + '%') +
      ' · 二级 ' + (rates.second === undefined ? '--' : rates.second + '%') +
      ' · 自身 ' + (rates.self === undefined ? '--' : rates.self + '%') +
      ' ｜ 奖励记录 ' + num(s.records, 0) + ' · 已入账 RM' + Number(s.credited || 0).toFixed(2) +
      ' · 待入账 RM' + Number(s.pending || 0).toFixed(2);
    var list = data.list || [];
    $('refList').innerHTML = list.length ? list.map(function (u) {
      var sub = [
        '直属 ' + num(u.direct, 0) + ' · 二级 ' + num(u.second, 0) +
          ' · 奖励 RM' + Number(u.reward_total || 0).toFixed(2) + '（' + num(u.reward_count, 0) + ' 条）',
        '邀请码 ' + esc(u.invite_code || '未分配') + ' · 注册 ' + dt(u.created_at),
        '账号状态 ' + esc(u.status)
      ];
      return row(esc(u.username || ('#' + u.id)), sub);
    }).join('') : App.stateBox('empty', '没有符合条件的推广用户');
    refState.total = Number(data.total) || 0;
    $('refPrev').hidden = refState.offset <= 0;
    $('refNext').hidden = refState.offset + refState.limit >= refState.total;
  }

  async function loadReferrals(force) {
    if (loaded.referrals && !force) return;
    App.showLoading($('refList'), '正在加载推广数据...');
    var res = await App.api('/api/admin/referrals?q=' + encodeURIComponent(refState.q) +
      '&limit=' + refState.limit + '&offset=' + refState.offset);
    if (!res.success) {
      App.showError($('refList'), res.message || '推广数据加载失败', function () { loadReferrals(true); });
      return;
    }
    loaded.referrals = true;
    renderReferrals(res.data);
  }

  async function loadReferralRewards() {
    var qs = [];
    if ($('rwFrom').value) qs.push('from=' + encodeURIComponent($('rwFrom').value));
    if ($('rwTo').value) qs.push('to=' + encodeURIComponent($('rwTo').value));
    App.showLoading($('refRewards'), '正在加载奖励台账...');
    var res = await App.api('/api/admin/referrals/rewards?limit=30' + (qs.length ? '&' + qs.join('&') : ''));
    if (!res.success) {
      App.showError($('refRewards'), res.message || '奖励台账加载失败', loadReferralRewards);
      return;
    }
    var list = res.data.list || [];
    $('refRewards').innerHTML = list.length ? list.map(function (w) {
      return row(esc((w.user.username || '#' + w.user.id) + ' +RM' + Number(w.reward_amount).toFixed(2)) +
        ' ' + tag(w.status_text, w.status === 'CREDITED' ? 'active' : 'muted') +
        ' ' + tag(w.level_text, 'admin'),
        ['比例 ' + Number(w.rate) + '% · 基数 RM' + Number(w.base_amount).toFixed(2) +
          ' · 资产 ' + esc(w.asset_type),
         '来源 ' + esc(w.source_ref || w.source_type) +
          (w.source_user ? ' · 下线 ' + esc(w.source_user.username || ('#' + w.source_user.id)) : ''),
         dt(w.credited_at || w.created_at)]);
    }).join('') : App.stateBox('empty', '暂无奖励记录');
  }

  async function settleRewards() {
    var id = Number($('settleOrderId').value);
    if (!id || id <= 0) { $('settleStatus').textContent = '请输入充值订单ID'; return; }
    if (!await App.confirmDialog({ title: '补结算推广奖励', text: '按该充值订单补结算奖励（幂等，重复执行不会重复发奖）。确定继续吗？' })) return;
    var res = await App.api('/api/admin/referrals/rewards/settle', { method: 'POST', body: { order_id: id } });
    $('settleStatus').textContent = res.success
      ? ('本次新入账 ' + res.data.created + ' 条奖励')
      : (res.message || '补结算失败');
    if (res.success) loadReferralRewards();
  }

  // ---------- 双人复核 ----------
  function renderApprovals(data) {
    var s = data.summary || {};
    $('approvalSummary').textContent = '待复核 ' + num(s.pending, 0) + ' · 已通过 ' + num(s.approved, 0) +
      ' · 已拒绝 ' + num(s.rejected, 0) + ' · 合计 ' + num(s.total, 0) +
      (data.enabled === false ? '（复核功能未启用，高风险动作将单人执行）' : '');
    if (!data.list.length) {
      $('approvalList').innerHTML = App.stateBox('empty',
        apFilter === 'PENDING' ? '当前没有待复核的请求' : '暂无复核记录');
      return;
    }
    $('approvalList').innerHTML = data.list.map(function (a) {
      var sub = [
        '目标 ' + esc(a.target_nickname || a.target_username || ('#' + a.target_user_id)) + ' · 申请 ' + dt(a.requested_at),
        '申请原因 ' + esc(a.reason || '--'),
        '参数 ' + esc(JSON.stringify(a.payload || {})),
        '申请人 ' + esc(a.requested_by.username || ('#' + a.requested_by.id)) +
          (a.reviewed_by ? ' · 复核人 ' + esc(a.reviewed_by.username || ('#' + a.reviewed_by.id)) + ' · ' + dt(a.reviewed_at) : ''),
        a.review_note ? '复核备注 ' + esc(a.review_note) : '',
        a.apply_result ? '执行结果 ' + esc(a.apply_result) : ''
      ].filter(Boolean);
      var actions = a.can_review
        ? '<div class="admin-tools">' +
          '<button class="btn btn-gold" type="button" data-ap-approve="' + Number(a.id) + '">复核通过并执行</button>' +
          '<button class="btn btn-dark" type="button" data-ap-reject="' + Number(a.id) + '">拒绝</button></div>'
        : (a.status === 'PENDING'
          ? '<p class="admin-note">不能复核自己提交的请求，请由另一名管理员处理。</p>' : '');
      return '<section class="card"><div class="card-title">#' + Number(a.id) + ' ' + esc(a.action_label) + ' ' +
        tag(a.status, a.status === 'APPROVED' ? 'active' : (a.status === 'REJECTED' ? 'banned' : 'muted')) +
        '</div>' + row('', sub) + actions + '</section>';
    }).join('');
  }

  async function loadApprovals(force) {
    if (loaded.approvals && !force) return;
    App.showLoading($('approvalList'), '正在加载复核队列...');
    var res = await App.api('/api/admin/approvals?status=' + encodeURIComponent(apFilter));
    if (!res.success || !res.data) {
      App.showError($('approvalList'), res.message || '复核队列加载失败', function () { loadApprovals(true); });
      return;
    }
    loaded.approvals = true;
    renderApprovals(res.data);
  }

  async function decideApproval(id, decision) {
    var note = '';
    if (decision === 'approve') {
      var okk = await App.confirmDialog({
        title: '复核通过',
        text: '通过后将立即执行该动作（不可撤销，会写入审计日志）。',
        okText: '通过并执行'
      });
      if (!okk) return;
    } else {
      note = askReason('拒绝复核请求');
      if (!note) return;
    }
    var res = await App.api('/api/admin/approvals/' + Number(id) + '/decide', {
      method: 'POST', body: { decision: decision, note: note }
    });
    if (res.success) {
      App.toast(decision === 'approve' ? '已通过并执行' : '已拒绝该请求', 'ok');
    } else {
      App.toast(res.message || '复核处理失败', 'err');
    }
    loaded.approvals = false;
    await loadApprovals(true);
    await searchUsers(true);
    await loadOverview(true);
  }

  // ---------- Tab 切换 ----------

  var TABS = ['overview', 'users', 'approvals', 'recharge', 'receiving', 'avatars', 'funds', 'deposits', 'withdrawals', 'ledger', 'realname', 'referrals', 'announce', 'notices', 'rounds', 'niu', 'games', 'support', 'staff', 'settings', 'audit'];
  function globalResultSection(title, rows) {
    if (!rows.length) return '';
    return '<div class="card" style="margin-bottom:8px"><b>' + App.escapeHtml(title) + '</b><div class="admin-note">' + rows.map(function (x) { return App.escapeHtml(x); }).join('<br>') + '</div></div>';
  }
  async function runGlobalSearch() {
    var q = $('globalQuery').value.trim();
    if (q.length < 2) { App.toast('请输入至少 2 个字符', 'err'); return; }
    var box = $('globalResults'); box.hidden = false; box.innerHTML = '<div class="sk-box" style="height:100px"></div>';
    var res = await App.api('/api/admin/search?q=' + encodeURIComponent(q));
    if (!res.success || !res.data) { App.showError(box, res.message || '搜索失败', runGlobalSearch); return; }
    var d = res.data;
    var html = globalResultSection('用户', (d.users || []).map(function (u) { return u.username + ' · ' + (u.invite_code || '无邀请码') + ' · ' + u.status; }));
    html += globalResultSection('订单', (d.orders || []).map(function (o) { return o.order_no + ' · ' + (o.username || '—') + ' · RM ' + o.amount + ' · ' + o.status; }));
    html += globalResultSection('推广', (d.referrals || []).map(function (r) { return (r.inviter || '—') + ' → ' + (r.invitee || '—') + ' · ' + r.level + '级 · ' + r.status; }));
    html += globalResultSection('客服', (d.support || []).map(function (s) { return s.username + ' · ' + s.status + ' · ' + App.fmtDateTime(s.updated_at); }));
    box.innerHTML = html || App.stateBox('empty', '暂无结果', '没有匹配的用户、订单、推广或客服会话。');
  }
  function showTab(tab) {
    TABS.forEach(function (key) {
      var panel = $('panel-' + key);
      if (panel) panel.hidden = key !== tab;
    });
    Array.prototype.forEach.call(document.querySelectorAll('.admin-tab'), function (btn) {
      var on = btn.dataset.tab === tab;
      btn.classList.toggle('active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    if (tab === 'overview') loadOverview(false);
    // 管理后台扩展面板（对局 / 游戏 / 通知 / 客服 / 管理员）
    if (window.AdminOpsPanel && AdminOpsPanel.refresh) AdminOpsPanel.refresh(tab);
    if (tab === 'users') searchUsers(false);
    if (tab === 'approvals') loadApprovals(false);
    if (tab === 'recharge' && window.AdminRechargePanel && AdminRechargePanel.refresh) AdminRechargePanel.refresh();
    if (tab === 'receiving' && window.AdminReceivingPanel && AdminReceivingPanel.refresh) AdminReceivingPanel.refresh();
    if (tab === 'avatars' && window.AdminAvatarsPanel && AdminAvatarsPanel.refresh) AdminAvatarsPanel.refresh();
    if (tab === 'niu' && window.AdminNiuPanel && AdminNiuPanel.refresh) AdminNiuPanel.refresh();
    if (tab === 'funds') loadFunds(false);
    if (tab === 'deposits') loadOrderList('deposits', false);
    if (tab === 'withdrawals') loadOrderList('withdrawals', false);
    if (tab === 'referrals') { loadReferrals(false); loadReferralRewards(); }
    if (tab === 'ledger') loadLedger(false);
    if (tab === 'realname') loadRealName(false);
    if (tab === 'announce') loadAnnouncements(false);
    if (tab === 'settings') { loadSettings(false); loadQuickReplies(); }
    if (tab === 'audit') loadAudit(false);
  }

  // ---------- 权限校验 ----------
  async function loadMe() {
    var res = await App.api('/api/auth/me');
    if (!res.success || !res.data) {
      App.showError($('adminGate'), res.message || '权限校验失败', loadMe);
      return;
    }
    if (res.data.role !== 'admin') {
      $('adminGate').innerHTML = App.stateBox('error', '无权访问', '当前账号不是管理员，无法打开管理后台。') +
        '<div class="admin-tools" style="justify-content:center"><a class="btn btn-dark" href="/me.html">返回我的</a></div>';
      return;
    }
    $('adminGate').hidden = true;
    $('adminBody').hidden = false;
    resetLoaded();
    showTab('overview');
  }

  // ---------- 事件 ----------
  $('adminTabs').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-tab]');
    if (btn) showTab(btn.dataset.tab);
  });
  $('globalSearch').addEventListener('click', runGlobalSearch);
  $('globalQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); runGlobalSearch(); } });
  // 「用户总数 / 今日注册」等统计卡：点进去直接看用户列表
  $('statGrid').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-go]');
    if (btn) showTab(btn.dataset.go);
  });
  $('searchUsers').addEventListener('click', function () {
    query = $('userQuery').value.trim();
    offset = 0;
    searchUsers(true);
  });
  $('userQuery').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); $('searchUsers').click(); }
  });
  $('prevPage').addEventListener('click', function () { offset = Math.max(0, offset - limit); searchUsers(true); });
  $('nextPage').addEventListener('click', function () { offset = offset + limit; searchUsers(true); });
  $('userList').addEventListener('click', function (ev) {
    var user = ev.target.closest('[data-user]');
    if (user) { openUserSheet(user.dataset.user); return; }
    var btn = ev.target.closest('[data-status]');
    if (btn) changeStatus(btn.dataset.id, btn.dataset.status);
  });
  // 用户面板：禁言筛选按钮
  $('panel-users').addEventListener('click', function (ev) {
    var m = ev.target.closest('[data-mute-filter]');
    if (m) { muteFilter = m.dataset.muteFilter; offset = 0; searchUsers(true); }
  });
  // 复核面板：筛选 + 通过 / 拒绝
  $('panel-approvals').addEventListener('click', function (ev) {
    var st = ev.target.closest('[data-ap-status]');
    if (st) { apFilter = st.dataset.apStatus; loaded.approvals = false; loadApprovals(true); return; }
    var ap = ev.target.closest('[data-ap-approve]');
    if (ap) { decideApproval(ap.dataset.apApprove, 'approve'); return; }
    var rj = ev.target.closest('[data-ap-reject]');
    if (rj) decideApproval(rj.dataset.apReject, 'reject');
  });
  $('realNameList').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-review]');
    if (btn) reviewRealName(btn.dataset.id, btn.dataset.review);
  });
  $('panel-realname').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-rn-filter]');
    if (!btn) return;
    rnFilter = btn.dataset.rnFilter;
    loadRealName(true);
  });
  $('announceList').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-announce]');
    if (btn) setAnnouncementStatus(btn.dataset.id, btn.dataset.announce);
  });
  $('announceForm').addEventListener('submit', createAnnouncement);
  $('panel-audit').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-audit-action]');
    if (!btn) return;
    auditAction = btn.dataset.auditAction;
    loadAudit(true);
  });
  $('fundsList').addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-order]');
    if (btn) reviewOrder(Number(btn.dataset.id), btn.dataset.order, btn.dataset.type);
  });
  // ---------- 充值管理 / 提款管理 事件 ----------
  ['deposits', 'withdrawals'].forEach(function (kind) {
    var flag = kind === 'deposits' ? 'dep' : 'wd';
    var state = kind === 'deposits' ? depState : wdState;
    $(flag + 'Search').addEventListener('click', function () {
      state.q = $(flag + 'Query').value.trim();
      state.offset = 0;
      loadOrderList(kind, true);
    });
    $(flag + 'Query').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $(flag + 'Search').click(); }
    });
    $(flag + 'Prev').addEventListener('click', function () {
      state.offset = Math.max(0, state.offset - state.limit);
      loadOrderList(kind, true);
    });
    $(flag + 'Next').addEventListener('click', function () {
      state.offset = state.offset + state.limit;
      loadOrderList(kind, true);
    });
    $('panel-' + kind).addEventListener('click', function (ev) {
      var st = ev.target.closest('[data-' + flag + '-status]');
      if (st) {
        state.status = st.dataset[flag + 'Status'];
        state.offset = 0;
        loadOrderList(kind, true);
        return;
      }
      var v = ev.target.closest('[data-voucher]');
      if (v) { openVoucher(v.dataset.kind, v.dataset.voucher); return; }
      var a = ev.target.closest('[data-approve]');
      if (a) { reviewFundsOrder(a.dataset.kind, a.dataset.approve, 'approve'); return; }
      var r = ev.target.closest('[data-reject]');
      if (r) { reviewFundsOrder(r.dataset.kind, r.dataset.reject, 'reject'); return; }
      var s = ev.target.closest('[data-settle]');
      if (s) { $('settleOrderId').value = s.dataset.settle; settleRewards(); return; }
    });
  });
  // ---------- 推广管理 事件 ----------
  $('refSearch').addEventListener('click', function () {
    refState.q = $('refQuery').value.trim();
    refState.offset = 0;
    loadReferrals(true);
  });
  $('refQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); $('refSearch').click(); } });
  $('refPrev').addEventListener('click', function () { refState.offset = Math.max(0, refState.offset - refState.limit); loadReferrals(true); });
  $('refNext').addEventListener('click', function () { refState.offset = refState.offset + refState.limit; loadReferrals(true); });
  $('rwSearch').addEventListener('click', loadReferralRewards);
  $('settleBtn').addEventListener('click', settleRewards);
  $('panel-funds').addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-ft-type]');
    var s = ev.target.closest('[data-ft-status]');
    if (t) { fundsType = t.dataset.ftType; loadFunds(true); }
    if (s) { fundsStatus = s.dataset.ftStatus; loadFunds(true); }
  });
  $('ledgerSearch').addEventListener('click', function () { loaded.ledger = false; loadLedger(true); });
  $('ledgerUser').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); $('ledgerSearch').click(); } });
  $('adjustSubmit').addEventListener('click', submitAdjust);
  window.addEventListener('pageshow', function (event) {
    if (event.persisted && App.getToken()) loadMe();
  });
  window.addEventListener('pagehide', function () {
    resetLoaded();
    $('statGrid').innerHTML = '';
    $('userList').innerHTML = '';
    $('realNameList').innerHTML = '';
    $('announceList').innerHTML = '';
    $('auditList').innerHTML = '';
    $('fundsList').innerHTML = '';
    $('ledgerList').innerHTML = '';
    $('depList').innerHTML = '';
    $('wdList').innerHTML = '';
    $('refList').innerHTML = '';
    $('refRewards').innerHTML = '';
    $('settleStatus').textContent = '';
    $('approvalList').innerHTML = '';
    $('approvalSummary').textContent = '';
    $('muteExpiring').innerHTML = '';
  });
  // ---------- 系统设置（阶段 37 / 36） ----------
  var SETTING_GROUP_LABEL = {
    basic: '基础信息', funds: '充值 / 提款', referral: '推广比例',
    limits: '上传 / 聊天限制', system: '系统状态'
  };
  var settingDefs = null;
  var settingValues = null;
  var settingsLoaded = false;
  var settingsSaving = false;

  function settingField(def, value) {
    var id = 'set-' + def.key;
    var label = '<label for="' + esc(id) + '">' + esc(def.label) + '</label>';
    var note = def.note ? '<p class="tx-sub">' + esc(def.note) + '</p>' : '';
    if (def.type === 'boolean') {
      return '<label class="admin-check"><input type="checkbox" id="' + esc(id) + '" data-key="' + esc(def.key) + '"' +
        (value === true ? ' checked' : '') + '> ' + esc(def.label) + '</label>' + note;
    }
    var attrs;
    if (def.type === 'number') {
      attrs = ' type="number"' + (def.min === undefined ? '' : ' min="' + esc(def.min) + '"') +
        (def.max === undefined ? '' : ' max="' + esc(def.max) + '"') +
        (def.step === undefined ? '' : ' step="' + esc(def.step) + '"');
    } else {
      attrs = ' type="text" maxlength="' + esc(def.max || 200) + '"';
    }
    var shown = value === null || value === undefined ? '' : value;
    return label + '<input class="input" id="' + esc(id) + '" data-key="' + esc(def.key) + '"' + attrs +
      ' value="' + esc(shown) + '">' + note;
  }

  function renderSettingFields() {
    if (!settingDefs) return;
    var groups = [];
    settingDefs.forEach(function (d) { if (groups.indexOf(d.group) < 0) groups.push(d.group); });
    $('settingsFields').innerHTML = groups.map(function (g) {
      return '<div class="group-title">' + esc(SETTING_GROUP_LABEL[g] || g) + '</div>' +
        settingDefs.filter(function (d) { return d.group === g; }).map(function (d) {
          return settingField(d, settingValues ? settingValues[d.key] : d.default);
        }).join('');
    }).join('');
    $('settingsForm').hidden = false;
  }

  async function loadSettings(force) {
    if (settingsLoaded && !force) return;
    $('settingsForm').hidden = true;
    $('settingsBox').hidden = false;
    App.showLoading($('settingsBox'), '正在加载系统设置...');
    var res = await App.api('/api/admin/settings');
    if (!res.success || !res.data) {
      App.showError($('settingsBox'), res.message || '系统设置加载失败', function () { loadSettings(true); });
      return;
    }
    settingDefs = res.data.definitions || [];
    settingValues = res.data.values || {};
    $('settingsBox').innerHTML = '';
    $('settingsBox').hidden = true;
    renderSettingFields();
    settingsLoaded = true;
  }

  function collectSettings() {
    var values = {};
    Array.prototype.forEach.call($('settingsFields').querySelectorAll('[data-key]'), function (el) {
      values[el.dataset.key] = el.type === 'checkbox' ? !!el.checked : String(el.value).trim();
    });
    return values;
  }

  async function saveSettings(event) {
    event.preventDefault();
    if (settingsSaving || !settingDefs) return;
    settingsSaving = true;
    $('saveSettings').disabled = true;
    $('settingsStatus').textContent = '正在保存…';
    try {
      var res = await App.api('/api/admin/settings', {
        method: 'PUT',
        body: { values: collectSettings(), reason: $('settingsReason').value.trim() }
      });
      if (!res.success || !res.data) {
        $('settingsStatus').textContent = res.message || '保存失败，请重试';
        return;
      }
      settingValues = res.data.values || settingValues;
      $('settingsReason').value = '';
      renderSettingFields();
      $('settingsStatus').textContent = res.data.message || '已保存';
      App.toast('系统设置已保存', 'ok');
    } catch (_) {
      $('settingsStatus').textContent = '网络错误，请稍后重试';
    } finally {
      settingsSaving = false;
      $('saveSettings').disabled = false;
    }
  }

  $('settingsForm').addEventListener('submit', saveSettings);
  $('reloadSettings').addEventListener('click', function () { settingsLoaded = false; loadSettings(true); });

  // ---------- 客服快捷回复（阶段 34） ----------
  var qrBusy = false;

  function qrRow(r) {
    return '<div class="list-row"><div class="lr-main"><div class="lr-title">' + esc(r.content) + '</div>' +
      '<div class="tx-sub">排序 ' + esc(r.sort) + ' · ' + esc(r.status === 'active' ? '启用中' : '已下线') + '</div></div>' +
      '<div class="lr-side">' + (r.status === 'active'
        ? '<button class="btn btn-dark btn-sm" type="button" data-qr-hide="' + Number(r.id) + '">下线</button>' : '') +
      '</div></div>';
  }

  async function loadQuickReplies() {
    App.showLoading($('qrList'), '正在加载快捷回复...');
    var res = await App.api('/api/admin/support/quick-replies');
    if (!res.success || !res.data) {
      App.showError($('qrList'), res.message || '快捷回复加载失败', loadQuickReplies);
      return;
    }
    var list = res.data.list || [];
    $('qrList').innerHTML = list.length ? list.map(qrRow).join('')
      : App.stateBox('empty', '暂无快捷回复', '新增后客服可在会话中一键插入，不会自动发送。');
  }

  async function addQuickReply() {
    if (qrBusy) return;
    var content = $('qrContent').value.trim();
    if (content.length < 2) { $('qrStatus').textContent = '内容至少 2 个字符'; return; }
    qrBusy = true;
    $('addQr').disabled = true;
    $('qrStatus').textContent = '正在保存…';
    try {
      var res = await App.api('/api/admin/support/quick-replies', {
        method: 'POST', body: { content: content, sort: Number($('qrSort').value) || 0 }
      });
      if (!res.success) { $('qrStatus').textContent = res.message || '保存失败，请重试'; return; }
      $('qrContent').value = '';
      $('qrStatus').textContent = '已新增';
      loadQuickReplies();
    } catch (_) {
      $('qrStatus').textContent = '网络错误，请稍后重试';
    } finally {
      qrBusy = false;
      $('addQr').disabled = false;
    }
  }

  $('addQr').addEventListener('click', addQuickReply);
  $('qrList').addEventListener('click', async function (ev) {
    var btn = ev.target.closest('[data-qr-hide]');
    if (!btn || qrBusy) return;
    qrBusy = true;
    try {
      var res = await App.api('/api/admin/support/quick-replies/' + Number(btn.dataset.qrHide), { method: 'DELETE' });
      if (res.success) loadQuickReplies(); else App.toast(res.message || '操作失败', 'err');
    } catch (_) {
      App.toast('网络错误，请稍后重试', 'err');
    } finally { qrBusy = false; }
  });


  loadMe();
})();