// 26牛牛 - 管理后台「充值订单」面板（自包含）
// 数据源 /api/admin/recharge/*：虚拟现金筹码充值订单，不接真实支付网关
// 只展示真实订单（无数据=暂无记录）；确认/取消由后端管理员权限校验
// 页面提供 <div id="adminRechargeMount"></div> 即自动挂载
(function(){
'use strict';
var ST={PENDING:'待审核',COMPLETED:'审核通过',REJECTED:'审核拒绝',CANCELLED:'已取消',EXPIRED:'已过期'};
var FL=[{k:'PENDING',t:'待审核'},{k:'COMPLETED',t:'已完成'},{k:'REJECTED',t:'已拒绝'},{k:'CANCELLED',t:'已取消'},{k:'EXPIRED',t:'已过期'},{k:'',t:'全部'}];
var mount=null,listEl=null,cur='PENDING',kw='',busy=false;
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function fm(v){var n=Number(v);return (isFinite(n)?n:0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}
function ft(t){if(!t)return'-';var d=new Date(t);if(isNaN(d))return esc(t);function p(x){return x<10?'0'+x:''+x}
return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())}
function toast(m,t){if(window.App&&App.toast)App.toast(m,t||'info');else console.log('[recharge]',m)}
async function api(p,o){if(window.App&&App.api)return App.api(p,o);
try{var r=await fetch(p,{method:(o&&o.method)||'GET',headers:{'Content-Type':'application/json'},body:(o&&o.body!==undefined)?JSON.stringify(o.body):undefined,credentials:'same-origin'});
var j=null;try{j=await r.json()}catch(e){}return j||{success:false,message:'请求失败('+r.status+')'}}catch(e){return{success:false,message:'网络错误'}}}
function tag(s){var t=ST[s]||s||'-',c=s==='COMPLETED'?'#16a34a':s==='PENDING'?'#d97706':s==='REJECTED'?'#ef4444':'#9ca3af';
return '<span style="padding:1px 8px;border-radius:10px;font-size:12px;background:'+c+'22;color:'+c+'">'+esc(t)+'</span>'}
function row(o){var id=(o.id!=null)?o.id:(o.order_id||o.order_no||'');var pd=o.status==='PENDING';
 var a=o.receiving_account||null;
 var acc=a?('<div style="font-size:12px;opacity:.8;margin-top:3px">收款账户：'+esc(a.type_text||a.type||'')+' · '+esc(a.name)+' · 户名 '+esc(a.holder)+' · 账号 '+esc(a.account_no)+'</div>'+
   (a.id?'<div style="font-size:11px;opacity:.6">账户ID #'+esc(a.id)+'（订单创建时固定，停用后历史不变）</div>':'')):'<div style="font-size:12px;opacity:.8;margin-top:3px">收款账户：未分配</div>';
 var pref=o.payment_reference?('<div style="font-size:12px;opacity:.75;margin-top:3px">付款参考编号：'+esc(o.payment_reference)+'</div>'):'';
 var rj=o.reject_reason?('<div style="font-size:12px;color:#f87171;margin-top:3px">拒绝原因：'+esc(o.reject_reason)+'</div>'):'';
 var nr=o.admin_remark?('<div style="font-size:12px;opacity:.75;margin-top:3px">审核备注：'+esc(o.admin_remark)+'</div>'):'';
 return '<div style="border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px 12px;margin-bottom:8px"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">'+
 '<div style="min-width:0;flex:1"><div style="font-weight:600;word-break:break-all">订单 '+esc(o.order_no||o.order_id||('#'+id))+' '+tag(o.status)+'</div>'+
 '<div style="font-size:12px;opacity:.75;margin-top:3px">用户 #'+esc(o.user_id)+(o.username?'（'+esc(o.username)+'）':'')+' · '+fm(o.amount)+' 现金筹码 · 创建 '+ft(o.created_at)+(o.submitted_at?' · 提交 '+ft(o.submitted_at):'')+(o.completed_at?' · 审核 '+ft(o.completed_at):'')+(o.operator_id?' · 操作人 #'+esc(o.operator_id):'')+'</div>'+
 acc+pref+rj+nr+'</div>'+
(o.has_receipt?'<button type="button" class="btn btn-dark btn-sm" data-receipt="'+esc(o.receipt_url||'')+'">查看凭证</button> ':'')+
    (pd?'<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" data-act="confirm" data-id="'+esc(id)+'" style="padding:6px 12px;border-radius:8px;font-size:13px;cursor:pointer;background:#d4af37;border:none;color:#1a1408;font-weight:600">审核通过</button>'+
'<button type="button" data-act="reject" data-id="'+esc(id)+'" style="padding:6px 12px;border-radius:8px;font-size:13px;cursor:pointer;background:none;border:1px solid rgba(239,68,68,.6);color:#ef4444">拒绝</button>'+
'<button type="button" data-act="cancel" data-id="'+esc(id)+'" style="padding:6px 12px;border-radius:8px;font-size:13px;cursor:pointer;background:none;border:1px solid rgba(255,255,255,.25);color:inherit">取消订单</button></div>':'')+
'</div></div>'}
async function load(){if(!listEl||busy)return;busy=true;listEl.innerHTML='<div style="opacity:.7;padding:14px">加载中…</div>';
var q=(cur?'status='+encodeURIComponent(cur)+'&':'status=')+(kw?'q='+encodeURIComponent(kw)+'&':'')+'limit=50';
var r=await api('/api/admin/recharge?'+q);busy=false;
if(!r.success){listEl.innerHTML='<div style="color:#f87171;padding:14px">'+esc(r.message||'充值订单加载失败')+'</div>';return}
var d=r.data||{};var list=d.list||d.orders||d.rows||(Array.isArray(d)?d:[]);
listEl.innerHTML=list.length?list.map(row).join(''):'<div style="opacity:.7;padding:14px">暂无记录</div>'}
async function act(id,a,b){var lb=a==='confirm'?'审核通过':(a==='reject'?'拒绝订单':'取消订单');var body={};
if(a==='reject'){var rs=window.prompt('请输入拒绝原因（必填）','');if(rs===null)return;rs=String(rs).trim();
if(!rs){toast('拒绝必须填写原因','err');return}
var rk=window.prompt('可填写审核备注（可选）','');if(rk===null)return;rk=String(rk).trim().slice(0,255);
body={reason:rs,admin_remark:rk}}
else if(a==='confirm'){var nk=window.prompt('可填写审核备注（可选）','');if(nk===null)return;
body={admin_remark:String(nk).trim().slice(0,255)}}
else{var go=true;
if(window.App&&App.confirmDialog)go=await App.confirmDialog({title:lb,text:'订单 '+id+'：'+lb+'后立即生效，且不可撤销。确定继续？',okText:lb,danger:true});
else go=window.confirm('确认对订单 '+id+' 执行「'+lb+'」？不可撤销');
if(!go)return}
if(b){b.disabled=true;b.style.opacity=.6}
var r=await api('/api/admin/recharge/'+encodeURIComponent(id)+'/'+(a==='confirm'?'complete':(a==='reject'?'reject':'cancel')),{method:'POST',body:body});
if(!r.success){toast(r.message||'操作失败','err');if(b){b.disabled=false;b.style.opacity=1}return}
toast(lb+'成功','ok');load()}
function paintFilters(){var bar=mount.querySelector('.arp-f');bar.innerHTML=FL.map(function(f){var on=cur===f.k;
return '<button type="button" data-f="'+f.k+'" style="padding:6px 14px;border-radius:16px;font-size:13px;cursor:pointer;border:1px solid '+(on?'#d4af37':'rgba(255,255,255,.2)')+';background:'+(on?'rgba(212,175,55,.15)':'transparent')+';color:'+(on?'#d4af37':'inherit')+'">'+esc(f.t)+'</button>'}).join('')}
function mountPanel(el){mount=el;el.innerHTML='<div style="display:flex;gap:8px;margin-bottom:10px"><input class="input" id="arpQ" type="search" maxlength="64" placeholder="订单号 / 付款参考编号 / 用户名" style="flex:1"><button type="button" class="btn btn-dark" id="arpSearch">查询</button></div><div class="arp-f" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"></div><div class="arp-l"></div>';
listEl=el.querySelector('.arp-l');paintFilters();
el.querySelector('#arpSearch').addEventListener('click',function(){kw=String(el.querySelector('#arpQ').value||'').trim();load()});
el.querySelector('#arpQ').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();el.querySelector('#arpSearch').click()}});
el.querySelector('.arp-f').addEventListener('click',function(e){var b=e.target.closest('[data-f]');if(!b)return;cur=b.getAttribute('data-f');paintFilters();load()});
  listEl.addEventListener('click', async function (e) {
    var receiptBtn = e.target.closest('[data-receipt]');
    if (receiptBtn) {
      if (receiptBtn.disabled) return;
      receiptBtn.disabled = true;
      try {
        var token = window.App && App.getToken ? App.getToken() : '';
        var res = await fetch(receiptBtn.dataset.receipt, { headers: { Authorization: 'Bearer ' + token } });
        if (!res.ok) throw new Error('凭证读取失败');
        var url = URL.createObjectURL(await res.blob());
        window.open(url, '_blank', 'noopener');
      } catch (err) {
        toast((err && err.message) || '凭证读取失败', 'err');
      }
      receiptBtn.disabled = false;
      return;
    }
    var b = e.target.closest('[data-act]');
    if (!b || b.disabled) return;
    act(b.getAttribute('data-id'), b.getAttribute('data-act'), b);
  });
load()}
function ready(fn){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',fn):fn()}
ready(function(){var el=document.getElementById('adminRechargeMount');if(el&&!el.dataset.arp){el.dataset.arp='1';mountPanel(el)}});
window.AdminRechargePanel={mount:mountPanel,refresh:load};
})();
