// ============================================
// 26牛牛 - 充值页（现金筹码充值订单）
// 流程: 充值数量 → 订单确认 → 上传凭证 → 提交订单 → 等待审核 → 审核结果
// ============================================
(function () {
  'use strict';
  if (!App.requireLogin()) return;
  App.mountNetBanner();

  var $ = function (id) { return document.getElementById(id); };
  var esc = App.escapeHtml;
  var submitting = false;
  var voucherFile = null;
  var STATUS_CLS = { PENDING: 'pending', COMPLETED: 'ok', REJECTED: 'fail', CANCELLED: '', EXPIRED: 'fail' };
  var STATUS_TEXT = { PENDING: '待审核', COMPLETED: '审核通过', REJECTED: '审核拒绝', CANCELLED: '已取消', EXPIRED: '已过期' };

  function hint(text, cls) {
    var el = $('amountHint');
    el.textContent = text || '';
    el.className = 'field-hint' + (cls ? ' ' + cls : '');
  }

  function parseChips(raw) {
    var s = String(raw === null || raw === undefined ? '' : raw).trim();
    if (!s || !/^\d{1,7}(\.\d{1,2})?$/.test(s)) return null;
    var n = Number(s);
    if (!Number.isFinite(n) || n < 30 || n > 50000) return null;
    return n;
  }

  function validate() {
    var n = parseChips($('amount').value);
    if (n === null) { hint('请输入合法充值金额（30-50000，最多2位小数）', 'err'); return null; }
    hint('充值数量：' + n.toLocaleString('en-US') + ' 现金筹码', 'ok');
    return n;
  }

  function renderQuick() {
    var quick = [30, 100, 500, 1000, 2000, 3000, 5000];
    $('quickGrid').innerHTML = quick.map(function (v) {
      return '<button class="amount-chip" type="button" data-amt="' + v + '">' + v.toLocaleString('en-US') + '</button>';
    }).join('');
  }

  async function loadOrders() {
    var box = $('orderList');
    var res = await App.api('/api/recharge/orders?limit=10');
    if (!res.success) { App.showError(box, res.message || '充值记录加载失败', loadOrders); return; }
    var list = (res.data && res.data.list) || [];
    if (!list.length) { box.innerHTML = App.stateBox('empty', '暂无充值订单', '输入数量后点击「提交充值订单」'); return; }
    box.innerHTML = list.map(function (o) {
      var cls = STATUS_CLS[o.status] || 'pending';
      return '<a class="list-row" href="/recharge-detail.html?id=' + Number(o.id) + '" style="text-decoration:none;color:inherit;">' +
        '<div class="lr-main"><div class="lr-title">' + Number(o.amount).toLocaleString('en-US') + ' 现金筹码' +
        ' <span class="order-tag ' + cls + '">' + esc(STATUS_TEXT[o.status] || o.status_text || o.status) + '</span></div>' +
        '<div class="tx-sub">' + esc(o.order_id) + ' · ' + esc(App.fmtDateTime(o.created_at)) + '</div></div>' +
        '<span class="ic i-next"></span></a>';
    }).join('');
  }

  $('quickGrid').addEventListener('click', function (e) {
    var b = e.target.closest('[data-amt]');
    if (!b) return;
    document.querySelectorAll('#quickGrid .amount-chip').forEach(function (x) { x.classList.remove('active'); });
    b.classList.add('active');
    $('amount').value = b.dataset.amt;
    validate();
  });

  $('amount').addEventListener('input', function () {
    var v = $('amount').value;
    document.querySelectorAll('#quickGrid .amount-chip').forEach(function (x) {
      x.classList.toggle('active', Number(x.dataset.amt) === parseChips(v));
    });
    validate();
  });

  // ---------- 凭证：选择 / 预览 / 重新选择 / 删除 ----------
  function paintVoucher() {
    var box = $('voucherPreview');
    var hintEl = $('voucherHint');
    if (!voucherFile) { box.innerHTML = ''; hintEl.textContent = ''; return; }
    var url = URL.createObjectURL(voucherFile);
    box.innerHTML = '<img src="' + esc(url) + '" alt="充值凭证预览" style="max-width:100%;border-radius:8px;" loading="lazy">';
    hintEl.textContent = '已选择：' + voucherFile.name + '（' + Math.round(voucherFile.size / 1024) + 'KB）';
  }
  $('voucher').addEventListener('change', function () {
    var f = this.files && this.files[0];
    if (!f) return;
    if (!/image\/(jpeg|png|webp)/.test(f.type)) { $('voucherHint').textContent = '仅支持 JPG / JPEG / PNG / WEBP'; this.value = ''; return; }
    if (f.size > 5 * 1024 * 1024) { $('voucherHint').textContent = '文件过大，最大 5MB'; this.value = ''; return; }
    voucherFile = f;
    paintVoucher();
  });
  $('voucherReselect').addEventListener('click', function () { $('voucher').click(); });
  $('voucherRemove').addEventListener('click', function () { voucherFile = null; $('voucher').value = ''; paintVoucher(); });

  $('submitBtn').addEventListener('click', async function () {
    if (submitting) return;
    var btn = this;
    var status = $('formStatus');
    var amount = validate();
    if (amount === null) { status.textContent = ''; return; }
    if (!voucherFile) { status.textContent = '请先上传充值凭证'; $('voucherHint').textContent = '请先上传充值凭证'; return; }

    var okGo = await App.confirmDialog({ title: '订单确认', text: '充值 ' + amount + ' 现金筹码？提交后进入待审核。', okText: '确认提交' });
    if (!okGo) return;

    submitting = true; btn.disabled = true; status.textContent = '正在创建充值订单…';
    try {
      var res = await App.api('/api/recharge/orders', {
        method: 'POST',
        body: { amount: String(amount) }
      });
      if (!res.success) { status.textContent = res.message || '充值订单创建失败，请重试'; return; }
      var orderId = Number(res.data.order.id);
      status.textContent = '订单已创建，正在上传凭证…';
      var form = new FormData();
      form.append('receipt', voucherFile);
      var up = await fetch('/api/recharge/orders/' + orderId + '/receipt', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + App.getToken() },
        body: form
      });
      var uj = null;
      try { uj = await up.json(); } catch (e) {}
      if (!up.ok || !uj || uj.success === false) {
        status.textContent = (uj && uj.message) || '凭证上传失败，订单已创建，请在详情页重新上传';
        window.location.href = '/recharge-detail.html?id=' + orderId;
        return;
      }
      status.textContent = '提交成功，等待审核…';
      window.location.href = '/recharge-detail.html?id=' + orderId;
    } finally {
      submitting = false; btn.disabled = false;
    }
  });

  renderQuick();
  loadOrders();
})();
