// ============================================
// 26牛牛 - 选择头像（官方头像库）
// 用户只能挑选后台发布的启用头像；保存时只提交 avatar_id，后端二次校验
// ============================================
(function () {
  'use strict';

  var DEFAULT_AVATAR = '/assets/avatars/official.jpg';
  var cats = [];
  var activeCat = 0;      // 0 = 全部
  var selectedId = 0;     // 当前已选（未保存）
  var currentId = 0;      // 当前已生效

  function $(id) { return document.getElementById(id); }
  function esc(s) { return App.escapeHtml(s); }

  function stateHtml(type, title, sub) {
    return App.stateBox(type, title, sub);
  }

  function renderCats() {
    var box = $('avCats');
    if (!box) return;
    var html = '<button class="av-cat' + (activeCat === 0 ? ' active' : '') + '" type="button" data-cat="0">全部</button>';
    cats.forEach(function (c) {
      html += '<button class="av-cat' + (activeCat === c.id ? ' active' : '') +
        '" type="button" data-cat="' + c.id + '">' + esc(c.name) + '</button>';
    });
    box.innerHTML = html;
  }

  function renderGrid(list) {
    var grid = $('avGrid');
    if (!grid) return;
    if (!list.length) {
      grid.innerHTML = '';
      $('avState').innerHTML = stateHtml('empty', '暂无可用头像', '管理员还没有发布头像，请稍后再试。');
      return;
    }
    $('avState').innerHTML = '';
    grid.innerHTML = list.map(function (a) {
      var url = esc(a.image_path);
      var on = (a.id === selectedId) ? ' active' : '';
      return '<button class="av-item' + on + '" type="button" data-id="' + a.id + '">' +
        '<img src="' + url + '" alt="' + esc(a.name) + '" loading="lazy">' +
        '<span class="av-item-name">' + esc(a.name) + '</span>' +
        '<span class="av-check">✓</span></button>';
    }).join('');
  }

  function syncSaveBtn() {
    var btn = $('avSave');
    if (!btn) return;
    btn.disabled = !(selectedId > 0 && selectedId !== currentId);
  }

  async function loadCats() {
    var res = await App.api('/api/avatars/categories');
    cats = (res.success && res.data && res.data.categories) ? res.data.categories : [];
    renderCats();
  }

  async function loadAvatars() {
    var grid = $('avGrid');
    App.showLoading(grid, '正在加载头像...');
    var url = '/api/avatars' + (activeCat ? ('?category_id=' + activeCat) : '');
    var res = await App.api(url);
    if (!res.success || !res.data) {
      App.showError(grid, res.message || '头像加载失败', loadAvatars);
      return;
    }
    var list = res.data.avatars || [];
    if (currentId) {
      var cur = list.filter(function (a) { return a.id === currentId; });
      // 当前头像可能在别的分类，这里只影响高亮，不影响保存
      if (cur.length) selectedId = selectedId || currentId;
    }
    renderGrid(list);
    syncSaveBtn();
  }

  async function loadCurrent() {
    var res = await App.api('/api/avatars/mine');
    if (res.success && res.data) {
      currentId = res.data.avatar_id || 0;
      selectedId = currentId;
      var wrap = $('avCurrent');
      var img = $('avCurrentImg');
      if (img) img.src = res.data.avatar_url || DEFAULT_AVATAR;
      if ($('avCurrentName')) {
        $('avCurrentName').textContent = res.data.avatar_source === 'library'
          ? (res.data.avatar_name || '官方头像')
          : '官方默认头像';
      }
      if (wrap) wrap.hidden = false;
    }
    syncSaveBtn();
  }

  async function save() {
    if (!(selectedId > 0)) { App.toast('请先选择一个头像', 'err'); return; }
    var btn = $('avSave');
    btn.disabled = true;
    var res = await App.api('/api/avatars/select', { method: 'POST', body: { avatar_id: selectedId } });
    if (!res.success) {
      App.toast(res.message || '更换头像失败', 'err');
      syncSaveBtn();
      return;
    }
    App.toast('已保存', 'ok');
    setTimeout(function () { window.location.replace('/me.html'); }, 600);
  }

  function bind() {
    var catsBox = $('avCats');
    if (catsBox) {
      catsBox.addEventListener('click', function (ev) {
        var el = ev.target.closest ? ev.target.closest('.av-cat') : null;
        if (!el) return;
        activeCat = parseInt(el.dataset.cat, 10) || 0;
        renderCats();
        loadAvatars();
      });
    }
    var grid = $('avGrid');
    if (grid) {
      grid.addEventListener('click', function (ev) {
        var el = ev.target.closest ? ev.target.closest('.av-item') : null;
        if (!el) return;
        selectedId = parseInt(el.dataset.id, 10) || 0;
        Array.prototype.forEach.call(grid.querySelectorAll('.av-item'), function (b) {
          b.classList.toggle('active', parseInt(b.dataset.id, 10) === selectedId);
        });
        syncSaveBtn();
      });
    }
    var save_btn = $('avSave');
    if (save_btn) save_btn.addEventListener('click', save);
  }

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(function () {
    if (!App.requireLogin()) return;
    var holder = $('pageHeader');
    if (holder) holder.innerHTML = App.headerHtml({ title: '选择头像', back: '/me.html' });
    bind();
    loadCurrent();
    loadCats();
    loadAvatars();
  });
})();
