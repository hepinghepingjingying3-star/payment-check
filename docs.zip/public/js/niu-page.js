// ============================================
// 26牛牛 - 26牛牛娱乐场前端页面
// ============================================
// 原则:
//   1. 页面只负责展示与提交「意图」（进入 / 抢庄 / 倍数 / 离开），
//      所有阶段推进、发牌、牌型、结算都由服务端完成（前端提交的状态一律不被信任）
//   2. 手牌只通过个人通道（niu:private / niu:state_full）下发，永不从他人数据推断
//   3. Socket 断开时自动降级为 REST 轮询（/api/game/niu/state），保证弱网可玩
//   4. 积分只来自每日免费发放与管理员发放：本页没有任何充值 / 提现入口
// ============================================
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var esc = App.escapeHtml;

  // ---------- 多语言（中文简体 / Bahasa Melayu / English，默认中文简体） ----------
  var I18N = {
    'zh-CN': {
      title: '26牛牛娱乐场', rooms: '选择场次', join: '进入', full: '已满', playing: '对局中',
      online: '在线', base: '底分', need: '需要', points: '游戏积分', leave: '离开',
      grab: '抢庄', noGrab: '不抢', grabWait: '等待抢庄选择…', bet: '选择倍数',
      waiting: '等待开局', settle: '结算中', dealing: '发牌中', result: '比牌结果',
      banker: '庄家', me: '我', balance: '积分', hand: '牌型', delta: '本局变化',
      stats: '我的战绩', rounds: '总对局', wins: '胜局', winRate: '胜率', net: '累计净积分',
      board: '积分排行榜', records: '对局记录', empty: '暂无数据', noRecords: '暂无对局记录',
      free: '领取每日积分', sound: '音效', rules: '玩法说明', prev: '上一页', next: '下一页',
      capped: '积分不足，按可结算上限结算', waitPlayers: '等待更多玩家加入', offline: '网络已断开，正在使用轮询同步'
    },
    ms: {
      title: 'Kasino 26 Niu Niu', rooms: 'Pilih meja', join: 'Masuk', full: 'Penuh', playing: 'Sedang bermain',
      online: 'Dalam talian', base: 'Kadar asas', need: 'Perlu', points: 'Mata permainan', leave: 'Keluar',
      grab: 'Rebut bank', noGrab: 'Tidak', grabWait: 'Menunggu pilihan…', bet: 'Pilih ganda',
      waiting: 'Menunggu', settle: 'Penyelesaian', dealing: 'Membahagi kad', result: 'Keputusan',
      banker: 'Bank', me: 'Saya', balance: 'Mata', hand: 'Jenis', delta: 'Perubahan',
      stats: 'Statistik saya', rounds: 'Pusingan', wins: 'Menang', winRate: 'Kadar menang', net: 'Mata bersih',
      board: 'Papan pendahulu', records: 'Rekod pusingan', empty: 'Tiada data', noRecords: 'Tiada rekod',
      free: 'Mata harian', sound: 'Bunyi', rules: 'Peraturan', prev: 'Sebelum', next: 'Seterusnya',
      capped: 'Mata tidak cukup, diselesaikan pada had', waitPlayers: 'Menunggu pemain lain', offline: 'Sambungan terputus, menggunakan tinjauan berkala'
    },
    en: {
      title: '26 Niu Niu Arena', rooms: 'Choose a table', join: 'Enter', full: 'Full', playing: 'In game',
      online: 'online', base: 'Base', need: 'Need', points: 'Game points', leave: 'Leave',
      grab: 'Grab banker', noGrab: 'Pass', grabWait: 'Waiting for choices…', bet: 'Choose multiplier',
      waiting: 'Waiting', settle: 'Settling', dealing: 'Dealing', result: 'Result',
      banker: 'Banker', me: 'Me', balance: 'Points', hand: 'Hand', delta: 'Change',
      stats: 'My record', rounds: 'Rounds', wins: 'Wins', winRate: 'Win rate', net: 'Net points',
      board: 'Leaderboard', records: 'Round history', empty: 'No data', noRecords: 'No rounds yet',
      free: 'Daily points', sound: 'Sound', rules: 'Rules', prev: 'Prev', next: 'Next',
      capped: 'Not enough points, settled at cap', waitPlayers: 'Waiting for more players', offline: 'Disconnected, polling instead'
    }
  };

  function lang() {
    var v = localStorage.getItem('nn_lang');
    return I18N[v] ? v : 'zh-CN';
  }
  function t(key) {
    var pack = I18N[lang()] || I18N['zh-CN'];
    return pack[key] || I18N['zh-CN'][key] || key;
  }

  // ---------- 音效（WebAudio 合成，无外部音频文件，可随时关闭）----------
  var soundOn = localStorage.getItem('nn_niu_sound') !== '0';
  var audioCtx = null;
  function beep(kind) {
    if (!soundOn) return;
    try {
      if (!audioCtx) {
        var Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        audioCtx = new Ctx();
      }
      var map = {
        start: [520, 0.10], grab: [700, 0.12], deal: [420, 0.06],
        action: [600, 0.07], result: [880, 0.14], settle: [980, 0.18]
      };
      var cfg = map[kind] || map.action;
      var osc = audioCtx.createOscillator();
      var gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = cfg[0];
      gain.gain.value = 0.05;
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      var now = audioCtx.currentTime;
      osc.start(now);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + cfg[1]);
      osc.stop(now + cfg[1] + 0.02);
    } catch (e) { /* 浏览器策略限制静默失败，不影响玩法 */ }
  }

  function paintSound() {
    var btn = $('ngSound');
    if (btn) btn.textContent = t('sound') + '：' + (soundOn ? '开' : '关');
  }

  // ---------- 页面状态 ----------
  var state = {
    cfg: null,
    rooms: [],
    joined: null,       // 已在的场次 key
    snap: null,         // 最近的个人视角快照
    lastPhase: null,
    endsAt: 0,
    serverSkew: 0,
    revealed: null,     // 亮牌列表（揭晓后）
    settled: null,      // 结算明细
    notices: [],
    page: 1,
    pageSize: 20,
    total: 0,
    busy: false,
    pollTimer: null,
    socketOn: false
  };

  function pointsText(v) { return App.fmtMoney(v); }

  function setPoints(v) {
    var el = $('ngPoints');
    if (el) el.textContent = pointsText(v);
  }

  function gate(html) {
    var el = $('ngGate');
    if (el) el.innerHTML = html || '';
  }


  // ---------- 头像映射（只使用官方头像库，不接受任何自定义链接） ----------
  var avatarMap = {};
  var DEFAULT_AVATAR = '/assets/avatars/official.jpg';

  async function loadAvatarMap() {
    var res = await App.api('/api/avatars');
    if (res.success && res.data && Array.isArray(res.data.avatars)) {
      res.data.avatars.forEach(function (a) { avatarMap[String(a.id)] = a.image_path; });
    }
  }

  function avatarUrl(id) {
    var p = id ? avatarMap[String(id)] : null;
    if (!p) return DEFAULT_AVATAR;
    return p.charAt(0) === '/' ? p : '/' + p;
  }

  // ---------- 场次列表 ----------
  function renderRooms() {
    var box = $('ngRooms');
    if (!box) return;
    if (!state.rooms.length) {
      box.innerHTML = App.stateBox('empty', t('empty'), '');
      return;
    }
    box.innerHTML = state.rooms.map(function (r) {
      var full = r.online >= r.seat_limit;
      var tag = !state.cfg.enabled ? '<span class="ng-room-tag off">维护中</span>'
        : (r.playing ? '<span class="ng-room-tag">' + esc(t('playing')) + '</span>'
          : (full ? '<span class="ng-room-tag off">' + esc(t('full')) + '</span>' : ''));
      var btn = '<button class="btn btn-gold btn-sm" type="button" data-enter="' + esc(r.key) + '"' +
        (full && !r.seated ? ' disabled' : '') + '>' + esc(r.seated ? '回到房间' : t('join')) + '</button>';
      return '<div class="ng-room">' +
        '<div class="ng-room-main">' +
        '<div class="ng-room-t">' + esc(r.name) + tag + '</div>' +
        '<div class="ng-room-s">' + esc(t('base')) + ' ' + esc(r.base_stake) + ' · ' +
        esc(t('online')) + ' ' + esc(r.online) + '/' + esc(r.seat_limit) +
        (r.min_points > 0 ? ' · ' + esc(t('need')) + ' ' + esc(r.min_points) + ' ' + esc(t('points')) : '') +
        '</div>' +
        '<div class="ng-room-s">' + esc(r.desc || '') + '</div>' +
        '</div>' + btn + '</div>';
    }).join('');
  }

  async function loadRooms() {
    var res = await App.api('/api/game/niu/rooms');
    if (!res.success || !res.data) {
      var box = $('ngRooms');
      if (box) App.showError(box, res.message || '场次加载失败', loadRooms);
      return;
    }
    state.rooms = res.data.rooms || [];
    state.cfg = state.cfg || {};
    state.cfg.enabled = res.data.enabled;
    if (res.data.asset) state.cfg.asset = res.data.asset;
    renderRooms();
  }

  // ---------- 进入 / 离开 ----------
  async function enterRoom(key) {
    if (state.busy) return;
    state.busy = true;
    try {
      var res = await App.api('/api/game/niu/join', { method: 'POST', body: { room: key } });
      if (!res.success) { App.toast(res.message || '进入失败', 'err'); return; }
      state.joined = key;
      applySnapshot(res.data);
      $('ngRoomSec').hidden = false;
      gate('');
      subscribeRoom(key);
      refreshStats();
      var sec = $('ngRoomSec');
      if (sec && sec.scrollIntoView) sec.scrollIntoView({ block: 'start' });
    } finally {
      state.busy = false;
    }
  }

  async function leaveRoom() {
    if (!state.joined || state.busy) return;
    var yes = await App.confirmDialog({
      title: t('leave'), text: '确定离开当前场次？对局进行中离开会让本局作废（不结算任何积分）。',
      okText: t('leave'), danger: true
    });
    if (!yes) return;
    state.busy = true;
    try {
      var key = state.joined;
      var res = await App.api('/api/game/niu/leave', { method: 'POST', body: { room: key } });
      if (!res.success) { App.toast(res.message || '离开失败', 'err'); return; }
      App.socketEmit('niu:unsubscribe', key);
      state.joined = null;
      state.snap = null;
      state.revealed = null;
      state.settled = null;
      state.notices = [];
      $('ngRoomSec').hidden = true;
      App.toast(res.message || '已离开', 'ok');
      loadRooms();
      refreshStats();
    } finally {
      state.busy = false;
    }
  }

  // ---------- 房间渲染 ----------
  function cardFace(card, back) {
    if (back) return '<div class="ng-cardface back">★</div>';
    if (!card) return '';
    var red = card.suit_code === 'H' || card.suit_code === 'D';
    return '<div class="ng-cardface' + (red ? ' red' : '') + '">' +
      '<span>' + esc(card.rank_label) + '</span><span>' + esc(card.suit_label.slice(0, 1)) + '</span></div>';
  }

  function phaseText(phase) {
    var map = {
      WAITING: t('waiting'), GRABBING: t('grab'), BETTING: t('bet'),
      DEALING: t('dealing'), RESULT: t('result'), SETTLEMENT: t('settle'), FINISHED: t('settle')
    };
    return map[phase] || t('waiting');
  }

  function phaseSeconds(phase) {
    var T = (state.cfg && state.cfg.timers) || {};
    var map = {
      WAITING: T.WAITING, GRABBING: T.GRABBING, BETTING: T.BETTING,
      DEALING: T.DEALING, RESULT: T.RESULT, SETTLEMENT: T.SETTLEMENT, FINISHED: T.FINISHED
    };
    return Number(map[phase]) || 8;
  }

  function renderSeats() {
    var box = $('ngSeats');
    var snap = state.snap;
    if (!box || !snap) return;
    var revealMap = {};
    (state.revealed || []).forEach(function (x) { revealMap[String(x.user_id)] = x; });
    var deltaMap = {};
    (state.settled || []).forEach(function (x) { deltaMap[String(x.user_id)] = x; });
    var meId = String((App.getUser() || {}).id || '');

    box.innerHTML = snap.players.map(function (p) {
      var uid = String(p.user_id);
      var rev = revealMap[uid];
      var dl = deltaMap[uid];
      var isMe = uid === meId;
      var open = ['RESULT', 'SETTLEMENT', 'FINISHED'].indexOf(snap.phase) !== -1;
      var cards = '';
      if (isMe && snap.my && snap.my.cards) {
        cards = snap.my.cards.map(function (c) { return cardFace(c, false); }).join('');
      } else if (rev && rev.cards) {
        cards = rev.cards.map(function (c) { return cardFace(c, false); }).join('  ');
      } else if (!open && snap.phase !== 'WAITING') {
        cards = new Array(5).fill(0).map(function () { return cardFace(null, true); }).join('');
      }
      var hand = (isMe && snap.my && snap.my.hand_name) || (rev && rev.hand_name) || '';
      var pts = (isMe && snap.my && typeof snap.my.points === 'number') ? snap.my.points : p.points;
      var flags = '<span class="k' + (p.grab ? ' hot' : '') + '">' + esc(t('grab')) + ':' + (p.grab ? '✓' : '—') + '</span>' +
        '<span class="k' + (p.bet_level > 1 ? ' hot' : '') + '">x' + esc(p.bet_level) + '</span>' +
        (p.online ? '' : '<span class="k">离线</span>');
      return '<div class="ng-seat' + (p.role === 'BANKER' ? ' banker' : '') + (isMe ? ' me' : '') +
        (p.online ? '' : ' offline') + '">' +
        '<div class="ng-seat-top">' +
        '<img class="ng-seat-av" alt="" src="' + esc(avatarUrl(p.avatar_id)) + '">' +
        '<div style="min-width:0">' +
        '<div class="ng-seat-name">' + esc(p.nickname) + (isMe ? '（' + esc(t('me')) + '）' : '') +
        (p.role === 'BANKER' ? ' · ' + esc(t('banker')) : '') + '</div>' +
        '<div class="ng-seat-pts">' + esc(t('balance')) + ' ' + esc(pointsText(pts)) + '</div>' +
        '</div></div>' +
        '<div class="ng-cards">' + cards + '</div>' +
        (hand ? '<div class="ng-hand-tag">' + esc(t('hand')) + '：' + esc(hand) +
          (p.point_value ? '（' + esc(p.point_value) + '）' : '') + '</div>' : '') +
        (dl ? '<div class="ng-delta ' + (dl.delta >= 0 ? 'up' : 'down') + '">' + esc(t('delta')) + ' ' +
          (dl.delta >= 0 ? '+' : '') + esc(App.fmtMoney(dl.delta)) + '</div>' : '') +
        '<div class="ng-seat-flags">' + flags + '</div>' +
        '</div>';
    }).join('');
  }

  function renderPhase() {
    var snap = state.snap;
    if (!snap) return;
    var total = phaseSeconds(snap.phase);
    var left = Math.max(0, Math.round((state.endsAt - (Date.now() + state.serverSkew)) / 1000));
    var el = $('ngPhaseText');
    if (el) el.textContent = phaseText(snap.phase);
    var le = $('ngPhaseLeft');
    if (le) le.textContent = snap.phase === 'WAITING' ? (left + 's · ' + t('waitPlayers')) : (left + 's');
    var bar = $('ngPhaseBar');
    if (bar) bar.style.width = Math.min(100, Math.max(0, Math.round((left / total) * 100))) + '%';
  }

  function renderActions() {
    var box = $('ngActions');
    var snap = state.snap;
    if (!box || !snap || !snap.my) return;
    var html = '';
    var meId = String((App.getUser() || {}).id || '');
    if (snap.phase === 'WAITING') {
      html = '<span class="ng-note">' + esc(t('waitPlayers')) + '</span>';
    } else if (snap.phase === 'GRABBING') {
      var done = !!snap.my.grab_locked;
      html = '<button class="btn btn-gold" type="button" data-act="grab" data-value="1"' + (done ? ' disabled' : '') + '>' + esc(t('grab')) + '</button>' +
        '<button class="btn btn-dark" type="button" data-act="grab" data-value="0"' + (done ? ' disabled' : '') + '>' + esc(t('noGrab')) + '</button>' +
        (done ? '<span class="ng-note">' + esc(t('grabWait')) + '</span>' : '');
    } else if (snap.phase === 'BETTING') {
      if (String(snap.banker_id || '') === meId) {
        html = '<span class="ng-note">' + esc(t('banker')) + ' · ' + esc(t('grabWait')) + '</span>';
      } else {
        html = (snap.bet_levels || []).map(function (b) {
          return '<button class="btn ' + (snap.my.bet_level === b.level ? 'btn-gold' : 'btn-dark') +
            '" type="button" data-act="bet" data-value="' + esc(b.level) + '">' + esc(b.label) + '</button>';
        }).join('');
      }
    } else {
      html = '<span class="ng-note">' + esc(phaseText(snap.phase)) + '…</span>';
    }
    box.innerHTML = html;
  }

  function renderNotices() {
    var box = $('ngNotices');
    if (!box) return;
    box.innerHTML = state.notices.length
      ? state.notices.slice(-30).map(function (n) { return '<div class="ng-notice">' + esc(n.text) + '</div>'; }).join('')
      : '<div class="ng-note">' + esc(t('empty')) + '</div>';
    box.scrollTop = box.scrollHeight;
  }

  function renderResult() {
    var box = $('ngResult');
    if (!box) return;
    var snap = state.snap;
    var show = state.settled && snap && (snap.phase === 'SETTLEMENT' || snap.phase === 'FINISHED');
    var meId = String((App.getUser() || {}).id || '');
    var mine = null;
    (state.settled || []).forEach(function (x) {
      if (String(x.user_id) === meId) mine = x;
    });
    if (!show || !mine) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    box.innerHTML = '<div class="ng-card">' +
      '<div class="ng-row"><span>' + esc(t('hand')) + '</span><b>' + esc(mine.hand_key || '--') + '</b></div>' +
      '<div class="ng-row"><span>' + esc(t('delta')) + '</span><b>' +
      (mine.delta >= 0 ? '+' : '') + esc(App.fmtMoney(mine.delta)) + '</b></div>' +
      '<div class="ng-row"><span>' + esc(t('balance')) + '</span><b>' + esc(pointsText(mine.balance_after)) + '</b></div>' +
      (mine.is_capped ? '<p class="ng-note">' + esc(t('capped')) + '</p>' : '') +
      '</div>';
    beep('settle');
  }

  /** 用服务端快照刷新页面（唯一数据来源） */
  function applySnapshot(snap) {
    if (!snap) return;
    var prev = state.snap ? state.snap.phase : null;
    state.snap = snap;
    if (snap.server_now) {
      state.serverSkew = new Date(snap.server_now).getTime() - Date.now();
    }
    if (snap.phase_ends_at) state.endsAt = new Date(snap.phase_ends_at).getTime();
    if (snap.notices) state.notices = snap.notices.slice();
    if (snap.my && typeof snap.my.points === 'number') setPoints(snap.my.points);
    if (prev !== snap.phase) {
      if (snap.phase === 'GRABBING') beep('start');
      if (snap.phase === 'DEALING') beep('deal');
      if (snap.phase === 'RESULT') beep('result');
      if (snap.phase === 'WAITING') { state.revealed = null; state.settled = null; }
    }
    var nameEl = $('ngRoomName');
    if (nameEl) nameEl.textContent = snap.room_name + ' · ' + (snap.round_no ? '#' + snap.round_no : '');
    var metaEl = $('ngRoomMeta');
    if (metaEl) {
      metaEl.textContent = t('base') + ' ' + snap.base_stake + ' · ' + snap.players.length + '/' + snap.seat_limit +
        ' · ' + phaseText(snap.phase);
    }
    renderSeats();
    renderPhase();
    renderActions();
    renderNotices();
    renderResult();
  }

  // ---------- 实时通道（Socket 推送；断开时自动轮询兜底） ----------
  function startPolling() {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(function () {
      if (!state.joined) return;
      App.api('/api/game/niu/state?room=' + encodeURIComponent(state.joined)).then(function (res) {
        if (res.success && res.data) applySnapshot(res.data);
        loadRooms();
      });
    }, 3000);
  }

  function stopPolling() {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  }

  async function subscribeRoom(key) {
    App.socketEmit('niu:subscribe', key);
    if (state.socketOn) return;
    state.socketOn = true;

    await App.socketOn('connect', function () {
      if (state.joined) App.socketEmit('niu:subscribe', state.joined);
      stopPolling();
    });
    await App.socketOn('niu:state', function (p) {
      if (!state.snap || !p) return;
      state.snap.phase = p.phase || state.snap.phase;
      state.snap.banker_id = p.banker_id || null;
      state.snap.round_no = p.round_no || state.snap.round_no;
      if (Array.isArray(p.seats)) {
        state.snap.players = p.seats.map(function (s) {
          return Object.assign({}, s, { point_value: s.point_value });
        });
      }
      renderSeats(); renderActions();
      var metaEl = $('ngRoomMeta');
      if (metaEl) metaEl.textContent = t('base') + ' ' + state.snap.base_stake + ' · ' +
        state.snap.players.length + '/' + state.snap.seat_limit + ' · ' + phaseText(state.snap.phase);
    });
    await App.socketOn('niu:phase', function (p) {
      if (!p) return;
      if (state.snap) state.snap.phase = p.phase || state.snap.phase;
      state.endsAt = p.ends_at ? new Date(p.ends_at).getTime() : state.endsAt;
      if (p.server_now) state.serverSkew = new Date(p.server_now).getTime() - Date.now();
      renderPhase();
      renderSeats();
      renderActions();
    });
    await App.socketOn('niu:private', function (p) {
      if (!p || !state.snap || !state.snap.my) return;
      state.snap.my.cards = p.cards || null;
      state.snap.my.hand_name = p.hand ? p.hand.name : null;
      state.snap.my.hand_key = p.hand ? p.hand.key : null;
      state.snap.my.point_value = p.hand ? p.hand.point_value : null;
      renderSeats();
    });
    await App.socketOn('niu:state_full', function (snap) { applySnapshot(snap); });
    await App.socketOn('niu:grab_update', function (p) {
      if (!state.snap || !p) return;
      state.snap.players.forEach(function (s) { if (s.user_id === p.user_id) s.grab = p.grab; });
      renderSeats();
    });
    await App.socketOn('niu:bet_update', function (p) {
      if (!state.snap || !p) return;
      state.snap.players.forEach(function (s) { if (s.user_id === p.user_id) s.bet_level = p.bet_level; });
      renderSeats();
    });
    await App.socketOn('niu:reveal', function (p) {
      if (!p) return;
      state.revealed = p.list || [];
      beep('result');
      renderSeats();
    });
    await App.socketOn('niu:settled', function (p) {
      if (!p) return;
      state.settled = p.list || [];
      renderSeats();
      renderResult();
      refreshStats();
      refreshRecords();
      loadRooms();
    });
    await App.socketOn('niu:points', function (p) {
      if (!p) return;
      setPoints(p.game_points);
      if (state.snap && state.snap.my) state.snap.my.points = p.game_points;
      renderSeats();
    });
    await App.socketOn('niu:notice', function (n) {
      if (!n) return;
      state.notices.push(n);
      if (state.notices.length > 30) state.notices.shift();
      renderNotices();
    });
    await App.socketOn('niu:error', function (p) {
      App.toast((p && p.message) || '实时连接异常，已切换为轮询', 'err');
      startPolling();
    });
    await App.socketOn('disconnect', function () {
      if (state.joined) startPolling();
    });
  }

  // ---------- 操作（抢庄 / 倍数）：只提交意图，服务端裁决 ----------
  async function doGrab(value) {
    if (!state.joined || state.busy) return;
    state.busy = true;
    try {
      var res = await App.api('/api/game/niu/grab', {
        method: 'POST', body: { room: state.joined, grab: Number(value) ? 1 : 0 }
      });
      if (!res.success) { App.toast(res.message || '操作失败', 'err'); return; }
      beep('grab');
      if (state.snap && state.snap.my) {
        state.snap.my.grab = res.data.grab;
        state.snap.my.grab_locked = true;
      }
      renderActions();
      renderSeats();
    } finally {
      state.busy = false;
    }
  }

  async function doBet(level) {
    if (!state.joined || state.busy) return;
    state.busy = true;
    try {
      var res = await App.api('/api/game/niu/bet', {
        method: 'POST', body: { room: state.joined, bet_level: Number(level) }
      });
      if (!res.success) { App.toast(res.message || '操作失败', 'err'); return; }
      beep('action');
      if (state.snap && state.snap.my) state.snap.my.bet_level = res.data.bet_level;
      renderActions();
      renderSeats();
    } finally {
      state.busy = false;
    }
  }

  // ---------- 我的战绩 ----------
  function statCell(k, v) {
    return '<div class="ng-cell"><div class="ng-cell-k">' + esc(k) + '</div><div class="ng-cell-v">' + esc(v) + '</div></div>';
  }

  async function refreshStats() {
    var box = $('ngStats');
    if (!box) return;
    var res = await App.api('/api/game/niu/stats');
    if (!res.success || !res.data) {
      box.innerHTML = App.stateBox('empty', t('empty'), '');
      return;
    }
    var d = res.data;
    setPoints(d.game_points);
    box.innerHTML =
      statCell(t('rounds'), d.total_rounds) +
      statCell(t('wins'), d.win_rounds) +
      statCell(t('winRate'), d.win_rate + '%') +
      statCell(t('net'), App.fmtMoney(d.total_delta));
  }

  // ---------- 排行榜 ----------
  async function loadBoard() {
    var box = $('ngBoard');
    if (!box) return;
    var res = await App.api('/api/game/niu/leaderboard');
    if (!res.success || !res.data) {
      App.showError(box, res.message || '排行榜加载失败', loadBoard);
      return;
    }
    var list = res.data.list || [];
    box.innerHTML = list.length
      ? list.map(function (x) {
        return '<div class="ng-row"><span>#' + x.rank + ' ' + esc(x.nickname) + '</span>' +
          '<span><b>' + esc(App.fmtMoney(x.net)) + '</b> · ' + x.rounds + ' 局</span></div>';
      }).join('')
      : App.stateBox('empty', t('empty'), '还没有真实对局数据。');
  }

  // ---------- 对局记录（分页） ----------
  async function refreshRecords() {
    var box = $('ngRecords');
    if (!box) return;
    var res = await App.api('/api/game/niu/records?page=' + state.page + '&size=' + state.pageSize);
    if (!res.success || !res.data) {
      App.showError(box, res.message || '对局记录加载失败', refreshRecords);
      return;
    }
    var d = res.data;
    state.total = Number(d.total) || 0;
    var list = d.list || [];
    box.innerHTML = list.length
      ? list.map(function (r) {
        var up = Number(r.delta) >= 0;
        return '<div class="ng-row"><span>' + esc(App.fmtDateTime(r.created_at)) + ' · ' +
          esc(r.room_name || r.room_key) + ' · ' + esc(r.role === 'BANKER' ? t('banker') : '') +
          ' ' + esc(r.hand_name || '--') + '</span>' +
          '<b>' + (up ? '+' : '') + esc(App.fmtMoney(r.delta)) + '</b></div>';
      }).join('')
      : App.stateBox('empty', t('noRecords'), '');
    var pages = Math.max(1, Math.ceil(state.total / state.pageSize));
    var info = $('ngPageInfo');
    if (info) info.textContent = state.page + ' / ' + pages + '（共 ' + state.total + ' 条）';
    if ($('ngPrev')) $('ngPrev').disabled = state.page <= 1;
    if ($('ngNext')) $('ngNext').disabled = state.page >= pages;
  }

  // ---------- 每日免费积分 ----------
  async function claimDailyFree() {
    var btn = $('ngFree');
    if (btn) btn.disabled = true;
    try {
      var res = await App.api('/api/game/niu/daily-free', { method: 'POST', body: {} });
      if (!res.success) { App.toast(res.message || '领取失败', 'err'); return; }
      if (res.data && typeof res.data.game_points === 'number') setPoints(res.data.game_points);
      App.toast(res.message || (res.data && res.data.granted ? '已发放积分' : '当前积分充足'), 'ok');
      refreshStats();
    } finally {
      if (btn) btn.disabled = false;
    }
  }



  // ---------- 事件绑定 ----------
  function bind() {
    [$('ngRooms'), $('ngActions')].forEach(function (root) {
      if (!root) return;
      root.addEventListener('click', function (ev) {
        var el = ev.target.closest ? ev.target.closest('[data-enter],[data-act]') : null;
        if (!el) return;
        if (el.getAttribute('data-enter')) { enterRoom(el.getAttribute('data-enter')); return; }
        var act = el.getAttribute('data-act');
        var value = el.getAttribute('data-value');
        if (act === 'grab') doGrab(value);
        if (act === 'bet') doBet(value);
      });
    });

    if ($('ngLeave')) $('ngLeave').addEventListener('click', leaveRoom);
    if ($('ngFree')) $('ngFree').addEventListener('click', claimDailyFree);
    if ($('ngRules')) $('ngRules').addEventListener('click', function () {
      window.location.href = '/tutorial.html?id=26niuniu-basics';
    });
    if ($('ngSound')) $('ngSound').addEventListener('click', function () {
      soundOn = !soundOn;
      localStorage.setItem('nn_niu_sound', soundOn ? '1' : '0');
      paintSound();
      if (soundOn) beep('action');
      App.toast(soundOn ? '已开启对局音效' : '已关闭对局音效', 'ok');
    });
    if ($('ngPrev')) $('ngPrev').addEventListener('click', function () {
      if (state.page > 1) { state.page -= 1; refreshRecords(); }
    });
    if ($('ngNext')) $('ngNext').addEventListener('click', function () {
      state.page += 1; refreshRecords();
    });
  }

  // 倒计时每秒刷新（纯前端时钟，阶段是否推进仍由服务端决定）
  function startClock() {
    setInterval(function () {
      if (state.snap) renderPhase();
    }, 1000);
  }

  async function boot() {
    if (!App.requireLogin()) return;
    var holder = $('pageHeader');
    if (holder) holder.innerHTML = App.headerHtml({ title: t('title'), back: '/lobby.html' });
    App.mountNav('lobby');
    App.mountNetBanner();
    paintSound();
    bind();
    startClock();

    var cfg = await App.api('/api/game/niu/config');
    if (!cfg.success || !cfg.data) {
      gate(App.stateBox('error', '游戏配置加载失败', cfg.message || '请稍后重试'));
      return;
    }
    state.cfg = cfg.data;
    var dis = $('ngDisclaimer');
    if (dis) dis.textContent = '游戏积分只用于娱乐，不可充值、不可提现、不可兑换现金。' + (cfg.data.disclaimer || '');
    setPoints(cfg.data.game_points);
    if (!cfg.data.enabled) {
      gate(App.stateBox('warn', '26牛牛娱乐场暂时关闭',
        cfg.data.disabled_message || '管理员已暂停游戏，已完成的对局与积分不受影响。'));
    }

    await loadAvatarMap();
    await Promise.all([loadRooms(), refreshStats(), loadBoard(), refreshRecords()]);

    // 回到原座位（断线重连 / 刷新页面：服务端按 userId 认座位）
    if (cfg.data.seated_room) {
      var st = await App.api('/api/game/niu/state?room=' + encodeURIComponent(cfg.data.seated_room));
      if (st.success && st.data) {
        state.joined = cfg.data.seated_room;
        applySnapshot(st.data);
        $('ngRoomSec').hidden = false;
        subscribeRoom(cfg.data.seated_room);
      }
    }
    if (location.hash === '#records') {
      var sec = $('ngRecordsSec');
      if (sec && sec.scrollIntoView) sec.scrollIntoView({ block: 'start' });
    }
    setInterval(loadRooms, 15000);   // 场次在线人数定期刷新（真实数据）
  }

  window.addEventListener('pagehide', function () { stopPolling(); });

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(boot);
})();
