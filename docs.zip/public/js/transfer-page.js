// 26牛牛 - 现金筹码转账页
(function () {
  'use strict';
  if (!App.requireLogin()) return;
  App.mountNetBanner();
  var $ = function (id) { return document.getElementById(id); };
  var submitting = false;
  function vAmt() {
    var s = ($('amount').value || '').trim();
    if (!/^\d{1,9}(\.\d{1,2})?$/.test(s) || Number(s) <= 0) { $('amountHint').textContent = '请输入有效的转账金额'; return 0; }
    $('amountHint').textContent = '';
    return Number(s);
  }
  async function loadLimit() {
    var r = await App.api('/api/transfers/limits');
    if (r.success && r.data) $('limitHint').textContent = '单日转账上限：5000现金筹码（今日已转 ' + Number(r.data.used_today || 0) + '，剩余 ' + Number(r.data.remaining_today || 0) + '）';
  }
  $('submitBtn').addEventListener('click', async function () {
    if (submitting) return;
    var toUid = ($('toUid').value || '').trim();
    var amt = vAmt();
    var pwd = ($('payPwd').value || '').trim();
    if (!toUid) { $('uidHint').textContent = '请输入对方UID'; return; }
    $('uidHint').textContent = '';
    if (!amt) return;
    if (!/^\d{6}$/.test(pwd)) { $('payPwdHint').textContent = '支付密码必须为6位数字'; return; }
    $('payPwdHint').textContent = '';
    var okGo = await App.confirmDialog({ title: '确认转账', text: '向 ' + toUid + ' 转账 ' + amt + ' 现金筹码？', okText: '确认转账' });
    if (!okGo) return;
    submitting = true; this.disabled = true; $('formStatus').textContent = '正在转账…';
    try {
      var key = App.newRequestId('web');
      var r = await App.api('/api/transfers', { method: 'POST', body: { to_uid: toUid, amount: amt, pay_password: pwd, idempotency_key: key } });
      $('formStatus').textContent = r.success ? ('转账成功：单号 ' + (r.data.transaction_id || '')) : (r.message || '转账失败');
      if (r.success) { $('amount').value = ''; $('payPwd').value = ''; loadLimit(); }
    } finally { submitting = false; this.disabled = false; }
  });
  loadLimit();
})();
