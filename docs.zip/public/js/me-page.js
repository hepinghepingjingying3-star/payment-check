// ============================================
// 26牛牛 - 「我的」首页
// 只保留：头像 / 用户名 / UID / 游戏余额 / 现金筹码 / 账户状态 / 我的消息 / 设置
// 数据全部来自后端真实接口，无数据即显示 0，绝不随机生成
// ============================================
(function () {
  'use strict';

  var STATUS_TEXT = { active: '正常', banned: '已禁用', deleted: '已注销' };
  var STATUS_CLASS = { active: '', banned: 'danger', deleted: 'danger' };
  var REALNAME_TEXT = {
    unsubmitted: '未提交', pending: '审核中', approved: '已通过', rejected: '已拒绝'
  };

  function $(id) { return document.getElementById(id); }

  function esc(s) { return App.escapeHtml(s); }

  function renderHeader() {
    var holder = $('pageHeader');
    if (holder) holder.innerHTML = App.headerHtml({ title: '我的' });
  }

  function renderSkeletonError(msg) {
    var box = $('meProfile');
    if (box) {
      box.innerHTML = '<div class="me-user"><span class="me-avatar" aria-hidden="true"></span>' +
        '<div class="me-user-main"><div class="me-name">暂时无法加载</div>' +
        '<div class="me-uid">' + esc(msg || '请稍后重试') + '</div></div></div>' +
        '<p class="me-tip">下拉或重新进入本页可重试。</p>';
    }
    var st = $('meStatus');
    if (st) st.textContent = '--';
    var rn = $('meRealName');
    if (rn) rn.textContent = '--';
  }

  function renderProfile(me, avatar) {
    var box = $('meProfile');
    if (!box) return;
    var url = (avatar && avatar.avatar_url) || '/assets/avatars/official.jpg';
    var name = me.nickname || me.username || '用户';
    var uid = me.invite_code || '--';

    box.innerHTML =
      '<div class="me-user">' +
        '<button class="me-avatar-btn" type="button" id="meAvatarBtn" aria-label="更换头像">' +
          '<img class="me-avatar" id="meAvatar" alt="头像" src="' + esc(url) + '">' +
          '<span class="me-avatar-badge">改</span>' +
        '</button>' +
        '<div class="me-user-main">' +
          '<div class="me-name">' + esc(name) + '</div>' +
          '<div class="me-uid">UID：<b>' + esc(uid) + '</b>' +
            '<button class="me-copy" type="button" id="meCopyUid">复制</button>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<p class="me-tip">点击头像可从官方头像库更换头像</p>';

    var btn = $('meAvatarBtn');
    if (btn) btn.addEventListener('click', function () { window.location.href = '/avatar.html'; });

    var cp = $('meCopyUid');
    if (cp) {
      cp.addEventListener('click', async function () {
        var t = String(uid);
        if (!t || t === '--') { App.toast('暂无可复制的 UID', 'err'); return; }
        var ok = await App.copyText(t);
        App.toast(ok ? '已复制' : '复制失败，请长按手动复制', ok ? 'ok' : 'err');
      });
    }

    var img = $('meAvatar');
    if (img) img.addEventListener('error', function () { img.src = '/assets/avatars/official.jpg'; });
  }

  function renderBalance(bal, stats) {
    var grid = $('meBalance');
    if (!grid) return;
    var points = App.fmtMoney(stats && stats.game_points);
    var game = App.fmtMoney(bal && bal.game_balance);
    var chips = App.fmtMoney(bal && bal.cash_chips);
    grid.innerHTML =
      '<a class="me-cell" href="/niu.html">' +
        '<div class="me-cell-k">游戏积分</div>' +
        '<div class="me-cell-v">' + esc(points) + '</div>' +
        '<div class="me-cell-s">26牛牛娱乐场（不可提现）</div>' +
      '</a>' +
      '<a class="me-cell" href="/wallet.html">' +
        '<div class="me-cell-k">游戏余额</div>' +
        '<div class="me-cell-v">' + esc(game) + '</div>' +
        '<div class="me-cell-s">进入钱包查看</div>' +
      '</a>' +
      '<a class="me-cell" href="/wallet.html">' +
        '<div class="me-cell-k">现金筹码</div>' +
        '<div class="me-cell-v">' + esc(chips) + '</div>' +
        '<div class="me-cell-s">虚拟资产，不可提现</div>' +
      '</a>';
  }

  /** 注册天数：按 created_at 到今天的自然日差值（不足一天算 1 天，最少 1 天） */
  function daysSince(createdAt) {
    var d = createdAt ? new Date(createdAt) : null;
    if (!d || isNaN(d.getTime())) return 0;
    var t = Date.now() - d.getTime();
    if (t < 0) return 1;
    return Math.max(1, Math.floor(t / 86400000) + 1);
  }

  function renderStats(me, stats) {
    var grid = $('meStats');
    if (!grid) return;
    var days = daysSince(me && me.created_at);
    var rounds = stats && typeof stats.total_rounds === 'number' ? stats.total_rounds : 0;
    grid.innerHTML =
      '<a class="me-cell" href="/profile.html">' +
        '<div class="me-cell-k">注册天数</div>' +
        '<div class="me-cell-v">' + (days ? days : '--') + '</div>' +
        '<div class="me-cell-s">注册于 ' + esc(me && me.created_at ? App.fmtDate(me.created_at) : '--') + '</div>' +
      '</a>' +
      '<a class="me-cell" href="/niu.html#records">' +
        '<div class="me-cell-k">总对局数量</div>' +
        '<div class="me-cell-v">' + rounds + '</div>' +
        '<div class="me-cell-s">26牛牛娱乐场累计对局</div>' +
      '</a>';
    var sub = $('meRoundSub');
    if (sub) sub.textContent = '26牛牛娱乐场累计 ' + rounds + ' 局';
  }

  // ---------- 语言（默认中文简体；游戏页读取同一键）----------
  var LANGS = [
    { key: 'zh-CN', label: '中文（简体）' },
    { key: 'ms', label: 'Bahasa Melayu' },
    { key: 'en', label: 'English' }
  ];

  function currentLang() {
    var v = localStorage.getItem('nn_lang');
    return LANGS.some(function (l) { return l.key === v; }) ? v : 'zh-CN';
  }

  function langLabel(key) {
    var hit = LANGS.filter(function (l) { return l.key === key; })[0];
    return hit ? hit.label : '中文（简体）';
  }

  function bindLang() {
    var row = $('meLangRow');
    var label = $('meLangV');
    if (!row || !label) return;
    function paint() {
      var cur = currentLang();
      label.textContent = langLabel(cur);
      document.documentElement.lang = cur;
    }
    paint();
    row.addEventListener('click', function () {
      App.openSheet({
        title: '语言 / Language / Bahasa',
        items: LANGS.map(function (l) {
          return {
            label: l.label + (currentLang() === l.key ? ' ✓' : ''),
            onClick: function () {
              localStorage.setItem('nn_lang', l.key);
              paint();
              App.toast('已切换为 ' + l.label, 'ok');
            }
          };
        })
      });
    });
  }

  function renderStatus(me, realName) {
    var st = $('meStatus');
    if (st) {
      var key = (me && me.status) || '';
      st.innerHTML = '<span class="me-dot ' + (STATUS_CLASS[key] || 'warn') + '"></span>' +
        esc(STATUS_TEXT[key] || '未知');
    }
    var rn = $('meRealName');
    if (rn) {
      var s = realName && realName.status ? realName.status : 'unsubmitted';
      rn.textContent = REALNAME_TEXT[s] || '未提交';
    }
  }

  async function load() {
    App.mountNav('me');

    var me = await App.api('/api/auth/me');
    if (!me.success || !me.data) {
      renderSkeletonError(me.message);
      return;
    }
    var user = me.data;

    var [balRes, avRes, rnRes, stRes] = await Promise.all([
      App.api('/api/wallet/balance'),
      App.api('/api/avatars/mine'),
      App.api('/api/profile/real-name'),
      App.api('/api/game/niu/stats')
    ]);

    renderProfile(user, avRes && avRes.success ? avRes.data : null);
    var stats = stRes && stRes.success ? stRes.data : null;
    renderBalance(balRes && balRes.success ? balRes.data : { game_balance: 0, cash_chips: 0 }, stats);
    renderStats(user, stats);
    renderStatus(user, rnRes && rnRes.success ? rnRes.data : null);
  }

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(function () {
    if (!App.requireLogin()) return;
    renderHeader();
    bindLang();
    load();
    window.addEventListener('pageshow', function (ev) {
      if (ev.persisted) load();
    });
  });
})();
