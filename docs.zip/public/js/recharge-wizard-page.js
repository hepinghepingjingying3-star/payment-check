'use strict';
(function () {
  if (!App.requireLogin()) return;
  App.mountNetBanner();
  var $ = function (id) { return document.getElementById(id); };
  var cfg = { min: 30, max: 50000, quick: [30, 100, 500, 1000, 2000, 3000, 5000] };
  var orders = [];
  var available = true;
  function parse(raw) {
    var s = String(raw == null ? '' : raw).trim();
    if (!s || !/^\d{1,8}(\.\d{1,2})?$/.test(s)) return null;
    var n = Number(s);
    if (!Number.isFinite(n) || n < cfg.min || n > cfg.max) return null;
    return n;
  }
  function money(n) { return 'RM' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function validate() {
    var raw = String($('amount').value == null ? '' : $('amount').value).trim();
    var n = parse(raw);
    var text;
    if (!raw || raw === '0' || raw === '0.00') text = '请输入充值金额';
    else if (n === null && /^\d+(?:\.\d+)?$/.test(raw) && Number(raw) < cfg.min) text = '充值金额最低为 RM30';
    else if (n === null && /^\d+(?:\.\d+)?$/.test(raw) && Number(raw) > cfg.max) text = '单笔充值金额最高为 RM50000';
    else if (n === null) text = '请输入合法充值金额（30-50000，最多2位小数）';
    else text = '充值金额：' + money(n);
    $('amountHint').textContent = text;
    $('amountHint').className = 'field-hint' + (n === null ? ' err' : ' ok');
    return n;
  }
  function renderQuick() {
    $('quickGrid').innerHTML = cfg.quick.map(function (v) { return '<button class="amount-chip" type="button" data-amt="' + v + '">' + v.toLocaleString('en-US') + '</button>'; }).join('');
  }
  function renderOrders() {
    var box = $('orderList');
    if (!orders.length) { box.innerHTML = App.stateBox('empty', '暂无充值记录', '完成充值后会在这里显示'); return; }
    box.innerHTML = orders.map(function (o) {
      var href = o.status === 'PENDING' && !o.submitted_at ? '/recharge-confirm.html?id=' + o.id : (o.status === 'PENDING' ? '/recharge-voucher.html?id=' + o.id : '/recharge-detail.html?id=' + o.id);
      return '<a class="list-row" href="' + href + '"><div class="lr-main"><div class="lr-title">' + money(o.amount) + ' <span class="order-tag ' + (o.status === 'COMPLETED' ? 'ok' : o.status === 'REJECTED' ? 'fail' : 'pending') + '">' + App.escapeHtml(o.status_text || o.status) + '</span></div><div class="tx-sub">' + App.escapeHtml(o.order_id) + ' · ' + App.fmtDateTime(o.created_at) + '</div></div><span class="ic i-next"></span></a>';
    }).join('');
  }
  async function load() {
    var c = await App.api('/api/recharge/config');
    if (c.success && c.data) {
      cfg = c.data; renderQuick();
      available = c.data.receiving_available !== false;
      if (!available) {
        $('formStatus').textContent = c.data.notice || '目前暂无可用的收款账户，请联系客服。';
        $('submitBtn').disabled = true; $('bankTransferBtn').disabled = true;
      }
    }
    var r = await App.api('/api/recharge/orders?limit=10');
    if (r.success) { orders = (r.data && r.data.list) || []; renderOrders(); }
    validate();
  }
  $('quickGrid').addEventListener('click', function (e) {
    var b = e.target.closest('[data-amt]'); if (!b) return;
    document.querySelectorAll('#quickGrid .amount-chip').forEach(function (x) { x.classList.remove('active'); });
    b.classList.add('active'); $('amount').value = b.dataset.amt; validate();
  });
  $('amount').addEventListener('input', function () {
    var n = parse($('amount').value);
    document.querySelectorAll('#quickGrid .amount-chip').forEach(function (x) { x.classList.toggle('active', Number(x.dataset.amt) === n); });
    validate();
  });
  async function createOrder(btn) {
    if (!available) { App.toast('目前暂无可用的收款账户，请联系客服。', 'err'); return; }
    var n = validate();
    if (n === null) return;
    var yes = await App.confirmDialog({ title: '确认充值金额', text: '充值金额为 ' + money(n) + '，确认创建订单？', okText: '确认' });
    if (!yes) return;
    btn.disabled = true;
    $('formStatus').textContent = '正在创建订单…';
    var r = await App.api('/api/recharge/orders', { method: 'POST', body: { amount: String(n) } });
    if (!r.success) { btn.disabled = false; $('formStatus').textContent = r.message || '订单创建失败'; return; }
    window.location.href = '/recharge-confirm.html?id=' + r.data.order.id;
  }
  $('submitBtn').addEventListener('click', function () { createOrder(this); });
  $('bankTransferBtn').addEventListener('click', function () { createOrder(this); });
  renderQuick(); load();
})();
