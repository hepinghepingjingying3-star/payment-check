// ============================================
// 26牛牛 - 管理后台扩展面板
// 覆盖：运营统计 / 对局管理 / 游戏管理 / 系统通知 / 客服管理 / 管理员管理
//
// 设计约束（与项目其它后台面板一致）：
//   1) Loading / 成功 / 失败 / 空状态齐全，绝不出现 undefined / null / NaN
//   2) 数字为 null（不可用）时显示「--」，绝不用 0 冒充
//   3) 写操作按钮在提交期间 disabled，防止重复点击
//   4) 绝不渲染密码、支付密码、OTP
// ============================================
(function () {
  'use strict';
  if (!window.App) return;

  var $ = function (id) { return document.getElementById(id); };
  var esc = App.escapeHtml;
  var LOADED = {};
  var BUSY = {};

  /** null → '--'，其余安全转字符串 */
  function num(v) {
    if (v === null || v === undefined || v === '') return '--';
    var n = Number(v);
    return Number.isFinite(n) ? String(n) : '--';
  }
  function dt(v) { return esc(v ? App.fmtDateTime(v) : '--'); }

  function statCard(label, value, sub) {
    return '<div class="stat-card"><div class="stat-label">' + esc(label) + '</div>' +
      '<div class="stat-value">' + esc(String(value)) + '</div>' +
      (sub ? '<div class="stat-sub">' + esc(sub) + '</div>' : '') + '</div>';
  }

  /** 统一的「写操作」包装：自动 disable、失败提示、成功后刷新 */
  async function writeAction(key, button, run) {
    if (BUSY[key]) return false;
    BUSY[key] = true;
    if (button) button.disabled = true;
    try {
      var res = await run();
      if (!res || !res.success) { App.toast((res && res.message) || '操作失败，请稍后重试', 'err'); return false; }
      return true;
    } catch (_) {
      App.toast('网络错误，请稍后重试', 'err');
      return false;
    } finally {
      BUSY[key] = false;
      if (button) button.disabled = false;
    }
  }

  // ============================================
  // 运营统计（控制台）
  // ============================================
  async function loadOverview() {
    var box = $('opsStatGrid');
    if (!box) return;
    box.innerHTML = '<div class="sk-box" style="height:80px"></div>';
    var res = await App.api('/api/admin/ops/overview');
    if (!res.success || !res.data) {
      box.innerHTML = App.stateBox('error', res.message || '运营统计加载失败');
      return;
    }
    var d = res.data;
    box.innerHTML = [
      statCard('对局总数', num(d.rounds.total), '今日 ' + num(d.rounds.today) + ' · 进行中 ' + num(d.rounds.live)),
      statCard('今日参与对局人数', num(d.rounds.players_today), '真实 game_results 去重统计'),
      statCard('游戏入口', num(d.games.active) + ' / ' + num(d.games.total), '启用 / 全部'),
      statCard('系统通知', num(d.notices.total), '已发布 ' + num(d.notices.sent) + ' · 7日触达 ' + num(d.notices.users_7d)),
      statCard('客服消息（24h）', num(d.support.messages_24h), '会话 ' + num(d.support.threads) + ' · 待处理举报 ' + num(d.support.reports)),
      statCard('待审核资金', num(d.wallets.recharge_pending) + ' / ' + num(d.wallets.withdraw_pending), '充值 / 提现'),
      statCard('游戏余额总额', num(d.wallets.game_balance_total), '全平台 users.game_balance 合计'),
      statCard('现金筹码总额', num(d.wallets.cash_chips_total), '全平台 users.cash_chips 合计'),
      statCard('管理员 / 客服', num(d.staff.admins) + ' / ' + num(d.staff.supports), '来自 users.role')
    ].join('');
  }

  // ============================================
  // 对局管理（只读）
  // ============================================
  var rd = { offset: 0, limit: 20, q: '', status: '', from: '', to: '' };

  async function loadRounds(force) {
    if (!force && LOADED.rounds) return;
    var box = $('rdList');
    if (!box) return;
    box.innerHTML = '<div class="sk-box" style="height:100px"></div>';
    var qs = '?limit=' + rd.limit + '&offset=' + rd.offset +
      '&q=' + encodeURIComponent(rd.q) + '&status=' + encodeURIComponent(rd.status) +
      '&from=' + encodeURIComponent(rd.from) + '&to=' + encodeURIComponent(rd.to);
    var res = await App.api('/api/admin/ops/rounds' + qs);
    if (!res.success || !res.data) {
      box.innerHTML = App.stateBox('error', res.message || '对局列表加载失败', function () { loadRounds(true); });
      return;
    }
    var d = res.data;
    if (!d.available) {
      $('rdSummary').textContent = '';
      box.innerHTML = App.stateBox('empty', '暂无对局数据', d.note || '当前系统没有对局表');
      return;
    }
    $('rdSummary').textContent = '共 ' + d.total + ' 条 · 每页 ' + d.limit + ' 条 · 第 ' +
      (Math.floor(d.offset / d.limit) + 1) + ' 页';
    if (!d.list.length) {
      box.innerHTML = App.stateBox('empty', '没有符合条件的对局');
      return;
    }
    box.innerHTML = d.list.map(function (r) {
      return '<section class="card"><div class="card-title">' + esc(r.round_id || ('#' + r.id)) + '</div>' +
        '<div class="admin-note">状态 ' + esc(r.status_text) + ' · 参与 ' + num(r.players) + ' 人' +
        (r.banker_id ? ' · 庄家 #' + num(r.banker_id) : '') + '</div>' +
        '<div class="admin-note">开始 ' + dt(r.created_at) + ' · 更新 ' + dt(r.updated_at) + '</div>' +
        '<div class="admin-tools"><button class="btn btn-dark btn-sm" type="button" data-rd-detail="' +
        num(r.id) + '">查看详情</button></div></section>';
    }).join('');
  }

  async function showRound(id) {
    var res = await App.api('/api/admin/ops/rounds/' + encodeURIComponent(id));
    if (!res.success || !res.data) { App.toast(res.message || '加载失败', 'err'); return; }
    var r = res.data;
    var body = '<div class="admin-note">对局编号 ' + esc(r.round_id || '--') + '</div>' +
      '<div class="admin-note">状态 ' + esc(r.status_text) + ' · 房间 ' + num(r.room_id) + '</div>' +
      '<div class="admin-note">开始 ' + dt(r.created_at) + '</div>' +
      '<div class="admin-note">更新 ' + dt(r.updated_at) + '</div>' +
      '<div class="admin-note" style="margin-top:8px">参与玩家 ' + r.players.length + ' 人</div>';
    if (r.players.length) {
      body += '<div style="margin-top:8px">' + r.players.map(function (p) {
        return '<div class="admin-note">' + esc(p.username || ('#' + p.user_id)) + ' · ' + esc(p.role) +
          ' · ' + (p.is_winner ? '赢' : '输') + '</div>';
      }).join('') + '</div>';
    }
    if (App.sheet) App.sheet('对局详情', body);
  }

  // ============================================
  // 游戏管理
  // ============================================
  async function loadGames(force) {
    if (!force && LOADED.games) return;
    var box = $('gmList');
    if (!box) return;
    box.innerHTML = '<div class="sk-box" style="height:80px"></div>';
    var res = await App.api('/api/admin/ops/games');
    if (!res.success || !res.data) {
      box.innerHTML = App.stateBox('error', res.message || '游戏列表加载失败', function () { loadGames(true); });
      return;
    }
    if (!res.data.available) { box.innerHTML = App.stateBox('empty', '游戏功能不可用'); return; }
    if (!res.data.list.length) { box.innerHTML = App.stateBox('empty', '还没有游戏入口', '可在下方新增。'); return; }
    box.innerHTML = res.data.list.map(function (g) {
      return '<section class="card"><div class="card-title">' + esc(g.name) + '</div>' +
        '<div class="admin-note">标识 ' + esc(g.key) + ' · 排序 ' + num(g.sort_order) +
        (g.description ? ' · ' + esc(g.description) : '') + '</div>' +
        '<div class="admin-note">' + (g.is_active ? '已启用' : '已停用') + ' · 更新 ' + dt(g.updated_at) + '</div>' +
        '<div class="admin-tools"><button class="btn btn-dark btn-sm" type="button" data-gm-toggle="' +
        g.id + '" data-gm-active="' + (g.is_active ? '1' : '0') + '">' +
        (g.is_active ? '停用' : '启用') + '</button></div></section>';
    }).join('');
  }

  async function addGame(btn) {
    var key = $('gmKey').value.trim();
    var name = $('gmName').value.trim();
    if (!key) { $('gmStatus').textContent = '请填写游戏标识'; return; }
    if (!name) { $('gmStatus').textContent = '请填写显示名称'; return; }
    $('gmStatus').textContent = '正在保存…';
    var done = await writeAction('gmAdd', btn, function () {
      return App.api('/api/admin/ops/games', {
        method: 'POST',
        body: {
          key: key, name: name,
          description: $('gmDesc').value.trim(),
          entry_image: $('gmImage').value.trim(),
          sort_order: Number($('gmSort').value) || 0
        }
      });
    });
    if (!done) { $('gmStatus').textContent = '新增失败，请检查填写内容'; return; }
    $('gmKey').value = ''; $('gmName').value = ''; $('gmDesc').value = ''; $('gmImage').value = '';
    $('gmStatus').textContent = '已新增';
    App.toast('游戏入口已新增', 'ok');
    LOADED.games = false;
    loadGames(true);
  }

  async function toggleGame(btn) {
    var id = btn.dataset.gmToggle;
    var want = btn.dataset.gmActive !== '1';
    var yes = await App.confirmDialog({
      title: want ? '启用游戏' : '停用游戏',
      text: want ? '确认启用该游戏入口？' : '确认停用该游戏入口？停用后前台不再展示，已产生的对局记录不受影响。',
      okText: '确认', danger: !want
    });
    if (!yes) return;
    var done = await writeAction('gm' + id, btn, function () {
      return App.api('/api/admin/ops/games/' + id + '/status', { method: 'POST', body: { is_active: want } });
    });
    if (!done) return;
    App.toast(want ? '已启用' : '已停用', 'ok');
    LOADED.games = false;
    loadGames(true);
  }

  // ============================================
  // 系统通知（与聊天消息完全分离）
  // ============================================
  async function loadNotices(force) {
    if (!force && LOADED.notices) return;
    var box = $('ntList');
    if (!box) return;
    box.innerHTML = '<div class="sk-box" style="height:100px"></div>';
    var res = await App.api('/api/admin/ops/notices?limit=20&offset=0');
    if (!res.success || !res.data) {
      box.innerHTML = App.stateBox('error', res.message || '通知列表加载失败', function () { loadNotices(true); });
      return;
    }
    if (!res.data.available) { box.innerHTML = App.stateBox('empty', '通知功能不可用'); return; }
    if (!res.data.list.length) { box.innerHTML = App.stateBox('empty', '还没有发送过通知'); return; }
    box.innerHTML = res.data.list.map(function (n) {
      var who = n.scope === 'all' ? '全部用户' : ('用户 ' + esc(n.audience_name || ('#' + n.audience_id)));
      var act = n.status === 'published'
        ? '<button class="btn btn-dark btn-sm" type="button" data-nt-withdraw="' + esc(n.id) + '">撤回</button>'
        : '<button class="btn btn-dark btn-sm" type="button" data-nt-publish="' + esc(n.id) + '">重新发布</button>';
      return '<section class="card"><div class="card-title">' + esc(n.title) + '</div>' +
        '<div class="admin-note">' + who + ' · ' + esc(n.category) + ' · ' + dt(n.created_at) + '</div>' +
        '<div class="admin-note">' + esc(n.content) + '</div>' +
        '<div class="admin-note" style="margin-top:6px">' + (n.status === 'published' ? '已发布' : '已撤回') +
        (n.is_read ? ' · 已读' : ' · 未读') + '</div>' +
        '<div class="admin-tools">' + act + '</div></section>';
    }).join('');
  }

  async function sendNotice(btn) {
    var title = $('ntTitle').value.trim();
    var content = $('ntContent').value.trim();
    if (!title) { $('ntStatus').textContent = '请填写通知标题'; return; }
    if (!content) { $('ntStatus').textContent = '请填写通知内容'; return; }
    var scope = $('ntScope').value === 'all' ? 'all' : 'user';
    var userId = $('ntUserId').value.trim();
    if (scope === 'user' && !/^\d+$/.test(userId)) {
      $('ntStatus').textContent = '指定用户时请填写正确的用户 ID';
      return;
    }
    $('ntStatus').textContent = '正在发送…';
    var done = await writeAction('ntSend', btn, function () {
      return App.api('/api/admin/ops/notices', {
        method: 'POST',
        body: {
          title: title, content: content, scope: scope,
          user_id: scope === 'user' ? Number(userId) : null,
          category: $('ntCategory').value,
          link: $('ntLink').value.trim()
        }
      });
    });
    if (!done) { $('ntStatus').textContent = '发送失败，请检查填写内容'; return; }
    $('ntTitle').value = ''; $('ntContent').value = ''; $('ntLink').value = '';
    $('ntStatus').textContent = '已发送';
    App.toast('通知已发送', 'ok');
    LOADED.notices = false;
    loadNotices(true);
  }

  async function setNoticeStatus(btn, status) {
    var id = btn.dataset.ntWithdraw || btn.dataset.ntPublish;
    var done = await writeAction('nt' + id, btn, function () {
      return App.api('/api/admin/ops/notices/' + encodeURIComponent(id) + '/status', {
        method: 'POST', body: { status: status }
      });
    });
    if (!done) return;
    App.toast(status === 'withdrawn' ? '已撤回' : '已重新发布', 'ok');
    LOADED.notices = false;
    loadNotices(true);
  }

  // ============================================
  // 客服管理（只读）
  // ============================================
  async function loadSupport(force) {
    if (!force && LOADED.support) return;
    var list = $('spList');
    var rep = $('spReports');
    if (!list || !rep) return;
    list.innerHTML = '<div class="sk-box" style="height:80px"></div>';
    var res = await App.api('/api/admin/ops/support?limit=20&offset=0');
    if (!res.success || !res.data) {
      list.innerHTML = App.stateBox('error', res.message || '客服数据加载失败', function () { loadSupport(true); });
      return;
    }
    var d = res.data;
    $('spSummary').textContent = '会话 ' + num(d.threads.total) + ' 个 · 待处理举报 ' + num(d.reports.total) + ' 条';
    if (!d.threads.available || !d.threads.list.length) {
      list.innerHTML = App.stateBox('empty', '暂无客服会话', d.threads.available ? '' : '当前系统没有会话表');
    } else {
      list.innerHTML = d.threads.list.map(function (t) {
        return '<section class="card"><div class="card-title">' + esc(t.thread_key) + '</div>' +
          '<div class="admin-note">' + esc(t.status) + ' · 更新 ' + dt(t.updated_at) + '</div></section>';
      }).join('');
    }
    if (!d.reports.available || !d.reports.list.length) {
      rep.innerHTML = App.stateBox('empty', '暂无聊天举报');
      return;
    }
    rep.innerHTML = d.reports.list.map(function (r) {
      return '<section class="card"><div class="card-title">' + esc(r.reason || '举报') + '</div>' +
        '<div class="admin-note">举报人 ' + esc(r.reporter || '--') + ' · ' + dt(r.created_at) + '</div>' +
        '<div class="admin-note">' + esc(r.message || '（原消息已不可用）') + '</div>' +
        '<div class="admin-note" style="margin-top:6px">' + (r.status === 'pending' ? '待处理' : '已处理') + '</div></section>';
    }).join('');
  }

  // ============================================
  // 管理员管理
  // ============================================
  var stf = { offset: 0, limit: 20, q: '', role: '' };

  async function loadStaff(force) {
    if (!force && LOADED.staff) return;
    var box = $('stfList');
    if (!box) return;
    box.innerHTML = '<div class="sk-box" style="height:80px"></div>';
    var qs = '?limit=' + stf.limit + '&offset=' + stf.offset +
      '&q=' + encodeURIComponent(stf.q) + '&role=' + encodeURIComponent(stf.role);
    var res = await App.api('/api/admin/ops/staff' + qs);
    if (!res.success || !res.data) {
      box.innerHTML = App.stateBox('error', res.message || '管理员列表加载失败', function () { loadStaff(true); });
      return;
    }
    var d = res.data;
    $('stfSummary').textContent = '共 ' + d.total + ' 个账号 · 启用中的管理员 ' + d.active_admins + ' 名';
    if (!d.list.length) { box.innerHTML = App.stateBox('empty', '没有符合条件的账号'); return; }
    box.innerHTML = d.list.map(function (u) {
      var act = u.is_self
        ? '<span class="admin-note">当前登录账号</span>'
        : (u.status === 'active'
          ? '<button class="btn btn-dark btn-sm" type="button" data-stf-off="' + u.id + '">停用</button>'
          : '<button class="btn btn-gold btn-sm" type="button" data-stf-on="' + u.id + '">启用</button>');
      return '<section class="card"><div class="card-title">' + esc(u.username) + '</div>' +
        '<div class="admin-note">' + (u.role === 'admin' ? '管理员' : '客服') + ' · ' +
        (u.status === 'active' ? '启用中' : '已停用') + ' · #' + u.id + '</div>' +
        '<div class="admin-note">创建 ' + dt(u.created_at) + '</div>' +
        '<div class="admin-tools">' + act + '</div></section>';
    }).join('');
  }

  async function setStaffStatus(btn, status) {
    var id = btn.dataset.stfOff || btn.dataset.stfOn;
    var reason = '';
    if (status === 'banned') {
      reason = await App.promptDialog({
        title: '停用管理员',
        text: '请输入停用原因（必填，会写入审计日志）',
        placeholder: '例如：账号异常，需要核查'
      });
      if (reason === null) return;
      if (!String(reason).trim()) { App.toast('停用管理员必须填写原因', 'err'); return; }
    }
    var done = await writeAction('stf' + id, btn, function () {
      return App.api('/api/admin/ops/staff/' + id + '/status', {
        method: 'POST', body: { status: status, reason: String(reason || '').trim() }
      });
    });
    if (!done) return;
    App.toast(status === 'banned' ? '已停用' : '已启用', 'ok');
    LOADED.staff = false;
    loadStaff(true);
  }

  // ============================================
  // 事件绑定
  // ============================================
  function bind() {
    if ($('ntScope')) {
      $('ntScope').addEventListener('change', function () {
        $('ntUserWrap').hidden = this.value !== 'user';
      });
    }
    if ($('ntSend')) $('ntSend').addEventListener('click', function () { sendNotice(this); });
    if ($('ntList')) $('ntList').addEventListener('click', function (ev) {
      var w = ev.target.closest('[data-nt-withdraw]');
      if (w) { setNoticeStatus(w, 'withdrawn'); return; }
      var p = ev.target.closest('[data-nt-publish]');
      if (p) setNoticeStatus(p, 'published');
    });
    if ($('gmAdd')) $('gmAdd').addEventListener('click', function () { addGame(this); });
    if ($('gmList')) $('gmList').addEventListener('click', function (ev) {
      var t = ev.target.closest('[data-gm-toggle]');
      if (t) toggleGame(t);
    });
    if ($('rdSearch')) $('rdSearch').addEventListener('click', function () {
      rd.q = $('rdQuery').value.trim(); rd.from = $('rdFrom').value; rd.to = $('rdTo').value;
      rd.offset = 0; loadRounds(true);
    });
    if ($('rdQuery')) $('rdQuery').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $('rdSearch').click(); }
    });
    if ($('rdStatusBar')) $('rdStatusBar').addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-rd-status]');
      if (!b) return;
      rd.status = b.dataset.rdStatus; rd.offset = 0; loadRounds(true);
    });
    if ($('rdPrev')) $('rdPrev').addEventListener('click', function () {
      rd.offset = Math.max(0, rd.offset - rd.limit); loadRounds(true);
    });
    if ($('rdNext')) $('rdNext').addEventListener('click', function () {
      rd.offset = rd.offset + rd.limit; loadRounds(true);
    });
    if ($('rdList')) $('rdList').addEventListener('click', function (ev) {
      var d = ev.target.closest('[data-rd-detail]');
      if (d) showRound(d.dataset.rdDetail);
    });
    if ($('stfSearch')) $('stfSearch').addEventListener('click', function () {
      stf.q = $('stfQuery').value.trim(); stf.offset = 0; loadStaff(true);
    });
    if ($('stfQuery')) $('stfQuery').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $('stfSearch').click(); }
    });
    if ($('stfRoleBar')) $('stfRoleBar').addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-stf-role]');
      if (!b) return;
      stf.role = b.dataset.stfRole; stf.offset = 0; loadStaff(true);
    });
    if ($('stfPrev')) $('stfPrev').addEventListener('click', function () {
      stf.offset = Math.max(0, stf.offset - stf.limit); loadStaff(true);
    });
    if ($('stfNext')) $('stfNext').addEventListener('click', function () {
      stf.offset = stf.offset + stf.limit; loadStaff(true);
    });
    if ($('stfList')) $('stfList').addEventListener('click', function (ev) {
      var off = ev.target.closest('[data-stf-off]');
      if (off) { setStaffStatus(off, 'banned'); return; }
      var on = ev.target.closest('[data-stf-on]');
      if (on) setStaffStatus(on, 'active');
    });
  }

  // ============================================
  // 对外接口：供 admin-page.js 的 showTab 调用
  // ============================================
  window.AdminOpsPanel = {
    refresh: function (tab) {
      LOADED[tab] = false;
      if (tab === 'overview') return loadOverview();
      if (tab === 'rounds') return loadRounds(true);
      if (tab === 'games') return loadGames(true);
      if (tab === 'notices') return loadNotices(true);
      if (tab === 'support') return loadSupport(true);
      if (tab === 'staff') return loadStaff(true);
      return Promise.resolve();
    },
    reset: function () {
      LOADED = {};
      rd.offset = 0;
      stf.offset = 0;
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);
  else bind();
})();
