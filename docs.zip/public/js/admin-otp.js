// Manual delivery console. OTP values remain in memory, never browser storage.
(function () {
  'use strict';
  if (!App.requireLogin()) return;
  App.mountNav('me');
  App.mountNetBanner();
  var list = document.getElementById('otpList');
  var filter = document.getElementById('otpStatus');
  var reload = document.getElementById('reloadOtp');
  var gate = document.getElementById('otpGate');
  var body = document.getElementById('otpBody');
  var rows = [];
  var busy = false;
  var generation = 0;
  var expiryTimer = null;
  var esc = App.escapeHtml;

  function clearExpiry() {
    clearTimeout(expiryTimer);
    expiryTimer = null;
  }
  function remaining(r) {
    return Math.max(0, Math.ceil((r.deadline - Date.now()) / 1000));
  }
  function scheduleExpiry() {
    clearExpiry();
    var live = rows.filter(function (r) { return r.code && remaining(r) > 0; });
    if (!live.length) return;
    expiryTimer = setTimeout(function () {
      rows.forEach(function (r) { if (!remaining(r)) r.code = null; });
      render();
      scheduleExpiry();
    }, Math.max(1, Math.min.apply(null, live.map(function (r) { return r.deadline - Date.now(); }))));
  }

  function clearPrivate() {
    generation++;
    clearExpiry();
    rows = [];
    list.innerHTML = App.stateBox('empty', '验证码已隐藏', '刷新可查看状态，已领取验证码不可再次查看');
  }
  function render() {
    list.innerHTML = rows.length ? rows.map(function (r) {
      var available = r.status === 'pending' && r.code && remaining(r) > 0;
      return '<section class="card"><div class="card-title">' + esc(r.phone) + '</div>' +
        '<div class="otp-detail">' + esc(r.status_text || r.status) +
        '<br>创建：' + esc(App.fmtDateTime(r.created_at)) +
        '<br>过期：' + esc(App.fmtDateTime(r.expires_at)) + '</div>' +
        (available ? '<div class="otp-value">' + esc(r.code) + '</div>' : '') +
        '<div class="otp-actions">' +
        (r.code_available && !available && remaining(r) > 0 ? '<button class="btn btn-gold" data-action="reveal" data-id="' + Number(r.id) + '">领取一次</button>' : '') +
        (available ? '<button class="btn btn-dark" data-action="copy" data-id="' + Number(r.id) + '">复制验证码</button>' : '') +
        (r.status === 'pending' && remaining(r) > 0 ? '<button class="btn btn-gold" data-action="mark-sent" data-id="' + Number(r.id) + '">标记已发送</button>' : '') +
        '<button class="btn btn-dark" data-action="regenerate" data-id="' + Number(r.id) + '">重新生成</button></div></section>';
    }).join('') : App.stateBox('empty', '暂无验证码记录');
  }
  async function load() {
    if (busy) return;
    busy = true;
    reload.disabled = true;
    filter.disabled = true;
    clearExpiry();
    rows = [];
    var requestGeneration = ++generation;
    list.innerHTML = '<div class="sk-box" style="height:160px" aria-label="正在加载"></div>';
    try {
      var res = await App.api('/api/admin/otp?status=' + encodeURIComponent(filter.value));
      if (requestGeneration !== generation || document.hidden) return;
      if (!res.success) {
        App.showError(list, res.message || '验证码加载失败或无访问权限', load);
        return;
      }
      rows = ((res.data && res.data.list) || []).map(function (r) {
        r.deadline = Date.now() + Math.max(0, Number(r.seconds_left) || 0) * 1000;
        return r;
      });
      render();
    } finally {
      busy = false;
      reload.disabled = false;
      filter.disabled = false;
    }
  }
  list.addEventListener('click', async function (event) {
    var button = event.target.closest('[data-action]');
    if (!button || busy) return;
    var row = rows.find(function (r) { return Number(r.id) === Number(button.dataset.id); });
    if (!row) return;
    var action = button.dataset.action;
    busy = true;
    button.disabled = true;
    var refresh = false;
    var actionGeneration = generation;
    try {
      if (action === 'reveal') {
        var accepted = await App.confirmDialog({ title: '一次性领取', text: '领取后只能在当前页面查看一次。切换页面、隐藏窗口或过期后会清除，请及时复制并通过 WhatsApp 发送。' });
        if (!accepted || document.hidden || actionGeneration !== generation) return;
        var revealed = await App.api('/api/admin/otp/' + Number(row.id) + '/reveal', { method: 'POST' });
        if (document.hidden || actionGeneration !== generation) return;
        if (!revealed.success) {
          App.toast(revealed.message || '领取失败', 'err');
          refresh = true;
          return;
        }
        row.code = revealed.data.code;
        row.code_available = false;
        row.deadline = Date.now() + Math.max(0, Number(revealed.data.seconds_left) || 0) * 1000;
        render();
        scheduleExpiry();
        return;
      }
      if (action === 'copy') {
        if (!remaining(row)) { row.code = null; render(); return; }
        var copied = await App.copyText(row.code || '');
        App.toast(copied ? '已复制，请通过 WhatsApp 手动发送' : '复制失败', copied ? 'ok' : 'err');
        return;
      }
      if (action !== 'mark-sent' && action !== 'regenerate') return;
      var confirmed = await App.confirmDialog({
        title: action === 'mark-sent' ? '确认已发送' : '重新生成验证码',
        text: action === 'mark-sent' ? '请确认已通过 WhatsApp 发送。此操作将清除临时明文。' : '旧验证码会立即失效，确定继续吗？'
      });
      if (!confirmed || document.hidden) return;
      var res = await App.api('/api/admin/otp/' + Number(row.id) + '/' + action, { method: 'POST' });
      App.toast(res.success ? '操作成功' : (res.message || '操作失败'), res.success ? 'ok' : 'err');
      refresh = res.success;
    } finally {
      busy = false;
      button.disabled = false;
      if (refresh && !document.hidden) load();
    }
  });
  reload.addEventListener('click', load);
  filter.addEventListener('change', load);
  document.addEventListener('visibilitychange', function () { if (document.hidden) clearPrivate(); });
  window.addEventListener('pagehide', clearPrivate);
  window.addEventListener('pageshow', function (event) { if (event.persisted && App.getToken()) loadMe(); });

  // 权限校验：非管理员不渲染任何后台内容（页面 HTML 本身也被后端边界挡住）
  async function loadMe() {
    gate.hidden = false;
    body.hidden = true;
    gate.innerHTML = '<div class="sk-box" style="height:120px" aria-label="正在校验权限"></div>';
    var res = await App.api('/api/auth/me');
    if (!res.success || !res.data) {
      App.showError(gate, res.message || '权限校验失败', loadMe);
      return;
    }
    if (res.data.role !== 'admin') {
      gate.innerHTML = App.stateBox('error', '无权访问', '当前账号不是管理员，无法打开 OTP 管理。') +
        '<div class="otp-actions"><a class="btn btn-dark" href="/me.html">返回我的</a></div>';
      return;
    }
    gate.hidden = true;
    body.hidden = false;
    load();
  }

  loadMe();
})();
