// ============================================
// 26牛牛 - 账户安全
// 复用现有登录密码（bcrypt）与支付密码接口，绝不新建第二套密码系统
// 密码只在请求体中提交，不回显、不入库明文、不写日志
// ============================================
(function () {
  'use strict';

  function $(id) { return document.getElementById(id); }
  function text(id, v) { var el = $(id); if (el) el.textContent = v; }
  function esc(s) { return App.escapeHtml(s); }

  // ---------- 登录密码 ----------
  function bindChangePassword() {
    var btn = $('scChangePwd');
    if (!btn) return;
    btn.addEventListener('click', async function () {
      var values = await App.openFormSheet({
        title: '修改登录密码',
        okText: '保存',
        fields: [
          { key: 'old_password', label: '原密码', type: 'password' },
          { key: 'new_password', label: '新密码（至少 6 位）', type: 'password' },
          { key: 'confirm_password', label: '确认新密码', type: 'password' }
        ],
        onSubmit: function (v) {
          if (!v.old_password) { App.toast('请输入原密码', 'err'); return false; }
          if (String(v.new_password || '').length < 6) { App.toast('新密码至少 6 个字符', 'err'); return false; }
          if (v.new_password !== v.confirm_password) { App.toast('两次输入的新密码不一致', 'err'); return false; }
          return true;
        }
      });
      if (!values) return;
      var res = await App.api('/api/auth/change-password', { method: 'POST', body: values });
      if (!res.success) { App.toast(res.message || '修改失败', 'err'); return; }
      App.toast(res.message || '密码已更新，请使用新密码登录', 'ok');
    });
  }

  // ---------- 支付密码 ----------
  async function loadPayStatus() {
    var badge = $('scPayBadge');
    var btn = $('scPayBtn');
    var res = await App.api('/api/pay-password/status');
    if (!res.success || !res.data) {
      if (badge) badge.textContent = '未知';
      return;
    }
    var isSet = !!res.data.set;
    if (badge) {
      badge.textContent = isSet ? '已设置' : '未设置';
      badge.className = 'sc-badge ' + (isSet ? 'ok' : 'warn');
    }
    if (btn) {
      btn.disabled = false;
      btn.textContent = isSet ? '修改支付密码' : '设置支付密码';
    }
  }

  function bindPay() {
    var btn = $('scPayBtn');
    if (!btn) return;
    btn.addEventListener('click', async function () {
      var isSet = ($('scPayBadge') || {}).textContent === '已设置';
      var fields = [];
      if (isSet) fields.push({ key: 'old_password', label: '原支付密码（6 位数字）', type: 'password' });
      fields.push({ key: 'pay_password', label: '支付密码（6 位数字）', type: 'password' });
      fields.push({ key: 'confirm_password', label: '确认支付密码', type: 'password' });

      var values = await App.openFormSheet({
        title: isSet ? '修改支付密码' : '设置支付密码',
        okText: '确认提交',
        fields: fields,
        onSubmit: function (v) {
          if (isSet && !/^\d{6}$/.test(String(v.old_password || ''))) { App.toast('请输入原 6 位支付密码', 'err'); return false; }
          if (!/^\d{6}$/.test(String(v.pay_password || ''))) { App.toast('支付密码必须为6位数字', 'err'); return false; }
          if (v.pay_password !== v.confirm_password) { App.toast('两次支付密码不一致', 'err'); return false; }
          return true;
        }
      });
      if (!values) return;
      var res = await App.api(isSet ? '/api/pay-password/change' : '/api/pay-password/set', {
        method: 'POST', body: values
      });
      if (!res.success) { App.toast(res.message || '操作失败', 'err'); return; }
      App.toast(res.message || '支付密码已更新', 'ok');
      loadPayStatus();
    });
  }

  // ---------- 退出其它设备 ----------
  function bindLogoutOther() {
    var btn = $('scLogoutOther');
    if (!btn) return;
    btn.addEventListener('click', async function () {
      var yes = await App.confirmDialog({
        title: '退出其它设备',
        text: '其它设备上的登录状态将立即失效，当前设备会继续在线。确定继续吗？',
        okText: '确定'
      });
      if (!yes) return;
      var res = await App.api('/api/auth/logout-other', { method: 'POST' });
      if (!res.success) { App.toast(res.message || '操作失败', 'err'); return; }
      if (res.data && res.data.token) {
        var user = App.getUser() || {};
        App.setSession(res.data.token, user);
      }
      App.toast('其它设备已退出', 'ok');
    });
  }

  // ---------- 最近登录记录 ----------
  async function loadLoginRecords() {
    var box = $('scLoginList');
    if (!box) return;
    App.showLoading(box, '正在加载登录记录...');
    var res = await App.api('/api/auth/login-records?limit=15');
    if (!res.success || !res.data) {
      App.showError(box, res.message || '登录记录加载失败', loadLoginRecords);
      return;
    }
    var list = res.data.list || [];
    if (!list.length) {
      App.showEmpty(box, '暂无登录记录', '');
      return;
    }
    box.innerHTML = list.map(function (r) {
      var okLog = r.status === 'success';
      return '<div class="sc-log">' +
        '<div class="sc-log-k">' +
          '<div class="sc-log-t">' + esc(App.fmtDateTime(r.created_at)) + '</div>' +
          '<div class="sc-log-s">IP ' + esc(r.ip || '--') + ' · ' + esc((r.user_agent || '未知设备').slice(0, 60)) + '</div>' +
        '</div>' +
        '<div class="sc-log-r ' + (okLog ? 'ok' : 'bad') + '">' + esc(r.status_text || (okLog ? '登录成功' : '登录失败')) + '</div>' +
      '</div>';
    }).join('');
  }

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(function () {
    if (!App.requireLogin()) return;
    var holder = $('pageHeader');
    if (holder) holder.innerHTML = App.headerHtml({ title: '账户安全', back: '/settings.html' });
    App.mountNav('me');
    bindChangePassword();
    bindPay();
    bindLogoutOther();
    loadPayStatus();
    loadLoginRecords();
  });
})();
