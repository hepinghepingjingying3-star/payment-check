'use strict';
(function () {
  if (!App.requireLogin()) return; App.mountNetBanner();
  var $ = function (id) { return document.getElementById(id); };
  var id = new URLSearchParams(location.search).get('id');
  var order = null, busy = false;
  function money(v) { return 'RM' + Number(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function copy(value) { App.copyText(value).then(function (ok) { App.toast(ok ? '已复制' : '复制失败', ok ? 'ok' : 'err'); }); }
  async function load() {
    if (!/^\d+$/.test(id || '')) { $('confirmBox').innerHTML = App.stateBox('error', '订单不存在', '链接参数无效'); return; }
    var b = await App.api('/api/recharge/orders/' + id);
    if (!b.success) { $('confirmBox').innerHTML = App.stateBox('error', '订单加载失败', (b.message || '请稍后重试')); return; }
    order = b.data.order; paint();
  }
  function paint() {
    // 收款账户只来自「本订单创建时分配的账户快照」；刷新页面不会重新选择
    var r = order.receiving_account || null;
    var accountHtml = r
      ? '<div class="copy-line"><span class="k">收款方式</span><span class="v">' + App.escapeHtml(r.type_text || r.type || '') + '</span></div>' +
        '<div class="copy-line"><span class="k">' + App.escapeHtml(r.type === 'EWALLET' ? '电子钱包' : '收款银行') + '</span><span class="v">' + App.escapeHtml(r.name) + '</span></div>' +
        '<div class="copy-line"><span class="k">收款账号</span><span class="v">' + App.escapeHtml(r.account_no) + '</span><button class="btn btn-ghost btn-sm" data-copy="' + App.escapeHtml(r.account_no) + '">复制</button></div>' +
        '<div class="copy-line"><span class="k">收款户名</span><span class="v">' + App.escapeHtml(r.holder) + '</span><button class="btn btn-ghost btn-sm" data-copy="' + App.escapeHtml(r.holder) + '">复制</button></div>'
      : '<div class="warning-box">该订单未分配收款账户，请联系客服处理</div>';
    var refHtml = order.payment_reference
      ? '<div class="copy-line"><span class="k">付款参考编号</span><span class="v">' + App.escapeHtml(order.payment_reference) + '</span><button class="btn btn-ghost btn-sm" data-copy="' + App.escapeHtml(order.payment_reference) + '">复制</button></div>'
      : '';
    $('confirmBox').innerHTML = '<div class="card card-gold"><div class="card-title">充值订单</div><div class="recharge-amount mt-8">' + money(order.amount) + '</div><div class="tx-sub mt-8">订单号：' + App.escapeHtml(order.order_id) + '</div></div>' +
      '<div class="card"><div class="card-title">收款资料</div>' + accountHtml + refHtml + '<p class="card-note">请按订单金额转账，付款时填写付款参考编号，并在下一步上传清晰的转账凭证。</p></div>' +
      '<div class="warning-box">转账金额、收款账户和订单号必须一致；如需修改金额，请返回上一步重新创建订单。</div>' +
      '<a class="btn btn-gold btn-block mt-12" href="/recharge-voucher.html?id=' + order.id + '">下一步・上传付款证明</a>' +
      '<button class="btn btn-ghost btn-block mt-8" id="modifyBtn" type="button">金额错误？点我修改</button>';
    document.querySelectorAll('[data-copy]').forEach(function (b) { b.addEventListener('click', function () { copy(b.dataset.copy); }); });
    $('modifyBtn').addEventListener('click', async function () {
      if (busy) return;
      var yes = await App.confirmDialog({ title: '修改充值金额', text: '将取消当前待审核订单，并返回第一步重新填写金额。', okText: '取消并修改', danger: true });
      if (!yes) return;
      busy = true; this.disabled = true;
      var r2 = await App.api('/api/recharge/orders/' + order.id + '/cancel', { method: 'POST' });
      if (!r2.success) { busy = false; this.disabled = false; App.toast(r2.message || '订单取消失败，请稍后重试', 'err'); return; }
      window.location.href = '/recharge.html';
    });
  }
  load();
})();
