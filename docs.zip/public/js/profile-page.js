// ============================================
// 26牛牛 - 个人资料（仅本人可见自己的手机/邮箱/真实姓名）
// 头像只能从官方头像库更换，无任何上传入口
// ============================================
(function () {
  'use strict';

  var ROLE_TEXT = { user: '成员', admin: '管理员', support: '客服' };
  var REALNAME_TEXT = { unsubmitted: '未提交', pending: '审核中', approved: '已通过', rejected: '已拒绝' };
  var REALNAME_CLASS = { unsubmitted: 'warn', pending: 'warn', approved: 'ok', rejected: 'bad' };
  var REALNAME_RE = /^[\u4e00-\u9fa5A-Za-z][\u4e00-\u9fa5A-Za-z .·']{1,49}$/;

  function $(id) { return document.getElementById(id); }
  function text(id, v) { var el = $(id); if (el) el.textContent = v; }
  function esc(s) { return App.escapeHtml(s); }

  async function loadMe() {
    var res = await App.api('/api/auth/me');
    if (!res.success || !res.data) {
      text('pfName', '暂时无法加载');
      text('pfUid', '--');
      return null;
    }
    var u = res.data;
    text('pfName', u.nickname || u.username || '用户');
    text('pfUid', u.invite_code || '--');
    text('pfUsername', u.username || '--');
    text('pfInvite', u.invite_code || '--');
    text('pfPhone', u.phone ? App.fmtPhone(u.phone) : '未绑定');
    text('pfEmail', u.email ? App.fmtEmail(u.email) : '未绑定');
    text('pfRole', ROLE_TEXT[u.role] || '成员');
    return u;
  }

  async function loadAvatar() {
    var res = await App.api('/api/avatars/mine');
    var img = $('pfAvatar');
    if (!img) return;
    if (res.success && res.data && res.data.avatar_url) img.src = res.data.avatar_url;
    img.addEventListener('error', function () { img.src = '/assets/avatars/official.jpg'; });
  }

  async function loadRealName() {
    var res = await App.api('/api/profile/real-name');
    var btn = $('pfSubmitRealName');
    if (!res.success || !res.data) {
      text('pfRealNameStatus', '--');
      if (btn) btn.hidden = true;
      return;
    }
    var d = res.data;
    var s = d.status || 'unsubmitted';
    var st = $('pfRealNameStatus');
    if (st) {
      st.innerHTML = '<span class="pf-badge ' + (REALNAME_CLASS[s] || '') + '">' +
        esc(REALNAME_TEXT[s] || '未提交') + '</span>';
    }
    text('pfRealName', d.real_name ? d.real_name : '未提交');
    var row = $('pfRemarkRow');
    if (row) {
      if (d.remark) { row.hidden = false; text('pfRemark', d.remark); }
      else row.hidden = true;
    }
    if (btn) {
      // 待审核或已通过时不再提示重复提交
      btn.hidden = (s === 'pending' || s === 'approved');
      btn.textContent = (s === 'rejected') ? '重新提交账户资料' : '提交账户资料';
    }
  }

  function bind() {
    var ca = $('pfChangeAvatar');
    if (ca) ca.addEventListener('click', function () { window.location.href = '/avatar.html'; });

    var en = $('pfEditNickname');
    if (en) en.addEventListener('click', async function () {
      var me = await App.api('/api/auth/me');
      var cur = (me.success && me.data && me.data.nickname) || '';
      var values = await App.openFormSheet({
        title: '修改昵称',
        okText: '保存',
        fields: [{ key: 'nickname', label: '昵称（2–24 字）', value: cur, placeholder: '请输入昵称' }],
        onSubmit: function (v) {
          var n = String(v.nickname || '').trim();
          var len = Array.from(n).length;
          if (len < 2 || len > 24) { App.toast('昵称须为 2–24 个字符', 'err'); return false; }
          return true;
        }
      });
      if (!values) return;
      var res = await App.api('/api/profile', { method: 'PATCH', body: { nickname: String(values.nickname).trim() } });
      if (!res.success) { App.toast(res.message || '昵称保存失败', 'err'); return; }
      App.toast('已保存', 'ok');
      loadMe();
    });

    var sr = $('pfSubmitRealName');
    if (sr) sr.addEventListener('click', async function () {
      var values = await App.openFormSheet({
        title: '提交账户资料',
        okText: '提交',
        fields: [{ key: 'real_name', label: '真实姓名', value: '', placeholder: '请输入与收款账户一致的姓名' }],
        onSubmit: function (v) {
          var n = String(v.real_name || '').trim();
          if (!REALNAME_RE.test(n)) { App.toast('请输入 2–50 位真实姓名（中文或英文）', 'err'); return false; }
          return true;
        }
      });
      if (!values) return;
      var res = await App.api('/api/profile/real-name', {
        method: 'POST',
        body: { real_name: String(values.real_name).trim() }
      });
      if (!res.success) { App.toast(res.message || '提交失败', 'err'); return; }
      App.toast('已提交，等待管理员审核', 'ok');
      loadRealName();
    });
  }

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(function () {
    if (!App.requireLogin()) return;
    var holder = $('pageHeader');
    if (holder) holder.innerHTML = App.headerHtml({ title: '个人资料', back: '/settings.html' });
    App.mountNav('me');
    bind();
    loadMe();
    loadAvatar();
    loadRealName();
  });
})();
