// ============================================
// 26牛牛 - 游戏群游戏操作卡片（聊天页内嵌）
// ============================================
// 架构约定（重要）：
//   游戏在「26牛牛游戏群」里进行，聊天消息流本身就是游戏消息流。
//   本模块只在聊天界面**上方**加一张操作卡片，用于：
//     1) 展示当前阶段 / 剩余时间 / 是否在座
//     2) 在需要玩家操作的阶段（抢庄、选倍数）提供按钮
//     3) 展示自己的牌（只展示自己的，绝不展示他人手牌）
//   卡片不改动聊天 UI（消息列表、输入框、贴图、红包全部原样保留），
//   没有可执行操作时自动隐藏，不占屏幕。
//
// 安全边界：
//   前端只提交 room / grab / bet_level 三个字段；
//   牌、牌型、结果、结算全部由服务器计算（utils/niuRoom + utils/niuEngine）。
// ============================================
(function () {
  'use strict';

  var API = '/api/game/niu';
  var POLL_MS = 5000;

  var S = {
    cfg: null,          // /config 返回的公开配置
    room: null,         // 当前关注的场次 key（?room=xxx 或默认第一个）
    snap: null,         // 该场次的实时状态（个人视角）
    timer: null,        // 倒计时本地 tick
    poll: null,         // 轮询兜底（Socket 断线时仍能更新）
    busy: false
  };

  // 支持 /group-chat.html?room=middle 直达指定场次（只接受配置内白名单 key）
  function roomFromUrl() {
    try {
      var m = /[?&]room=([a-z0-9_-]{1,20})/i.exec(location.search || '');
      return m ? String(m[1]).toLowerCase() : null;
    } catch (_) { return null; }
  }

  function $(id) { return document.getElementById(id); }
  function esc(s) { return App.escapeHtml(s); }

  // ---------- 阶段定义（与后端 config/niuGame.js 的 PHASE 对应）----------
  var PHASE_TEXT = {
    WAITING: '等待开局', GRABBING: '抢庄中', BETTING: '选择倍数',
    DEALING: '发牌中', RESULT: '开牌结果', SETTLEMENT: '结算中', FINISHED: '本局结束'
  };
  function phaseText(p) { return PHASE_TEXT[p] || '等待开局'; }

  function myId() {
    var u = App.getUser() || {};
    return Number(u.id || 0);
  }

  function fmt(n) {
    var v = Number(n || 0);
    return v.toFixed(2).replace(/\.00$/, '');
  }

  /** 我在座位表里的那一条（后端快照只带自己的牌，不含他人手牌） */
  function mySeat(snap) {
    if (!snap || !snap.players) return null;
    var id = myId();
    for (var i = 0; i < snap.players.length; i++) {
      if (Number(snap.players[i].user_id) === id) return snap.players[i];
    }
    return null;
  }

// ---------- 渲染 ----------
  function hide() {
    var c = $('niuCard');
    if (c) c.hidden = true;
  }

  function renderMeta() {
    var el = $('niuCardMeta');
    if (!el) return;
    if (!S.snap) { el.textContent = ''; return; }
    var p = mySeat(S.snap);
    var parts = [S.snap.players.length + '/' + S.snap.seat_limit + ' 人在座'];
    if (p) parts.push('我的积分 ' + fmt(p.points));
    if (S.snap.banker_id && Number(S.snap.banker_id) === myId()) parts.push('我是庄家');
    el.textContent = parts.join(' · ');
  }

  /** 当前场次的入座门槛（积分不足时引导领取每日免费积分） */
  function needPoints() {
    if (!S.cfg || !S.cfg.rooms) return 0;
    var r = null;
    for (var i = 0; i < S.cfg.rooms.length; i++) {
      if (S.cfg.rooms[i].key === S.room) { r = S.cfg.rooms[i]; break; }
    }
    return r ? Number(r.min_points || 0) : 0;
  }

  /** 本阶段我能否操作、可以做什么（阶段由后端决定，前端只负责呈现） */
  function actions(snap) {
    if (!snap) return [];
    var me = mySeat(snap);
    if (!me) {
      // 积分不足 → 先引导领取每日免费积分（唯一积分来源，服务端有当日闸门）
      var need = needPoints();
      var pts = Number((S.cfg && S.cfg.game_points) || 0);
      var today = new Date().toISOString().slice(0, 10);
      var claimed = String((S.cfg && S.cfg.daily_free_date) || '') >= today;
      if (need > 0 && pts < need && !claimed) {
        return [
          { key: 'daily', label: '领取每日积分' },
          { key: 'join', label: '进入' + (snap.room_name || '本场') }
        ];
      }
      return [{ key: 'join', label: '进入' + (snap.room_name || '本场') }];
    }
    var out = [];
    if (snap.phase === 'GRABBING' && !me.grab_locked) {
      out.push({ key: 'grab', label: '抢庄' });
      out.push({ key: 'nograb', label: '不抢' });
    }
    if (snap.phase === 'BETTING') {
      var levels = (S.cfg && S.cfg.bet_levels) || [1, 2, 3, 5];
      levels.forEach(function (lv) { out.push({ key: 'bet:' + lv, label: String(lv) + ' 倍' }); });
    }
    if (!out.length) out.push({ key: 'leave', label: '离开座位' });
    return out;
  }

  /** 我的牌面 + 服务器算出的牌型 */
  function handHtml(me) {
    var cards = (me.cards || []).map(function (c) {
      return '<span class="ngc-card' + (Number(c.point) === 10 ? ' ten' : '') + '">' +
        '<i>' + esc(c.suit_label || '') + '</i><b>' + esc(c.rank_label || c.rank) + '</b></span>';
    }).join('');
    var t = me.hand || {};
    return '<div class="ngc-cards">' + cards + '</div>' +
      '<div class="ngc-hand-name">' + esc(t.name || '') +
      (me.point_value ? ' ' + Number(me.point_value) + ' 点' : '') +
      (t.multiplier ? ' · ' + Number(t.multiplier) + ' 倍' : '') + '</div>';
  }

  function actsHtml(acts) {
    var html = '<div class="ngc-acts">';
    acts.forEach(function (a) {
      var cls = a.key === 'leave' ? 'btn btn-dark btn-sm' : 'btn btn-gold btn-sm';
      html += '<button class="' + cls + '" type="button" data-act="' + esc(a.key) + '">' +
        esc(a.label) + '</button>';
    });
    return html + '</div>';
  }

  function render() {
    var card = $('niuCard');
    var body = $('niuCardBody');
    var badge = $('niuCardPhase');
    var timerEl = $('niuCardTimer');
    if (!card || !body) return;
    if (!S.snap || !S.cfg || S.cfg.enabled === false) { hide(); return; }

    var me = mySeat(S.snap);
    // 不在座且当前是等待阶段 → 没有可做的事，完全不打扰聊天
    if (!me && S.snap.phase === 'WAITING') { hide(); renderMeta(); return; }

    card.hidden = false;
    if (badge) badge.textContent = phaseText(S.snap.phase);
    body.innerHTML = (me && me.hand ? handHtml(me) : '') + actsHtml(actions(S.snap));
    renderMeta();

    // 本地倒计时（只做显示，不参与任何判定）
    if (timerEl) {
      var left = Math.max(0, Math.round((new Date(S.snap.ends_at || 0).getTime() - Date.now()) / 1000));
      timerEl.textContent = left > 0 ? ('剩余 ' + left + ' 秒') : '';
    }
  }
// ---------- 网络 ----------
  // ---------- 实时推送（Socket 优先，5 秒轮询只做兜底）----------
  var offFns = [];

  function scheduleRefresh() {
    if (S.refreshPending) return;
    S.refreshPending = true;
    setTimeout(function () { S.refreshPending = false; loadState(); }, 250);
  }

  /**
   * 订阅当前场次的实时事件：
   *   niu:phase / niu:state / niu:grab_update / niu:bet_update / niu:reveal / niu:settled
   *     → 250ms 防抖后拉一次最新状态（手牌等隐私仍由服务端按人下发）
   *   niu:points（只有本人频道能收到）→ 直接更新积分显示
   *   niu:state_full → 订阅成功时服务端回推的完整快照
   */
  function setupSocket() {
    if (typeof App === 'undefined' || typeof App.socketOn !== 'function') return;
    ['niu:phase', 'niu:state', 'niu:grab_update', 'niu:bet_update', 'niu:reveal', 'niu:settled', 'niu:chat', 'niu:notice']
      .forEach(function (ev) {
        App.socketOn(ev, scheduleRefresh).then(function (off) { if (off) offFns.push(off); });
      });
    App.socketOn('niu:state_full', function (snap) {
      if (snap && snap.room_key && snap.room_key === S.room) { S.snap = snap; render(); }
    }).then(function (off) { if (off) offFns.push(off); });
    App.socketOn('niu:points', function (p) {
      if (!p) return;
      if (S.cfg) S.cfg.game_points = Number(p.game_points || 0);
      var me = mySeat(S.snap);
      if (me) me.points = Number(p.game_points || 0);
      render();
    }).then(function (off) { if (off) offFns.push(off); });
    App.socketEnsure().then(function () {
      if (S.room) App.socketEmit('niu:subscribe', S.room);
    });
  }

  function teardownSocket() {
    if (S.room && typeof App !== 'undefined' && typeof App.socketEmit === 'function') {
      App.socketEmit('niu:unsubscribe', S.room);
    }
    offFns.forEach(function (off) { try { off(); } catch (_) { /* 忽略 */ } });
    offFns = [];
  }

  // 必须走 App.api：它自动附加 Authorization: Bearer（后端 auth 中间件只认 Bearer，
  // 用裸 fetch 会导致全部请求 401，卡片静默失效）。
  // 返回保持 { status, data } 形态，避免改动下游调用。
  function req(method, path, body) {
    var opts = { method: method };
    if (body) opts.body = body;
    return App.api(API + path, opts).then(function (j) {
      var status = 200;
      if (!j || j.success === false) {
        status = (j && j.unauthorized) ? 401 : (j && j.network ? 0 : 400);
      }
      return { status: status, data: j || { success: false, message: '响应异常' } };
    }).catch(function () {
      return { status: 0, data: { success: false, message: '网络错误，请稍后重试' } };
    });
  }

  function loadCfg() {
    return req('GET', '/config').then(function (x) {
      if (!x.data || x.data.success === false) return null;
      S.cfg = x.data.data;
      // 场次：优先 URL 指定（白名单校验），否则取配置里的第一个
      var urlRoom = roomFromUrl();
      if (urlRoom && S.cfg.rooms && S.cfg.rooms.some(function (r) { return r.key === urlRoom; })) {
        S.room = urlRoom;
      }
      if (!S.room && S.cfg.rooms && S.cfg.rooms.length) S.room = S.cfg.rooms[0].key;
      return S.cfg;
    });
  }

  function loadState() {
    if (!S.room) return Promise.resolve(null);
    return req('GET', '/state?room=' + encodeURIComponent(S.room)).then(function (x) {
      if (!x.data || x.data.success === false) { S.snap = null; return null; }
      S.snap = x.data.data;
      render();
      return S.snap;
    });
  }

  function toast(msg) {
    if (typeof App !== 'undefined' && typeof App.toast === 'function') App.toast(msg);
    else if (typeof App !== 'undefined' && typeof App.showToast === 'function') App.showToast(msg);
  }

  function act(key) {
    if (S.busy) return;
    S.busy = true;
    var p;
    if (key === 'join') p = req('POST', '/join', { room: S.room });
    else if (key === 'leave') p = req('POST', '/leave', { room: S.room });
    else if (key === 'grab') p = req('POST', '/grab', { room: S.room, grab: 1 });
    else if (key === 'nograb') p = req('POST', '/grab', { room: S.room, grab: 0 });
    else if (key === 'daily') p = req('POST', '/daily-free', {});
    else if (key.indexOf('bet:') === 0) {
      p = req('POST', '/bet', { room: S.room, bet_level: Number(key.slice(4)) });
    } else return;
    p.then(function (x) {
      var okd = x.data && x.data.success !== false;
      if (!okd) toast((x.data && x.data.message) || '操作失败，请稍后重试');
      else if (x.data && x.data.message) toast(x.data.message);
      // 领取每日积分会改积分，配置里的 game_points / daily_free_date 也要刷新
      if (key === 'daily') return loadCfg().then(loadState);
      return loadState();
    }).catch(function () {
      toast('网络异常，请稍后重试');
    }).then(function () { S.busy = false; render(); });
  }

  // ---------- 本地倒计时（只显示，不判定）----------
  function tick() {
    if (!S.snap) return;
    var el = $('niuCardTimer');
    if (!el) return;
    var left = Math.max(0, Math.round((new Date(S.snap.ends_at || 0).getTime() - Date.now()) / 1000));
    el.textContent = left > 0 ? ('剩余 ' + left + ' 秒') : '';
    // 倒计时归零后主动拉一次，避免阶段切换延迟
    if (left === 0 && !S.busy) loadState();
  }

  // ---------- 事件绑定 ----------
  function bind() {
    var card = $('niuCard');
    if (!card || card.dataset.niuBound === '1') return;
    card.dataset.niuBound = '1';
    card.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('[data-act]') : null;
      if (!btn) return;
      var key = btn.getAttribute('data-act');
      if (key) act(key);
    });
  }

  // ---------- 对外暴露（供 chat-page.js 在切频道时调用）----------
  function onEnterGroup() {
    if (!$('niuCard')) return;              // 不在游戏群页面，不启动
    bind();
    loadCfg().then(function () {
      if (!S.cfg || S.cfg.enabled === false) { hide(); return; }
      if (S.timer) clearInterval(S.timer);
      S.timer = setInterval(tick, 1000);
      if (S.poll) clearInterval(S.poll);
      S.poll = setInterval(loadState, POLL_MS);   // Socket 断线兜底
      render();
      loadState().then(setupSocket);
    });
  }

  function onLeaveGroup() {
    if (S.timer) { clearInterval(S.timer); S.timer = null; }
    if (S.poll) { clearInterval(S.poll); S.poll = null; }
    teardownSocket();
    hide();
  }

  window.NiuChatCard = {
    onEnterGroup: onEnterGroup,
    onLeaveGroup: onLeaveGroup,
    refresh: loadState,
    isRoomGroup: function () { return !!$('niuCard'); }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onEnterGroup);
  } else {
    onEnterGroup();
  }
})();

