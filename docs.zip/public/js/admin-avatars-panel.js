// ============================================
// 26牛牛 - 管理后台「头像管理」面板（自包含）
// 数据源：/api/admin/avatar-categories、/api/admin/avatars（仅管理员，后端二次校验权限）
// 页面提供 <div id="adminAvatarsMount"></div> 即自动挂载
// ============================================
(function () {
  'use strict';

  var state = { cats: [], avatars: [], catFilter: 0, busy: false };

  function $(id) { return document.getElementById(id); }
  function esc(s) { return App.escapeHtml(s); }
  function num(v) { return Number(v) || 0; }

  function uploadFile(path, formData) {
    return fetch(path, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + (App.getToken() || '') },
      credentials: 'same-origin',
      body: formData
    }).then(function (r) { return r.json().catch(function () { return null; }); })
      .catch(function () { return { success: false, message: '网络错误，请稍后重试' }; });
  }

  function template() {
    return '' +
      '<p class="admin-note">头像只能由管理员在这里发布。普通用户只能在「我的 - 更换头像」中挑选已启用的头像，' +
      '不能上传、不能填写图片链接。停用头像后普通用户无法再选择，已使用该头像的用户不会失效。</p>' +

      '<div class="group-title">头像分类</div>' +
      '<div class="card" style="padding:12px">' +
        '<div class="admin-tools" style="flex-wrap:wrap;gap:8px">' +
          '<input class="input" id="avCatName" type="text" maxlength="32" placeholder="新分类名称" style="max-width:200px">' +
          '<input class="input" id="avCatSort" type="number" min="0" max="9999" value="0" placeholder="排序" style="max-width:100px">' +
          '<button class="btn btn-gold btn-sm" type="button" id="avCatAdd">新增分类</button>' +
        '</div>' +
        '<div id="avCatList" style="margin-top:12px"></div>' +
      '</div>' +

      '<div class="group-title">上传头像</div>' +
      '<div class="card" style="padding:12px">' +
        '<div class="admin-tools" style="flex-wrap:wrap;gap:8px">' +
          '<input class="input" id="avName" type="text" maxlength="80" placeholder="头像名称" style="max-width:200px">' +
          '<select class="input" id="avCat" style="max-width:180px"></select>' +
          '<input class="input" id="avSort" type="number" min="0" max="9999" value="0" placeholder="排序" style="max-width:100px">' +
          '<input class="input" id="avFile" type="file" accept="image/jpeg,image/png,image/webp" style="max-width:260px">' +
          '<button class="btn btn-gold btn-sm" type="button" id="avUpload">上传并发布</button>' +
        '</div>' +
        '<p class="admin-note" style="margin-top:8px">支持 JPG / JPEG / PNG / WEBP，单张不超过 3MB。已存在的站内图片也可以填路径后点「按路径添加」。</p>' +
        '<div class="admin-tools" style="flex-wrap:wrap;gap:8px">' +
          '<input class="input" id="avPath" type="text" maxlength="200" placeholder="/assets/avatars/official/xxx.jpg" style="max-width:320px">' +
          '<button class="btn btn-dark btn-sm" type="button" id="avPathAdd">按路径添加</button>' +
        '</div>' +
      '</div>' +

      '<div class="group-title">头像列表</div>' +
      '<div class="admin-tools" style="flex-wrap:wrap;gap:8px">' +
        '<select class="input" id="avFilter" style="max-width:200px"></select>' +
        '<button class="btn btn-dark btn-sm" type="button" id="avReload">刷新</button>' +
      '</div>' +
      '<div id="avList" style="margin-top:12px"></div>';
  }

  function catOptions(selected) {
    var html = '<option value="0">未分类</option>';
    state.cats.forEach(function (c) {
      html += '<option value="' + c.id + '"' + (Number(selected) === c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>';
    });
    return html;
  }

  function renderCats() {
    var box = $('avCatList');
    if (!box) return;
    if (!state.cats.length) {
      box.innerHTML = App.stateBox('empty', '暂无分类', '可以只使用「未分类」，也可以先新建分类。');
      return;
    }
    box.innerHTML = state.cats.map(function (c) {
      return '<div class="list-row" style="display:flex;align-items:center;gap:10px">' +
        '<div style="flex:1 1 auto;min-width:0">' +
          '<div style="font-size:14px">' + esc(c.name) + '</div>' +
          '<div style="font-size:12px;color:var(--text-secondary)">排序 ' + esc(c.sort_order) + ' · ' + (c.is_active ? '已启用' : '已停用') + '</div>' +
        '</div>' +
        '<button class="btn btn-dark btn-sm" type="button" data-cat-edit="' + c.id + '">改名</button>' +
        '<button class="btn ' + (c.is_active ? 'btn-dark' : 'btn-gold') + ' btn-sm" type="button" data-cat-status="' + c.id + '" data-next="' + (c.is_active ? 0 : 1) + '">' +
          (c.is_active ? '停用' : '启用') + '</button>' +
      '</div>';
    }).join('');
  }

  function renderAvatars() {
    var box = $('avList');
    if (!box) return;
    if (!state.avatars.length) {
      box.innerHTML = App.stateBox('empty', '暂无头像', '上传官方头像后，普通用户才能更换头像。');
      return;
    }
    box.innerHTML = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px">' +
      state.avatars.map(function (a) {
        return '<div class="card" style="padding:10px">' +
          '<img src="' + esc(a.image_path) + '" alt="' + esc(a.name) + '" loading="lazy" ' +
            'style="width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:12px;border:1px solid var(--border)">' +
          '<div style="margin-top:8px;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(a.name) + '</div>' +
          '<div style="margin-top:4px;font-size:12px;color:var(--text-secondary)">' + esc(a.category_name || '未分类') + ' · 排序 ' + esc(a.sort_order) + '</div>' +
          '<div style="margin-top:4px;font-size:12px;color:' + (a.is_active ? 'var(--success)' : 'var(--text-muted)') + '">' +
            (a.is_active ? '已启用' : '已停用') + ' · 使用中 ' + num(a.used_count) + '</div>' +
          '<div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap">' +
            '<button class="btn btn-dark btn-sm" type="button" data-av-edit="' + a.id + '">编辑</button>' +
            '<button class="btn ' + (a.is_active ? 'btn-dark' : 'btn-gold') + ' btn-sm" type="button" data-av-status="' + a.id + '" data-next="' + (a.is_active ? 0 : 1) + '">' +
              (a.is_active ? '停用' : '启用') + '</button>' +
            '<button class="btn btn-danger btn-sm" type="button" data-av-del="' + a.id + '">删除</button>' +
          '</div>' +
        '</div>';
      }).join('') + '</div>';
  }

  function fillSelects() {
    var cat = $('avCat');
    if (cat) cat.innerHTML = catOptions(cat.value);
    var f = $('avFilter');
    if (f) {
      var keep = state.catFilter;
      f.innerHTML = '<option value="0">全部头像</option>' + state.cats.map(function (c) {
        return '<option value="' + c.id + '">' + esc(c.name) + '</option>';
      }).join('');
      f.value = String(keep);
    }
  }

  async function loadAll() {
    var box = $('avList');
    if (box) App.showLoading(box, '正在加载头像库...');
    var cRes = await App.api('/api/admin/avatar-categories');
    if (!cRes.success) { App.showError(box, cRes.message || '分类加载失败', loadAll); return; }
    state.cats = (cRes.data && cRes.data.categories) || [];
    var aRes = await App.api('/api/admin/avatars' + (state.catFilter ? ('?category_id=' + state.catFilter) : ''));
    if (!aRes.success) { App.showError(box, aRes.message || '头像加载失败', loadAll); return; }
    state.avatars = (aRes.data && aRes.data.avatars) || [];
    renderCats();
    fillSelects();
    renderAvatars();
  }

  // ---------- 操作 ----------
  async function addCategory() {
    var name = ($('avCatName') || {}).value || '';
    if (!String(name).trim()) { App.toast('请输入分类名称', 'err'); return; }
    var res = await App.api('/api/admin/avatar-categories', {
      method: 'POST',
      body: { name: String(name).trim(), sort_order: ($('avCatSort') || {}).value || 0 }
    });
    if (!res.success) { App.toast(res.message || '新增分类失败', 'err'); return; }
    App.toast('分类已新增', 'ok');
    if ($('avCatName')) $('avCatName').value = '';
    loadAll();
  }

  async function editCategory(id) {
    var c = state.cats.filter(function (x) { return x.id === id; })[0];
    if (!c) return;
    var values = await App.openFormSheet({
      title: '修改分类',
      okText: '保存',
      fields: [
        { key: 'name', label: '分类名称', value: c.name },
        { key: 'sort_order', label: '排序', value: String(c.sort_order) }
      ],
      onSubmit: function (v) {
        if (!String(v.name || '').trim()) { App.toast('分类名称不能为空', 'err'); return false; }
        return true;
      }
    });
    if (!values) return;
    var res = await App.api('/api/admin/avatar-categories/' + id, {
      method: 'PUT', body: { name: String(values.name).trim(), sort_order: values.sort_order }
    });
    if (!res.success) { App.toast(res.message || '更新分类失败', 'err'); return; }
    App.toast('分类已更新', 'ok');
    loadAll();
  }

  async function setCategoryStatus(id, next) {
    var res = await App.api('/api/admin/avatar-categories/' + id + '/status', {
      method: 'POST', body: { is_active: next }
    });
    if (!res.success) { App.toast(res.message || '更新分类状态失败', 'err'); return; }
    App.toast(next ? '分类已启用' : '分类已停用', 'ok');
    loadAll();
  }

  async function doUpload() {
    var fileEl = $('avFile');
    var file = fileEl && fileEl.files && fileEl.files[0];
    if (!file) { App.toast('请选择要上传的头像图片', 'err'); return; }
    var fd = new FormData();
    fd.append('file', file);
    fd.append('name', ($('avName') || {}).value || '');
    fd.append('category_id', ($('avCat') || {}).value || '0');
    fd.append('sort_order', ($('avSort') || {}).value || '0');
    var btn = $('avUpload');
    if (btn) btn.disabled = true;
    var res = await uploadFile('/api/admin/avatars/upload', fd);
    if (btn) btn.disabled = false;
    if (!res || !res.success) { App.toast((res && res.message) || '头像上传失败，请重新选择图片', 'err'); return; }
    App.toast('头像已发布', 'ok');
    if (fileEl) fileEl.value = '';
    loadAll();
  }

  async function addByPath() {
    var p = ($('avPath') || {}).value || '';
    if (!String(p).trim()) { App.toast('请填写头像图片路径', 'err'); return; }
    var res = await App.api('/api/admin/avatars', {
      method: 'POST',
      body: {
        name: ($('avName') || {}).value || '官方头像',
        image_path: String(p).trim(),
        category_id: ($('avCat') || {}).value || 0,
        sort_order: ($('avSort') || {}).value || 0
      }
    });
    if (!res.success) { App.toast(res.message || '新增头像失败', 'err'); return; }
    App.toast('头像已添加', 'ok');
    if ($('avPath')) $('avPath').value = '';
    loadAll();
  }

  async function editAvatar(id) {
    var a = state.avatars.filter(function (x) { return x.id === id; })[0];
    if (!a) return;
    var values = await App.openFormSheet({
      title: '编辑头像',
      okText: '保存',
      fields: [
        { key: 'name', label: '头像名称', value: a.name },
        { key: 'category_id', label: '分类ID（0 表示未分类）', value: String(a.category_id || 0) },
        { key: 'sort_order', label: '排序', value: String(a.sort_order) }
      ],
      onSubmit: function (v) {
        if (!String(v.name || '').trim()) { App.toast('头像名称不能为空', 'err'); return false; }
        return true;
      }
    });
    if (!values) return;
    var res = await App.api('/api/admin/avatars/' + id, {
      method: 'PUT',
      body: {
        name: String(values.name).trim(),
        category_id: values.category_id,
        sort_order: values.sort_order
      }
    });
    if (!res.success) { App.toast(res.message || '更新头像失败', 'err'); return; }
    App.toast('头像已更新', 'ok');
    loadAll();
  }

  async function setAvatarStatus(id, next) {
    var res = await App.api('/api/admin/avatars/' + id + '/status', {
      method: 'POST', body: { is_active: next }
    });
    if (!res.success) { App.toast(res.message || '更新头像状态失败', 'err'); return; }
    App.toast(next ? '头像已启用' : '头像已停用', 'ok');
    loadAll();
  }

  async function deleteAvatar(id) {
    var yes = await App.confirmDialog({
      title: '删除头像',
      text: '删除后无法恢复。若仍有用户正在使用该头像，系统会拒绝删除并建议改为停用。',
      okText: '删除',
      danger: true
    });
    if (!yes) return;
    var res = await App.api('/api/admin/avatars/' + id, { method: 'DELETE' });
    if (!res.success) { App.toast(res.message || '删除头像失败', 'err'); return; }
    App.toast('头像已删除', 'ok');
    loadAll();
  }

  function bind(root) {
    root.addEventListener('click', function (ev) {
      var cl = ev.target && ev.target.closest ? ev.target.closest('button') : null;
      if (!cl) return;
      if (cl.id === 'avCatAdd') return addCategory();
      if (cl.id === 'avUpload') return doUpload();
      if (cl.id === 'avPathAdd') return addByPath();
      if (cl.id === 'avReload') return loadAll();
      if (cl.dataset.catEdit) return editCategory(parseInt(cl.dataset.catEdit, 10));
      if (cl.dataset.catStatus) return setCategoryStatus(parseInt(cl.dataset.catStatus, 10), parseInt(cl.dataset.next, 10));
      if (cl.dataset.avEdit) return editAvatar(parseInt(cl.dataset.avEdit, 10));
      if (cl.dataset.avStatus) return setAvatarStatus(parseInt(cl.dataset.avStatus, 10), parseInt(cl.dataset.next, 10));
      if (cl.dataset.avDel) return deleteAvatar(parseInt(cl.dataset.avDel, 10));
      return undefined;
    });
    root.addEventListener('change', function (ev) {
      if (ev.target && ev.target.id === 'avFilter') {
        state.catFilter = parseInt(ev.target.value, 10) || 0;
        loadAll();
      }
    });
  }

  function mountPanel(root) {
    root.innerHTML = template();
    bind(root);
    loadAll();
  }

  window.AdminAvatarsPanel = { refresh: loadAll };

  function ready(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }

  ready(function () {
    var el = document.getElementById('adminAvatarsMount');
    if (el && !el.dataset.aap) { el.dataset.aap = '1'; mountPanel(el); }
  });
})();
