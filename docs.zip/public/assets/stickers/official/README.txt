26牛牛 - 官方贴图放置说明
=========================

⚠️ 官方贴图必须使用【真实图片】，禁止使用 emoji。

放置位置: public/assets/stickers/official/

支持的文件名（可只放其中几个，放多少显示多少）:
  welcome.png    欢迎
  hello.png      你好
  thanks.png     谢谢
  goodluck.png   加油
  win.png        赢了
  gg.png         下次再来
  cheer.png      助威
  angry.png      生气
  cry.png        哭泣
  rich.png       发财

也支持 .jpg / .jpeg / .webp / .gif，文件名不变（改扩展名即可）。

未放入任何官方贴图时，聊天页面的「官方贴图」分类会显示空状态提示，
不会显示 emoji，也不会产生 404 请求。

用户自己上传的贴图保存在 public/assets/stickers/user/（由后端写入）。