26牛牛 - 游戏图标放置说明
=========================

放置位置: public/assets/games/

建议文件名（与 config/games.js 中 logo_candidates 对应）:
  26niuniu.png / 26niuniu.svg      26牛牛娱乐场

支持 .png / .jpg / .jpeg / .webp / .svg

新增游戏时:
  1. 在 config/games.js 的 GAMES 数组追加一项（id / name / intro / entry / tag）
  2. 把图标放到本目录，文件名与该项的 logo_candidates 一致
  3. 大厅会自动渲染新的 GameCard，无需重新设计大厅

未放入图标时，卡片显示无图占位（首字母），不会产生 404 请求。