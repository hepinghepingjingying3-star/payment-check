26牛牛 - 玩法教学插图放置说明
=============================

放置位置: public/assets/tutorial/

建议文件名:
  points.png        点数说明插图
  card-types.png    牌型倍数插图
  flow.png          游戏流程插图
  banker.png        庄家/闲家插图
  multiplayer.png   多人对战插图
  tips.png          注意事项插图

支持 .png / .jpg / .jpeg / .webp / .svg

说明:
  - 教学页面为纯教学页（无聊天输入框、无玩家消息、无红包、无贴图）
  - 页面会展示本目录下真实存在的插图；没有时只显示文字与步骤卡片
  - 不会产生 404 请求