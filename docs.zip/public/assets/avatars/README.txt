26牛牛 - 官方头像 / 头像类素材放置说明
======================================

放置位置: public/assets/avatars/

建议文件（可只放其中几个）:
  official.png   官方头像（默认）
  group.png      26牛牛游戏群头像
  support.png    在线客服头像
  system.png     系统消息头像

支持 .png / .jpg / .jpeg / .webp / .svg

说明:
  - 游戏群会优先使用 group.*，客服优先使用 support.*
  - 未放入时，列表与聊天页使用无图占位（图标 + 首字母），不会产生 404
  - 建议 256x256 透明 PNG