26牛牛 - 轮播公告图片放置说明
=============================

放置位置: public/assets/banners/

支持文件名: banner1.png ~ banner5.png（也支持 .jpg / .webp / .svg）

如何让公告显示图片:
  1. 把图片放入本目录
  2. 在公告数据（announcements 表或 config/announcements.js）中把 image 字段
     写成站内路径，例如: /assets/banners/banner1.png

说明:
  - 文字公告不需要图片
  - 图片公告建议尺寸 750x360 左右，比例约 2:1，前端会自动裁切显示
  - 未放入图片时，轮播显示文字卡片，不会产生 404 请求