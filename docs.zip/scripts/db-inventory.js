// ============================================
// 26牛牛 - 数据库结构清单生成器（只读）
// ============================================
// 运行: node scripts/db-inventory.js
// 作用: 读取 information_schema，输出 docs/db-structure.md
//       包含：表 + 真实行数 + 注释 + 索引；关键表列出字段类型
// 边界: 全程只读，绝不建表 / 改表 / 删数据
// ============================================
'use strict';

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'docs', 'db-structure.md');
const DB = process.env.DB_NAME;

/** 结构文档里重点展开的表（其余只列表名 / 行数 / 索引） */
const DETAIL = [
  'users', 'balance_transactions', 'wallet_orders', 'recharge_orders', 'withdraw_requests',
  'referral_relations', 'chat_messages', 'notifications', 'registration_otp', 'avatars',
  'niu_rounds', 'niu_round_players', 'niu_user_stats', 'system_settings'
];

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: DB
  });
  const [tables] = await conn.query(
    `SELECT TABLE_NAME t, TABLE_ROWS r, TABLE_COMMENT c, CREATE_TIME ct
       FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME`, [DB]);
  const [idx] = await conn.query(
    `SELECT TABLE_NAME t, INDEX_NAME n, NON_UNIQUE nu, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) cols
       FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = ?
      GROUP BY TABLE_NAME, INDEX_NAME, NON_UNIQUE ORDER BY TABLE_NAME, INDEX_NAME`, [DB]);
  const [cols] = await conn.query(
    `SELECT TABLE_NAME t, COLUMN_NAME n, COLUMN_TYPE ty, IS_NULLABLE nl, COLUMN_DEFAULT df, EXTRA x
       FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME, ORDINAL_POSITION`, [DB]);
  await conn.end();

  const idxBy = new Map();
  idx.forEach(i => {
    if (!idxBy.has(i.t)) idxBy.set(i.t, []);
    idxBy.get(i.t).push(i);
  });
  const colBy = new Map();
  cols.forEach(c => {
    if (!colBy.has(c.t)) colBy.set(c.t, []);
    colBy.get(c.t).push(c);
  });

  const L = [];
  L.push('# 26牛牛 - 数据库结构清单');
  L.push('');
  L.push('> 由 `node scripts/db-inventory.js` 自动生成（只读扫描 information_schema），请勿手工编辑。');
  L.push('> 数据库：`' + DB + '` · 表数量：**' + tables.length + '** · 生成时间：' + new Date().toISOString());
  L.push('');
  L.push('## 说明');
  L.push('');
  L.push('- 所有结构变更只能通过 `database/migrations/*.js` 增量迁移完成（全部为安全增量，不 DROP、不 TRUNCATE）。');
  L.push('- 一次性执行全部迁移：`node database/migrations/run-all.js`');
  L.push('- 行数为 InnoDB 估算值（`information_schema.TABLE_ROWS`），仅用于判断「是否有真实数据」。');
  L.push('- `niu_*` 三张表属于 26牛牛娱乐场（非现金化游戏积分），与旧红包对战表（`game_*`）互不复用。');
  L.push('');
  L.push('## 表清单');
  L.push('');
  L.push('| 表 | 估算行数 | 说明 |');
  L.push('| --- | --- | --- |');
  tables.forEach(t => L.push('| `' + t.t + '` | ' + Number(t.r || 0) + ' | ' + String(t.c || '').replace(/\|/g, '/') + ' |'));
  L.push('');
  L.push('## 索引');
  L.push('');
  tables.forEach(t => {
    const list = idxBy.get(t.t) || [];
    if (!list.length) return;
    L.push('### `' + t.t + '`');
    L.push('');
    list.forEach(i => L.push('- ' + (Number(i.nu) === 0 ? '**唯一** ' : '') + '`' + i.n + '` (' + i.cols + ')'));
    L.push('');
  });
  L.push('## 关键字段');
  L.push('');
  DETAIL.forEach(t => {
    if (!colBy.has(t)) return;
    L.push('### `' + t + '`');
    L.push('');
    L.push('| 字段 | 类型 | 可空 | 默认 | 备注 |');
    L.push('| --- | --- | --- | --- | --- |');
    colBy.get(t).forEach(c => L.push('| `' + c.n + '` | ' + c.ty.replace(/\|/g, '/') + ' | ' + c.nl + ' | ' +
      (c.df === null ? 'NULL' : '`' + String(c.df).replace(/\|/g, '/') + '`') + ' | ' + (c.x || '') + ' |'));
    L.push('');
  });

  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, L.join('\n'), 'utf8');
  console.log('DB_STRUCTURE_WRITTEN ' + path.relative(ROOT, OUT) + ' tables=' + tables.length);
}

main().catch(e => { console.error('DB_INVENTORY_FAILED: ' + e.message); process.exitCode = 1; });
