// ============================================
// 26牛牛 - 一次性清理：自动化压测遗留的 26牛牛娱乐场测试数据 + 测试机器人账号
// ============================================
// 清理范围（全部只针对本轮自动化测试产生的数据）:
//   1) niu_round_players / niu_rounds            —— 全部由压测产生
//   2) niu_user_stats                            —— 只删测试账号的
//   3) balance_transactions 中 currency_type='GAME_POINTS' —— 只删测试账号的
//   4) 测试机器人账号（用户名以 test 开头）：testuser1/2/3、test_*_s7
//   5) users.game_points 归零                    —— 只清测试账号
//
// 绝不触碰: bobo / 37491058 / dodo / hondee35132 / koko 等真实用户，
//          包括管理员 bobo 由「每日免费积分」真实发放的 1000 积分与其流水，
//          以及 admin.html、聊天记录、钱包订单、充值提现、头像等任何既有业务数据。
// 真实用户的积分与流水必须保持「余额 = 流水累计」的一致性，不做归零处理。
// 每日免费积分在需要时会由系统自动补发，因此测试账号归零后功能完全正常。
// ============================================
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const db = require('../config/db');

(async () => {
  const conn = db.promise();
  const removed = {};
  const bump = (k, n) => { if (n) removed[k] = (removed[k] || 0) + n; };

  // 先锁定测试账号（后续所有删除都限定在这个 id 集合内）
  const [bots] = await conn.query("SELECT id, username FROM users WHERE username LIKE 'test%' ORDER BY id");
  if (!bots.length) {
    console.log('没有测试账号，无需清理');
  } else {
    const list = bots.map(b => Number(b.id)).join(',');
    console.log('待删测试账号：' + bots.map(b => b.id + ':' + b.username).join(', '));

    // 1) 26牛牛娱乐场对局
    //   安全前提：只删除「全部参与者都是测试账号」的整局；只要有一局含真实用户就整局保留，
    //   绝不为清理数据而破坏真实用户的对局记录。
    const [mixed] = await conn.query(
      'SELECT COUNT(*) c FROM niu_rounds r WHERE EXISTS (SELECT 1 FROM niu_round_players p WHERE p.round_id = r.id AND p.user_id NOT IN (' + list + '))');
    const mixedCount = Number(mixed[0].c);
    if (mixedCount) {
      console.log('⚠ 存在 ' + mixedCount + ' 局含真实用户的对局，这些局将完整保留，只清理纯测试局');
    }
    const [rp] = await conn.query(
      'DELETE FROM niu_round_players WHERE round_id IN (' +
      'SELECT id FROM (SELECT r.id FROM niu_rounds r WHERE NOT EXISTS (' +
      'SELECT 1 FROM niu_round_players p2 WHERE p2.round_id = r.id AND p2.user_id NOT IN (' + list + '))) AS pure' +
      ') OR user_id IN (' + list + ')');
    bump('niu_round_players', rp.affectedRows);
    const [rr] = await conn.query(
      'DELETE FROM niu_rounds WHERE id NOT IN (SELECT round_id FROM niu_round_players)');
    bump('niu_rounds', rr.affectedRows);
    const [us] = await conn.query('DELETE FROM niu_user_stats WHERE user_id IN (' + list + ')');
    bump('niu_user_stats', us.affectedRows);

    // 2) 游戏积分流水：只删测试账号的（真实用户的每日免费积分流水必须保留）
    const [lt] = await conn.query(
      "DELETE FROM balance_transactions WHERE currency_type = 'GAME_POINTS' AND user_id IN (" + list + ")");
    bump('balance_transactions(GAME_POINTS)', lt.affectedRows);

    // 3) 余额归零（只清测试账号：没有流水就没有余额）
    const [up] = await conn.query(
      'UPDATE users SET game_points = 0.00 WHERE id IN (' + list + ') AND game_points <> 0');
    bump('users.game_points=0', up.affectedRows);

    // 4) 删除测试机器人账号及其全部历史引用
    // 先清所有外键引用
    const [fks] = await conn.query(
      `SELECT table_name AS t, column_name AS c FROM information_schema.key_column_usage
       WHERE referenced_table_name = 'users' AND table_schema = DATABASE()`);
    let remaining = fks.slice();
    for (let pass = 0; pass < 4 && remaining.length; pass++) {
      const next = [];
      for (const fk of remaining) {
        try {
          const [r] = await conn.query('DELETE FROM `' + fk.t + '` WHERE `' + fk.c + '` IN (' + list + ')');
          bump(fk.t, r.affectedRows);
        } catch (_) { next.push(fk); }
      }
      remaining = next;
    }
    // 再清无外键的历史引用（表名与列名均为固定白名单）
    const legacy = [
      ['chat_read_state', 'user_id'], ['user_presence', 'user_id'], ['user_stickers', 'user_id'],
      ['chat_messages', 'user_id'], ['chat_reports', 'reporter_id'],
      ['chat_red_packet_claims', 'user_id'], ['chat_red_packets', 'sender_id'],
      ['wallet_orders', 'user_id'], ['balance_transactions', 'user_id'],
      ['notifications', 'user_id'], ['login_logs', 'user_id'],
      ['admin_logs', 'admin_id'], ['admin_logs', 'target_user_id'],
      ['admin_approvals', 'requested_by'], ['admin_approvals', 'reviewed_by'], ['admin_approvals', 'target_user_id'],
      ['referral_rewards', 'user_id'], ['referral_rewards', 'source_user_id'],
      ['referral_relations', 'referrer_id'], ['referral_relations', 'referred_user_id'],
      ['real_name_reviews', 'user_id'], ['password_reset_tokens', 'user_id'],
      ['room_players', 'user_id'], ['game_rooms', 'banker_id'],
      ['game_rounds', 'banker_id'], ['banker_bids', 'user_id'], ['player_bets', 'user_id'],
      ['registration_otp', 'user_id'], ['recent_visits', 'user_id']
    ];
    for (const [t, c] of legacy) {
      try {
        const [cols] = await conn.query(
          `SELECT 1 FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1`, [t, c]);
        if (!cols.length) continue;
        const [r] = await conn.query('DELETE FROM `' + t + '` WHERE `' + c + '` IN (' + list + ')');
        bump(t + '.' + c, r.affectedRows);
      } catch (_) {}
    }
    const [d] = await conn.query('DELETE FROM users WHERE id IN (' + list + ')');
    bump('users', d.affectedRows);
  }

  // 5) 清理自动化压测遗留的「零影响」对局
  //   判定条件（三者同时满足才删，最大限度保护真实对局）:
  //     a) 整局所有明细的 delta 全为 0（不产生任何积分变动）
  //     b) 整局所有明细的 result 都是 DRAW（没有真实胜负）
  //     c) 整局只有 1 名参与者（压测时被中途清理后剩下的空壳局）
  const [zero] = await conn.query(`
    SELECT r.id, COUNT(*) c, IFNULL(SUM(ABS(p.delta)),0) moved
    FROM niu_rounds r JOIN niu_round_players p ON p.round_id = r.id
    GROUP BY r.id
    HAVING c = 1 AND moved = 0 AND SUM(p.result = 'DRAW') = c`);
  const zeroIds = zero.map(z => Number(z.id));
  if (zeroIds.length) {
    const ids = zeroIds.join(',');
    const [zrp] = await conn.query('DELETE FROM niu_round_players WHERE round_id IN (' + ids + ')');
    const [zrr] = await conn.query('DELETE FROM niu_rounds WHERE id IN (' + ids + ')');
    bump('零影响空壳对局(players)', zrp.affectedRows);
    bump('零影响空壳对局(rounds)', zrr.affectedRows);
  } else {
    console.log('没有可安全清理的零影响对局');
  }

  console.log('清理结果：' + JSON.stringify(removed, null, 1));
  const [left] = await conn.query('SELECT COUNT(*) c FROM niu_rounds');
  const [users] = await conn.query('SELECT id, username, role, game_points FROM users ORDER BY id');
  const [gpx] = await conn.query("SELECT COUNT(*) c, IFNULL(SUM(amount),0) s FROM balance_transactions WHERE currency_type='GAME_POINTS'");
  console.log('剩余对局：' + left[0].c);
  console.log('剩余游戏积分流水：' + gpx[0].c + ' 条 / 合计 ' + gpx[0].s);
  console.log('剩余用户：' + users.map(u => u.id + ':' + u.username + '(' + u.role + ',积分' + u.game_points + ')').join(', '));
  await conn.end();
})().catch(e => { console.error('清理失败:', e.message); process.exitCode = 1; });
