import os

img_dir = r"C:\26niuniu\public\assets\img"
os.makedirs(img_dir, exist_ok=True)

# Minimal valid JPEGs (single-pixel placeholders)
mer_bytes = bytes.fromhex('ffd8ffe000104a46494600010101004800480000ffdbed647667c2423c42001040302010203ffff')
line_bytes = bytes.fromhex('ffd8ffe000104a46494600010101004800480000ffdbed647667c2423c4200204030201020304ffff')
skip_bytes = bytes.fromhex('ffd8ffe000104a46494600010101004800480000ffdbed647667c2423c4200304030201020305ffff')
wave_bytes = bytes.fromhex('ffd8ffe000104a46494600010101004800480000ffdbed647667c2423c4200404030201020306ffff')

files = {
    'mer.jpg': mer_bytes,
    'line.jpg': line_bytes,
    'skip.jpg': skip_bytes,
    'wave.jpg': wave_bytes,
}

for name, data in files.items():
    with open(os.path.join(img_dir, name), 'wb') as f:
        f.write(data)

print('Created placeholder JPEGs:', ', '.join(files.keys()))
