// ============================================
// 26牛牛 - API 清单生成器
// ============================================
// 运行: node scripts/api-inventory.js
// 作用: 扫描 routes/*.js 里的 router.<method>('<path>', <守卫>...)，
//       结合 server.js 的挂载顺序，输出 docs/api-list.md（权限标注来自守卫名）
// 说明: 只读扫描源码，不连接数据库；每次新增接口后重跑即可保持文档同步
// ============================================
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const ROUTES_DIR = path.join(ROOT, 'routes');
const OUT = path.join(ROOT, 'docs', 'api-list.md');

/** server.js 中的挂载与说明（与 server.js 保持一致） */
const MOUNTS = [
  { file: 'auth.js', title: '认证 / OTP / 账号安全' },
  { file: 'recovery.js', title: '找回密码' },
  { file: 'profile.js', title: '个人资料 / 头像 / 客服' },
  { file: 'lobby.js', title: '大厅聚合（公告 / 通知）' },
  { file: 'home.js', title: '大厅首页数据' },
  { file: 'announcements.js', title: '公告' },
  { file: 'notifications.js', title: '通知（铃铛 / 我的消息）' },
  { file: 'wallet.js', title: '钱包（余额 / 流水）' },
  { file: 'deposits.js', title: '充值下单' },
  { file: 'recharge.js', title: '充值向导（订单 / 凭证）' },
  { file: 'withdrawals.js', title: '提现申请' },
  { file: 'transfers.js', title: '筹码转账' },
  { file: 'pay-password.js', title: '支付密码' },
  { file: 'niu.js', title: '26牛牛娱乐场（非现金化娱乐积分）' },
  { file: 'game.js', title: '旧红包对战（只读兼容）' },
  { file: 'promote.js', title: '推广 / 邀请' },
  { file: 'referral.js', title: '推广关系补充接口' },
  { file: 'chat.js', title: '聊天（游戏群 / 在线客服）' },
  { file: 'chat-moderation.js', title: '聊天禁言 / 举报' },
  { file: 'avatars.js', title: '官方头像库（用户端）' },
  { file: 'stickers.js', title: '贴图' },
  { file: 'settings.js', title: '用户协议 / 隐私 / 语言' },
  { file: 'support-guest.js', title: '游客客服' },
  { file: 'admin.js', title: '管理后台（核心）' },
  { file: 'admin-funds.js', title: '管理后台（资金 / 审核）' },
  { file: 'admin-recharge.js', title: '管理后台（充值审核）' },
  { file: 'admin-otp.js', title: '管理后台 / 客服（OTP）' },
  { file: 'admin-support.js', title: '管理后台（客服线程）' },
  { file: 'admin-avatars.js', title: '管理后台（头像库）' },
  { file: 'admin-ops.js', title: '管理后台（运营 / 对局 / 游戏入口 / 通知）' },
  { file: 'admin-niu.js', title: '管理后台（26牛牛娱乐场）' },
  { file: 'admin-search.js', title: '管理后台（搜索）' },
  { file: 'health.js', title: '健康检查' }
];

/** 守卫 → 权限文字 */
function guardOf(args) {
  if (/requireAdmin|requireRole\(\s*'admin'\s*\)/.test(args)) return '管理员';
  if (/requireRole\([^)]*'support'/.test(args)) return /'admin'\s*,\s*'support'/.test(args) ? '管理员 / 客服' : '客服';
  if (/\bauth\b|requireAuth|authRequired/.test(args)) return '登录用户';
  if (/guestToken|guestCapability/.test(args)) return '游客令牌';
  return '公开';
}

function scan(file) {
  const src = fs.readFileSync(path.join(ROUTES_DIR, file), 'utf8');
  // 先收集「路径前缀常量」：如 const PREFIX = '/game/niu'，路由写作 router.get(PREFIX + '/config', ...)
  const consts = {};
  const cre = /const\s+([A-Za-z_$][\w$]*)\s*=\s*'(\/[^']*)'/g;
  let cm;
  while ((cm = cre.exec(src))) consts[cm[1]] = cm[2];
  const rows = [];
  const re = /(router)\.(get|post|put|patch|delete)\(\s*(?:(\w+)\s*\+\s*)?(['"`])([^'"`]+)\4([\s\S]{0,140}?)[,)]/g;
  let m;
  while ((m = re.exec(src))) {
    const method = m[2].toUpperCase();
    const prefix = m[3] ? (consts[m[3]] || '') : '';   // PREFIX + '/x' -> '/prefix/x'
    let p = prefix + m[5];
    p = p.startsWith('/') ? p : '/' + p;
    const args = (m[1] || '') + m[3] + m[6];
    rows.push({ method: method, path: p, guard: guardOf(args) });
  }
  // 去重（同 method+path 只保留权限最高的一条）
  const rank = { '公开': 0, '游客令牌': 1, '登录用户': 2, '管理员 / 客服': 3, '客服': 3, '管理员': 4 };
  const map = new Map();
  rows.forEach(r => {
    const k = r.method + ' ' + r.path;
    if (!map.has(k) || rank[r.guard] > rank[map.get(k).guard]) map.set(k, r);
  });
  return Array.from(map.values()).sort((a, b) => (a.path + a.method).localeCompare(b.path + b.method));
}

const lines = [];
lines.push('# 26牛牛 - API 清单');
lines.push('');
lines.push('> 由 `node scripts/api-inventory.js` 自动生成，请勿手工编辑。');
lines.push('> 全部接口统一挂在 `/api` 前缀下；`/api/admin/*` 由 `middleware/admin-boundary.js`');
lines.push('> 在进入路由之前统一要求 `role = admin`（OTP 与客服线程允许 `support`），普通用户一律 403。');
lines.push('');
let total = 0;
MOUNTS.forEach(m => {
  const full = path.join(ROUTES_DIR, m.file);
  if (!fs.existsSync(full)) return;
  const rows = scan(m.file);
  if (!rows.length) return;
  total += rows.length;
  lines.push('## ' + m.title + '（routes/' + m.file + '）');
  lines.push('');
  lines.push('| 方法 | 路径 | 权限 |');
  lines.push('| --- | --- | --- |');
  rows.forEach(r => lines.push('| ' + r.method + ' | `/api' + r.path + '` | ' + r.guard + ' |'));
  lines.push('');
});
lines.push('---');
lines.push('');
lines.push('合计 ' + total + ' 个接口（不含 Socket.IO 事件通道）。');
lines.push('');

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, lines.join('\n'), 'utf8');
console.log('API_LIST_WRITTEN ' + path.relative(ROOT, OUT) + ' endpoints=' + total);
