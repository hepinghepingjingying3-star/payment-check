'use strict';
// ============================================
// 26牛牛 - 一键重启（解决「旧进程占着端口，新代码起不来」）
// 用法:
//   npm run restart                 使用 .env 里的 PORT（默认 3000）
//   set PORT=3001 && npm run restart  临时换端口
//   npm run restart -- --force      端口被「非 node / 未知」进程占用时也结束它
// 步骤:
//   1) 读取 .env 的 PORT
//   2) 只读查询监听该端口的进程（Windows: netstat -ano；macOS/Linux: lsof）
//   3) 默认只结束 node 进程（避免误杀 MySQL 等其它服务），并等待端口释放
//   4) 释放后以「当前代码」在同一个终端启动 server.js
// 说明: 不修改任何数据；找不到占用进程时直接启动
// ============================================
const path = require('node:path');
const root = path.resolve(__dirname, '..');

require('dotenv').config({ path: path.join(root, '.env') });
process.chdir(root);   // server.js 依赖项目根目录

const portOwner = require('../utils/portOwner');

(async () => {
  const port = Number(process.env.PORT || 3000);
  const force = process.argv.indexOf('--force') >= 0;
  console.log('=== 26牛牛 一键重启（端口 ' + port + '）===');

  const holders = await portOwner.findListeners(port);
  if (!holders.length) {
    console.log('端口空闲，直接启动当前代码。');
  } else {
    holders.forEach(h => console.log('发现占用进程: ' + (h.name || '未知进程') + '  PID ' + h.pid));

    const isNode = h => /node/i.test(String(h.name || ''));
    const nodeHolders = holders.filter(isNode);
    const unknownHolders = holders.filter(h => !isNode(h));

    if (unknownHolders.length && !force) {
      console.error('!! 端口被非 node / 未知进程占用，出于安全默认不结束它: ' +
        unknownHolders.map(h => (h.name || '未知') + '(' + h.pid + ')').join(', '));
      console.error('   确认那是可以结束的旧服务后，可执行: npm run restart -- --force');
      console.error('   或手动结束: ' + unknownHolders.map(h => portOwner.killCommand(h.pid)).join(' ; '));
      process.exitCode = 1;
      return;
    }

    const targets = force ? holders : nodeHolders;
    for (const h of targets) {
      const ok = await portOwner.killProcess(h.pid);
      console.log((ok ? '已结束旧进程' : '无法结束（可能属于其它用户或系统会话）') + ' PID ' + h.pid);
    }

    if (!await portOwner.waitPortFree(port, 6000)) {
      console.error('!! 端口 ' + port + ' 仍被占用，请手动结束后再运行：' +
        holders.map(h => portOwner.killCommand(h.pid)).join(' ; '));
      process.exitCode = 1;
      return;
    }
    console.log('端口已释放。');
  }

  console.log('正在用当前代码启动服务...\n');
  require(path.join(root, 'server.js'));
})().catch(err => {
  console.error('重启失败:', err && err.message ? err.message : err);
  process.exitCode = 1;
});
