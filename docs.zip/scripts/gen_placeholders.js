// 生成 4 张占位 JPEG：8x8 块级平均色（DC-only 基线 JPEG，自带编码器，零依赖）
// mer=480x360 文章介绍 / line=960x32 分割线 / skip=640x160 转载说明 / wave=480x480 播客封面
const fs = require('fs');
const OUT = 'public/assets/img';
fs.mkdirSync(OUT, { recursive: true });

const Q0 = 16; // DC 量化步长
// 自定义 Huffman：DC 符号 0..11（长度 1..12），AC 仅 EOB(0x00) 长度 1
const dcCounts = [1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0];
const dcSyms   = [0,1,2,3,4,5,6,7,8,9,10,11];
const dcCodes  = []; { let c = 0; for (let len = 1; len <= 12; len++) dcCodes[len] = c++; } // 0:'0',1:'10',...
const acCounts = [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
const acSyms   = [0x00];
const AC_EOB = [0, 1]; // code '0' len 1

class BW {
  constructor() { this.b = []; this.cur = 0; this.n = 0; }
  put(code, len) { for (let i = len - 1; i >= 0; i--) { this.cur = (this.cur << 1) | ((code >>> i) & 1); if (++this.n === 8) { this.emit(this.cur); this.cur = 0; this.n = 0; } } }
  emit(byte) { this.b.push(byte); if (byte === 0xff) this.b.push(0); } // 0xff 填充
  flush() { while (this.n !== 0) this.put(1, 1); }
}

function encodeJPEG(px, W, H) {
  const out = [0xff, 0xd8]; // SOI
  const w16 = (v) => out.push((v >> 8) & 0xff, v & 0xff);
  out.push(0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1, 0, 1, 0); // APP0 JFIF
  out.push(0xff, 0xdb, 0, 67, 0); // DQT
  for (let i = 0; i < 64; i++) out.push(Q0); // 全表统一步长（zigzag 顺序，值相同无需区分）
  out.push(0xff, 0xc0); w16(11); out.push(8); w16(H); w16(W); out.push(1, 1, 0x11, 0); // SOF0 灰度
  out.push(0xff, 0xc4); w16(2 + 16 + dcSyms.length); out.push(0x00, ...dcCounts, ...dcSyms); // DHT DC
  out.push(0xff, 0xc4); w16(2 + 16 + acSyms.length);  out.push(0x10, ...acCounts, ...acSyms); // DHT AC
  out.push(0xff, 0xda, 0, 8, 1, 1, 0, 0, 63, 0); // SOS
  const bw = new BW(); let dcPred = 0;
  for (let by = 0; by < H; by += 8) for (let bx = 0; bx < W; bx += 8) {
    let sum = 0;
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const sx = Math.min(bx + x, W - 1), sy = Math.min(by + y, H - 1);
      sum += px[sy * W + sx] - 128;
    }
    const avg = sum / 64;
    const dcq = Math.max(-2048, Math.min(2047, Math.round(avg / Q0)));
    const diff = dcq - dcPred; dcPred = dcq;
    const s = diff === 0 ? 0 : 32 - Math.clz32(Math.abs(diff));
    bw.put(dcCodes[s] || 0, s + 1); // DC 码长 = s+1（自定义表）
    if (s > 0) {
      let v = Math.abs(diff) & ((1 << s) - 1);
      if (diff < 0) v = ((1 << s) - 1) - (Math.abs(diff) - 1);
      bw.put(v, s);
    }
    bw.put(AC_EOB[0], AC_EOB[1]); // EOB
  }
  bw.flush();
  for (const b of bw.b) out.push(b);
  out.push(0xff, 0xd9); // EOI
  return Buffer.from(out);
}

const BG = 26, FG = 190, FG2 = 110;
const jobs = [
  { f: 'mer.jpg', w: 480, h: 360, draw: (x, y, w, h) => {
      const d = Math.hypot(x - w/2, y - h/2 - 24);
      if (d < 46) return FG; if (d < 58) return FG2;
      if (y > h-74 && y < h-66 && x > 48 && x < w-48) return FG2;
      if (y > h-48 && y < h-40 && x > 48 && x < w/2+36) return FG;
      return BG; } },
  { f: 'line.jpg', w: 960, h: 32, draw: (x, y) => {
      if (y >= 14 && y <= 17) return FG;
      if (y >= 12 && y <= 19 && x % 160 < 3) return FG2;
      return BG; } },
  { f: 'skip.jpg', w: 640, h: 160, draw: (x, y, w, h) => {
      if (x < 8 || x > w-9 || y < 8 || y > h-9) return FG2;
      if (x > 32 && x < 64 && y > 32 && y < 64) return FG;
      if (y > 42 && y < 48 && x > 92 && x < w-32) return FG2;
      if (y > 84 && y < 90 && x > 32 && x < w-32) return FG2;
      if (y > 110 && y < 116 && x > 32 && x < w/2) return FG2;
      return BG; } },
  { f: 'wave.jpg', w: 480, h: 480, draw: (x, y, w, h) => {
      const d = Math.hypot(x - w/2, y - h/2);
      if (d > 190) return BG;
      const yy = h/2 + Math.sin(x/14) * 60 * (1 - d/220);
      if (Math.abs(y - yy) < 7) return FG;
      if (Math.abs(y - yy) < 12) return FG2;
      return BG; } },
];

for (const j of jobs) {
  const px = new Uint8Array(j.w * j.h);
  for (let y = 0; y < j.h; y++) for (let x = 0; x < j.w; x++) px[y * j.w + x] = j.draw(x, y, j.w, j.h);
  const buf = encodeJPEG(px, j.w, j.h);
  fs.writeFileSync(`${OUT}/${j.f}`, buf);
  const ok = buf[0] === 0xff && buf[1] === 0xd8 && buf[buf.length-2] === 0xff && buf[buf.length-1] === 0xd9;
  console.log(`${j.f}  ${j.w}x${j.h}  ${buf.length} bytes  SOI/EOI=${ok ? 'OK' : 'BAD'}`);
}
console.log('DONE');
