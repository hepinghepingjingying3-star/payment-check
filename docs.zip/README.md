# 🐮 26牛牛

移动端优先 Web 项目

## 📋 项目结构

```
26niuniu/
├── package.json          # 项目配置文件（依赖、启动命令）
├── .env                  # 环境变量配置（数据库密码等，不提交到 Git）
├── .gitignore            # Git 忽略文件
├── server.js             # 服务器入口文件
├── config/
│   └── db.js             # MySQL 数据库连接配置
├── database/
│   ├── schema.sql        # 数据库初始化 SQL（创建数据库和表）
│   └── setup.js          # 数据库初始化脚本（运行: node database/setup.js）
├── public/
│   └── index.html        # 首页占位页面
└── README.md             # 项目说明文档
```

## 🗄️ 数据库（Phase 2）

### 初始化数据库

在项目根目录运行：

```bash
node database/setup.js
```

这会创建：
- 数据库 `26niuniu`
- 用户表 `users`（包含 id、username、email、phone、password_hash、role、status、created_at、updated_at）

### users 表字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT UNSIGNED | 用户ID（自增主键） |
| username | VARCHAR(50) | 用户名（唯一） |
| email | VARCHAR(100) | 邮箱（唯一，可空） |
| phone | VARCHAR(20) | 手机号（唯一，可空） |
| password_hash | VARCHAR(255) | 密码哈希值（bcrypt 加密，禁止明文） |
| role | ENUM | 角色: user / admin |
| status | ENUM | 状态: active / banned / deleted |
| created_at | TIMESTAMP | 创建时间（自动） |
| updated_at | TIMESTAMP | 更新时间（自动） |

## 🚀 如何启动项目

### 1. 安装依赖

在项目根目录（`c:\26niuniu`）打开终端，运行：

```bash
npm install
```

### 2. 配置数据库

1. 打开 `.env` 文件
2. 将 `DB_PASSWORD=your_mysql_password` 改成你自己的 MySQL 密码
3. 确保 MySQL 服务已启动

### 3. 启动服务器

```bash
npm start
```

### 4. 访问项目

浏览器打开：http://localhost:3000

## ✅ 如何确认 Phase 1 成功

1. 终端显示 `🚀 26牛牛 服务器已启动`
2. 终端显示 `✅ MySQL 数据库连接成功`（如果数据库配置正确）
3. 浏览器访问 http://localhost:3000 能看到「26牛牛」页面

## ✅ 如何确认 Phase 2 成功

1. 运行 `node database/setup.js` 显示 `🎉 Phase 2 数据库初始化完成！`
2. 终端显示 `✅ 数据库 26niuniu 创建成功`
3. 终端显示 `✅ users 表创建成功`
4. 终端显示 `✅ 验证通过: users 表已存在于数据库 26niuniu 中`
5. 启动服务器 `npm start` 后终端显示 `✅ MySQL 数据库连接成功`

## 🔐 认证系统（Phase 3）

### 功能列表

- **注册**: 用户名、电话号码、邮箱、姓名、密码（bcrypt 加密）、确认密码
- **登录**: 用户名 + 密码，bcrypt 验证，生成 JWT
- **个人中心**: 查看自己的资料与安全设置
- **公开用户资料**: 只返回用户名等公开字段，保护隐私
- **客服核验**: 忘记密码 / 账号找回统一走人工客服或管理员身份核验

### 账号找回（人工核验）

- 通过站内「在线客服」说明账号归属与注册资料
- 客服或管理员人工核验用户名、手机号、邮箱与注册信息
- 核验通过后由管理员在后台按流程协助恢复账号
- 平台不提供任何自动化自助找回方式，一律人工核验

### 隐私保护

- 普通玩家之间只能看到用户名
- 禁止返回: phone、email、real_name、password_hash
- 自己的个人中心可以查看自己的绑定资料

### 数据库迁移

如果 users 表需要添加新字段，运行：

```bash
node database/migrate.js
```

### 页面地址

| 页面 | 地址 |
|------|------|
| 登录 | http://localhost:3000/login.html |
| 注册 | http://localhost:3000/register.html |
| 大厅 | http://localhost:3000/lobby.html |
| 个人中心 | http://localhost:3000/me.html |

### API 接口

| 方法 | 路径 | 说明 | 权限 |
|------|------|------|------|
| POST | /api/auth/register | 注册 | 公开 |
| POST | /api/auth/login | 登录 | 公开 |
| GET | /api/auth/me | 个人中心 | 需登录 |
| GET | /api/users/:id | 公开用户资料 | 公开 |
| GET | /api/users | 用户列表 | 公开 |
| POST | /api/support/lookup | 客服查询 | support/admin |

## 📌 技术栈

- **后端**: Node.js + Express
- **数据库**: MySQL (mysql2)
- **认证**: JWT + bcrypt（后续阶段）
- **实时通信**: Socket.IO（后续阶段）
## 🧾 本轮新增（V6 治理闭环 + 聊天红包）

### 数据库迁移（幂等、只新增，不删除任何数据）

```bash
node database/migrations/006-presence-approval.js   # user_presence + admin_approvals
node database/migrations/007-chat-redpacket.js      # chat_messages.redpacket + chat_red_packets + claims
# 或一次性执行全部增量迁移
node database/migrations/run-all.js
```

### 新能力

| 能力 | 说明 | 配置位置 |
|------|------|----------|
| 在线人数 | Socket 连接与聊天轮询写心跳（20 秒节流），在线 = 最近 90 秒活跃；表不可用时返回 null，不用账号总数冒充 | `config/moderation.js → PRESENCE` |
| 禁言联动 | 被禁言时禁止：发消息 / 发红包 / 建房进房 / 竞标下注抢包 / 提交提款；充值与读取不受影响 | `config/moderation.js → MUTE.SCOPE` |
| 双人复核 | 封禁/解封、管理员权限变更、解除禁言需另一名管理员复核后才生效；申请人不能复核自己，仅剩一名活跃管理员时按配置降级 | `config/moderation.js → DUAL_APPROVAL` |
| 封禁断开连接 | 封禁生效后推送 `account:revoked` 并断开该账号全部 Socket | `utils/presence.js` |
| 禁言到期提醒 | 后台概览 / `GET /api/admin/mute-expiring` / 用户列表「即将解禁」筛选 | 提醒窗口 24 小时 |
| 聊天红包 | 群聊红包（平台测试资产）：先扣款后发放、随机分配、绝不超发、不能抢自己的、未领完自动退回 | `config/redPacket.js` |

### 关键接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/chat/redpackets | 发聊天红包（游戏群，测试资产） |
| GET | /api/chat/redpackets/:id | 红包详情（领取记录 / 手气最佳 / 我能否领取） |
| POST | /api/chat/redpackets/:id/claim | 抢红包（事务 + 行锁 + 唯一键） |
| GET | /api/admin/online | 在线用户（真实心跳） |
| GET | /api/admin/mute-expiring | 禁言到期提醒名单 |
| GET | /api/admin/approvals | 双人复核队列 |
| POST | /api/admin/approvals/:id/decide | 复核通过 / 拒绝（不能复核自己提交的请求） |

### 验收测试

```bash
node tests/moderation-redpacket-live.js   # 真实 server + 真实 MySQL + 真实 Socket.IO（110 项，临时 zzmt_* 账号结束即删）
node tests/admin-access-browser.js        # 真实 Chrome + 真实 MySQL 后台端到端（87 项）
node tests/admin-dashboard.js             # 隔离 VM 测试（20 项）
node tests/platform-smoke.js              # 平台冒烟
```

> 说明：聊天红包与游戏内「红包对战」是两个不同功能，且都只使用平台内部测试资产，不接任何真实支付 / 银行 / USDT 通道。
