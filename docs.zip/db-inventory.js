// 一次性：数据库结构盘点（只读）
'use strict';
require('dotenv').config();
const fs = require('fs');
const mysql = require('mysql2/promise');
(async () => {
  const c = await mysql.createConnection({
    host: process.env.DB_HOST, port: process.env.DB_PORT, user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
  const out = [];
  const [tables] = await c.query(
    'SELECT table_name FROM information_schema.tables WHERE table_schema = ? ORDER BY table_name', [process.env.DB_NAME]);
  out.push('=== TABLES (' + tables.length + ') ===');
  out.push(tables.map(t => t.TABLE_NAME).join(', '));
  for (const t of tables) {
    const name = t.TABLE_NAME;
    const [cols] = await c.query(
      'SELECT column_name, column_type, is_nullable, column_default FROM information_schema.columns WHERE table_schema=? AND table_name=? ORDER BY ordinal_position',
      [process.env.DB_NAME, name]);
    out.push('');
    out.push('--- ' + name + ' ---');
    out.push(cols.map(x => x.COLUMN_NAME + ' ' + x.COLUMN_TYPE + (x.IS_NULLABLE === 'YES' ? ' NULL' : ' NOT NULL')).join(' | '));
  }
  fs.writeFileSync(__dirname + '/db-inventory.txt', out.join('\n'), 'utf8');
  await c.end();
  console.log('DONE tables=' + tables.length);
})().catch(e => { console.error('ERR ' + e.message); process.exit(1); });
