// 一次性提取写入 admin-recharge.js / withdrawals.js 所需的全部签名与表结构
'use strict';
const fs = require('fs');
const R = 'C:/26niuniu/';
const out = [];
function sec(t) { out.push('', '==== ' + t + ' ===='); }
function g(p) { try { return fs.readFileSync(R + p, 'utf8'); } catch (e) { return '(MISSING ' + p + ')'; } }

(async () => {
  // ---------- 1. 数据库真实表结构（最优先） ----------
  sec('DB TABLES');
  try {
    const db = require(R + 'config/db');
    const p = db.promise();
    const [tables] = await p.query('SHOW TABLES');
    out.push(tables.map(r => Object.values(r)[0]).join(', '));

    const want = ['recharge_orders', 'withdraw_requests', 'cash_chip_ledger', 'cash_chips_ledger',
      'ledger', 'balance_transactions', 'account_reviews', 'chat_moderation', 'wallet_orders', 'users'];
    for (const t of want) {
      try {
        const [cols] = await p.query('SHOW COLUMNS FROM ??', [t]);
        if (cols.length) {
          sec('COLUMNS ' + t);
          out.push(cols.map(c => c.Field + ':' + c.Type + (c.Key ? ':' + c.Key : '')).join(' | '));
        }
      } catch (e) { /* 表不存在则跳过 */ }
    }
    process.env.PG = '1';
  } catch (e) { out.push('DB ERR: ' + e.message); }

  // ---------- 2. utils/ledger.js 签名 ----------
  sec('ledger.js');
  const led = g('utils/ledger.js');
  out.push(led.split(/\r?\n/).filter(l =>
    /^function |^async function |module\.exports|^const \w+ = |^exports\./.test(l.trim())
  ).join('\n'));

  // ---------- 3. 配置与工具导出 ----------
  for (const mod of ['config/cashChips.js', 'utils/payPassword.js', 'utils/moderation.js', 'middleware/auth.js', 'utils/request.js']) {
    sec(mod);
    try {
      const m = require(R + mod);
      out.push('exports: ' + Object.keys(m).join(', '));
      out.push('signatures: ' + Object.keys(m).map(k => {
        const v = m[k];
        return (typeof v === 'function') ? (k + String(v).split('{')[0].trim().slice(k.length)) : (k + '=' + JSON.stringify(v));
      }).join(' ;; '));
    } catch (e) { out.push('ERR ' + e.message); }
  }

  // ---------- 4. migration 010 表定义 ----------
  sec('migration 010');
  out.push(g('database/migrations/010-cash-chips.js'));

  // ---------- 5. recharge.js 路由清单 ----------
  sec('recharge.js routes');
  out.push(g('routes/recharge.js').split(/\r?\n/).filter(l => /router\.(get|post|put|patch|delete)/.test(l)).join('\n'));

  // ---------- 6. server.js 挂载 ----------
  sec('server.js mounts');
  out.push(g('server.js').split(/\r?\n/).map((l, i) => (i + 1) + ': ' + l)
    .filter(x => /recharge|withdraw|transfer|moderation|account/.test(x)).join('\n'));

  fs.writeFileSync(R + 'last-sig.txt', out.join('\n'), 'utf8');
  console.log('WROTE last-sig.txt, chars=' + out.join('\n').length);
  process.exit(0);
})();
