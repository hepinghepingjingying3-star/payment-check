// ============================================
// 26牛牛 - 资金模块集中配置（充值 / 提款 / 凭证）
// ============================================
// 说明:
//   - 充值 / 提款的所有阈值、快捷金额、付款方式、收款账户只在本文件维护
//   - 禁止把金额上下限、收款账户散落在前端 HTML / 各 JS / 各 API
// ============================================

// ---------- 充值 ----------
const DEPOSIT = {
  MIN: 30,                 // 单笔最低 RM30
  MAX: 50000,              // 单笔最高 RM50,000
  DECIMALS: 2,
  QUICK_AMOUNTS: [30, 100, 500, 1000, 2000, 3000, 5000],
  PAYMENT_METHODS: [
    {
      code: 'BANK',
      label: '银行转账',
      note: '客服人工审核，通常 5–30 分钟处理',
      enabled: true
    }
  ],
  DEFAULT_METHOD: 'BANK',
  // 提交前确认提示（充值声明）
  DECLARATION: {
    title: '请确认付款资料与订单信息一致',
    items: ['充值金额', '付款方式', '订单号'],
    note: '如果资料不一致，管理员可以拒绝该充值申请。'
  },
  // 充值方式说明（当前未接入任何真实支付渠道）
  TEST_MODE_NOTICE: {
    title: '当前充值方式暂不可用',
    text: '平台未接入任何真实支付渠道。充值订单提交后进入待处理，由管理员人工确认为准。'
  },
  // 收款资料仅来自系统设置中心；未配置时由用户端显示提示
  TEST_RECEIVING: {
    account_name: '',
    bank_name: '',
    account_no: '',
    notice: '暂未配置收款账户'
  },
  // 备注提示
  REMARK_HINTS: ['OKOK', 'DONE', 'NOTED'],
  REMARK_NOTE: '请按照订单要求填写备注。',
  USDT_ENTRY: {
    text: '需要 USDT 充值？联系客服',
    link: '/support-chat.html',
    note: '当前不提供真实 USDT 入金，仅接入站内在线客服。'
  }
};

// ---------- 提款 ----------
const WITHDRAW = {
  MIN: 0.01,
  MAX: 50000,
  DECIMALS: 2,
  // 资产类型（与 wallet_orders.currency_type 对应，两者完全独立）
  ASSET_TYPES: [
    { code: 'CASH_CHIPS', label: '现金筹码' },
    { code: 'GAME_BALANCE', label: '游戏余额' }
  ],
  DEFAULT_ASSET: 'CASH_CHIPS',
  ACCOUNT_TYPES: [
    { code: 'BANK', label: '银行账户' },
    { code: 'TNG', label: 'TNG' },
    { code: 'DUITNOW', label: 'DuitNow' },
    { code: 'OTHER', label: '其他' }
  ],
  DEFAULT_ACCOUNT_TYPE: 'BANK',
  ACCOUNT_REF_MAX: 120,
  TEST_MODE_NOTICE: {
    title: '提款申请说明',
    text: '提款仅代表系统内虚拟现金筹码申请状态，不执行真实银行、现金或第三方支付出款。'
  }
};

// ---------- 凭证上传（充值凭证 / 头像 / 贴图 共用规则） ----------
const VOUCHER = {
  MIME_TYPES: ['image/jpeg', 'image/png', 'image/webp'],
  EXT_BY_MIME: { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' },
  MAX_BYTES: 5 * 1024 * 1024,      // 单张最大 5MB
  MIN_BYTES: 1024,                 // 过小视为无效文件
  MIN_WIDTH: 64,
  MIN_HEIGHT: 64,
  MAX_WIDTH: 8000,
  MAX_HEIGHT: 8000,
  // 凭证需清晰显示的信息（前端提示，纯展示）
  REQUIREMENTS: ['转账金额', '转账时间', '对方账户', '转账状态']
};

// ---------- 订单状态机 ----------
// 充值: PENDING_PAYMENT → PENDING_REVIEW → APPROVED / REJECTED
//       PENDING_PAYMENT / PENDING_REVIEW → CANCELLED（用户取消）
// 提款: PENDING → PROCESSING → APPROVED / REJECTED，PENDING → CANCELLED
// 兼容历史数据: PENDING（旧充值待审）、COMPLETED（旧审核通过）
const STATUS = {
  PENDING_PAYMENT: 'PENDING_PAYMENT',
  PENDING_REVIEW: 'PENDING_REVIEW',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED',
  CANCELLED: 'CANCELLED',
  PENDING: 'PENDING',
  PROCESSING: 'PROCESSING',
  COMPLETED: 'COMPLETED'
};

const STATUS_TEXT = {
  PENDING_PAYMENT: '待付款',
  PENDING_REVIEW: '待审核',
  PENDING: '待审核',
  PROCESSING: '处理中',
  APPROVED: '已通过',
  COMPLETED: '已通过',
  REJECTED: '已拒绝',
  CANCELLED: '已取消'
};

/** 充值订单：允许管理员审核的状态（含历史 PENDING） */
const DEPOSIT_REVIEWABLE = [STATUS.PENDING_REVIEW, STATUS.PENDING];
/** 提款订单：允许管理员审核的状态（含历史 PENDING） */
const WITHDRAW_REVIEWABLE = [STATUS.PENDING, STATUS.PROCESSING];
/** 用户可自行取消的状态 */
const DEPOSIT_CANCELLABLE = [STATUS.PENDING_PAYMENT, STATUS.PENDING_REVIEW, STATUS.PENDING];

/** 金额安全解析：返回分为单位的整数，非法返回 null（禁止 NaN / Infinity / 字符串绕过） */
function parseAmountToCents(raw, min, max) {
  if (raw === null || raw === undefined) return null;
  if (typeof raw === 'object') return null;
  const s = String(raw).trim();
  if (!s || !/^-?\d{1,12}(\.\d{1,2})?$/.test(s)) return null;   // 拒绝科学计数法 / 多余小数 / 空格
  const num = Number(s);
  if (!Number.isFinite(num)) return null;
  const cents = Math.round(num * 100);
  if (!Number.isSafeInteger(cents)) return null;
  if (cents < Math.round(min * 100) || cents > Math.round(max * 100)) return null;
  return cents;
}

function centsToAmount(cents) {
  return Number((cents / 100).toFixed(2));
}

function amountString(cents) {
  return (cents / 100).toFixed(2);
}

module.exports = {
  DEPOSIT,
  WITHDRAW,
  VOUCHER,
  STATUS,
  STATUS_TEXT,
  DEPOSIT_REVIEWABLE,
  WITHDRAW_REVIEWABLE,
  DEPOSIT_CANCELLABLE,
  parseAmountToCents,
  centsToAmount,
  amountString
};
