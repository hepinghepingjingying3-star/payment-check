// ============================================
// 26牛牛 - 26牛牛娱乐场（非现金化）集中配置
// ============================================
// 说明:
//   - 本文件是 26 牛牛娱乐场所有数值 / 文案 / 开关的唯一来源
//     路由、引擎、页面一律从这里读取，禁止散落硬编码
//   - 资产：游戏积分（users.game_points）
//       · 只能由「每日免费发放」与「管理员发放」产生
//       · 不可充值、不可转账、不可提现、不可兑换现金或现金筹码
//       · 因此本游戏不是赌博：没有资金流入，也没有资金流出
//   - 房间 / 回合 / 结算全部由后端计算，前端只负责展示
// ============================================

// ---------- 资产（非现金化娱乐积分）----------
const POINTS = {
  ASSET: 'GAME_POINTS',                 // 与 balance_transactions.currency_type 对应
  FIELD: 'game_points',                 // users 表字段
  TEXT: '游戏积分',
  DECIMALS: 2,
  // 每日免费发放：积分低于下限时补发（同一天只发一次）
  DAILY_FREE: {
    AMOUNT: 1000,
    TRIGGER_BELOW: 300,
    MIN_BALANCE: 0
  },
  LEDGER_TYPES: {
    DAILY_FREE: 'POINTS_DAILY',
    ADMIN_GRANT: 'POINTS_GRANT',
    GAME_SETTLE: 'POINTS_GAME'
  },
  LEDGER_TYPE_TEXT: {
    POINTS_DAILY: '每日免费积分',
    POINTS_GRANT: '管理员发放积分',
    POINTS_GAME: '26牛牛对局结算'
  }
};

// ---------- 全局开关（管理后台可实时关闭）----------
const SWITCHES = {
  // system_settings 中的键名；值 '1'/'0'
  DB_KEY: 'niu_game_enabled',
  DEFAULT_ENABLED: true,
  DISABLED_MESSAGE: '26牛牛娱乐场暂时关闭，请稍后再试。'
};

// ---------- 房间场次（进入门槛只看游戏积分）----------
const ROOMS = [
  {
    key: 'junior',
    name: '初级场',
    base_stake: 10,
    seat_limit: 6,
    min_points: 0,
    max_points: 0,               // 0 = 不限
    order: 1,
    desc: '每分 10 积分，适合熟悉流程'
  },
  {
    key: 'middle',
    name: '中级场',
    base_stake: 50,
    seat_limit: 6,
    min_points: 1000,
    max_points: 0,
    order: 2,
    desc: '每分 50 积分，需要至少 1000 游戏积分'
  },
  {
    key: 'senior',
    name: '高级场',
    base_stake: 200,
    seat_limit: 6,
    min_points: 8000,
    max_points: 0,
    order: 3,
    desc: '每分 200 积分，需要至少 8000 游戏积分'
  }
];

function roomByKey(key) {
  return ROOMS.find(r => r.key === String(key || '')) || null;
}

// ---------- 人数 ----------
const PLAYERS = {
  MIN: 2,
  DEFAULT_MAX: 6,
  HARD_MAX: 6
};

// ---------- 状态机（后端唯一驱动，前端只读）----------
const PHASE = {
  WAITING: 'WAITING',        // 等待玩家坐满 / 倒计时
  GRABBING: 'GRABBING',      // 抢庄
  BETTING: 'BETTING',        // 选择倍数
  DEALING: 'DEALING',        // 发牌
  RESULT: 'RESULT',          // 亮牌比大小
  SETTLEMENT: 'SETTLEMENT',  // 积分结算
  FINISHED: 'FINISHED'       // 本局结束（自动开下一局）
};

const PHASE_TEXT = {
  WAITING: '等待开局',
  GRABBING: '抢庄阶段',
  BETTING: '选择倍数',
  DEALING: '发牌中',
  RESULT: '比牌结果',
  SETTLEMENT: '积分结算',
  FINISHED: '本局结束'
};

// ---------- 各阶段时长（秒）----------
const TIMERS = {
  WAITING: 15,
  GRABBING: 8,
  BETTING: 10,
  DEALING: 3,
  RESULT: 8,
  SETTLEMENT: 5,
  FINISHED: 3,
  // 超时未推进的回合由清扫任务安全结束（服务器重启兜底）
  ROUND_MAX_LIVE_SECONDS: 15 * 60,
  // 空闲房间自动关闭：无人且多久没有回合
  ROOM_IDLE_CLOSE_SECONDS: 10 * 60,
  // 引擎心跳间隔（毫秒）
  TICK_MS: 1000
};

// ---------- 抢庄 ----------
const GRAB = {
  YES: 1,
  NO: 0
};

// ---------- 下注倍数（纯游戏积分倍数，不涉及任何真实资金）----------
const BET_LEVELS = [
  { level: 1, label: 'x1' },
  { level: 2, label: 'x2' },
  { level: 3, label: 'x3' },
  { level: 5, label: 'x5' }
];
const BET_DEFAULT_LEVEL = 1;

function isValidBetLevel(level) {
  return BET_LEVELS.some(b => b.level === Number(level));
}

/** 倍数白名单的纯文本（群内话术用，避免把对象 join 出来变成 [object Object]） */
function betLevelsText() {
  return BET_LEVELS.map(b => b.label).join(' / ');
}

// ---------- 牌型（倍数唯一来源）----------
const HAND_TYPES = {
  WU_XIAO:  { key: 'WU_XIAO',  name: '五小牛',  multiplier: 10, order: 100 },
  ZHA_DAN:  { key: 'ZHA_DAN',  name: '炸弹牛',  multiplier: 8,  order: 90 },
  WU_HUA:   { key: 'WU_HUA',   name: '五花牛',  multiplier: 5,  order: 80 },
  TONG_HUA: { key: 'TONG_HUA', name: '同花牛',  multiplier: 4,  order: 70 },
  NIU_NIU:  { key: 'NIU_NIU',  name: '牛牛',    multiplier: 3,  order: 60 },
  NIU_9:    { key: 'NIU_9',    name: '牛九',    multiplier: 2,  order: 59 },
  NIU_8:    { key: 'NIU_8',    name: '牛八',    multiplier: 2,  order: 58 },
  NIU_7:    { key: 'NIU_7',    name: '牛七',    multiplier: 1,  order: 57 },
  NIU_6:    { key: 'NIU_6',    name: '牛六',    multiplier: 1,  order: 56 },
  NIU_5:    { key: 'NIU_5',    name: '牛五',    multiplier: 1,  order: 55 },
  NIU_4:    { key: 'NIU_4',    name: '牛四',    multiplier: 1,  order: 54 },
  NIU_3:    { key: 'NIU_3',    name: '牛三',    multiplier: 1,  order: 53 },
  NIU_2:    { key: 'NIU_2',    name: '牛二',    multiplier: 1,  order: 52 },
  NIU_1:    { key: 'NIU_1',    name: '牛一',    multiplier: 1,  order: 51 },
  NO_NIU:   { key: 'NO_NIU',   name: '无牛',    multiplier: 1,  order: 10 }
};

// ---------- 排行榜 ----------
const LEADERBOARD = {
  DEFAULT_LIMIT: 20,
  MAX_LIMIT: 50,
  // 统计窗口（天）：0 = 全部历史
  DEFAULT_DAYS: 0
};

// ---------- 分页 / 限流 ----------
const LIMITS = {
  RECORDS_PAGE_SIZE: 20,
  RECORDS_MAX_PAGE_SIZE: 50,
  ROOM_LIST_MAX: 30,
  // 每用户每分钟允许的写操作（加入 / 抢庄 / 倍数 / 离开）
  ACTION_PER_MIN: 60,
  // 系统消息长度上限
  CHAT_NOTICE_MAX: 200
};

// ---------- 游戏系统消息（发在「26牛牛游戏群」= chat_messages.channel='group'）----------
// 关键约定：游戏不在独立页面里进行，而是在聊天群里进行。
// 因此所有阶段提示、牌型公布、结算明细都作为 message_type='game' 的聊天消息入库，
// 并带 room_id / round_id / phase，聊天页据此渲染游戏操作卡片。
const CHAT = {
  GROUP_CHANNEL: 'group',              // 与 routes/chat.js 的 GROUP_CHANNEL 保持一致
  MESSAGE_TYPE: 'game',                // 与聊天 message_type 枚举一致（text/image/sticker/system/game）
  SOURCE: 'niu_game',
  // Socket 内部推送房间名（技术细节，与聊天频道无关；真正的消息都落在 group 频道）
  SOCKET_ROOM_PREFIX: 'niu:',
  // 群内话术（唯一来源，后端状态机在阶段切换时写入聊天群）
  LINES: {
    NEW_ROUND: '26牛牛新一局开始',
    GRAB_START: '开始抢庄，请在聊天上方点击「抢庄」或「不抢」。',
    GRAB_END: '抢庄结束。',
    BANKER_IS: '本局庄家：',
    BET_START: '请闲家选择倍数。',
    DEAL_DONE: '发牌完成，牌型由服务器计算。',
    REVEAL_HEAD: '本局亮牌（庄家 ',
    SETTLE_HEAD: '本局结算明细：',
    ROUND_END: '本局游戏结束。'
  }
};

// ============================================
// 26牛牛游戏机器人（由管理员控制，后端运行）
// ============================================
// 架构要点：
//   - 机器人是「系统身份」，不是玩家、不是管理员账号，聊天群里显示为
//     「26牛牛游戏机器人」+ 官方头像，绝不显示管理员用户名。
//   - 机器人是否运行由 **后端** 决定并持久化在数据库，管理员网页关掉也照常运行。
//   - 只有真实管理员（users.role='admin'）能启动/停止/改模板，普通用户一律 403。
//   - 消息模板集中在本文件（默认值），后台可覆盖并写进统一配置中心。
// ============================================
const BOT = {
  NAME: '26牛牛游戏机器人',
  // 官方头像：优先用后台已发布的官方头像库；缺失时前端回退到站点官方标识，
  // 绝不使用 Emoji / 随机头像 / AI 生成头像。
  AVATAR_URL: '/assets/logo/bot.png',
  FALLBACK_AVATAR_URL: '/assets/logo/logo.png',
  // 机器人状态唯一行主键（单例，避免出现多个机器人实例）
  STATE_ID: 1,
  // 自动推进节拍与两局之间的等待（秒）
  TICK_MS: 1000,
  NEXT_ROUND_WAIT: 12,
  // 群内话术模板（后台可改；DB 键前缀 + 文案）
  TEMPLATE_KEY_PREFIX: 'niu_bot_tpl_',
  TEMPLATES: {
    round_start: '26牛牛新一局开始',
    grab_start: '开始抢庄，请在聊天上方点击「抢庄」或「不抢」。',
    grab_end: '抢庄结束。',
    banker_is: '本局庄家：{name}',
    bet_start: '请闲家选择倍数。',
    deal_done: '发牌完成，牌型由服务器计算。',
    result: '本局结果已公布。',
    settle_head: '本局结算明细：',
    round_end: '本局游戏结束。',
    next_round: '下一局即将开始，请留在「26牛牛游戏群」等待。',
    bot_started: '26牛牛游戏机器人已启动。',
    bot_stopped: '26牛牛游戏机器人已停止（聊天记录与当前状态保留）。'
  },
  // 模板中文名（后台编辑界面直接显示，避免前端硬编码）
  TEMPLATE_LABELS: {
    round_start: '新一局开始',
    grab_start: '抢庄开始',
    grab_end: '抢庄结束',
    banker_is: '本局庄家',
    bet_start: '选择倍数',
    deal_done: '发牌完成',
    result: '结果公布',
    settle_head: '结算明细',
    round_end: '本局结束',
    next_round: '下一局提示',
    bot_started: '机器人启动提示',
    bot_stopped: '机器人停止提示'
  }
};

// ---------- 音效 / 动画（前端读取，用户可在设置里关闭）----------
const FX = {
  SOUND_ENABLED_DEFAULT: true,
  PREF_KEY: 'nn_niu_sound',          // localStorage 键
  SOUNDS: ['start', 'grab', 'deal', 'action', 'result', 'settle'],
  ANIM_MS: { deal_each: 180, reveal: 260, result: 520 }
};

/** 给前端的公开配置（不含任何内部字段） */
function publicConfig() {
  return {
    asset: { code: POINTS.ASSET, text: POINTS.TEXT },
    daily_free: { amount: POINTS.DAILY_FREE.AMOUNT, trigger_below: POINTS.DAILY_FREE.TRIGGER_BELOW },
    rooms: ROOMS.slice().sort((a, b) => a.order - b.order).map(r => ({
      key: r.key, name: r.name, base_stake: r.base_stake, seat_limit: r.seat_limit,
      min_points: r.min_points, desc: r.desc
    })),
    players: { min: PLAYERS.MIN, max: PLAYERS.DEFAULT_MAX },
    bet_levels: BET_LEVELS.slice(),
    timers: Object.assign({}, TIMERS),
    phases: Object.keys(PHASE).map(k => ({ key: PHASE[k], text: PHASE_TEXT[PHASE[k]] })),
    hands: Object.keys(HAND_TYPES).map(k => ({
      key: HAND_TYPES[k].key, name: HAND_TYPES[k].name, multiplier: HAND_TYPES[k].multiplier
    })).sort((a, b) => b.multiplier - a.multiplier),
    leaderboard: { limit: LEADERBOARD.DEFAULT_LIMIT, max: LEADERBOARD.MAX_LIMIT },
    fx: { sound_default: FX.SOUND_ENABLED_DEFAULT, pref_key: FX.PREF_KEY, sounds: FX.SOUNDS.slice(), anim_ms: Object.assign({}, FX.ANIM_MS) },
    disclaimer: '26牛牛娱乐场只使用不可充值、不可提现、不可兑换现金的游戏积分，仅用于娱乐。'
  };
}

module.exports = {
  POINTS,
  SWITCHES,
  ROOMS,
  roomByKey,
  PLAYERS,
  PHASE,
  PHASE_TEXT,
  TIMERS,
  GRAB,
  BET_LEVELS,
  BET_DEFAULT_LEVEL,
  isValidBetLevel,
  betLevelsText,
  HAND_TYPES,
  LEADERBOARD,
  LIMITS,
  CHAT,
  BOT,
  FX,
  publicConfig
};
