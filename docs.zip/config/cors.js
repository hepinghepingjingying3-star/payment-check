'use strict';
// ============================================
// 26牛牛 - 跨域白名单（config/cors.js）
//
// 背景：.env.example 从一开始就文档化了 CORS_ORIGINS，
// 但代码里从未读取它，server.js 一直是裸 app.use(cors())，
// 即默认「任何来源都可以调本项目全部 API」。文档承诺的控制从未生效。
// 这里把它真正接上线。
//
// 语义（与 .env.example 的说明完全一致）：
//   - CORS_ORIGINS 留空 = 同源部署（默认，也是生产推荐）。
//     前端用相对路径 /api/**，不需要任何跨域，因此**不放行任何跨域来源**。
//     注意：这里不是「允许 *」，而是「不允许跨域」——同源请求不受 CORS 约束。
//   - CORS_ORIGINS 非空 = 只放行列表内的来源（前端与后端分离部署时用）。
//
// 为什么要收紧（安全）：
//   裸 cors() + credentials 会让任意网站都能用受害者已登录的浏览器
//   调本项目接口（CSRF / 数据窃取）。收紧后攻击者拿不到响应，
//   浏览器也会在预检阶段直接拦掉。
// ============================================

/** 解析 CORS_ORIGINS → 规范化来源数组（去尾斜杠、去空项、去重） */
function parseOrigins(raw) {
  if (!raw) return [];
  return String(raw)
    .split(',')
    .map(s => s.trim())
    .filter(Boolean)
    .map(s => s.replace(/\/+$/, ''))   // 去掉结尾斜杠：https://a.com/ 与 https://a.com 等价
    .filter((s, i, arr) => arr.indexOf(s) === i);
}

/** 启动时读取一次（避免每个请求重复解析）；测试可重新读取 */
function load() {
  const list = parseOrigins(process.env.CORS_ORIGINS);
  return {
    // 空数组 = 同源模式，不放行跨域
    allowList: list,
    enabled: list.length > 0,
    // Socket.IO 用同一份白名单，保证网页与实时通道口径一致
    socketOrigin: list.length ? list : false
  };
}

/**
 * 构造 cors() 配置。
 * 同源模式（默认）返回一个「不放行任何来源」的配置，
 * 但仍然照常处理 OPTIONS 预检，不影响同源请求与健康检查。
 */
function corsOptions() {
  const cfg = load();
  if (!cfg.enabled) {
    return {
      origin: false,          // 任何跨域来源都不放行（不抛错，只是不返回 ACAO 头）
      credentials: true,       // 同源请求仍需携带 Cookie（管理后台页面票据）
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization'],
      maxAge: 600
    };
  }
  return {
    origin: cfg.allowList,     // 数组形式 = 白名单，cors 会逐个比对 Origin
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    maxAge: 600
  };
}

module.exports = { parseOrigins, load, corsOptions };