// ============================================
// 26牛牛 - 推广奖励比例集中配置
// ============================================
// 说明:
//   - 所有推广奖励比例只在本文件维护，禁止散落在 HTML / CSS / 各 JS / 各 API
//   - 当前为「暂定展示规则」，仅用于页面展示与结构占位
//   - 本阶段【不接入真实游戏下注流水，不做真实资金结算】
//   - 修改比例时只需修改本文件
// ============================================

// 比例数值（百分比，展示用）
const REFERRAL_RATES = {
  // 直属下线奖励 0.5%
  DIRECT: 0.5,
  // 二级下线奖励 0.3%
  SECOND_LEVEL: 0.3,
  // 自身游戏奖励 0.7%
  SELF: 0.7
};

// 邀请层级常量（与 referral_relations.level 对应）
const REFERRAL_LEVEL = {
  DIRECT: 1,        // 一级（直属）
  SECOND_LEVEL: 2   // 二级
};

// 每日数据统计的默认值（本阶段无真实流水，统一返回 0，绝不造假）
const REFERRAL_EMPTY_STATS = {
  total_reward: 0,
  self_reward: 0,
  direct_reward: 0,
  second_reward: 0,
  new_members: 0
};

// 比例展示文案（供前端渲染三栏卡片，避免前端硬编码）
function getRateCards() {
  return [
    {
      key: 'direct',
      title: '直属下线',
      rate: REFERRAL_RATES.DIRECT,
      unit: '%',
      desc: '奖励'
    },
    {
      key: 'second',
      title: '下线会员（二级）',
      rate: REFERRAL_RATES.SECOND_LEVEL,
      unit: '%',
      desc: '奖励'
    },
    {
      key: 'self',
      title: '自身游戏奖励',
      rate: REFERRAL_RATES.SELF,
      unit: '%',
      desc: '奖励'
    }
  ];
}

// 供 API 返回给前端的比例对象（前端不硬编码数字）
function publicRates() {
  return {
    direct: REFERRAL_RATES.DIRECT,
    second: REFERRAL_RATES.SECOND_LEVEL,
    self: REFERRAL_RATES.SELF
  };
}

module.exports = {
  REFERRAL_RATES,
  REFERRAL_LEVEL,
  REFERRAL_EMPTY_STATS,
  getRateCards,
  publicRates
};