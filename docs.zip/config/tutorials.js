// ============================================
// 26牛牛 - 玩法教学（Tutorial）集中配置
// ============================================
// 说明:
//   - 玩法介绍是【独立纯教学页面】，绝对不出现聊天输入框 / 玩家聊天 /
//     红包 / 贴图 / 打赏客服 / 假的玩家消息
//   - 大厅「玩法介绍」区域按本文件渲染卡片，点击进入 /tutorial.html?id=xxx
//   - 新增教学内容只需在此追加，不需要改大厅结构
//   - 数值（倍数 / 抽水）以本文件为唯一来源，页面不再硬编码
// ============================================

// 全局教学数值（集中维护）
const TUTORIAL_NUMBERS = {
  FEE_BANKER: 5,        // 庄家抽水 %
  FEE_PLAYER: 5,        // 闲赢抽水 %
  MAX_MULTIPLIER: 17    // 最高倍数（豹子）
};

// 牌型与倍数（唯一来源）
const CARD_TYPES = [
  { name: '豹子', multiplier: 17, desc: '三位非零相同数字，如 1.11 / 7.77 / 9.99' },
  { name: '满牛', multiplier: 15, desc: '整数金额，如 1.00 / 5.00 / 88.00' },
  { name: '反顺', multiplier: 14, desc: '三位数字严格递减，如 9.87 / 3.21 / 2.10' },
  { name: '顺子', multiplier: 13, desc: '三位数字严格递增，如 0.12 / 1.23 / 7.89' },
  { name: '对子', multiplier: 12, desc: '末两位相同非零数字，如 1.22 / 7.55' },
  { name: '金牛', multiplier: 11, desc: '仅一位非零数字，如 0.10 / 0.50' },
  { name: '普通', multiplier: '1-10', desc: '按点数倍数结算' }
];

// 点数说明
const POINT_RULES = [
  { point: '牛牛', desc: '末三位数字相加为 10 的倍数，即为牛牛（最高点数）' },
  { point: '牛九 ~ 牛一', desc: '任取两位之和为 10 的倍数，剩余一位即为牛数' },
  { point: '无牛', desc: '任意两位数字之和都不是 10 的倍数' }
];

// 教学条目：每个条目 = 一张大厅卡片 + 一个独立教学页面
const TUTORIALS = [
  {
    id: '26niuniu-basics',
    title: '26牛牛玩法介绍',
    subtitle: '从零开始了解 26 牛牛',
    group: 'basics',
    icon: 'book',
    order: 1,
    sections: [
      {
        title: '什么是 26 牛牛',
        paragraphs: [
          '26 牛牛是以「红包金额」作为牌面的多人对战玩法。每局由一位庄家坐庄，其余玩家为闲家。',
          '每个红包金额的末三位数字即为你的牌面，按牌型与点数计算倍数，倍数越高收益越高。'
        ]
      },
      {
        title: '一局是怎么进行的',
        steps: [
          { title: '竞标上庄', desc: '想坐庄的玩家竞标庄钱，出价最高者成为本局庄家。' },
          { title: '闲家下注', desc: '闲家在下注倒计时内选择金额下注，超时视为弃权。' },
          { title: '发放红包', desc: '系统按规则为每位参与者生成红包链接。' },
          { title: '抢包', desc: '玩家按操作顺序抢包，金额决定牌面。' },
          { title: '结算', desc: '按牌型倍数与抽水规则结算，结果写入游戏记录。' }
        ]
      },
      {
        title: '需要注意',
        paragraphs: [
          '牌型、倍数、抽水比例会根据运营情况调整，请以游戏内显示为准。',
          '上庄前请确认账户余额足够覆盖庄池，不足将自动退回竞标庄钱。'
        ]
      }
    ]
  },
  {
    id: 'newbie-guide',
    title: '新手必看',
    subtitle: '第一次玩先看这里',
    group: 'start',
    icon: 'shield',
    order: 2,
    sections: [
      {
        title: '三步上手',
        steps: [
          { title: '进入游戏群', desc: '从大厅点击「进入游戏群」，在群内等待开局。' },
          { title: '看余额', desc: '在「钱包」中确认游戏余额与现金筹码，两者相互独立。' },
          { title: '先小额试玩', desc: '建议先小额下注熟悉节奏，再考虑上庄。' }
        ]
      },
      {
        title: '常见疑问（新手）',
        faq: [
          { q: '没抢到红包怎么办？', a: '按规则未抢部分自动处理或退回，不参与结算。' },
          { q: '为什么我被判定为平局？', a: '庄家金额不足赔付时会进入喝水机制，结果视为平局，仅退还本金。' }
        ]
      }
    ]
  },
  {
    id: 'game-rules',
    title: '游戏规则',
    subtitle: '点数 · 牌型 · 倍数 · 抽水',
    group: 'rules',
    icon: 'code',
    order: 3,
    sections: [
      { title: '点数说明', points: POINT_RULES },
      {
        title: '牌型与倍数',
        card_types: CARD_TYPES,
        paragraphs: ['倍数从普通牌型的 1-10 倍，到豹子的 ' + TUTORIAL_NUMBERS.MAX_MULTIPLIER + ' 倍。']
      },
      {
        title: '抽水与费用',
        paragraphs: [
          '庄家盈利时，平台从盈利中抽取庄家抽水（默认 ' + TUTORIAL_NUMBERS.FEE_BANKER + '%）。',
          '闲家赢钱时，扣除闲赢抽水（默认 ' + TUTORIAL_NUMBERS.FEE_PLAYER + '%）。',
          '具体比例以游戏内显示为准，本页面仅作说明。'
        ]
      }
    ]
  },
  {
    id: 'game-flow',
    title: '游戏流程',
    subtitle: '从竞标到结算的完整顺序',
    group: 'rules',
    icon: 'refresh',
    order: 4,
    sections: [
      {
        title: '流程顺序',
        steps: [
          { title: '1. 抢庄阶段', desc: '竞标庄钱，最高者成为庄家，其余为闲家。' },
          { title: '2. 下注阶段', desc: '闲家在倒计时内下注；超时弃权，不参与结算。' },
          { title: '3. 发红包', desc: '系统为每位参与者生成红包链接。' },
          { title: '4. 抢包阶段', desc: '按抢包顺序记录金额，形成牌面。' },
          { title: '5. 结算阶段', desc: '按倍数与抽水结算，写入游戏记录。' },
          { title: '6. 续庄或结束', desc: '庄家盈利可选择续庄一次，或结束本局。' }
        ]
      },
      {
        title: '特殊情况',
        paragraphs: [
          '无人竞标庄钱：本局自动取消，无人参与结算。',
          '下注阶段无人下注：本局取消，庄池全额退回庄家。',
          '红包链接异常 / 失效：系统自动取消本局，冻结金额原路退回。',
          '抢包超时：未抢部分按规则自动结算或退回。'
        ]
      }
    ]
  },
  {
    id: 'banker-player',
    title: '庄家与闲家',
    subtitle: '两种身份，两种体验',
    group: 'rules',
    icon: 'account',
    order: 5,
    sections: [
      {
        title: '如果您是庄家',
        paragraphs: [
          '承担全桌输赢，赔付总额以庄池为上限，不会超过庄池亏损。',
          '本局所有已下注的闲家都与您对赌。',
          '庄家盈利时，平台从盈利中抽取庄家抽水（默认 ' + TUTORIAL_NUMBERS.FEE_BANKER + '%）。',
          '本局结束后可选择「续庄」，同一玩家每桌仅可续庄一次。'
        ]
      },
      {
        title: '如果您是闲家',
        paragraphs: [
          '请在下注倒计时内完成下注；超时未下注视为弃权，不参与结算。',
          '赢家按牌型倍数 × 下注获得收益，并扣除闲赢抽水。',
          '输家下注全数归庄家。',
          '未下注 / 弃权时，本局对您不结算，余额不变。'
        ]
      },
      {
        title: '喝水机制',
        paragraphs: [
          '庄家上庄金额不足赔付后续闲家时，剩余玩家进入喝水机制，结果视为平局，仅退还本金。',
          '赔付顺序固定，不会随机调整。'
        ]
      }
    ]
  },
  {
    id: 'faq',
    title: '常见问题',
    subtitle: 'FAQ · 遇到问题先看这里',
    group: 'help',
    icon: 'notice',
    order: 6,
    sections: [
      {
        title: 'FAQ',
        faq: [
          { q: '游戏余额和现金筹码有什么区别？', a: '两者完全独立：游戏余额用于虚拟娱乐，现金筹码单独记账，不做混合计算。' },
          { q: '忘记用户名或密码怎么办？', a: '请联系在线客服或管理员进行人工身份核验，提供用户名、手机号与邮箱以便核对。' },
          { q: '提款审核如何处理？', a: '提款申请提交后会进入待审核状态，由管理员审核通过或拒绝；本阶段不执行真实银行出款。' },
          { q: '聊天里的系统消息是什么？', a: '游戏开始、抢庄、下注等阶段提示会以系统消息形式出现在游戏群聊天流中。' },
          { q: '可以自己添加其他玩家聊天吗？', a: '不可以。平台不提供玩家之间互相搜索或添加好友的能力，聊天只包含官方游戏群与在线客服。' }
        ]
      }
    ]
  }
];

/** 大厅卡片用的精简结构 */
function listTutorials() {
  return TUTORIALS.slice().sort((a, b) => a.order - b.order).map(t => ({
    id: t.id,
    title: t.title,
    subtitle: t.subtitle,
    group: t.group,
    icon: t.icon,
    order: t.order,
    section_count: (t.sections || []).length
  }));
}

/** 综合入口复用原有教学数据，避免规则数值出现两份来源。 */
const OVERVIEW = {
  id: '26niuniu-overview',
  title: '26牛牛玩法与规则',
  subtitle: '流程、点数、牌型与常见问题',
  group: 'basics', icon: 'book', order: 0,
  sections: [
    TUTORIALS.find(t => t.id === '26niuniu-basics').sections[0],
    TUTORIALS.find(t => t.id === 'game-flow').sections[0],
    ...TUTORIALS.find(t => t.id === 'game-rules').sections,
    ...TUTORIALS.find(t => t.id === 'banker-player').sections,
    TUTORIALS.find(t => t.id === 'game-flow').sections[1],
    TUTORIALS.find(t => t.id === 'newbie-guide').sections[1],
    TUTORIALS.find(t => t.id === 'faq').sections[0]
  ]
};

function getTutorial(id) {
  if (id === OVERVIEW.id) return OVERVIEW;
  return TUTORIALS.find(x => x.id === id) || null;
}

/** 供全局搜索使用的纯文本摘要（不含 HTML） */
function tutorialSearchText(t) {
  const parts = [t.title, t.subtitle];
  (t.sections || []).forEach(s => {
    parts.push(s.title || '');
    (s.paragraphs || []).forEach(p => parts.push(p));
    (s.steps || []).forEach(st => parts.push(st.title + ' ' + st.desc));
    (s.faq || []).forEach(f => parts.push(f.q + ' ' + f.a));
    (s.points || []).forEach(p => parts.push(p.point + ' ' + p.desc));
    (s.card_types || []).forEach(c => parts.push(c.name + ' ' + c.desc));
  });
  return parts.join(' ');
}

module.exports = {
  TUTORIAL_NUMBERS,
  CARD_TYPES,
  POINT_RULES,
  TUTORIALS,
  listTutorials,
  getTutorial,
  tutorialSearchText
};