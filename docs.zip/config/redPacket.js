// ============================================
// 26牛牛 - 聊天红包配置（群聊红包）
// ============================================
// 说明:
//   - 聊天红包使用平台内部【现金筹码】记账（users.cash_chips），
//     与游戏内的「红包对战」是完全不同的两件事，也与真实支付无关
//   - 不产生任何真实资金流动；余额变更全部写 balance_transactions 流水
//   - 所有阈值只在本文件维护，路由与前端不得写死
// ============================================

module.exports = {
  // 使用的资产（与 config/funds.js 的资产定义保持一致）
  ASSET: 'CASH_CHIPS',
  ASSET_TEXT: '现金筹码',
  // 允许发红包的频道（当前仅 26牛牛游戏群；客服频道为留言模式，不开放）
  CHANNELS: ['group'],
  // 发送者受禁言联动范围限制（config/moderation.js → MUTE.SCOPE.redpacket）
  SCOPE_KEY: 'redpacket',

  MIN_AMOUNT: 1,          // 单个红包总额下限（RM）
  MAX_AMOUNT: 500,        // 单个红包总额上限（RM）
  MIN_COUNT: 1,           // 最少个数
  MAX_COUNT: 100,         // 最多个数
  MIN_PER_PACKET: 0.01,   // 每份最小金额
  BLESSING_MAX: 40,       // 祝福语最大长度
  EXPIRE_HOURS: 24,       // 未抢完自动退回发送者
  ALLOW_SENDER_CLAIM: false, // 是否允许发送者抢自己的红包（默认不允许）
  CLAIM_LIST_LIMIT: 20,   // 红包详情最多展示的领取记录条数

  // 余额流水类型（balance_transactions.type，VARCHAR(30)）
  TX: {
    SEND: 'RED_PACKET_SEND',
    CLAIM: 'RED_PACKET_CLAIM',
    REFUND: 'RED_PACKET_REFUND'
  },
  TX_TEXT: {
    RED_PACKET_SEND: '聊天红包支出',
    RED_PACKET_CLAIM: '抢到聊天红包',
    RED_PACKET_REFUND: '聊天红包退回'
  },

  // 用户可见提示
  NOTICE: '聊天红包使用平台现金筹码，不可兑换真实资金。'
};
