// ============================================
// 26牛牛 - 用户治理规则集中配置
// ============================================
// 说明:
//   - 禁言/封禁的业务边界只在本文件维护，禁止散落在各个路由里写死
//   - 「禁言联动范围」决定被禁言账号还能做什么：
//       chat     发送聊天消息（游戏群 / 在线客服）
//       redpacket 发送聊天红包
//       room     创建 / 加入游戏房间
//       game     竞标上庄、下注、抢红包
//       withdraw 提交提款申请（资金流出）
//       deposit  提交充值订单（资金流入：按业务规则不限制，资金进来对用户无风险）
//   - 「双人复核」用于高风险治理动作：同一动作必须由另一个管理员确认后才生效
//   - 「在线状态」窗口：最近 N 秒内有 Socket 连接或聊天轮询视为在线
// ============================================

module.exports = {
  // ---------- 禁言 ----------
  MUTE: {
    MIN_MINUTES: 5,              // 最短 5 分钟
    MAX_MINUTES: 30 * 24 * 60,   // 最长 30 天
    EXPIRE_REMIND_MINUTES: 24 * 60, // 后台「即将解禁」提醒窗口（24 小时）
    // 禁言联动范围（true = 被禁言时禁止该动作）
    SCOPE: {
      chat: true,
      redpacket: true,
      room: true,
      game: true,
      withdraw: true,
      deposit: false
    }
  },
  // 动作中文名（用于前端提示与审计可读性）
  SCOPE_TEXT: {
    chat: '发送聊天消息',
    redpacket: '发送聊天红包',
    room: '创建 / 加入游戏房间',
    game: '竞标上庄 / 下注 / 抢包',
    withdraw: '提交提款申请',
    deposit: '提交充值订单'
  },

  // ---------- 双人复核 ----------
  DUAL_APPROVAL: {
    ENABLED: true,
    // 需要第二个管理员复核才生效的动作
    ACTIONS: ['user_status', 'user_role', 'user_unmute'],
    // 系统仅剩一名活跃管理员时自动降级为单人执行（避免后台被自己锁死），审计会标注单管理员降级
    DEGRADE_WHEN_SINGLE_ADMIN: true,
    MAX_PENDING_PER_ADMIN: 20      // 同一管理员最多同时挂起的复核请求
  },

  // ---------- 在线状态 ----------
  PRESENCE: {
    ONLINE_WINDOW_SECONDS: 90,     // 最近 90 秒内活跃 = 在线
    TOUCH_THROTTLE_SECONDS: 20,    // 同一用户写库节流（内存判断，避免频繁 UPDATE）
    ONLINE_LIST_LIMIT: 100         // 后台「在线用户」最多展示条数
  }
};
