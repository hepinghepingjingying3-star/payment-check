// ============================================
// 26牛牛 - 公告（Announcements）集中配置
// ============================================
// 说明:
//   - 公告结构统一在这里定义，禁止在 HTML 中硬编码公告内容
//   - 公告数据来源（合并后统一按 sort + 时间排序）:
//       1. 本文件的 FALLBACK 静态公告（系统内置，永远可用）
//       2. 数据库 announcements 表（可由管理后台维护）
//       3. 旧表 system_notices（兼容历史数据，自动映射为文字公告）
//   - 支持: 标题 / 内容 / 图片 / 状态 / 排序 / 开始时间 / 结束时间 / 置顶
//   - 过滤规则: status 必须 active；start_at <= now <= end_at（为空表示不限）
// ============================================

// 公告类型
const ANNOUNCEMENT_TYPES = {
  TEXT: 'text',       // 文字公告（弹窗 / 详情页展示正文）
  IMAGE: 'image',     // 图片公告（轮播展示图片）
  ACTIVITY: 'activity', // 活动公告
  SYSTEM: 'system'    // 系统公告
};

// 状态
const ANNOUNCEMENT_STATUS = {
  ACTIVE: 'active',
  HIDDEN: 'hidden'
};

// 内置公告（无后台数据时的兜底，保证大厅轮播永远不空白）
const FALLBACK_ANNOUNCEMENTS = [
  {
    id: 'sys-welcome',
    type: ANNOUNCEMENT_TYPES.SYSTEM,
    title: '欢迎来到 26 牛牛',
    summary: '全新大厅已上线，游戏群 · 玩法教学 · 钱包推广一站直达',
    content: '欢迎来到 26 牛牛平台。\n\n· 大厅：公告、平台推荐、玩法介绍、最近访问\n· 聊天：26牛牛游戏群 + 在线客服\n· 钱包：游戏余额与现金筹码独立记账\n· 推广：邀请码邀请好友\n\n祝您游戏愉快。',
    image: null,
    status: ANNOUNCEMENT_STATUS.ACTIVE,
    pinned: true,
    sort: 100,
    start_at: null,
    end_at: null
  },
  {
    id: 'sys-tutorial',
    type: ANNOUNCEMENT_TYPES.SYSTEM,
    title: '新手请先看玩法介绍',
    summary: '点数、牌型、倍数、庄闲规则一次看懂',
    content: '如果您是第一次接触 26 牛牛，建议先阅读「玩法介绍」。\n\n大厅 → 玩法介绍 → 26牛牛玩法介绍 / 新手必看 / 游戏规则 / 游戏流程。\n\n玩法教学是独立的教学页面，与游戏群聊天分开，不会出现聊天内容。',
    image: null,
    status: ANNOUNCEMENT_STATUS.ACTIVE,
    pinned: false,
    sort: 90,
    start_at: null,
    end_at: null
  }
];

// 公告展示条数上限（大厅轮播）
const BANNER_LIMIT = 5;

/** 判断公告在给定时间点是否有效 */
function isEffective(a, now) {
  const t = (now instanceof Date ? now : new Date()).getTime();
  if (a.status !== ANNOUNCEMENT_STATUS.ACTIVE) return false;
  if (a.start_at) {
    const s = new Date(a.start_at).getTime();
    if (Number.isFinite(s) && t < s) return false;
  }
  if (a.end_at) {
    const e = new Date(a.end_at).getTime();
    if (Number.isFinite(e) && t > e) return false;
  }
  return true;
}

/** 统一排序：置顶优先 → sort 降序 → 创建时间降序 */
function sortAnnouncements(list) {
  return list.slice().sort((a, b) => {
    if (!!a.pinned !== !!b.pinned) return a.pinned ? -1 : 1;
    if ((b.sort || 0) !== (a.sort || 0)) return (b.sort || 0) - (a.sort || 0);
    const at = new Date(a.created_at || 0).getTime();
    const bt = new Date(b.created_at || 0).getTime();
    return bt - at;
  });
}

/** 供 API 输出（去掉内部字段） */
function publicAnnouncement(a) {
  return {
    id: a.id,
    type: a.type || ANNOUNCEMENT_TYPES.TEXT,
    title: a.title,
    summary: a.summary || '',
    content: a.content || '',
    image: a.image || null,
    pinned: !!a.pinned,
    sort: a.sort || 0,
    start_at: a.start_at || null,
    end_at: a.end_at || null,
    created_at: a.created_at || null
  };
}

/** 列表用的精简结构（不含长正文） */
function briefAnnouncement(a, contentLimit) {
  const full = publicAnnouncement(a);
  const limit = contentLimit || 120;
  let text = String(full.content || '').replace(/\s+/g, ' ').trim();
  if (text.length > limit) text = text.slice(0, limit) + '…';
  full.content = text;
  return full;
}

module.exports = {
  ANNOUNCEMENT_TYPES,
  ANNOUNCEMENT_STATUS,
  FALLBACK_ANNOUNCEMENTS,
  BANNER_LIMIT,
  isEffective,
  sortAnnouncements,
  publicAnnouncement,
  briefAnnouncement
};