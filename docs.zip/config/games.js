// ============================================
// 26牛牛 - 游戏（平台推荐）集中配置
// ============================================
// 说明:
//   - 大厅「平台推荐」按本文件渲染，新增游戏只需在此追加一项，
//     不需要重新设计大厅
//   - status: online=运行中, offline=未开放, maintenance=维护中
//   - entry.type: 'chat'    → 进入真实聊天页面（26牛牛游戏群，群里开局、游戏、结算）
//                 'tutorial'→ 进入玩法教学页面
//                 'none'    → 尚未开放（入口如实显示为不可用，不做假跳转）
//   - 重要：26牛牛的游戏核心就在「26牛牛游戏群」里，聊天系统本身就是游戏载体。
//     因此没有任何「独立游戏页」入口，大厅/我的/群聊一律指向同一个聊天群页面。
//   - 规则：本文件只登记「真实存在」的游戏；未开发完成的游戏不写入本文件，
//     避免大厅出现假名字、假图标、点不动的卡片。
//     将来要上线新游戏时，按下面 26niuniu 的结构复制一份并改 id / name /
//     logo_candidates / intro / entry 即可，无需改动大厅。
// ============================================

// 标签（大厅 GameCard 上的小徽标）
const GAME_TAGS = {
  HOT: { key: 'hot', label: '热门' },
  RECOMMEND: { key: 'recommend', label: '推荐' },
  NEW: { key: 'new', label: '新上线' },
  MAINTENANCE: { key: 'maintenance', label: '维护中' }
};

const GAMES = [
  {
    id: '26niuniu',
    name: '26牛牛游戏群',
    short_name: '26牛牛',
    logo_key: 'games',            // 对应 config/assets.js 的候选文件名
    logo_candidates: ['26niuniu.png', '26niuniu.svg'],
    intro: '在游戏群里开局：抢庄 · 选倍数 · 比牌型，全程使用游戏积分',
    description: '多人抢庄，5 张牌比牛牛牌型，倍数最高 5 倍。游戏就在聊天群里进行，只使用不可充值、不可提现的游戏积分。',
    status: 'online',
    status_text: '运行中',
    tags: ['hot', 'recommend'],
    is_official: true,
    order: 1,
    // 唯一入口：26牛牛游戏群（群里开局 / 操作 / 结算，没有独立游戏页）
    entry: { type: 'chat', url: '/group-chat.html', label: '进入游戏群' },
    // 玩法介绍 → 教学页面（只有规则，不参与对局）
    tutorial_id: '26niuniu-basics'
  }
  // 将来新增真实游戏时，在这里追加一项（照抄上面的结构并改字段）。
  // 未完成的游戏不写进来：大厅只展示真实可用的入口。
];

// 大厅「最近访问」可记录的目标类型（白名单，防止脏数据）
const RECENT_TARGET_TYPES = ['game', 'tutorial', 'announcement'];

/** 供 API 输出的精简结构（不含任何内部字段） */
function publicGame(g) {
  return {
    id: g.id,
    name: g.name,
    short_name: g.short_name || g.name,
    intro: g.intro,
    description: g.description,
    status: g.status,
    status_text: g.status_text,
    tags: g.tags || [],
    is_official: !!g.is_official,
    order: g.order || 99,
    entry: g.entry,
    tutorial_id: g.tutorial_id || null,
    logo_candidates: g.logo_candidates || []
  };
}

function listGames() {
  return GAMES.slice().sort((a, b) => (a.order || 99) - (b.order || 99)).map(publicGame);
}

function getGame(id) {
  const g = GAMES.find(x => x.id === id);
  return g ? publicGame(g) : null;
}

module.exports = {
  GAME_TAGS,
  GAMES,
  RECENT_TARGET_TYPES,
  listGames,
  getGame,
  publicGame
};