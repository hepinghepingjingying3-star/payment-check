// ============================================
// 26牛牛 - 手机号注册 OTP（验证码）集中配置
// ============================================
// 当前不接入第三方短信服务，采用「管理员手动发送验证码」模式：
//   用户输入手机号 → 点击获取验证码 → 后端生成 6 位随机 OTP
//   → 存库（只存哈希） → 管理后台显示待发送验证码
//   → 管理员复制后通过 WhatsApp 手动发送 → 用户输入验证码 → 后端验证
// ============================================

const OTP_CONFIG = {
  LENGTH: 6,                 // 6 位随机数字
  TTL_SECONDS: 300,          // 5 分钟有效
  RESEND_COOLDOWN_SECONDS: 60,    // 首次发送间隔 60 秒
  RESEND_COOLDOWN_SUBSEQUENT_SECONDS: 60, // 后续发送间隔 60 秒
  MAX_ATTEMPTS: 6,           // 单个验证码最多错误次数，达到上限锁定
  MAX_SEND_PER_PHONE_PER_DAY: 10, // 单手机号每日发送上限（防刷）
  MAX_SEND_PER_IP_PER_HOUR: 20,   // 单 IP 每小时发送上限（防刷）
  LOCK_MINUTES: 30,          // 连续错误达到上限后锁定分钟数
  REGISTER_TOKEN_TTL_SECONDS: 600 // 验证成功后签发的注册凭证有效期（10 分钟）
};

// OTP 状态
const OTP_STATUS = {
  PENDING: 'pending',     // 已生成，等待管理员发送
  SENT: 'sent',           // 管理员已标记发送
  VERIFIED: 'verified',   // 用户验证成功（随即失效）
  EXPIRED: 'expired',     // 过期
  LOCKED: 'locked'        // 错误次数过多被锁定
};

// 供前端展示的中文状态
const OTP_STATUS_TEXT = {
  pending: '等待发送',
  sent: '已发送',
  verified: '已验证',
  expired: '已过期',
  locked: '已锁定'
};

module.exports = { OTP_CONFIG, OTP_STATUS, OTP_STATUS_TEXT };