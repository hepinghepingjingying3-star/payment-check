// ============================================
// 26牛牛 - 站点配置中心（单一数据来源）
// 作用:
//   - 所有可运营配置集中在这里（默认值），数据库 system_settings 只存「管理员改过的项」
//   - 前端不再硬编码站点名称 / 客服名称 / 充值区间 / 推广比例 等
// 说明:
//   - 全部为「虚拟现金筹码」相关配置，不涉及任何真实资金通道
//   - 推广比例仅用于推广奖励台账（reward ledger）
// ============================================

const { REFERRAL_RATES } = require('./referral');

const SETTINGS = [
  {
    key: 'site_name',
    label: '网站名称',
    type: 'text',
    group: 'basic',
    max: 30,
    default: '26牛牛',
    note: '显示在登录、注册、大厅顶部与浏览器标题'
  },
  {
    key: 'logo_url',
    label: 'Logo 图片地址',
    type: 'text',
    group: 'basic',
    max: 200,
    default: '',
    note: '留空则使用文字 Logo；只允许站内路径（/assets/...）或 https 图片地址'
  },
  {
    key: 'support_name',
    label: '客服名称',
    type: 'text',
    group: 'basic',
    max: 30,
    default: '在线客服',
    note: '显示在聊天会话列表与客服页面'
  },
  {
    key: 'support_notice',
    label: '客服提示语',
    type: 'text',
    group: 'basic',
    max: 120,
    default: '客服暂时离线，可以留言，客服上线后会回复',
    note: '客服会话的副标题'
  },
  {
    key: 'group_chat_name',
    label: '游戏群名称',
    type: 'text',
    group: 'basic',
    max: 30,
    default: '26牛牛游戏群',
    note: '显示在消息列表与群聊顶部'
  },
  {
    key: 'deposit_min',
    label: '最低充值金额（RM）',
    type: 'number',
    group: 'funds',
    min: 30,
    max: 50000,
    default: 30,
    note: '后端强制校验；低于该金额的充值订单会被拒绝'
  },
  {
    key: 'deposit_max',
    label: '最高充值金额（RM）',
    type: 'number',
    group: 'funds',
    min: 30,
    max: 50000,
    default: 50000,
    note: '后端强制校验；必须大于等于最低金额'
  },
  {
    key: 'receiving_bank_name',
    label: '收款银行名称（已弃用）',
    type: 'text',
    group: 'funds',
    max: 80,
    default: '',
    note: '已弃用：收款账户请在后台「收款账户」中维护；本项仅保留历史兼容，迁移 017 已把旧值导入收款账户表'
  },
  {
    key: 'receiving_account_number',
    label: '收款账号（已弃用）',
    type: 'text',
    group: 'funds',
    max: 80,
    default: '',
    note: '已弃用：用户现在只会看到自己充值订单被分配的收款账户'
  },
  {
    key: 'receiving_account_holder',
    label: '收款账户姓名（已弃用）',
    type: 'text',
    group: 'funds',
    max: 80,
    default: '',
    note: '已弃用：收款账户请在后台「收款账户」中维护'
  },
  {
    key: 'withdraw_min',
    label: '最低提现金额（RM）',
    type: 'number',
    group: 'funds',
    min: 0.01,
    max: 100000,
    default: 0.01,
    note: '后端强制校验；金额必须大于0且不能超过可用余额'
  },
  {
    key: 'referral_rate_direct',
    label: '直属下线奖励比例（%）',
    type: 'number',
    group: 'referral',
    min: 0,
    max: 10,
    step: 0.1,
    default: REFERRAL_RATES.DIRECT,
    note: '按已通过有效订单的现金筹码数量计算，写入奖励台账'
  },
  {
    key: 'referral_rate_second',
    label: '二级下线奖励比例（%）',
    type: 'number',
    group: 'referral',
    min: 0,
    max: 10,
    step: 0.1,
    default: REFERRAL_RATES.SECOND_LEVEL,
    note: '与直属比例相互独立'
  },
  {
    key: 'referral_rate_self',
    label: '自身游戏奖励比例（%）',
    type: 'number',
    group: 'referral',
    min: 0,
    max: 10,
    step: 0.1,
    default: REFERRAL_RATES.SELF,
    note: '奖励配置，不产生现金结算'
  },
  {
    key: 'upload_max_kb',
    label: '图片上传大小上限（KB）',
    type: 'number',
    group: 'limits',
    min: 64,
    max: 10240,
    default: 2048,
    note: '凭证 / 头像 / 贴图统一上限；服务器会再次校验真实文件内容'
  },
  {
    key: 'chat_max_length',
    label: '聊天单条消息字数上限',
    type: 'number',
    group: 'limits',
    min: 20,
    max: 2000,
    default: 500,
    note: '超出会被后端拒绝'
  },
  {
    key: 'chat_poll_seconds',
    label: '聊天轮询间隔（秒）',
    type: 'number',
    group: 'limits',
    min: 2,
    max: 30,
    default: 6,
    note: '无 Socket 时的新消息拉取间隔'
  },
  {
    key: 'maintenance_mode',
    label: '维护模式',
    type: 'boolean',
    group: 'system',
    default: false,
    note: '开启后普通用户看到「系统维护中」，管理员与客服仍可正常进入'
  },
  {
    key: 'maintenance_notice',
    label: '维护公告文案',
    type: 'text',
    group: 'system',
    max: 200,
    default: '我们正在进行系统升级，请稍后再回来。',
    note: '维护期间显示在维护页面'
  },
  {
    key: 'niu_game_enabled',
    label: '26牛牛娱乐场开关',
    type: 'boolean',
    group: 'game',
    default: true,
    note: '关闭后玩家无法进入场次，进行中的一局安全作废且不使用积分；积分不可充值、不可提现、不可兑换现金'
  }
];

const BY_KEY = {};
SETTINGS.forEach(s => { BY_KEY[s.key] = s; });

const DEFAULTS = {};
SETTINGS.forEach(s => { DEFAULTS[s.key] = s.default; });

/** 充值快捷现金筹码档位（前端展示；仍受最低/最高数量约束） */
const DEPOSIT_QUICK = [30, 100, 500, 1000, 2000, 3000, 5000];

/** 收款资料由系统设置中心提供，默认不配置 */
const TEST_BANK = {
  account_name: '',
  bank_name: '',
  account_no: '',
  notice: '暂未配置收款账户'
};

/** 公开给未登录用户的字段（不含任何敏感配置） */
const PUBLIC_KEYS = [
  'site_name', 'logo_url', 'support_name', 'support_notice', 'group_chat_name',
  'deposit_min', 'deposit_max', 'withdraw_min', 'chat_max_length', 'chat_poll_seconds',
  'maintenance_mode', 'maintenance_notice'
];

module.exports = { SETTINGS, BY_KEY, DEFAULTS, DEPOSIT_QUICK, TEST_BANK, PUBLIC_KEYS };