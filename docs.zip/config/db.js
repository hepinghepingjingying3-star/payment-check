// 26牛牛 - MySQL 数据库连接配置
// 这个文件负责连接 MySQL 数据库

// 加载环境变量（读取 .env 文件中的数据库配置）
require('dotenv').config();

// 引入 mysql2 库（用于连接 MySQL 数据库）
const mysql = require('mysql2');

// 创建数据库连接池
// 连接池可以复用连接，比每次新建连接更高效
const pool = mysql.createPool({
  host: process.env.DB_HOST,        // 数据库地址（.env 中配置）
  port: process.env.DB_PORT,        // 数据库端口（.env 中配置）
  user: process.env.DB_USER,        // 数据库用户名（.env 中配置）
  password: process.env.DB_PASSWORD, // 数据库密码（.env 中配置）
  database: process.env.DB_NAME,    // 数据库名称（.env 中配置）
  waitForConnections: true,         // 连接池满时等待而不是报错
  connectionLimit: 10,              // 最大连接数
  queueLimit: 0                     // 排队连接数不限
});

// 导出连接池，供其他文件使用
module.exports = pool;