// ============================================
// 26牛牛 - 图片 / 静态资源集中配置
// ============================================
// 说明:
//   - 所有业务图片（Logo / 头像 / 官方贴图 / Banner / 游戏图标 / 教学插图）
//     的路径只在本文件维护，禁止散落在几十个 HTML / JS 中
//   - 本项目当前【不包含】任何官方图片素材：正式素材由站长自行放入
//     public/assets/<目录>/ 中，文件名与下方 candidates 对应即可自动生效
//   - 服务端会扫描 public/assets 目录，只有真实存在的文件才会下发给前端，
//     前端只在文件存在时渲染 <img>，因此不会产生 404 请求
//   - CSS 只负责尺寸 / 布局 / 圆角 / 比例，绝不修改原图内容
// ============================================

const path = require('path');

// 资源根目录（相对项目根）
const ASSETS_ROOT = path.join(__dirname, '..', 'public', 'assets');

// 逻辑资源 → 目录 + 候选文件名（按顺序取第一个真实存在的文件）
// 站长只需按候选名放入文件即可，无需改代码
const GROUPS = {
  // 品牌 Logo（登录页 / 启动页 / 我的页）
  logo: {
    dir: 'logo',
    urlBase: '/assets/logo',
    candidates: ['logo.png', 'logo.webp', 'logo.svg', '26niuniu.png', '26niuniu.svg']
  },
  // 官方头像（游戏群头像 / 客服头像 / 系统头像）
  avatars: {
    dir: 'avatars',
    urlBase: '/assets/avatars',
    candidates: ['official.png', 'official.webp', 'official.jpg', 'group.png', 'support.png', 'system.png']
  },
  // 官方贴图（禁止 emoji，必须使用真实图片）
  stickers: {
    dir: 'stickers/official',
    urlBase: '/assets/stickers/official',
    candidates: [
      'welcome.png', 'hello.png', 'thanks.png', 'goodluck.png',
      'win.png', 'gg.png', 'cheer.png', 'angry.png', 'cry.png', 'rich.png'
    ]
  },
  // 轮播公告图片
  banners: {
    dir: 'banners',
    urlBase: '/assets/banners',
    candidates: ['banner1.png', 'banner2.png', 'banner3.png', 'banner4.png', 'banner5.png']
  },
  // 游戏图标（每个游戏一个）
  games: {
    dir: 'games',
    urlBase: '/assets/games',
    candidates: ['26niuniu.png', 'game-a.png', 'game-b.png', 'game-c.png']
  },
  // 玩法教学插图
  tutorial: {
    dir: 'tutorial',
    urlBase: '/assets/tutorial',
    candidates: [
      'points.png', 'card-types.png', 'flow.png',
      'banker.png', 'multiplayer.png', 'tips.png'
    ]
  }
};

// 用户自定义贴图上传目录（用户自己上传的图片，非官方素材）
const USER_STICKER_DIR = 'stickers/user';
const USER_STICKER_URL_BASE = '/assets/stickers/user';

module.exports = {
  ASSETS_ROOT,
  GROUPS,
  USER_STICKER_DIR,
  USER_STICKER_URL_BASE
};