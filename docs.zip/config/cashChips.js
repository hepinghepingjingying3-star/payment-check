// ============================================
// 26牛牛 - 现金筹码集中配置
// ============================================
// 说明:
//   - 全站唯一资产名称：现金筹码（系统内虚拟资产）
//   - 不连接任何真实支付网关；不实现真实现金兑换 / 赌博资金结算 / 实际现金提款
//   - 所有额度、状态文案、账户类型只在本文件维护，禁止散落在各路由/页面
// ============================================

// 资产标识（与 users.cash_chips、balance_transactions.currency_type 对应）
const ASSET = 'CASH_CHIPS';
// 全站统一显示名称
const ASSET_TEXT = '现金筹码';

module.exports = {
  ASSET,
  ASSET_TEXT,

  // ---------- 充值（现金筹码）----------
  RECHARGE: {
    MIN: 30,
    MAX: 50000,
    DECIMALS: 2,
    YOURSELF_ONLY: true,
    QUICK: [30, 100, 500, 1000, 2000, 3000, 5000],
    REMARK_MAX: 200,
    STATUS_TEXT: {
      PENDING: '待审核',
      COMPLETED: '审核通过',
      REJECTED: '审核拒绝',
      CANCELLED: '已取消',
      EXPIRED: '已过期'
    }
  },

  // ---------- 后台收款账户（仅管理员可维护；不接真实支付网关）----------
  RECEIVING: {
    MAX_ACCOUNTS: 100,
    TYPES: [
      { code: 'BANK', label: '银行' },
      { code: 'EWALLET', label: '电子钱包' }
    ],
    TYPE_TEXT: { BANK: '银行', EWALLET: '电子钱包' },
    NAME_MAX: 100,
    HOLDER_MAX: 100,
    ACCOUNT_NO_MIN: 4,
    ACCOUNT_NO_MAX: 40,
    REMARK_MAX: 255,
    SORT_MIN: -9999,
    SORT_MAX: 9999,
    NO_ACCOUNT_MESSAGE: '目前暂无可用的收款账户，请联系客服。',
    PAYMENT_REFERENCE_MAX: 40
  },

  // ---------- 提现申请（本阶段不执行真实出款）----------
  WITHDRAW: {
    MIN: 0.01,
    MAX: 50000,
    DECIMALS: 2,
    ACCOUNT_REF_MAX: 120,
    ACCOUNT_NAME_MAX: 60,
    REMARK_MAX: 200,
    BANK_ACCOUNT_MIN: 6,
    BANK_ACCOUNT_MAX: 24,
    ACCOUNT_TYPES: [
      { code: 'BANK', label: '银行账户' },
      { code: 'TNG', label: 'TNG' },
      { code: 'DUITNOW', label: 'DuitNow' },
      { code: 'OTHER', label: '其他' }
    ],
    DEFAULT_ACCOUNT_TYPE: 'BANK',
    STATUS_TEXT: {
      PENDING: '待审核',
      APPROVED: '审核通过',
      REJECTED: '审核拒绝',
      CANCELLED: '已取消'
    }
  },

  // ---------- 现金筹码转账 ----------
  TRANSFER: {
    MIN: 1,
    MAX: 50000,
    DECIMALS: 2,
    DAILY_LIMIT: 5000,          // 单日累计转账上限（系统内虚拟现金筹码额度）
    UID_MAX: 32,
    REMARK_MAX: 100,
    STATUS_TEXT: { SUCCESS: '成功' }
  },

  // ---------- 6 位支付密码 ----------
  PAY_PASSWORD: {
    LENGTH: 6,
    MAX_ATTEMPTS: 5,
    LOCK_MINUTES: 15
  },

  // ---------- 账户资料审核 ----------
  ACCOUNT_REVIEW: {
    STATUS_TEXT: {
      pending: '待审核',
      approved: '已通过',
      rejected: '已拒绝'
    },
    MY_STATUS_TEXT: {
      pending: '审核中',
      approved: '已通过',
      rejected: '审核未通过'
    }
  },

  // ---------- 流水类型（balance_transactions.type）----------
  LEDGER_TYPES: {
    RECHARGE: 'RECHARGE',
    TRANSFER_IN: 'TRANSFER_IN',
    TRANSFER_OUT: 'TRANSFER_OUT',
    WITHDRAW_REQUEST: 'WITHDRAW_REQUEST',
    ADJUSTMENT: 'ADJUSTMENT',
    DEPOSIT: 'DEPOSIT',           // 历史兼容
    ADMIN_GRANT: 'ADMIN_GRANT'    // 历史兼容
  },
  LEDGER_TYPE_TEXT: {
    RECHARGE: '现金筹码充值',
    TRANSFER_IN: '转入',
    TRANSFER_OUT: '转出',
    WITHDRAW_REQUEST: '提现申请',
    ADJUSTMENT: '管理员调整',
    DEPOSIT: '充值（历史）',
    ADMIN_GRANT: '管理员发放'
  }
};
