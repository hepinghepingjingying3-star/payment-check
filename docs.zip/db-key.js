// 一次性：关键表结构（recharge_orders / real_name_reviews / referral_relations / notifications）
'use strict';
require('dotenv').config();
const fs = require('fs');
const mysql = require('mysql2/promise');
(async () => {
  const c = await mysql.createConnection({
    host: process.env.DB_HOST, port: process.env.DB_PORT, user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
  const out = [];
  for (const t of ['recharge_orders', 'real_name_reviews', 'referral_relations', 'notifications', 'admin_approvals']) {
    const [cols] = await c.query(
      'SELECT column_name, column_type, is_nullable, column_default, column_key FROM information_schema.columns WHERE table_schema=? AND table_name=? ORDER BY ordinal_position',
      [process.env.DB_NAME, t]);
    out.push('--- ' + t + ' ---');
    out.push(cols.map(x => x.COLUMN_NAME + ' ' + x.COLUMN_TYPE + (x.IS_NULLABLE === 'YES' ? ' NULL' : ' NN') + (x.COLUMN_KEY ? ' [' + x.COLUMN_KEY + ']' : '')).join(' | '));
    const [idx] = await c.query('SHOW INDEX FROM ' + t);
    out.push('IDX: ' + idx.map(i => i.Key_name + (i.Non_unique === 0 ? '(U)' : '') + '→' + i.Column_name).join(', '));
    out.push('');
  }
  fs.writeFileSync(__dirname + '/db-key.txt', out.join('\n'), 'utf8');
  await c.end();
  console.log('DONE');
})().catch(e => { console.error('ERR ' + e.message); process.exit(1); });
