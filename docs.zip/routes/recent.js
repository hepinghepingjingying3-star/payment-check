// ============================================
// 26牛牛 - 最近访问路由
//   - GET    /api/recent     最近访问（最多 10 条）
//   - POST   /api/recent     记录访问 { target_type, target_id, title }
//   - DELETE /api/recent     清空最近访问
// 说明:
//   - 只记录 游戏 / 玩法介绍 / 公告，禁止记录玩家（防止通过最近访问发现其他玩家）
//   - 超过上限自动清理旧记录，不会无限增长
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { RECENT_TARGET_TYPES } = require('../config/games');
const { ok, fail } = require('../utils/request');

const TYPE_TEXT = { game: '游戏', tutorial: '玩法介绍', announcement: '公告' };
const RECENT_LIMIT = 10;

function validType(t) { return RECENT_TARGET_TYPES.includes(String(t)); }
function clip(s, n) { return String(s || '').slice(0, n || 120); }

// GET /api/recent
router.get('/recent', auth, async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      `SELECT id, target_type, target_id, title, visited_at
       FROM recent_visits WHERE user_id = ? ORDER BY visited_at DESC LIMIT ?`,
      [req.user.id, RECENT_LIMIT]
    );
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        target_type: r.target_type,
        target_type_text: TYPE_TEXT[r.target_type] || r.target_type,
        target_id: r.target_id,
        title: r.title || '',
        visited_at: r.visited_at
      }))
    });
  } catch (err) {
    console.error('获取最近访问失败:', err.message);
    return fail(res, '最近访问加载失败', 500);
  }
});

// POST /api/recent
router.post('/recent', auth, async (req, res) => {
  try {
    const type = String(req.body.target_type || '');
    const targetId = clip(req.body.target_id, 60);
    const title = clip(req.body.title, 120);
    if (!validType(type) || !targetId) return fail(res, '参数不正确');

    await db.promise().query(
      `INSERT INTO recent_visits (user_id, target_type, target_id, title)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE title = VALUES(title), visited_at = NOW()`,
      [req.user.id, type, targetId, title]
    );

    // 只保留最近 N 条（子查询包裹，避免 MySQL 同表更新限制）
    await db.promise().query(
      `DELETE FROM recent_visits
       WHERE user_id = ? AND id NOT IN (
         SELECT id FROM (
           SELECT id FROM recent_visits WHERE user_id = ? ORDER BY visited_at DESC LIMIT ?
         ) keep_rows
       )`,
      [req.user.id, req.user.id, RECENT_LIMIT]
    );

    return ok(res, { recorded: true, limit: RECENT_LIMIT });
  } catch (err) {
    console.error('记录最近访问失败:', err.message);
    return fail(res, '记录失败', 500);
  }
});

// DELETE /api/recent
router.delete('/recent', auth, async (req, res) => {
  try {
    const [r] = await db.promise().query('DELETE FROM recent_visits WHERE user_id = ?', [req.user.id]);
    return ok(res, { cleared: r.affectedRows || 0 });
  } catch (err) {
    console.error('清空最近访问失败:', err.message);
    return fail(res, '清空失败', 500);
  }
});

module.exports = router;