'use strict';
// ============================================
// 26牛牛 - 现金筹码充值订单（用户端）
// ============================================
// 流程: 填写数量 → 创建订单 → 上传凭证 → 提交 → 等待审核 → 审核结果
// 状态: PENDING 待审核 / COMPLETED 已完成 / REJECTED 已拒绝 / CANCELLED 已取消 / EXPIRED 已过期
// 安全:
//   - 无任何真实支付网关：订单只能由管理员审核，绝不伪造「支付成功」
//   - status / operator_id / completed_at / 余额 全部由后端控制，前端无法修改
//   - 凭证存 storage/vouchers（非 public 目录），只有本人与管理员可读取
// ============================================

const express = require('express');
const crypto = require('node:crypto');
const multer = require('multer');
const fs = require('fs');
const db = require('../config/db');
const CHIPS = require('../config/cashChips');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { limiter } = require('../utils/rateLimit');
const { writeAdminLog } = require('../utils/adminAudit');
const { pushNotification } = require('../utils/content');
const { checkImage } = require('../utils/imageCheck');
const voucherStore = require('../utils/voucherStore');
const { parseAmount } = require('../utils/ledger');

const router = express.Router();
const R = CHIPS.RECHARGE;
const RC = CHIPS.RECEIVING;
const TEXT = R.STATUS_TEXT;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 }
});

function posInt(v) { const n = Number(v); return Number.isSafeInteger(n) && n > 0 ? n : null; }

/** 订单 → 用户可见 JSON（仅本人；只返回该订单分配到的收款账户快照） */
function toUserOrder(o) {
  const typeText = RC.TYPE_TEXT[o.receiving_account_type] || '';
  const hasAccount = Boolean(o.receiving_account_id || o.receiving_account_no);
  return {
    id: Number(o.id),
    order_id: o.order_id,
    amount: Number(o.amount),
    currency: o.currency || CHIPS.ASSET,
    asset_text: CHIPS.ASSET_TEXT,
    status: o.status,
    status_text: TEXT[o.status] || o.status,
    remark: o.remark || '',
    reject_reason: o.reject_reason || '',
    admin_remark: o.admin_remark || '',
    payment_reference: o.payment_reference || '',
    receiving_account: hasAccount ? {
      type: o.receiving_account_type || '',
      type_text: typeText,
      name: o.receiving_account_name || '',
      holder: o.receiving_account_holder || '',
      account_no: o.receiving_account_no || ''
    } : null,
    has_receipt: Boolean(o.receipt_path),
    receipt_url: o.receipt_path ? ('/api/recharge/orders/' + Number(o.id) + '/receipt') : null,
    created_at: o.created_at,
    updated_at: o.updated_at || null,
    completed_at: o.completed_at || null,
    submitted_at: o.submitted_at || null
  };
}

function newOrderId() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) +
    pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  return 'RC' + stamp + crypto.randomBytes(4).toString('hex').toUpperCase();
}

/** 付款参考编号：订单内唯一，供用户转账备注与管理员对账使用 */
function newPaymentReference() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) +
    pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  return 'PAY' + stamp + crypto.randomBytes(3).toString('hex').toUpperCase();
}

const ORDER_COLS = 'id, order_id, user_id, amount, currency, status, remark, reject_reason, receipt_path, operator_id, created_at, updated_at, completed_at, submitted_at, receiving_account_id, receiving_account_type, receiving_account_name, receiving_account_holder, receiving_account_no, payment_reference, admin_remark';

// ============================================
// GET /api/recharge/config - 充值页配置（额度 / 档位 / 是否有可用收款账户）
// 注意：绝不返回收款账户列表。收款账户是敏感资料，用户只能在创建订单后
// 从自己的订单里看到被分配的那一个。
// ============================================
router.get('/recharge/config', auth, async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM recharge_receiving_accounts WHERE is_active = 1'
    );
    const available = Number(rows[0] && rows[0].c) || 0;
    return ok(res, {
      min: R.MIN,
      max: R.MAX,
      decimals: R.DECIMALS,
      quick: [30, 100, 500, 1000, 2000, 3000, 5000],
      currency: 'RM',
      receiving_available: available > 0,
      receiving_available_count: available,
      notice: available > 0 ? '' : RC.NO_ACCOUNT_MESSAGE,
      usdt: { text: '需要 USDT 充值？联系客服', link: '/support-chat.html' },
      voucher: { mime_types: ['image/jpeg', 'image/png', 'image/webp'], ext_text: 'JPG / JPEG / PNG / WEBP', max_mb: 5 },
      status_text: TEXT
    });
  } catch (err) {
    // 收款账户表尚未初始化时，按「暂无可用账户」处理，绝不伪造可用状态
    if (err && err.code === 'ER_NO_SUCH_TABLE') {
      return ok(res, {
        min: R.MIN, max: R.MAX, decimals: R.DECIMALS,
        quick: [30, 100, 500, 1000, 2000, 3000, 5000], currency: 'RM',
        receiving_available: false, receiving_available_count: 0,
        notice: RC.NO_ACCOUNT_MESSAGE,
        usdt: { text: '需要 USDT 充值？联系客服', link: '/support-chat.html' },
        voucher: { mime_types: ['image/jpeg', 'image/png', 'image/webp'], ext_text: 'JPG / JPEG / PNG / WEBP', max_mb: 5 },
        status_text: TEXT
      });
    }
    return fail(res, '充值配置加载失败，请稍后重试', 500);
  }
});

// ============================================
// POST /api/recharge/orders - 创建充值订单
// body: { amount, remark?, idempotency_key? }
// ============================================
router.post('/recharge/orders', auth, limiter('recharge.create', 10, 60 * 1000), async (req, res) => {
  const body = req.body || {};
  const amount = parseAmount(body.amount, R.MIN, R.MAX);
  if (amount === null) {
    const rawAmount = String(body.amount == null ? '' : body.amount).trim();
    if (!rawAmount || rawAmount === '0' || rawAmount === '0.00') {
      return fail(res, '请输入充值金额', 422, 'AMOUNT_REQUIRED');
    }
    if (/^-?\d+(?:\.\d+)?$/.test(rawAmount)) {
      const n = Number(rawAmount);
      if (n > 0 && n < R.MIN) return fail(res, '充值金额最低为 RM30', 422, 'AMOUNT_BELOW_MIN');
      if (n > R.MAX) return fail(res, '单笔充值金额最高为 RM50000', 422, 'AMOUNT_ABOVE_MAX');
    }
    return fail(res, '请输入合法充值金额（30-50000，最多2位小数）', 422, 'INVALID_AMOUNT');
  }
  const remark = String(body.remark || '').trim().slice(0, R.REMARK_MAX);
  const idem = String(body.idempotency_key || '').trim().slice(0, 64) || crypto.randomUUID();

  // 幂等：同一用户 + 同一幂等键已存在订单时，直接返回原订单（不会重新分配收款账户）
  try {
    const [dup] = await db.promise().query(
      'SELECT ' + ORDER_COLS + ' FROM recharge_orders WHERE idempotency_key = ? AND user_id = ? LIMIT 1',
      [idem, req.user.id]);
    if (dup[0]) return ok(res, { order: toUserOrder(dup[0]), duplicated: true });
  } catch (e) { /* 查询失败继续走创建流程 */ }

  const conn = await db.promise().getConnection();
  let createdId = null;
  try {
    await conn.beginTransaction();
    // 事务内锁定启用中的收款账户，并挑选该用户使用次数最少的一个（未用过优先）
    const [activeRows] = await conn.query(
      'SELECT id, account_type, account_name, holder_name, account_no FROM recharge_receiving_accounts ' +
      'WHERE is_active = 1 ORDER BY sort_order ASC, id ASC FOR UPDATE'
    );
    if (!activeRows.length) {
      await conn.rollback();
      return fail(res, RC.NO_ACCOUNT_MESSAGE, 409, 'NO_RECEIVING_ACCOUNT');
    }
    let chosen = null;
    let chosenUse = null;
    for (const acc of activeRows) {
      const [useRows] = await conn.query(
        'SELECT COUNT(*) AS c FROM recharge_orders WHERE user_id = ? AND receiving_account_id = ?',
        [req.user.id, acc.id]
      );
      const used = Number(useRows[0] && useRows[0].c) || 0;
      if (chosenUse === null || used < chosenUse) { chosenUse = used; chosen = acc; }
      if (used === 0) break;
    }

    for (let attempt = 0; attempt < 3 && createdId === null; attempt++) {
      try {
        const [result] = await conn.query(
          'INSERT INTO recharge_orders ' +
          '(order_id, user_id, amount, currency, status, remark, idempotency_key, ' +
          ' receiving_account_id, receiving_account_type, receiving_account_name, ' +
          ' receiving_account_holder, receiving_account_no, payment_reference) ' +
          "VALUES (?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?, ?, ?, ?)",
          [newOrderId(), req.user.id, amount.toFixed(2), CHIPS.ASSET, remark || null, idem,
            chosen.id, chosen.account_type, chosen.account_name,
            chosen.holder_name, chosen.account_no, newPaymentReference()]);
        createdId = Number(result.insertId);
      } catch (err) {
        if (err && err.code === 'ER_DUP_ENTRY') continue;  // 订单号/幂等键/参考编号冲突 → 重试
        if (err && err.code === 'ER_NO_SUCH_TABLE') {
          await conn.rollback();
          return fail(res, RC.NO_ACCOUNT_MESSAGE, 503, 'RECEIVING_NOT_READY');
        }
        throw err;
      }
    }
    if (createdId === null) { await conn.rollback(); return fail(res, '充值订单创建失败，请稍后重试', 500); }

    const [rows] = await conn.query(
      'SELECT ' + ORDER_COLS + ' FROM recharge_orders WHERE id = ? AND user_id = ? LIMIT 1',
      [createdId, req.user.id]);
    if (!rows[0]) { await conn.rollback(); return fail(res, '充值订单创建失败，请稍后重试', 500); }

    await writeAdminLog({
      conn: conn, adminId: req.user.id, targetUserId: req.user.id, action: 'recharge_order_create',
      detail: 'order=' + rows[0].order_id + ' amount=' + amount.toFixed(2) + ' account_id=' + chosen.id
    });
    await conn.commit();
    return res.status(201).json({
      success: true,
      message: '充值订单已创建，请按订单显示的收款账户转账并上传凭证',
      data: { order: toUserOrder(rows[0]) }
    });
  } catch (err) {
    try { await conn.rollback(); } catch (e2) {}
    return fail(res, '充值订单创建失败，请稍后重试', 500);
  } finally {
    try { conn.release(); } catch (e2) {}
  }
});

// ============================================
// GET /api/recharge/orders - 我的充值记录
// ============================================
router.get('/recharge/orders', auth, async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const status = String(req.query.status || '').toUpperCase();
    const where = ['user_id = ?'];
    const params = [req.user.id];
    if (TEXT[status]) { where.push('status = ?'); params.push(status); }
    const clause = where.join(' AND ');
    const [rows] = await db.promise().query(
      'SELECT ' + ORDER_COLS + ' FROM recharge_orders WHERE ' + clause + ' ORDER BY id DESC LIMIT ? OFFSET ?',
      params.concat([limit, offset]));
    const [cnt] = await db.promise().query('SELECT COUNT(*) AS c FROM recharge_orders WHERE ' + clause, params);
    return ok(res, {
      list: rows.map(toUserOrder), total: Number(cnt[0] ? cnt[0].c : 0), limit, offset,
      asset_text: CHIPS.ASSET_TEXT, status_text: TEXT
    });
  } catch (err) {
    if (err && (err.code === 'ER_NO_SUCH_TABLE' || err.code === 'ER_BAD_FIELD_ERROR')) {
      return ok(res, { list: [], total: 0, limit: 20, offset: 0, status_text: TEXT });
    }
    return fail(res, '充值记录加载失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/recharge/orders/:id - 订单详情（仅本人）
// ============================================
router.get('/recharge/orders/:id', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const [rows] = await db.promise().query(
      'SELECT ' + ORDER_COLS + ' FROM recharge_orders WHERE id = ? AND user_id = ? LIMIT 1', [id, req.user.id]);
    if (!rows[0]) return fail(res, '订单不存在', 404, 'ORDER_NOT_FOUND');
    return ok(res, { order: toUserOrder(rows[0]), status_text: TEXT, asset_text: CHIPS.ASSET_TEXT });
  } catch (err) { return fail(res, '订单详情加载失败，请稍后重试', 500); }
});

// ============================================
// POST /api/recharge/orders/:id/receipt - 上传 / 替换充值凭证
// 仅待审核订单可上传；类型与大小按文件真实内容判定（不信任前端）
// ============================================
router.post('/recharge/orders/:id/receipt', auth, limiter('recharge.receipt', 20, 60 * 1000), upload.single('file'), async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  if (!req.file || !req.file.buffer) return fail(res, '请选择要上传的凭证图片', 422, 'FILE_EMPTY');
  if (req.file.mimetype && !['image/jpeg', 'image/png', 'image/webp'].includes(req.file.mimetype)) {
    return fail(res, '凭证类型无效，仅支持 JPG / JPEG / PNG / WEBP', 422, 'RECEIPT_TYPE_INVALID');
  }
  const ext = String(req.file.originalname || '').toLowerCase().split('.').pop();
  if (!['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
    return fail(res, '凭证扩展名无效，仅支持 JPG / JPEG / PNG / WEBP', 422, 'RECEIPT_EXTENSION_INVALID');
  }
  const chk = checkImage(req.file.buffer, { maxBytes: 5 * 1024 * 1024, mimeTypes: ['image/jpeg', 'image/png', 'image/webp'] });
  if (!chk.ok) return fail(res, chk.message, 422, chk.code);

  let oldPath = null;
  try {
    const [rows] = await db.promise().query(
      'SELECT id, order_id, user_id, status, receipt_path FROM recharge_orders WHERE id = ? AND user_id = ? LIMIT 1',
      [id, req.user.id]);
    if (!rows[0]) return fail(res, '订单不存在', 404, 'ORDER_NOT_FOUND');
    if (rows[0].status !== 'PENDING') return fail(res, '只有待审核订单可以上传凭证', 409, 'INVALID_STATUS');
    oldPath = rows[0].receipt_path || null;

    const rel = voucherStore.saveVoucher(req.file.buffer, chk.ext, req.user.id);
    const [upd] = await db.promise().query(
      "UPDATE recharge_orders SET receipt_path = ? WHERE id = ? AND user_id = ? AND status = 'PENDING'",
      [rel, id, req.user.id]);
    if (Number(upd.affectedRows) !== 1) {
      const abs = voucherStore.resolveVoucher(rel);
      if (abs) { try { fs.unlinkSync(abs); } catch (e) { /* 忽略 */ } }
      return fail(res, '订单状态已变更，请刷新后重试', 409, 'INVALID_STATUS');
    }
    // 替换凭证时清理旧文件（失败不影响主流程）
    if (oldPath && oldPath !== rel) {
      const oldAbs = voucherStore.resolveVoucher(oldPath);
      if (oldAbs) { try { fs.unlinkSync(oldAbs); } catch (e) { /* 忽略 */ } }
    }
    await writeAdminLog({
      adminId: req.user.id, targetUserId: req.user.id, action: 'recharge_receipt_upload',
      detail: 'order=' + rows[0].order_id
    });
    return ok(res, {
      receipt: { url: '/api/recharge/orders/' + id + '/receipt', width: chk.width, height: chk.height, mime: chk.mime },
      message: '凭证已上传，等待管理员审核'
    });
  } catch (err) {
    return fail(res, '凭证上传失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/recharge/orders/:id/receipt - 读取凭证（仅本人 / 管理员 / 客服）
// ============================================
router.get('/recharge/orders/:id/receipt', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return res.status(422).json({ success: false, message: '无效的订单ID' });
  try {
    const [rows] = await db.promise().query('SELECT id, user_id, receipt_path FROM recharge_orders WHERE id = ? LIMIT 1', [id]);
    const row = rows[0];
    if (!row) return res.status(404).json({ success: false, message: '订单不存在' });
    const isOwner = Number(row.user_id) === Number(req.user.id);
    const isStaff = req.user.role === 'admin' || req.user.role === 'support';
    if (!isOwner && !isStaff) return res.status(403).json({ success: false, message: '没有权限查看该凭证' });
    if (!row.receipt_path) return res.status(404).json({ success: false, message: '该订单还没有上传凭证' });
    const abs = voucherStore.resolveVoucher(row.receipt_path);
    if (!abs || !fs.existsSync(abs)) return res.status(404).json({ success: false, message: '凭证文件不存在' });
    res.set('Cache-Control', 'private, no-store');
    res.set('Content-Type', /\.png$/i.test(abs) ? 'image/png' : (/\.webp$/i.test(abs) ? 'image/webp' : 'image/jpeg'));
    return fs.createReadStream(abs).pipe(res);
  } catch (err) {
    return res.status(500).json({ success: false, message: '凭证读取失败' });
  }
});

// ============================================
// POST /api/recharge/orders/:id/submit - 用户提交凭证进入待审核
// 只记录提交时间，不改变余额；状态仍为 PENDING
// ============================================
router.post('/recharge/orders/:id/submit', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const [r] = await db.promise().query(
      "UPDATE recharge_orders SET submitted_at = NOW() WHERE id = ? AND user_id = ? AND status = 'PENDING' AND receipt_path IS NOT NULL",
      [id, req.user.id]
    );
    if (Number(r.affectedRows) !== 1) return fail(res, '请先上传凭证，且订单必须处于待审核状态', 409, 'SUBMIT_NOT_ALLOWED');
    const [rows] = await db.promise().query('SELECT ' + ORDER_COLS + ' FROM recharge_orders WHERE id = ? AND user_id = ? LIMIT 1', [id, req.user.id]);
    return ok(res, { order: toUserOrder(rows[0]) }, { message: '充值订单已提交，请等待管理员审核' });
  } catch (err) { return fail(res, '提交失败，请稍后重试', 500); }
});

// ============================================
// POST /api/recharge/orders/:id/cancel - 用户取消（仅待审核）
// ============================================
router.post('/recharge/orders/:id/cancel', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const [r] = await db.promise().query(
      "UPDATE recharge_orders SET status = 'CANCELLED', completed_at = NOW() WHERE id = ? AND user_id = ? AND status = 'PENDING'",
      [id, req.user.id]);
    if (!r || Number(r.affectedRows) !== 1) return fail(res, '只有待审核订单可以取消', 409, 'INVALID_STATUS');
    const [rows] = await db.promise().query('SELECT ' + ORDER_COLS + ' FROM recharge_orders WHERE id = ? LIMIT 1', [id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: req.user.id, action: 'recharge_user_cancel', detail: 'order=' + rows[0].order_id });
    return ok(res, { order: toUserOrder(rows[0]) });
  } catch (err) { return fail(res, '取消失败，请稍后重试', 500); }
});

module.exports = router;
module.exports.STATUS_TEXT = TEXT;
module.exports.toUserOrder = toUserOrder;
