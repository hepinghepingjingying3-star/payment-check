// ============================================
// 26牛牛 - 手机号注册 OTP 路由
// 包含:
//   - POST /api/otp/request  { phone } 生成验证码（管理员手动 WhatsApp 发送）
//   - POST /api/otp/verify   { phone, code } 校验验证码 → 返回注册凭证 otp_token
//   - GET  /api/otp/status?phone=...  查询冷却 / 待验证状态（不返回任何验证码）
// 安全:
//   - 绝不把 OTP / otp_hash 返回给普通用户
//   - 60 秒冷却 + 手机号每日上限 + IP 每小时上限 + 错误次数锁定
//   - 验证成功立即失效（status=verified，清空明文）
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { OTP_CONFIG } = require('../config/otp');
const OTP = require('../utils/otp');
const { clientIp, normalizePhone, isValidPhone, maskPhone, ok, fail } = require('../utils/request');

// 是否已注册用户（注册 OTP 只用于新用户）
async function phoneExists(phone) {
  const [rows] = await db.promise().query('SELECT id FROM users WHERE phone = ? LIMIT 1', [phone]);
  return rows.length > 0;
}

/** 写审计日志（绝不含 OTP 明文） */
async function audit(operatorId, phone, otpId, action, detail, ip) {
  try {
    await db.promise().query(
      `INSERT INTO otp_audit_logs (operator_id, target_phone, otp_id, action, detail, ip)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [operatorId || null, phone || null, otpId || null, action, detail || null, ip || null]
    );
  } catch (e) {
    console.error('OTP 审计写入失败:', e.message);
  }
}

/** 把已过期但仍是 pending/sent 的记录标记为 expired，并清空明文 */
async function expireStale() {
  try {
    await db.promise().query(
      `UPDATE registration_otp
       SET status = 'expired', otp_plain_tmp = NULL
       WHERE status IN ('pending','sent') AND expires_at < NOW()`
    );
  } catch (e) {
    console.error('OTP 过期清理失败:', e.message);
  }
}

// ============================================
// POST /api/otp/request { phone }
// ============================================
router.post('/otp/request', async (req, res) => {
  try {
    const ip = clientIp(req);
    const phone = normalizePhone(req.body.phone);

    if (!phone) return fail(res, '请填写手机号');
    if (!isValidPhone(phone)) return fail(res, '手机号格式不正确（10-15 位数字）');
    if (await phoneExists(phone)) return fail(res, '该手机号已被注册，请直接登录');

    await expireStale();

    // 1) 60 秒冷却
    const [recent] = await db.promise().query(
      `SELECT id, last_sent_at FROM registration_otp
       WHERE phone = ? AND last_sent_at IS NOT NULL ORDER BY id DESC LIMIT 1`,
      [phone]
    );
    if (recent.length) {
      const last = new Date(recent[0].last_sent_at).getTime();
      const diff = Math.floor((Date.now() - last) / 1000);
      const cooldown = OTP_CONFIG.RESEND_COOLDOWN_SUBSEQUENT_SECONDS;
      if (Number.isFinite(last) && diff < cooldown) {
        return fail(res, '请等待 ' + (cooldown - diff) + ' 秒后重新获取验证码',
          429, 'OTP_COOLDOWN');
      }
    }

    // 2) 手机号每日发送上限
    const [dayRows] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM registration_otp WHERE phone = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)',
      [phone]
    );
    if (Number(dayRows[0].c) >= OTP_CONFIG.MAX_SEND_PER_PHONE_PER_DAY) {
      await audit(null, phone, null, 'lock', '超过每日发送上限', ip);
      return fail(res, '今日验证码获取次数过多，请稍后再试或联系客服', 429, 'OTP_DAILY_LIMIT');
    }

    // 3) IP 每小时上限
    if (ip) {
      const [ipRows] = await db.promise().query(
        `SELECT COUNT(*) AS c FROM registration_otp
         WHERE created_ip = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)`,
        [ip]
      );
      if (Number(ipRows[0].c) >= OTP_CONFIG.MAX_SEND_PER_IP_PER_HOUR) {
        await audit(null, phone, null, 'lock', '超过IP发送上限', ip);
        return fail(res, '当前网络环境操作过于频繁，请稍后再试', 429, 'OTP_IP_LIMIT');
      }
    }

    // 4) 作废该手机号尚未使用的旧验证码（防止旧码仍可用）
    const [oldRows] = await db.promise().query(
      `SELECT id FROM registration_otp WHERE phone = ? AND status IN ('pending','sent')`, [phone]
    );
    if (oldRows.length) {
      await db.promise().query(
        `UPDATE registration_otp SET status = 'expired', otp_plain_tmp = NULL
         WHERE phone = ? AND status IN ('pending','sent')`, [phone]
      );
      for (const o of oldRows) await audit(null, phone, o.id, 'expire', '生成新验证码，旧码作废', ip);
    }

    // 5) 生成新 OTP（明文仅临时保留，供管理员查看一次）
    const code = OTP.generateOtp();
    const expiresAt = OTP.sqlDateTime(new Date(Date.now() + OTP_CONFIG.TTL_SECONDS * 1000));

    const [ins] = await db.promise().query(
      `INSERT INTO registration_otp
        (phone, otp_hash, otp_plain_tmp, status, attempts, max_attempts, expires_at, last_sent_at, created_ip)
       VALUES (?, ?, ?, 'pending', 0, ?, ?, NOW(), ?)`,
      [phone, OTP.hashOtp(phone, code), code, OTP_CONFIG.MAX_ATTEMPTS, expiresAt, ip]
    );

    await audit(null, phone, ins.insertId, 'generate', '用户请求注册验证码', ip);

    // 注意：绝不把 code / hash 返回给前端
    return ok(res, {
      phone_masked: maskPhone(phone),
      expires_in: OTP_CONFIG.TTL_SECONDS,
            cooldown: recent.length ? OTP_CONFIG.RESEND_COOLDOWN_SUBSEQUENT_SECONDS : OTP_CONFIG.RESEND_COOLDOWN_SECONDS,
      status: 'pending',
      tip: '验证码已生成，请等待客服通过 WhatsApp 发送给您的手机号'
    });
  } catch (err) {
    console.error('生成验证码失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// GET /api/otp/status?phone=xxx
// 只返回状态与倒计时，绝不返回验证码
// ============================================
router.get('/otp/status', async (req, res) => {
  try {
    const phone = normalizePhone(req.query.phone);
    if (!phone || !isValidPhone(phone)) return fail(res, '手机号格式不正确');
    await expireStale();

    const [rows] = await db.promise().query(
      `SELECT id, status, expires_at, last_sent_at FROM registration_otp
       WHERE phone = ? ORDER BY id DESC LIMIT 1`,
      [phone]
    );
    if (rows.length === 0) {
      return ok(res, { exists: false, status: null, can_request: true, wait_seconds: 0, expires_in: 0 });
    }
    const r = rows[0];
    const last = r.last_sent_at ? new Date(r.last_sent_at).getTime() : 0;
    const diff = last ? Math.floor((Date.now() - last) / 1000) : 9999;
    const wait = Math.max(0, (recent.length ? OTP_CONFIG.RESEND_COOLDOWN_SUBSEQUENT_SECONDS : OTP_CONFIG.RESEND_COOLDOWN_SECONDS) - diff);

    return ok(res, {
      exists: true,
      status: r.status,
      expires_in: OTP.secondsLeft(r.expires_at),
      wait_seconds: wait,
      can_request: (r.status !== 'pending' && r.status !== 'sent') && wait === 0
    });
  } catch (err) {
    console.error('查询验证码状态失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// POST /api/otp/verify { phone, code }
// 成功 → 返回一次性注册凭证 otp_token（10 分钟有效）
// ============================================
router.post('/otp/verify', async (req, res) => {
  try {
    const ip = clientIp(req);
    const phone = normalizePhone(req.body.phone);
    const code = String(req.body.code || '').replace(/[^0-9]/g, '');

    if (!isValidPhone(phone)) return fail(res, '手机号格式不正确');
    if (code.length !== OTP_CONFIG.LENGTH) return fail(res, '请输入 ' + OTP_CONFIG.LENGTH + ' 位数字验证码');

    await expireStale();

    const [rows] = await db.promise().query(
      `SELECT id, otp_hash, status, attempts, max_attempts, expires_at
       FROM registration_otp WHERE phone = ? ORDER BY id DESC LIMIT 1`,
      [phone]
    );
    if (rows.length === 0) return fail(res, '请先获取验证码', 400, 'OTP_NOT_FOUND');

    const r = rows[0];
    if (r.status === 'verified') return fail(res, '该验证码已使用，请重新获取', 400, 'OTP_USED');
    if (r.status === 'locked') {
      return fail(res, '错误次数过多，请 ' + OTP_CONFIG.LOCK_MINUTES + ' 分钟后重新获取验证码', 429, 'OTP_LOCKED');
    }
    if (r.status === 'expired' || OTP.secondsLeft(r.expires_at) <= 0) {
      await db.promise().query(
        "UPDATE registration_otp SET status='expired', otp_plain_tmp=NULL WHERE id = ?", [r.id]
      );
      return fail(res, '验证码已过期，请重新获取', 400, 'OTP_EXPIRED');
    }

    // 比对哈希（常量时间比较）
    if (!OTP.safeEqualHex(OTP.hashOtp(phone, code), r.otp_hash)) {
      const attempts = Number(r.attempts) + 1;
      if (attempts >= Number(r.max_attempts)) {
        await db.promise().query(
          "UPDATE registration_otp SET attempts = ?, status='locked', otp_plain_tmp=NULL WHERE id = ?",
          [attempts, r.id]
        );
        await audit(null, phone, r.id, 'lock', '错误次数达到上限，验证码锁定', ip);
        return fail(res, '错误次数过多，验证码已锁定，请稍后重新获取', 429, 'OTP_LOCKED');
      }
      await db.promise().query('UPDATE registration_otp SET attempts = ? WHERE id = ?', [attempts, r.id]);
      await audit(null, phone, r.id, 'verify_fail', '验证码错误（第 ' + attempts + ' 次）', ip);
      return fail(res, '验证码不正确，还可尝试 ' + (Number(r.max_attempts) - attempts) + ' 次', 400, 'OTP_WRONG');
    }

    // 验证成功：立即失效（覆写哈希，保证同一验证码不能二次通过）+ 清空明文
    await db.promise().query(
      `UPDATE registration_otp
       SET status = 'verified', verified_at = NOW(), otp_plain_tmp = NULL, otp_hash = ?
       WHERE id = ?`,
      [OTP.hashOtp(phone, code + '|used|' + Date.now()), r.id]
    );
    await audit(null, phone, r.id, 'verify_ok', '验证码验证成功', ip);

    return ok(res, {
      verified: true,
      // 凭证绑定本次验证的 OTP 行（otp_id）：注册成功时会被标记消费，不能重放
      otp_token: OTP.signRegisterToken(phone, r.id),
      expires_in: OTP_CONFIG.REGISTER_TOKEN_TTL_SECONDS
    });
  } catch (err) {
    console.error('验证验证码失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

module.exports = router;
module.exports.audit = audit;
module.exports.expireStale = expireStale;