'use strict';
// ============================================
// 26牛牛 - 管理后台：26牛牛娱乐场管理
// ============================================
// GET  /api/admin/niu/status          运行状态（真实数据，绝不伪造）
// POST /api/admin/niu/switch          开启 / 关闭游戏（写审计日志）
// GET  /api/admin/niu/rounds          对局列表（分页 + 筛选）
// GET  /api/admin/niu/rounds/:id      对局详情（服务端结算明细）
// POST /api/admin/niu/grant-points    发放游戏积分（唯一人工积分来源，必填原因）
//
// 权限：全局 middleware/admin-boundary.js 已强制 /api/admin/** + requireRole('admin')
//       本文件再叠加一层 auth + requireRole('admin') 纵深防御（绝不比较 username）
// 审计：所有写操作写 admin_logs，不记录密码 / OTP / 支付密码
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const NG = require('../config/niuGame');
const niu = require('../utils/niuRoom');
const ledger = require('../utils/ledger');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');
const bot = require('../utils/niuBot');

router.use('/admin/niu', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
}, auth, requireRole('admin'));

function posInt(v) {
  const n = Number(v);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

// ---------- 运行状态 ----------
router.get('/admin/niu/status', async (req, res) => {
  try {
    return ok(res, await niu.adminStatus());
  } catch (e) {
    console.error('[admin/niu/status]', e.message);
    return fail(res, '获取游戏状态失败', 500);
  }
});

// ---------- 开关游戏 ----------
router.post('/admin/niu/switch', async (req, res) => {
  try {
    const flag = req.body && (req.body.enabled === true || req.body.enabled === 1 || req.body.enabled === '1');
    await niu.setEnabled(flag, req.user.id);
    await writeAdminLog({
      adminId: req.user.id, action: flag ? 'NIU_GAME_ENABLE' : 'NIU_GAME_DISABLE',
      detail: { scope: 'niu_game', enabled: flag, reason: String((req.body && req.body.reason) || '').slice(0, 200) || null }
    });
    return ok(res, { enabled: flag }, { message: flag ? '26牛牛娱乐场已开启' : '26牛牛娱乐场已关闭' });
  } catch (e) {
    console.error('[admin/niu/switch]', e.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});

// ---------- 对局列表 ----------
router.get('/admin/niu/rounds', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    // 对局数据复用现有游戏表：game_rounds + game_results（packet_type = 'PLATFORM' 即 26牛牛娱乐场）
    const where = ["packet_type = 'PLATFORM'"];
    const args = [];
    if (NG.roomByKey(String(req.query.room))) { where.push('room_key = ?'); args.push(String(req.query.room)); }
    if (['FINISHED', 'ABORTED', 'SETTLEMENT'].indexOf(String(req.query.status)) !== -1) {
      where.push('status = ?'); args.push(String(req.query.status));
    }
    if (posInt(req.query.user_id)) {
      where.push('EXISTS (SELECT 1 FROM game_results x WHERE x.round_id = game_rounds.round_id AND x.user_id = ?)');
      args.push(posInt(req.query.user_id));
    }
    const cond = where.join(' AND ');
    const [cnt] = await db.promise().query('SELECT COUNT(*) AS c FROM game_rounds WHERE ' + cond, args);
    const [rows] = await db.promise().query(
      `SELECT id, round_id, room_id, room_key, base_stake, banker_id, player_count, status, created_at, updated_at
       FROM game_rounds WHERE ${cond} ORDER BY id DESC LIMIT ${limit} OFFSET ${offset}`, args);
    return ok(res, {
      total: Number(cnt[0].c) || 0, limit: limit, offset: offset,
      asset: { code: NG.POINTS.ASSET, text: NG.POINTS.TEXT, cashable: false },
      list: rows.map(x => ({
        id: Number(x.id), round_no: x.round_id, room_id: x.room_id ? Number(x.room_id) : null,
        room_key: x.room_key, base_stake: Number(x.base_stake),
        banker_user_id: x.banker_id ? Number(x.banker_id) : null,
        player_count: Number(x.player_count), status: x.status,
        started_at: x.created_at, ended_at: x.updated_at, created_at: x.created_at
      }))
    });
  } catch (e) {
    console.error('[admin/niu/rounds]', e.message);
    return fail(res, '获取对局列表失败', 500);
  }
});

// ---------- 对局详情 ----------
router.get('/admin/niu/rounds/:id', async (req, res) => {
  try {
    const id = posInt(req.params.id);
    if (!id) return fail(res, '对局 ID 不合法', 422, 'INVALID_ID');
    // 对局数据复用现有表：game_rounds + game_results（packet_type = 'PLATFORM' 即 26牛牛娱乐场）
    const [rd] = await db.promise().query(
      `SELECT id, round_id, room_id, room_key, base_stake, banker_id, player_count, status,
              created_at, updated_at
       FROM game_rounds WHERE id = ? AND packet_type = 'PLATFORM'`, [id]);
    if (!rd.length) return fail(res, '对局不存在', 404, 'NOT_FOUND');
    const [pl] = await db.promise().query(
      `SELECT rp.user_id, u.username, u.nickname, u.avatar_id, rp.role, rp.grab_flag, rp.bet_level,
              rp.seat_no, rp.cards, rp.hand_key, rp.point_value, rp.multiplier,
              rp.expect_amount, rp.amount, rp.delta, rp.balance_before, rp.balance_after,
              rp.compare_result, rp.is_capped
       FROM game_results rp JOIN users u ON u.id = rp.user_id
       WHERE rp.round_id = ? ORDER BY rp.role = 'BANKER' DESC, rp.user_id ASC`, [rd[0].round_id]);
    const round = {
      id: Number(rd[0].id),
      round_no: rd[0].round_id,
      room_id: rd[0].room_id ? Number(rd[0].room_id) : null,
      room_key: rd[0].room_key,
      base_stake: Number(rd[0].base_stake || 0),
      banker_user_id: rd[0].banker_id ? Number(rd[0].banker_id) : null,
      player_count: Number(rd[0].player_count || 0),
      status: rd[0].status,
      started_at: rd[0].created_at,
      ended_at: rd[0].updated_at,
      created_at: rd[0].created_at
    };
    return ok(res, {
      round: round,
      asset: { code: NG.POINTS.ASSET, text: NG.POINTS.TEXT, cashable: false },
      players: pl.map(x => {
        let cards = x.cards;
        if (typeof cards === 'string') { try { cards = JSON.parse(cards); } catch (_) { cards = []; } }
        return {
          user_id: Number(x.user_id), username: x.username, nickname: x.nickname || x.username,
          avatar_id: x.avatar_id ? Number(x.avatar_id) : null,
          role: x.role, seat_no: Number(x.seat_no), grab_flag: Number(x.grab_flag),
          bet_level: Number(x.bet_level),
          cards: Array.isArray(cards) ? cards : [], hand_key: x.hand_key,
          hand_name: (NG.HAND_TYPES[x.hand_key] || {}).name || x.hand_key,
          point_value: Number(x.point_value), multiplier: Number(x.multiplier),
          expect_amount: Number(x.expect_amount), amount: Number(x.amount), delta: Number(x.delta),
          balance_before: Number(x.balance_before), balance_after: Number(x.balance_after),
          result: x.compare_result, is_capped: !!Number(x.is_capped)
        };
      })
    });
  } catch (e) {
    console.error('[admin/niu/round-detail]', e.message);
    return fail(res, '获取对局详情失败', 500);
  }
});

// ---------- 发放游戏积分（唯一人工积分来源：必须留原因 + 审计）----------
router.post('/admin/niu/grant-points', async (req, res) => {
  try {
    const uid = posInt(req.body && req.body.user_id);
    const reason = String((req.body && req.body.reason) || '').trim();
    if (!uid) return fail(res, '用户 ID 不合法', 422, 'INVALID_USER');
    if (reason.length < 2) return fail(res, '必须填写发放原因', 422, 'REASON_REQUIRED');
    const amount = Number(req.body && req.body.amount);
    if (!Number.isFinite(amount) || amount <= 0 || amount > 1000000) {
      return fail(res, '发放积分数量不合法', 422, 'INVALID_AMOUNT');
    }
    const [u] = await db.promise().query('SELECT id, username FROM users WHERE id = ? AND status = ?', [uid, 'active']);
    if (!u.length) return fail(res, '用户不存在或已停用', 404, 'USER_NOT_FOUND');

    const conn = await db.promise().getConnection();
    try {
      await conn.beginTransaction();
      const r = await ledger.applyBalance(conn, {
        userId: uid,
        delta: Number(amount.toFixed(2)),
        type: NG.POINTS.LEDGER_TYPES.ADMIN_GRANT,
        reason: reason.slice(0, 200),
        referenceNo: 'GRANT-' + Date.now().toString(36).toUpperCase(),
        operatorId: req.user.id,
        currencyType: NG.POINTS.ASSET
      });
      await conn.commit();
      await writeAdminLog({
        adminId: req.user.id, action: 'NIU_POINTS_GRANT', targetUserId: uid,
        detail: { scope: 'niu_points', user_id: uid, amount: Number(amount.toFixed(2)), reason: reason.slice(0, 200) }
      });
      return ok(res, { user_id: uid, granted: Number(amount.toFixed(2)), game_points: r.balance_after },
        { message: '已发放 ' + Number(amount.toFixed(2)) + ' ' + NG.POINTS.TEXT });
    } catch (err) {
      await conn.rollback().catch(() => {});
      throw err;
    } finally {
      conn.release();
    }
  } catch (e) {
    console.error('[admin/niu/grant-points]', e.message);
    return fail(res, '积分发放失败，请稍后重试', 500);
  }
});

// ============================================
// 26牛牛游戏机器人（后端权威运行，管理员唯一控制入口）
//   GET  /admin/niu/bot/status            机器人状态（真实数据库数据）
//   POST /admin/niu/bot/start             启动机器人（幂等，连点只启动一次）
//   POST /admin/niu/bot/stop              停止机器人（只停自动推进，绝不删数据）
//   POST /admin/niu/bot/auto-messages     开关自动游戏消息
//   POST /admin/niu/bot/say               管理员手动发送系统 / 游戏消息
//   GET  /admin/niu/bot/templates         读取话术模板
//   POST /admin/niu/bot/templates         修改话术模板
// 权限：本文件顶部已强制 auth + requireRole('admin')，普通用户一律 403。
// 审计：启动 / 停止 / 发消息 / 改模板 / 改设置 全部写 admin_logs。
// ============================================

/** 读取机器人状态（含面板要显示的当前房间 / 当前局 / 当前阶段 / 预计结束时间） */
router.get('/admin/niu/bot/status', async (req, res) => {
  try {
    return ok(res, await bot.status());
  } catch (e) {
    console.error('[admin/niu/bot/status]', e.message);
    return fail(res, '获取机器人状态失败', 500);
  }
});

/** 启动机器人：后端记录 running=1，管理员关掉网页也照常推进 */
router.post('/admin/niu/bot/start', async (req, res) => {
  try {
    const roomKey = req.body && req.body.room_key ? String(req.body.room_key) : '';
    if (roomKey && !NG.roomByKey(roomKey)) {
      return fail(res, '场次不存在', 422, 'INVALID_ROOM');
    }
    // 幂等：连续点击「启动」多次不会重复开局、不会重复播报（bot.start 内部只播报一次）
    const st = await bot.start(req.user.id, { room_key: roomKey || undefined });
    await writeAdminLog({
      adminId: req.user.id, action: 'NIU_BOT_START',
      detail: { scope: 'niu_bot', room_key: st.room_key, room_id: st.room_id, round_id: st.current_round_id,
        reason: String((req.body && req.body.reason) || '').slice(0, 200) || null }
    });
    return ok(res, st, { message: '26牛牛游戏机器人已启动' });
  } catch (e) {
    console.error('[admin/niu/bot/start]', e.message);
    return fail(res, '启动机器人失败，请稍后重试', 500);
  }
});

/** 停止机器人：只停止自动推进；房间 / 当前局 / 聊天记录 / 玩家 / 历史一律保留 */
router.post('/admin/niu/bot/stop', async (req, res) => {
  try {
    const st = await bot.stop(req.user.id);
    await writeAdminLog({
      adminId: req.user.id, action: 'NIU_BOT_STOP',
      detail: { scope: 'niu_bot', room_key: st.room_key, room_id: st.room_id, round_id: st.current_round_id,
        reason: String((req.body && req.body.reason) || '').slice(0, 200) || null }
    });
    return ok(res, st, { message: '26牛牛游戏机器人已停止（聊天记录与当前状态保留）' });
  } catch (e) {
    console.error('[admin/niu/bot/stop]', e.message);
    return fail(res, '停止机器人失败，请稍后重试', 500);
  }
});

/** 开关自动游戏消息（关闭后状态机仍由后端维护，只是不发阶段提示） */
router.post('/admin/niu/bot/auto-messages', async (req, res) => {
  try {
    const flag = req.body && (req.body.enabled === true || req.body.enabled === 1 || req.body.enabled === '1');
    const st = await bot.setAutoMessages(flag, req.user.id);
    await writeAdminLog({
      adminId: req.user.id, action: flag ? 'NIU_BOT_AUTO_MSG_ON' : 'NIU_BOT_AUTO_MSG_OFF',
      detail: { scope: 'niu_bot', auto_messages: flag }
    });
    return ok(res, st, { message: flag ? '已开启自动游戏消息' : '已关闭自动游戏消息（游戏状态仍由后端维护）' });
  } catch (e) {
    console.error('[admin/niu/bot/auto-messages]', e.message);
    return fail(res, '设置失败，请稍后重试', 500);
  }
});

/** 管理员手动发送消息到「26牛牛游戏群」（机器人系统身份，不显示管理员用户名） */
router.post('/admin/niu/bot/say', async (req, res) => {
  try {
    const content = String((req.body && req.body.content) || '').trim();
    if (!content) return fail(res, '消息内容不能为空', 422, 'EMPTY_MESSAGE');
    if (content.length > 300) return fail(res, '消息过长（最多 300 字）', 422, 'MESSAGE_TOO_LONG');
    const type = req.body && req.body.message_type === 'game' ? 'game' : 'system';
    const st = await bot.status();
    const sent = await bot.adminSay(content, req.user.id, {
      message_type: type,
      room_pk: st.room_id,
      round_id: st.current_round_id,
      phase: st.current_phase
    });
    await writeAdminLog({
      adminId: req.user.id, action: 'NIU_BOT_ADMIN_SAY',
      detail: { scope: 'niu_bot', message_type: type, content: content.slice(0, 200),
        room_id: st.room_id, round_id: st.current_round_id }
    });
    return ok(res, sent, { message: '消息已发送到「26牛牛游戏群」' });
  } catch (e) {
    console.error('[admin/niu/bot/say]', e.message);
    if (e && e.message === 'EMPTY_MESSAGE') return fail(res, '消息内容不能为空', 422, 'EMPTY_MESSAGE');
    return fail(res, '发送失败，请稍后重试', 500);
  }
});

/** 读取话术模板（默认值 + 数据库覆盖结果，前端只负责渲染） */
router.get('/admin/niu/bot/templates', async (req, res) => {
  try {
    const items = await bot.templates();
    const labels = NG.BOT.TEMPLATE_LABELS || {};
    const defaults = bot.defaultTemplates();
    return ok(res, {
      prefix: NG.BOT.TEMPLATE_KEY_PREFIX,
      templates: bot.TEMPLATE_KEYS.map(k => ({
        key: k, label: labels[k] || k, value: items[k], default_value: defaults[k]
      }))
    });
  } catch (e) {
    console.error('[admin/niu/bot/templates]', e.message);
    return fail(res, '读取话术模板失败', 500);
  }
});

/** 修改话术模板（写统一配置中心，立即生效，全部写审计） */
router.post('/admin/niu/bot/templates', async (req, res) => {
  try {
    const patch = (req.body && req.body.templates) || {};
    // 键名与取值白名单在 bot 内做，这里只负责传参和审计
    const r = await bot.saveTemplates(patch, req.user.id);
    if (!r.changed.length) return fail(res, '没有可保存的模板内容', 422, 'NO_TEMPLATE_CHANGED');
    const saved = {};
    bot.TEMPLATE_KEYS.forEach(k => { if (patch[k] !== undefined && String(patch[k]).trim()) saved[k] = String(patch[k]).trim().slice(0, 300); });
    await writeAdminLog({
      adminId: req.user.id, action: 'NIU_BOT_TEMPLATE_UPDATE',
      detail: { scope: 'niu_bot', keys: r.changed, changed: saved }
    });
    const items = await bot.templates();
    return ok(res, {
      templates: bot.TEMPLATE_KEYS.map(k => ({
        key: k, label: (NG.BOT.TEMPLATE_LABELS || {})[k] || k, value: items[k]
      }))
    }, { message: '话术模板已保存并立即生效' });
  } catch (e) {
    console.error('[admin/niu/bot/templates]', e.message);
    return fail(res, '保存话术模板失败，请稍后重试', 500);
  }
});

module.exports = router;
