// ============================================
// 26牛牛 - 多人红包对战路由（Phase 4C）
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const {
  generateRandomAmount,
  generateRedPacket,
  identifyCardType,
  calculatePointValue,
  compareResults,
  calculateSettlement,
  settleBanker
} = require('../utils/redPacket');
const crypto = require('crypto');
const { scopeBlocked } = require('../utils/moderation');

// Legacy game writes touch cash_chips. Keep history readable, but disable all
// mutations until a separately audited, non-redeemable virtual game is ready.
// 禁言联动（config/moderation.js → MUTE.SCOPE.room / game）：
//   建房 / 进房 / 竞标上庄 / 下注 / 抢包都经过这里，被禁言账号会先收到明确的 403 提示，
//   而不是笼统的 503；未禁言账号仍按原规则返回 503（旧现金游戏写接口全局停用）。
router.use('/game', auth, async (req, res, next) => {
  if (req.method === 'GET' || req.method === 'HEAD') return next();
  try {
    const muted = await scopeBlocked(req.user.id, 'game');
    if (muted) return res.status(403).json({ success: false, code: muted.code, message: muted.message });
    const roomBlocked = await scopeBlocked(req.user.id, 'room');
    if (roomBlocked) return res.status(403).json({ success: false, code: roomBlocked.code, message: roomBlocked.message });
  } catch (e) {
    console.error('禁言联动校验失败:', e.message);
  }
  return res.status(503).json({ success: false, code: 'GAME_WRITES_DISABLED', message: '游戏操作暂未开放，目前仅提供教学与聊天' });
});

const ROOM_STATUS = {
  WAITING: 'WAITING',
  BANKER_BIDDING: 'BANKER_BIDDING',
  BETTING: 'BETTING',
  RED_PACKET: 'RED_PACKET',
  CLAIMING: 'CLAIMING',
  CALCULATING: 'CALCULATING',
  SETTLEMENT: 'SETTLEMENT',
  ENDED: 'ENDED'
};

// GET /api/game/rooms - 房间列表
router.get('/game/rooms', auth, async (req, res) => {
  try {
    const [rooms] = await db.promise().query(
      `SELECT id, room_name, status, min_players, max_players, current_players,
              banker_id, banker_pool, packet_type, created_at
       FROM game_rooms
       WHERE status IN ('WAITING','BANKER_BIDDING','BETTING','RED_PACKET','CLAIMING')
       ORDER BY created_at DESC LIMIT 50`
    );
    res.json({ success: true, data: rooms });
  } catch (err) {
    console.error('获取房间列表失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// POST /api/game/rooms - 创建房间
router.post('/game/rooms', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const { room_name, min_players, max_players, packet_type } = req.body;
    const userId = req.user.id;
    if (!room_name || room_name.trim().length === 0) {
      return res.status(400).json({ success: false, message: '房间名称不能为空' });
    }
    const minP = Math.max(parseInt(min_players, 10) || 2, 2);
    const maxP = Math.min(parseInt(max_players, 10) || 10, 10);
    if (minP > maxP) {
      return res.status(400).json({ success: false, message: '最小人数不能大于最大人数' });
    }
    const pType = packet_type === 'TNG_SIMULATED' ? 'TNG_SIMULATED' : 'PLATFORM';
    await conn.beginTransaction();
    const [result] = await conn.query(
      `INSERT INTO game_rooms (room_name, min_players, max_players, packet_type, config)
       VALUES (?, ?, ?, ?, ?)`,
      [room_name.trim(), minP, maxP, pType, JSON.stringify({ fee_rate: 0.05 })]
    );
    const roomId = result.insertId;
    await conn.query(
      `INSERT INTO room_players (room_id, user_id, role, status) VALUES (?, ?, 'SPECTATOR', 'ACTIVE')`,
      [roomId, userId]
    );
    await conn.query(`UPDATE game_rooms SET current_players = 1 WHERE id = ?`, [roomId]);
    await conn.commit();
    res.status(201).json({ success: true, message: '房间创建成功', data: { room_id: roomId } });
  } catch (err) {
    await conn.rollback();
    console.error('创建房间失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/rooms/:id/join - 加入房间
router.post('/game/rooms/:id/join', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const roomId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    if (isNaN(roomId) || roomId <= 0) {
      return res.status(400).json({ success: false, message: '无效的房间ID' });
    }
    await conn.beginTransaction();
    const [rooms] = await conn.query(`SELECT * FROM game_rooms WHERE id = ? FOR UPDATE`, [roomId]);
    if (rooms.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '房间不存在' });
    }
    const room = rooms[0];
    if (room.status !== ROOM_STATUS.WAITING && room.status !== ROOM_STATUS.BANKER_BIDDING) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '房间当前不可加入' });
    }
    if (room.current_players >= room.max_players) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '房间已满' });
    }
    const [existing] = await conn.query(
      `SELECT id FROM room_players WHERE room_id = ? AND user_id = ? AND status = 'ACTIVE'`,
      [roomId, userId]
    );
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '您已在房间中' });
    }
    await conn.query(
      `INSERT INTO room_players (room_id, user_id, role, status) VALUES (?, ?, 'SPECTATOR', 'ACTIVE')`,
      [roomId, userId]
    );
    await conn.query(`UPDATE game_rooms SET current_players = current_players + 1 WHERE id = ?`, [roomId]);
    await conn.commit();
    res.json({ success: true, message: '加入房间成功', data: { room_id: roomId } });
  } catch (err) {
    await conn.rollback();
    console.error('加入房间失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/rooms/:id/leave - 离开房间
// 规则: WAITING 阶段自由离开；游戏进行中（BANKER_BIDDING/BETTING/RED_PACKET/CLAIMING）
//       允许标记离开（冻结筹码由结束/结算流程统一退还，不在此产生余额变动）；
//       CALCULATING/SETTLEMENT/ENDED 阶段不允许离开。
router.post('/game/rooms/:id/leave', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const roomId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    await conn.beginTransaction();
    const [rooms] = await conn.query(`SELECT status FROM game_rooms WHERE id = ? FOR UPDATE`, [roomId]);
    if (rooms.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '房间不存在' });
    }
    const roomStatus = rooms[0].status;
    if (roomStatus === 'CALCULATING' || roomStatus === 'SETTLEMENT' || roomStatus === 'ENDED') {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '当前阶段不允许离开房间' });
    }
    const [result] = await conn.query(
      `UPDATE room_players SET status = 'LEFT', left_at = NOW()
       WHERE room_id = ? AND user_id = ? AND status = 'ACTIVE'`,
      [roomId, userId]
    );
    if (result.affectedRows === 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '您不在该房间中' });
    }
    await conn.query(`UPDATE game_rooms SET current_players = GREATEST(current_players - 1, 0) WHERE id = ?`, [roomId]);
    await conn.commit();
    res.json({ success: true, message: '已离开房间' });
  } catch (err) {
    await conn.rollback();
    console.error('离开房间失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// GET /api/game/rooms/:id - 房间详情（仅房间成员可查看）
router.get('/game/rooms/:id', auth, async (req, res) => {
  try {
    const roomId = parseInt(req.params.id, 10);
    if (isNaN(roomId) || roomId <= 0) {
      return res.status(400).json({ success: false, message: '无效的房间ID' });
    }
    const [rooms] = await db.promise().query(`SELECT * FROM game_rooms WHERE id = ?`, [roomId]);
    if (rooms.length === 0) {
      return res.status(404).json({ success: false, message: '房间不存在' });
    }
    const room = rooms[0];
    // 权限校验：只有房间成员（或管理员）可以查看房间详情，防止越权
    const [membership] = await db.promise().query(
      `SELECT id FROM room_players WHERE room_id = ? AND user_id = ? AND status = 'ACTIVE'`,
      [roomId, req.user.id]
    );
    const isMember = membership.length > 0;
    if (!isMember && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: '您不是该房间的成员，无法查看房间详情' });
    }
    const [players] = await db.promise().query(
      `SELECT rp.user_id, u.username, rp.role, rp.status as player_status, rp.joined_at
       FROM room_players rp JOIN users u ON rp.user_id = u.id
       WHERE rp.room_id = ?`,
      [roomId]
    );
    const [bids] = await db.promise().query(
      `SELECT bb.user_id, u.username, bb.amount, bb.status
       FROM banker_bids bb JOIN users u ON bb.user_id = u.id
       WHERE bb.round_id = ? ORDER BY bb.amount DESC`,
      [room.round_id || '']
    );
    const [bets] = await db.promise().query(
      `SELECT pb.user_id, u.username, pb.amount, pb.status
       FROM player_bets pb JOIN users u ON pb.user_id = u.id
       WHERE pb.round_id = ? ORDER BY pb.created_at ASC`,
      [room.round_id || '']
    );
    // 房主 = 最早加入且仍为 ACTIVE 的成员（创建者自动加入，故 joined_at 最早）
    const activePlayers = players.filter(p => p.player_status === 'ACTIVE');
    const owner = activePlayers.length > 0 ? activePlayers[0] : null;
    res.json({
      success: true,
      data: {
        room: {
          id: room.id, room_name: room.room_name, status: room.status,
          min_players: room.min_players, max_players: room.max_players,
          current_players: room.current_players, banker_id: room.banker_id,
          banker_bid: Number(room.banker_bid), banker_pool: Number(room.banker_pool),
          packet_type: room.packet_type, round_id: room.round_id,
          owner_id: owner ? owner.user_id : null,
          owner_username: owner ? owner.username : null,
          is_owner: owner ? owner.user_id === req.user.id : false,
          is_member: isMember,
          created_at: room.created_at, updated_at: room.updated_at
        },
        players, bids, bets
      }
    });
  } catch (err) {
    console.error('获取房间详情失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// POST /api/game/rounds/:id/start - 开始游戏
router.post('/game/rounds/:id/start', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const roomId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    if (isNaN(roomId) || roomId <= 0) {
      return res.status(400).json({ success: false, message: '无效的房间ID' });
    }
    await conn.beginTransaction();
    const [rooms] = await conn.query(`SELECT * FROM game_rooms WHERE id = ? FOR UPDATE`, [roomId]);
    if (rooms.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '房间不存在' });
    }
    const room = rooms[0];
    const [creators] = await conn.query(
      `SELECT user_id FROM room_players WHERE room_id = ? AND status = 'ACTIVE' ORDER BY joined_at ASC LIMIT 1`,
      [roomId]
    );
    const isCreator = creators.length > 0 && creators[0].user_id === userId;
    if (!isCreator && req.user.role !== 'admin') {
      await conn.rollback();
      return res.status(403).json({ success: false, message: '只有房主可以开始游戏' });
    }
    if (room.current_players < room.min_players) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '人数不足，无法开始游戏' });
    }
    const roundId = crypto.randomUUID();
    await conn.query(
      `UPDATE game_rooms SET status = ?, round_id = ?, updated_at = NOW() WHERE id = ?`,
      [ROOM_STATUS.BANKER_BIDDING, roundId, roomId]
    );
    await conn.query(
      `INSERT INTO game_rounds (round_id, room_id, status, banker_pool, packet_type)
       VALUES (?, ?, ?, ?, ?)`,
      [roundId, roomId, ROOM_STATUS.BANKER_BIDDING, 0, room.packet_type]
    );
    await conn.commit();
    res.json({ success: true, message: '游戏开始，进入竞标庄钱阶段', data: { round_id: roundId, status: ROOM_STATUS.BANKER_BIDDING } });
  } catch (err) {
    await conn.rollback();
    console.error('开始游戏失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/bid - 竞标庄钱
router.post('/game/bid', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const { round_id, amount } = req.body;
    const userId = req.user.id;
    if (!round_id || !amount) {
      return res.status(400).json({ success: false, message: '缺少必要参数' });
    }
    const bidAmount = Number(amount);
    if (isNaN(bidAmount) || bidAmount <= 0) {
      return res.status(400).json({ success: false, message: '竞标金额必须为正数' });
    }
    await conn.beginTransaction();
    const [rounds] = await conn.query(`SELECT * FROM game_rounds WHERE round_id = ? FOR UPDATE`, [round_id]);
    if (rounds.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '游戏局不存在' });
    }
    const round = rounds[0];
    if (round.status !== ROOM_STATUS.BANKER_BIDDING) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '当前不是竞标阶段' });
    }
    const [existing] = await conn.query(
      `SELECT id FROM banker_bids WHERE round_id = ? AND user_id = ?`,
      [round_id, userId]
    );
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '您已竞标' });
    }
    const [users] = await conn.query(`SELECT cash_chips FROM users WHERE id = ? FOR UPDATE`, [userId]);
    if (users.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    const balanceBefore = Number(users[0].cash_chips);
    const balanceAfter = balanceBefore - bidAmount;
    if (balanceAfter < 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '余额不足' });
    }
    await conn.query(`UPDATE users SET cash_chips = ? WHERE id = ?`, [balanceAfter, userId]);
    await conn.query(
      `INSERT INTO banker_bids (round_id, user_id, amount, status) VALUES (?, ?, ?, 'PENDING')`,
      [round_id, userId, bidAmount]
    );
    await conn.query(
      `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
       VALUES (?, 'CASH_CHIPS', ?, ?, ?, 'GAME_BET', ?)`,
      [userId, -bidAmount, balanceBefore, balanceAfter, `竞标庄钱 ${round_id}`]
    );
    await conn.commit();
    res.json({ success: true, message: '竞标成功', data: { round_id, amount: bidAmount, balance_before: balanceBefore, balance_after: balanceAfter } });
  } catch (err) {
    await conn.rollback();
    console.error('竞标失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/bet - 闲家下注
router.post('/game/bet', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const { round_id, amount } = req.body;
    const userId = req.user.id;
    if (!round_id || !amount) {
      return res.status(400).json({ success: false, message: '缺少必要参数' });
    }
    const betAmount = Number(amount);
    if (isNaN(betAmount) || betAmount <= 0) {
      return res.status(400).json({ success: false, message: '下注金额必须为正数' });
    }
    await conn.beginTransaction();
    const [rounds] = await conn.query(`SELECT * FROM game_rounds WHERE round_id = ? FOR UPDATE`, [round_id]);
    if (rounds.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '游戏局不存在' });
    }
    const round = rounds[0];
    if (round.status !== ROOM_STATUS.BETTING) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '当前不是下注阶段' });
    }
    // 庄家不能下注
    if (round.banker_id === userId) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '庄家不能下注' });
    }
    const [existing] = await conn.query(
      `SELECT id FROM player_bets WHERE round_id = ? AND user_id = ?`,
      [round_id, userId]
    );
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '您已下注' });
    }
    const [users] = await conn.query(`SELECT cash_chips FROM users WHERE id = ? FOR UPDATE`, [userId]);
    if (users.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    const balanceBefore = Number(users[0].cash_chips);
    const balanceAfter = balanceBefore - betAmount;
    if (balanceAfter < 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '余额不足' });
    }
    await conn.query(`UPDATE users SET cash_chips = ? WHERE id = ?`, [balanceAfter, userId]);
    await conn.query(
      `INSERT INTO player_bets (round_id, user_id, amount, status) VALUES (?, ?, ?, 'PENDING')`,
      [round_id, userId, betAmount]
    );
    await conn.query(
      `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
       VALUES (?, 'CASH_CHIPS', ?, ?, ?, 'GAME_BET', ?)`,
      [userId, -betAmount, balanceBefore, balanceAfter, `下注 ${round_id}`]
    );
    await conn.commit();
    res.json({ success: true, message: '下注成功', data: { round_id, amount: betAmount, balance_before: balanceBefore, balance_after: balanceAfter } });
  } catch (err) {
    await conn.rollback();
    console.error('下注失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/redpacket - 生成红包
router.post('/game/redpacket', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const { round_id } = req.body;
    const userId = req.user.id;
    if (!round_id) {
      return res.status(400).json({ success: false, message: '缺少局ID' });
    }
    await conn.beginTransaction();
    const [rounds] = await conn.query(`SELECT * FROM game_rounds WHERE round_id = ? FOR UPDATE`, [round_id]);
    if (rounds.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '游戏局不存在' });
    }
    const round = rounds[0];
    // 状态机修复: 红包在下注阶段结束后生成，前置状态应为 BETTING
    if (round.status !== ROOM_STATUS.BETTING) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '当前不是发红包阶段（需在下注阶段结束后）' });
    }
    // 只有房主或管理员可以生成红包
    const [creators] = await conn.query(
      `SELECT user_id FROM room_players WHERE room_id = ? AND status = 'ACTIVE' ORDER BY joined_at ASC LIMIT 1`,
      [round.room_id]
    );
    const isCreator = creators.length > 0 && creators[0].user_id === userId;
    if (!isCreator && req.user.role !== 'admin') {
      await conn.rollback();
      return res.status(403).json({ success: false, message: '只有房主可以生成红包' });
    }
    // 获取参与抢红包的玩家（庄家 + 已下注闲家）
    const [bets] = await conn.query(
      `SELECT user_id FROM player_bets WHERE round_id = ?`,
      [round_id]
    );
    const claimUsers = [round.banker_id, ...bets.map(b => b.user_id)].filter(u => u);
    const playerCount = claimUsers.length;
    if (playerCount === 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '没有玩家可以抢红包' });
    }
    // 生成红包
    const packet = generateRedPacket(round_id, round.packet_type, playerCount);
    await conn.query(
      `INSERT INTO red_packets (packet_id, round_id, type, total_amount, remaining_amount, packet_count, status, expired_at)
       VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', ?)`,
      [packet.packet_id, round_id, packet.type, packet.total_amount, packet.remaining_amount, packet.packet_count, packet.expired_at]
    );
    // 状态机: BETTING → RED_PACKET（红包已生成，等待玩家抢包）
    await conn.query(
      `UPDATE game_rounds SET status = ? WHERE round_id = ?`,
      [ROOM_STATUS.RED_PACKET, round_id]
    );
    await conn.query(
      `UPDATE game_rooms SET status = ? WHERE id = ?`,
      [ROOM_STATUS.RED_PACKET, round.room_id]
    );
    await conn.commit();
    res.json({
      success: true,
      message: '红包生成成功',
      data: {
        packet_id: packet.packet_id,
        round_id,
        type: packet.type,
        total_amount: packet.total_amount,
        packet_count: packet.packet_count,
        expired_at: packet.expired_at
      }
    });
  } catch (err) {
    await conn.rollback();
    console.error('生成红包失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/redpacket/claim - 抢红包
router.post('/game/redpacket/claim', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const { packet_id } = req.body;
    const userId = req.user.id;
    if (!packet_id) {
      return res.status(400).json({ success: false, message: '缺少红包ID' });
    }
    await conn.beginTransaction();
    // 获取红包
    const [packets] = await conn.query(
      `SELECT * FROM red_packets WHERE packet_id = ? FOR UPDATE`,
      [packet_id]
    );
    if (packets.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '红包不存在' });
    }
    const packet = packets[0];
    if (packet.status !== 'ACTIVE') {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '红包已失效' });
    }
    // 阶段校验: 只有处于 RED_PACKET/CLAIMING 阶段的局才能抢红包
    const [claimRounds] = await conn.query(
      `SELECT status, room_id, banker_id FROM game_rounds WHERE round_id = ? FOR UPDATE`,
      [packet.round_id]
    );
    if (claimRounds.length === 0 ||
        (claimRounds[0].status !== ROOM_STATUS.RED_PACKET && claimRounds[0].status !== ROOM_STATUS.CLAIMING)) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '当前不在抢红包阶段' });
    }
    // 成员校验: 只有本局庄家或已下注的闲家可以抢红包
    if (claimRounds[0].banker_id !== userId) {
      const [userBet] = await conn.query(
        `SELECT id FROM player_bets WHERE round_id = ? AND user_id = ?`,
        [packet.round_id, userId]
      );
      if (userBet.length === 0) {
        await conn.rollback();
        return res.status(403).json({ success: false, message: '只有本局庄家或已下注的玩家可以抢红包' });
      }
    }
    // 首次抢包: 状态机 RED_PACKET → CLAIMING
    if (claimRounds[0].status === ROOM_STATUS.RED_PACKET) {
      await conn.query(`UPDATE game_rounds SET status = ? WHERE round_id = ?`, [ROOM_STATUS.CLAIMING, packet.round_id]);
      await conn.query(`UPDATE game_rooms SET status = ? WHERE id = ?`, [ROOM_STATUS.CLAIMING, claimRounds[0].room_id]);
    }
    // 检查是否已抢
    const [existing] = await conn.query(
      `SELECT id FROM red_packet_claims WHERE packet_id = ? AND user_id = ?`,
      [packet_id, userId]
    );
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '您已抢过这个红包' });
    }
    // 检查红包是否过期（先回滚事务，再独立标记过期，避免回滚吞掉状态更新）
    if (new Date() > new Date(packet.expired_at)) {
      await conn.rollback();
      await db.promise().query(`UPDATE red_packets SET status = 'EXPIRED' WHERE packet_id = ?`, [packet_id]);
      return res.status(400).json({ success: false, message: '红包已过期' });
    }
    // 获取抢包顺序
    const [claims] = await conn.query(
      `SELECT COUNT(*) as count FROM red_packet_claims WHERE packet_id = ?`,
      [packet_id]
    );
    const claimOrder = claims[0].count + 1;
    // 生成安全随机金额
    const amount = generateRandomAmount();
    // 确保金额不超过剩余金额
    let finalAmount = amount;
    if (finalAmount > Number(packet.remaining_amount)) {
      finalAmount = Number(packet.remaining_amount);
    }
    if (finalAmount < 0.01) {
      finalAmount = 0.01;
    }
    finalAmount = Number(finalAmount.toFixed(2));
    // 计算点数和牌型
    const point = calculatePointValue(finalAmount);
    const cardType = identifyCardType(finalAmount);
    // 更新红包剩余金额
    const newRemaining = Number((Number(packet.remaining_amount) - finalAmount).toFixed(2));
    await conn.query(
      `UPDATE red_packets SET remaining_amount = ? WHERE packet_id = ?`,
      [newRemaining, packet_id]
    );
    // 记录抢包
    await conn.query(
      `INSERT INTO red_packet_claims (packet_id, round_id, user_id, amount, claim_order, point_value, card_type, multiplier)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [packet_id, packet.round_id, userId, finalAmount, claimOrder, point, cardType.type, cardType.multiplier]
    );
    // 如果红包被抢完，标记为 CLAIMED
    if (newRemaining <= 0 || claimOrder >= packet.packet_count) {
      await conn.query(`UPDATE red_packets SET status = 'CLAIMED' WHERE packet_id = ?`, [packet_id]);
    }
    await conn.commit();
    res.json({
      success: true,
      message: '抢红包成功',
      data: {
        packet_id,
        amount: finalAmount,
        point: point,
        card_type: cardType.type,
        multiplier: cardType.multiplier,
        claim_order: claimOrder
      }
    });
  } catch (err) {
    await conn.rollback();
    console.error('抢红包失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/settle - 结算
router.post('/game/settle', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const { round_id } = req.body;
    const userId = req.user.id;
    if (!round_id) {
      return res.status(400).json({ success: false, message: '缺少局ID' });
    }
    await conn.beginTransaction();
    // 获取游戏局
    const [rounds] = await conn.query(`SELECT * FROM game_rounds WHERE round_id = ? FOR UPDATE`, [round_id]);
    if (rounds.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '游戏局不存在' });
    }
    const round = rounds[0];
    if (round.status === ROOM_STATUS.ENDED || round.status === ROOM_STATUS.SETTLEMENT) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '该局已结算' });
    }
    // 阶段校验: 只有抢包阶段（CLAIMING）结束后才能结算
    if (round.status !== ROOM_STATUS.CLAIMING) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '当前不在可结算阶段（需在抢红包结束后）' });
    }
    // 只有房主或管理员可以结算
    const [creators] = await conn.query(
      `SELECT user_id FROM room_players WHERE room_id = ? AND status = 'ACTIVE' ORDER BY joined_at ASC LIMIT 1`,
      [round.room_id]
    );
    const isCreator = creators.length > 0 && creators[0].user_id === userId;
    if (!isCreator && req.user.role !== 'admin') {
      await conn.rollback();
      return res.status(403).json({ success: false, message: '只有房主可以结算' });
    }
    // 获取庄家
    const bankerId = round.banker_id;
    if (!bankerId) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '没有庄家，无法结算' });
    }
    // 获取庄家抢红包结果
    const [bankerClaims] = await conn.query(
      `SELECT * FROM red_packet_claims WHERE round_id = ? AND user_id = ?`,
      [round_id, bankerId]
    );
    if (bankerClaims.length === 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '庄家未抢红包' });
    }
    const bankerClaim = bankerClaims[0];
    const bankerResult = {
      type: bankerClaim.card_type,
      multiplier: Number(bankerClaim.multiplier),
      point: bankerClaim.point_value,
      amount: Number(bankerClaim.amount)
    };
    // 获取所有闲家抢红包结果
    const [playerClaims] = await conn.query(
      `SELECT * FROM red_packet_claims WHERE round_id = ? AND user_id != ?`,
      [round_id, bankerId]
    );
    // 获取闲家下注
    const [bets] = await conn.query(
      `SELECT * FROM player_bets WHERE round_id = ?`,
      [round_id]
    );
    const betMap = {};
    bets.forEach(b => { betMap[b.user_id] = b; });
    // 构建闲家结果
    const playerResults = playerClaims.map(claim => {
      const bet = betMap[claim.user_id];
      return {
        user_id: claim.user_id,
        bet_amount: bet ? Number(bet.amount) : 0,
        multiplier: Number(claim.multiplier),
        point: claim.point_value,
        amount: Number(claim.amount),
        type: claim.card_type
      };
    });
    // 计算结算
    const feeRate = 0.05;
    const settlements = calculateSettlement(bankerResult, playerResults, Number(round.banker_pool), feeRate);
    // 结算庄家
    const bankerSettle = settleBanker(settlements, Number(round.banker_pool));
    // 状态机: CLAIMING → CALCULATING → SETTLEMENT → ENDED（同一事务内完成计算与发放）
    await conn.query(
      `UPDATE game_rounds SET status = ? WHERE round_id = ?`,
      [ROOM_STATUS.CALCULATING, round_id]
    );
    await conn.query(
      `UPDATE game_rooms SET status = ? WHERE id = ?`,
      [ROOM_STATUS.CALCULATING, round.room_id]
    );
    // 记录结算结果
    for (const s of settlements) {
      await conn.query(
        `INSERT INTO game_results (round_id, user_id, role, packet_amount, point_value, card_type, multiplier, is_winner, payout, fee, net_payout)
         VALUES (?, ?, 'PLAYER', ?, ?, ?, ?, ?, ?, ?, ?)`,
        [round_id, s.user_id, s.bet_amount, s.point || 0, s.type || '', s.multiplier, s.comparison === 'WIN' ? 1 : 0, s.gross_payout, s.fee, s.actual_payout || 0]
      );
    }
    // 记录庄家结算
    await conn.query(
      `INSERT INTO game_results (round_id, user_id, role, packet_amount, point_value, card_type, multiplier, is_winner, payout, fee, net_payout)
       VALUES (?, ?, 'BANKER', ?, ?, ?, ?, ?, ?, ?, ?)`,
      [round_id, bankerId, bankerResult.amount, bankerResult.point, bankerResult.type, bankerResult.multiplier, 0, 0, bankerSettle.banker_fee, bankerSettle.banker_net]
    );
    // 更新用户余额
    for (const s of settlements) {
      if (s.comparison === 'WIN') {
        await conn.query(
          `UPDATE users SET cash_chips = cash_chips + ? WHERE id = ?`,
          [s.actual_payout || 0, s.user_id]
        );
        await conn.query(
          `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
           VALUES (?, 'CASH_CHIPS', ?, ?, ?, 'GAME_WIN', ?)`,
          [s.user_id, s.actual_payout || 0, 0, 0, `游戏结算 ${round_id}`]
        );
      } else if (s.comparison === 'LOSE') {
        await conn.query(
          `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
           VALUES (?, 'CASH_CHIPS', 0, 0, 0, 'GAME_LOSE', ?)`,
          [s.user_id, `游戏结算 ${round_id}`]
        );
      }
    }
    // 庄家收益
    if (bankerSettle.banker_net > 0) {
      await conn.query(
        `UPDATE users SET cash_chips = cash_chips + ? WHERE id = ?`,
        [bankerSettle.banker_net, bankerId]
      );
    }
    // 状态机: CALCULATING → SETTLEMENT → ENDED（发放完成后落定）
    await conn.query(
      `UPDATE game_rounds SET status = ? WHERE round_id = ?`,
      [ROOM_STATUS.SETTLEMENT, round_id]
    );
    await conn.query(
      `UPDATE game_rooms SET status = ? WHERE id = ?`,
      [ROOM_STATUS.SETTLEMENT, round.room_id]
    );
    await conn.query(
      `UPDATE game_rounds SET status = ? WHERE round_id = ?`,
      [ROOM_STATUS.ENDED, round_id]
    );
    await conn.query(
      `UPDATE game_rooms SET status = ? WHERE id = ?`,
      [ROOM_STATUS.ENDED, round.room_id]
    );
    await conn.commit();
    res.json({
      success: true,
      message: '结算成功',
      data: {
        round_id,
        banker: { user_id: bankerId, ...bankerResult },
        players: settlements.map(s => ({
          user_id: s.user_id,
          comparison: s.comparison,
          bet_amount: s.bet_amount,
          multiplier: s.multiplier,
          payout: s.actual_payout || 0,
          fee: s.fee
        })),
        banker_net: bankerSettle.banker_net,
        remaining_pool: bankerSettle.remaining_pool
      }
    });
  } catch (err) {
    await conn.rollback();
    console.error('结算失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// GET /api/game/rounds/:id/packet - 获取某局的当前红包（玩家抢红包用）
router.get('/game/rounds/:roundId/packet', auth, async (req, res) => {
  try {
    const roundId = req.params.roundId;
    if (!roundId) {
      return res.status(400).json({ success: false, message: '缺少局ID' });
    }
    const [packets] = await db.promise().query(
      `SELECT packet_id, round_id, type, total_amount, remaining_amount, packet_count, status, expired_at
       FROM red_packets
       WHERE round_id = ? AND status = 'ACTIVE'
       ORDER BY created_at DESC
       LIMIT 1`,
      [roundId]
    );
    if (packets.length === 0) {
      return res.status(404).json({ success: false, message: '该局没有进行中的红包' });
    }
    const p = packets[0];
    res.json({
      success: true,
      data: {
        packet_id: p.packet_id,
        round_id: p.round_id,
        type: p.type,
        total_amount: Number(p.total_amount),
        remaining_amount: Number(p.remaining_amount),
        packet_count: p.packet_count,
        status: p.status,
        expired_at: p.expired_at
      }
    });
  } catch (err) {
    console.error('获取红包失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// GET /api/game/history - 游戏历史
router.get('/game/history', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 50);
    const [results] = await db.promise().query(
      `SELECT gr.round_id, gr.status, gr.banker_pool, gr.created_at,
              grr.role, grr.packet_amount, grr.point_value, grr.card_type,
              grr.multiplier, grr.is_winner, grr.payout, grr.fee, grr.net_payout
       FROM game_rounds gr
       JOIN game_results grr ON gr.round_id = grr.round_id
       WHERE grr.user_id = ?
       ORDER BY gr.created_at DESC
       LIMIT ?`,
      [userId, limit]
    );
    res.json({ success: true, data: results });
  } catch (err) {
    console.error('获取游戏历史失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// POST /api/game/rooms/:id/banker - 选定庄家
router.post('/game/rooms/:id/banker', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const roomId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    if (isNaN(roomId) || roomId <= 0) {
      return res.status(400).json({ success: false, message: '无效的房间ID' });
    }
    await conn.beginTransaction();
    // 成员校验: 只有房间成员（或管理员）可以触发选定庄家
    const [bankerMembership] = await conn.query(
      `SELECT id FROM room_players WHERE room_id = ? AND user_id = ? AND status = 'ACTIVE'`,
      [roomId, userId]
    );
    if (bankerMembership.length === 0 && req.user.role !== 'admin') {
      await conn.rollback();
      return res.status(403).json({ success: false, message: '您不是该房间的成员，无法执行此操作' });
    }
    const [rounds] = await conn.query(
      `SELECT * FROM game_rounds WHERE room_id = ? AND status = ? FOR UPDATE`,
      [roomId, ROOM_STATUS.BANKER_BIDDING]
    );
    if (rounds.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '没有正在竞标的游戏局' });
    }
    const round = rounds[0];
    // 获取最高竞标
    const [bids] = await conn.query(
      `SELECT * FROM banker_bids WHERE round_id = ? ORDER BY amount DESC, created_at ASC LIMIT 1`,
      [round.round_id]
    );
    if (bids.length === 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '无人竞标，游戏取消' });
    }
    const winningBid = bids[0];
    const bankerId = winningBid.user_id;
    // 更新竞标状态
    await conn.query(
      `UPDATE banker_bids SET status = 'WON' WHERE round_id = ? AND user_id = ?`,
      [round.round_id, bankerId]
    );
    await conn.query(
      `UPDATE banker_bids SET status = 'LOST' WHERE round_id = ? AND user_id != ?`,
      [round.round_id, bankerId]
    );
    // 退还其他竞标者的竞标金额
    const [otherBids] = await conn.query(
      `SELECT user_id, amount FROM banker_bids WHERE round_id = ? AND user_id != ? AND status = 'PENDING'`,
      [round.round_id, bankerId]
    );
    for (const bid of otherBids) {
      const [u] = await conn.query(`SELECT cash_chips FROM users WHERE id = ? FOR UPDATE`, [bid.user_id]);
      const before = Number(u[0].cash_chips);
      const after = Number((before + Number(bid.amount)).toFixed(2));
      await conn.query(`UPDATE users SET cash_chips = ? WHERE id = ?`, [after, bid.user_id]);
      await conn.query(
        `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
         VALUES (?, 'CASH_CHIPS', ?, ?, ?, 'GAME_BET', ?)`,
        [bid.user_id, bid.amount, before, after, `退还竞标 ${round.round_id}`]
      );
    }
    // 设置庄家
    await conn.query(
      `UPDATE game_rounds SET banker_id = ?, banker_bid = ?, banker_pool = ?, status = ? WHERE round_id = ?`,
      [bankerId, winningBid.amount, winningBid.amount, ROOM_STATUS.BETTING, round.round_id]
    );
    await conn.query(
      `UPDATE game_rooms SET banker_id = ?, banker_bid = ?, banker_pool = ?, status = ? WHERE id = ?`,
      [bankerId, winningBid.amount, winningBid.amount, ROOM_STATUS.BETTING, roomId]
    );
    await conn.commit();
    res.json({
      success: true,
      message: '庄家确定',
      data: { round_id: round.round_id, banker_id: bankerId, banker_bid: Number(winningBid.amount), banker_pool: Number(winningBid.amount) }
    });
  } catch (err) {
    await conn.rollback();
    console.error('确定庄家失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/rooms/:id/redpacket - 生成红包（房主）
router.post('/game/rooms/:id/redpacket', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const roomId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    if (isNaN(roomId) || roomId <= 0) {
      return res.status(400).json({ success: false, message: '无效的房间ID' });
    }
    await conn.beginTransaction();
    const [rounds] = await conn.query(
      `SELECT * FROM game_rounds WHERE room_id = ? AND status = ? FOR UPDATE`,
      [roomId, ROOM_STATUS.BETTING]
    );
    if (rounds.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '没有正在下注的游戏局' });
    }
    const round = rounds[0];
    // 只有房主或管理员可以生成红包
    const [creators] = await conn.query(
      `SELECT user_id FROM room_players WHERE room_id = ? AND status = 'ACTIVE' ORDER BY joined_at ASC LIMIT 1`,
      [roomId]
    );
    const isCreator = creators.length > 0 && creators[0].user_id === userId;
    if (!isCreator && req.user.role !== 'admin') {
      await conn.rollback();
      return res.status(403).json({ success: false, message: '只有房主可以生成红包' });
    }
    // 获取参与抢红包的玩家
    const [bets] = await conn.query(`SELECT user_id FROM player_bets WHERE round_id = ?`, [round.round_id]);
    const claimUsers = [round.banker_id, ...bets.map(b => b.user_id)].filter(u => u);
    const playerCount = claimUsers.length;
    if (playerCount === 0) {
      await conn.rollback();
      return res.status(400).json({ success: false, message: '没有玩家可以抢红包' });
    }
    const packet = generateRedPacket(round.round_id, round.packet_type, playerCount);
    await conn.query(
      `INSERT INTO red_packets (packet_id, round_id, type, total_amount, remaining_amount, packet_count, status, expired_at)
       VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', ?)`,
      [packet.packet_id, round.round_id, packet.type, packet.total_amount, packet.remaining_amount, packet.packet_count, packet.expired_at]
    );
    // 状态机: BETTING → RED_PACKET（与 /game/redpacket 保持一致，等待玩家抢包）
    await conn.query(`UPDATE game_rounds SET status = ? WHERE round_id = ?`, [ROOM_STATUS.RED_PACKET, round.round_id]);
    await conn.query(`UPDATE game_rooms SET status = ? WHERE id = ?`, [ROOM_STATUS.RED_PACKET, roomId]);
    await conn.commit();
    res.json({
      success: true,
      message: '红包生成成功',
      data: {
        packet_id: packet.packet_id,
        round_id: round.round_id,
        type: packet.type,
        total_amount: packet.total_amount,
        packet_count: packet.packet_count,
        expired_at: packet.expired_at
      }
    });
  } catch (err) {
    await conn.rollback();
    console.error('生成红包失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// POST /api/game/rooms/:id/end - 结束游戏（房主）
router.post('/game/rooms/:id/end', auth, async (req, res) => {
  const conn = await db.promise().getConnection();
  try {
    const roomId = parseInt(req.params.id, 10);
    const userId = req.user.id;
    if (isNaN(roomId) || roomId <= 0) {
      return res.status(400).json({ success: false, message: '无效的房间ID' });
    }
    await conn.beginTransaction();
    const [rooms] = await conn.query(`SELECT * FROM game_rooms WHERE id = ? FOR UPDATE`, [roomId]);
    if (rooms.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '房间不存在' });
    }
    const room = rooms[0];
    const [creators] = await conn.query(
      `SELECT user_id FROM room_players WHERE room_id = ? AND status = 'ACTIVE' ORDER BY joined_at ASC LIMIT 1`,
      [roomId]
    );
    const isCreator = creators.length > 0 && creators[0].user_id === userId;
    if (!isCreator && req.user.role !== 'admin') {
      await conn.rollback();
      return res.status(403).json({ success: false, message: '只有房主可以结束游戏' });
    }
    // 退还所有冻结的竞标金额
    const [bids] = await conn.query(
      `SELECT user_id, amount FROM banker_bids WHERE round_id = ? AND status = 'PENDING'`,
      [room.round_id || '']
    );
    for (const bid of bids) {
      const [u] = await conn.query(`SELECT cash_chips FROM users WHERE id = ? FOR UPDATE`, [bid.user_id]);
      const before = Number(u[0].cash_chips);
      const after = Number((before + Number(bid.amount)).toFixed(2));
      await conn.query(`UPDATE users SET cash_chips = ? WHERE id = ?`, [after, bid.user_id]);
      await conn.query(
        `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
         VALUES (?, 'CASH_CHIPS', ?, ?, ?, 'GAME_BET', ?)`,
        [bid.user_id, bid.amount, before, after, `退还竞标 ${room.round_id || ''}`]
      );
    }
    // 退还所有下注金额
    const [bets] = await conn.query(
      `SELECT user_id, amount FROM player_bets WHERE round_id = ? AND status = 'PENDING'`,
      [room.round_id || '']
    );
    for (const bet of bets) {
      const [u] = await conn.query(`SELECT cash_chips FROM users WHERE id = ? FOR UPDATE`, [bet.user_id]);
      const before = Number(u[0].cash_chips);
      const after = Number((before + Number(bet.amount)).toFixed(2));
      await conn.query(`UPDATE users SET cash_chips = ? WHERE id = ?`, [after, bet.user_id]);
      await conn.query(
        `INSERT INTO balance_transactions (user_id, currency_type, amount, balance_before, balance_after, type, reason)
         VALUES (?, 'CASH_CHIPS', ?, ?, ?, 'GAME_BET', ?)`,
        [bet.user_id, bet.amount, before, after, `退还下注 ${room.round_id || ''}`]
      );
    }
    // 更新房间状态
    await conn.query(
      `UPDATE game_rooms SET status = ?, round_id = NULL, banker_id = NULL, banker_bid = 0, banker_pool = 0 WHERE id = ?`,
      [ROOM_STATUS.WAITING, roomId]
    );
    if (room.round_id) {
      await conn.query(`UPDATE game_rounds SET status = ? WHERE round_id = ?`, [ROOM_STATUS.ENDED, room.round_id]);
    }
    await conn.commit();
    res.json({ success: true, message: '游戏已结束，所有冻结筹码已退还' });
  } catch (err) {
    await conn.rollback();
    console.error('结束游戏失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  } finally {
    conn.release();
  }
});

// GET /api/game/group-state - 游戏群当前状态（供聊天页渲染系统话术）
router.get('/game/group-state', auth, async (req, res) => {
  try {
    // 查找当前最活跃的一个房间作为"游戏群"（优先非WAITING状态）
    const [rooms] = await db.promise().query(
      `SELECT id, room_name, status, current_players, banker_id, banker_pool,
              packet_type, round_id FROM game_rooms
       ORDER BY (status != 'WAITING') DESC, updated_at DESC LIMIT 1`
    );
    if (rooms.length === 0) {
      return res.json({ success: true, data: { phase: 'WAITING', phaseText: '等待中', members: 0 } });
    }
    const room = rooms[0];
    const phaseMap = {
      'WAITING': 'waiting',
      'BANKER_BIDDING': 'BIDDING',
      'BETTING': 'BETTING',
      'RED_PACKET': 'GRABBING',
      'CLAIMING': 'GRABBING',
      'CALCULATING': 'SETTLEMENT',
      'SETTLEMENT': 'SETTLEMENT',
      'ENDED': 'ENDED'
    };
    const phase = phaseMap[room.status] || 'waiting';
    // 附加竞标/下注参数（默认值，之后可从配置读取）
    res.json({
      success: true,
      data: {
        phase: phase,
        phaseText: room.status,
        members: room.current_players,
        roomId: room.id,
        roomName: room.room_name,
        bankerPool: Number(room.banker_pool || 0),
        packetType: room.packet_type
      }
    });
  } catch (err) {
    console.error('获取群状态失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

module.exports = router;
