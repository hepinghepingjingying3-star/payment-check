// ============================================
// 26牛牛 - 收藏 + 最近访问路由
// 包含:
//   - GET    /api/favorites              我的收藏（分类筛选）
//   - POST   /api/favorites              添加收藏 { target_type, target_id, title }
//   - DELETE /api/favorites/:id          取消收藏（只能取消自己的）
//   - GET    /api/favorites/check        是否已收藏 ?target_type=&target_id=
//   - GET    /api/recent                 最近访问（最多 10 条）
//   - POST   /api/recent                 记录访问 { target_type, target_id, title }
//   - DELETE /api/recent                 清空最近访问
// 说明:
//   - target_type 白名单: game / tutorial / announcement
//     （禁止收藏玩家，防止通过收藏 / 最近访问发现其他玩家）
//   - 全部需要 JWT，user_id 只取自 JWT
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { RECENT_TARGET_TYPES } = require('../config/games');
const { ok, fail } = require('../utils/request');

const TYPE_TEXT = { game: '游戏', tutorial: '玩法介绍', announcement: '公告' };
const RECENT_LIMIT = 10;      // 最近访问最多保留 10 条，不无限增长

function validType(t) { return RECENT_TARGET_TYPES.includes(String(t)); }
function clip(s, n) { return String(s || '').slice(0, n || 120); }

// ---------- 收藏 ----------
router.get('/favorites', auth, async (req, res) => {
  try {
    const type = String(req.query.type || 'all');
    const params = [req.user.id];
    let where = 'user_id = ?';
    if (type !== 'all' && validType(type)) { where += ' AND target_type = ?'; params.push(type); }

    const [rows] = await db.promise().query(
      `SELECT id, target_type, target_id, title, created_at
       FROM favorites WHERE ${where} ORDER BY id DESC LIMIT 100`,
      params
    );

    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        target_type: r.target_type,
        target_type_text: TYPE_TEXT[r.target_type] || r.target_type,
        target_id: r.target_id,
        title: r.title || '',
        created_at: r.created_at
      })),
      types: Object.keys(TYPE_TEXT).map(k => ({ key: k, name: TYPE_TEXT[k] }))
    });
  } catch (err) {
    console.error('获取收藏失败:', err.message);
    return fail(res, '收藏加载失败', 500);
  }
});

router.get('/favorites/check', auth, async (req, res) => {
  try {
    const type = String(req.query.target_type || '');
    const id = String(req.query.target_id || '');
    if (!validType(type) || !id) return ok(res, { favorited: false });
    const [rows] = await db.promise().query(
      'SELECT id FROM favorites WHERE user_id = ? AND target_type = ? AND target_id = ? LIMIT 1',
      [req.user.id, type, clip(id, 60)]
    );
    return ok(res, { favorited: rows.length > 0, id: rows.length ? Number(rows[0].id) : null });
  } catch (err) {
    console.error('查询收藏状态失败:', err.message);
    return fail(res, '收藏状态查询失败', 500);
  }
});

router.post('/favorites', auth, async (req, res) => {
  try {
    const type = String(req.body.target_type || '');
    const targetId = clip(req.body.target_id, 60);
    const title = clip(req.body.title, 120);
    if (!validType(type)) return fail(res, '不支持收藏该类型（只能收藏游戏 / 玩法介绍 / 公告）');
    if (!targetId) return fail(res, '缺少收藏对象');

    await db.promise().query(
      `INSERT INTO favorites (user_id, target_type, target_id, title) VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE title = VALUES(title)`,
      [req.user.id, type, targetId, title]
    );
    return ok(res, { favorited: true, target_type: type, target_id: targetId });
  } catch (err) {
    console.error('添加收藏失败:', err.message);
    return fail(res, '收藏失败，请稍后重试', 500);
  }
});

router.delete('/favorites/:id', auth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return fail(res, '无效的收藏ID');
    const [r] = await db.promise().query(
      'DELETE FROM favorites WHERE id = ? AND user_id = ?', [id, req.user.id]
    );
    if (!r.affectedRows) return fail(res, '收藏不存在', 404);
    return ok(res, { id: id, removed: true });
  } catch (err) {
    console.error('取消收藏失败:', err.message);
    return fail(res, '取消收藏失败，请稍后重试', 500);
  }
});

module.exports = router;