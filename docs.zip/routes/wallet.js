// ============================================
// 26牛牛 - 钱包路由（Phase 4B）
// 包含:
//   - GET  /api/wallet/balance        查询自己的余额（需登录）
//   - POST /api/wallet/admin/grant    管理员发放余额（需 admin 角色）
//   - POST /api/wallet/deposit        已停用（充值请使用现金筹码充值页，订单由管理员确认）
//   - POST /api/wallet/withdraw       已停用（请使用 /api/withdrawals）
//   - POST /api/wallet/exchange       已停用（不提供任何真实货币兑换）
// 安全要求:
//   - 所有余额变化必须使用数据库事务
//   - 每次变化必须记录 balance_transactions
//   - 使用 DECIMAL，禁止 FLOAT/DOUBLE
//   - 普通用户不能修改自己的余额
//   - 管理员发放必须验证 JWT 和管理员权限
// ============================================

// 引入 Express 路由
const express = require('express');
const router = express.Router();

// 引入数据库连接
const db = require('../config/db');

// 引入认证中间件
const { auth, requireRole } = require('../middleware/auth');

// 引入统一响应工具
const { ok, fail } = require('../utils/request');

// 引入资金集中配置（金额上下限与前端 / 新充值接口保持一致）
const FUNDS = require('../config/funds');

// ============================================
// 工具函数
// ============================================

/**
 * 验证金额是否合法
 * - 必须是正数
 * - 不能为 0
 * - 不能为负数
 * - 不能超过最大值
 * - 最多 2 位小数
 */
function isValidAmount(amount) {
  if (typeof amount !== 'number' && typeof amount !== 'string') return false;
  const num = Number(amount);
  if (isNaN(num)) return false;
  if (num <= 0) return false;
  if (num > 999999999999.99) return false;
  // 检查最多 2 位小数
  const str = String(amount);
  const decimalPart = str.split('.')[1];
  if (decimalPart && decimalPart.length > 2) return false;
  return true;
}

/**
 * 验证货币类型
 */
function isValidCurrencyType(type) {
  return type === 'GAME_BALANCE' || type === 'CASH_CHIPS';
}

/**
 * 验证交易类型
 */
function isValidTransactionType(type) {
  const validTypes = ['ADMIN_GRANT', 'DEPOSIT', 'WITHDRAW', 'EXCHANGE', 'GAME_BET', 'GAME_WIN', 'GAME_LOSE'];
  return validTypes.includes(type);
}

/**
 * 在事务中更新余额并记录交易
 * @param {object} conn - 数据库连接（事务）
 * @param {number} userId - 目标用户ID
 * @param {string} currencyType - 货币类型（GAME_BALANCE/CASH_CHIPS）
 * @param {number} amount - 变化金额（正数=增加，负数=减少）
 * @param {string} type - 交易类型
 * @param {string} reason - 原因/备注
 * @param {number|null} operatorId - 操作者ID
 */
async function updateBalance(conn, userId, currencyType, amount, type, reason, operatorId) {
  // 1. 锁定用户行（防止并发）
  const [rows] = await conn.query(
    'SELECT id, game_balance, cash_chips FROM users WHERE id = ? FOR UPDATE',
    [userId]
  );

  if (rows.length === 0) {
    throw new Error('目标用户不存在');
  }

  const user = rows[0];
  const balanceField = currencyType === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
  const balanceBefore = Number(user[balanceField]);
  const balanceAfter = balanceBefore + amount;

  // 2. 检查余额是否足够（减少时）
  if (amount < 0 && balanceAfter < 0) {
    throw new Error('余额不足');
  }

  // 3. 更新余额
  await conn.query(
    `UPDATE users SET ${balanceField} = ? WHERE id = ?`,
    [balanceAfter, userId]
  );

  // 4. 记录交易
  await conn.query(
    `INSERT INTO balance_transactions 
     (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, currencyType, amount, balanceBefore, balanceAfter, type, reason, operatorId]
  );

  return { balanceBefore, balanceAfter };
}

// ============================================
// GET /api/wallet/balance - 查询自己的余额（需登录）
// ============================================
router.get('/wallet/balance', auth, async (req, res) => {
  try {
    // 从 JWT 获取用户 ID
    const userId = req.user.id;

    // 查询用户余额
    const [rows] = await db.promise().query(
      'SELECT id, username, game_balance, cash_chips FROM users WHERE id = ?',
      [userId]
    );

    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: '用户不存在，请重新登录' });
    }

    const user = rows[0];

    // 返回余额（不返回敏感字段）
    res.json({
      success: true,
      data: {
        id: user.id,
        username: user.username,
        game_balance: Number(user.game_balance),
        cash_chips: Number(user.cash_chips)
      }
    });
  } catch (err) {
    console.error('查询余额失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/wallet/admin/grant - 管理员发放余额（需 admin 角色）
// ============================================
router.post('/wallet/admin/grant', auth, requireRole('admin'), async (req, res) => {
  // 使用事务
  const conn = await db.promise().getConnection();
  try {
    // 1. 提取参数
    const targetUserId = parseInt(req.body.user_id, 10);
    const currencyType = req.body.currency_type;
    const amount = Number(req.body.amount);
    const reason = (req.body.reason || '').trim();

    // 2. 参数验证
    if (isNaN(targetUserId) || targetUserId <= 0) {
      return res.status(400).json({ success: false, message: '无效的目标用户ID' });
    }
    if (!isValidCurrencyType(currencyType)) {
      return res.status(400).json({ success: false, message: '无效的货币类型，必须是 GAME_BALANCE 或 CASH_CHIPS' });
    }
    if (!isValidAmount(amount)) {
      return res.status(400).json({ success: false, message: '发放数量必须为正数，且不能超过 999999999999.99' });
    }
    if (reason.length > 255) {
      return res.status(400).json({ success: false, message: '原因/备注不能超过 255 个字符' });
    }

    // 3. 开始事务
    await conn.beginTransaction();

    // 4. 检查目标用户是否存在
    const [targetRows] = await conn.query(
      'SELECT id, username FROM users WHERE id = ?',
      [targetUserId]
    );
    if (targetRows.length === 0) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: '目标用户不存在' });
    }

    // 5. 更新余额并记录交易
    const { balanceBefore, balanceAfter } = await updateBalance(
      conn, targetUserId, currencyType, amount, 'ADMIN_GRANT', reason, req.user.id
    );

    // 6. 记录管理员操作日志
    await conn.query(
      'INSERT INTO admin_logs (admin_id, target_user_id, action, detail) VALUES (?, ?, ?, ?)',
      [req.user.id, targetUserId, 'balance_grant', JSON.stringify({
        currency_type: currencyType,
        amount: amount,
        balance_before: balanceBefore,
        balance_after: balanceAfter,
        reason: reason
      })]
    );

    // 7. 提交事务
    await conn.commit();

    // 8. 返回成功
    res.json({
      success: true,
      message: '余额发放成功',
      data: {
        user_id: targetUserId,
        username: targetRows[0].username,
        currency_type: currencyType,
        amount: amount,
        balance_before: balanceBefore,
        balance_after: balanceAfter
      }
    });
  } catch (err) {
    // 回滚事务
    await conn.rollback();
    console.error('管理员发放余额失败:', err.message);
    res.status(500).json({ success: false, message: err.message || '服务器内部错误，请稍后重试' });
  } finally {
    conn.release();
  }
});

// ============================================
// POST /api/wallet/deposit - 充值申请（创建 PENDING 订单）
// 安全说明:
//   - 当前没有合法支付渠道，绝不直接加余额、绝不伪造「充值成功/到账」
//   - 只创建 PENDING 订单，等待后台人工/支付系统审核处理
//   - 订单通过后由管理员/结算系统使用 admin/grant 同等事务逻辑入账
// ============================================
const ORDER_METHODS = ['TNG', 'BANK', 'OTHER']; // 占位方式枚举，仅记录用途，不接入任何真实支付

/** 生成唯一订单号（时间戳 + 服务器安全随机数，避免 Math.random 可预测） */
function newOrderNo(type) {
  const rnd = require('crypto').randomInt(0, 46656).toString(36).toUpperCase().padStart(3, '0');
  return type + Date.now().toString(36).toUpperCase() + rnd;
}

/** 金额解析（返回 null 表示非法） */
function parseAmount(v) {
  const n = Number(v);
  if (!isValidAmount(n)) return null;
  return Math.round(n * 100) / 100;
}

/**
 * POST /api/wallet/deposit - 充值申请
 * 创建 PENDING 订单，等待管理员审核；绝不直接加余额、绝不伪造成功。
 * 金额单位 RM（仅用于现金筹码充值订单的记录字段，不接入真实支付渠道）。
 */
router.post('/wallet/deposit', auth, async (req, res) => {
  try {
    const amount = parseAmount(req.body.amount);
    const method = (req.body.payment_method || '').trim().toUpperCase();
    const account = String(req.body.account || '').trim().slice(0, 120);
    const remark = String(req.body.remark || '').trim().slice(0, 255);

    if (!amount) return res.status(422).json({ success: false, message: '充值金额必须为正数，最多 2 位小数' });
    if (!ORDER_METHODS.includes(method)) return res.status(400).json({ success: false, message: '无效的支付方式' });
    if (amount < FUNDS.DEPOSIT.MIN) {
      return res.status(422).json({ success: false, message: '最低充值金额为 RM' + FUNDS.DEPOSIT.MIN });
    }
    if (amount > FUNDS.DEPOSIT.MAX) {
      return res.status(422).json({ success: false, message: '单笔最高充值金额为 RM50,000' });
    }

    const [result] = await db.promise().query(
      `INSERT INTO wallet_orders (user_id, order_no, order_type, currency_type, amount, method, account, remark, status)
       VALUES (?, ?, 'DEPOSIT', 'CASH_CHIPS', ?, ?, ?, ?, 'PENDING')`,
      [req.user.id, newOrderNo('D'), amount, method, account || null, remark || null]
    );
    return res.status(201).json({
      success: true, message: '充值申请已提交，等待管理员确认',
      data: { id: Number(result.insertId), amount, status: 'PENDING', note: '审核通过后余额才会增加' }
    });
  } catch (err) {
    console.error('充值申请失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

/**
 * POST /api/wallet/withdraw - 提现申请
 * 创建 PENDING 订单；审核通过时才扣余额（事务内校验余额充足）。
 */
router.post('/wallet/withdraw', auth, async (req, res) => {
  try {
    const amount = parseAmount(req.body.amount);
    const method = (req.body.withdraw_method || '').trim().toUpperCase();
    const account = String(req.body.account || '').trim().slice(0, 120);
    const remark = String(req.body.remark || '').trim().slice(0, 255);

    if (!amount) return res.status(400).json({ success: false, message: '提现金额必须为正数，最多 2 位小数' });
    if (!ORDER_METHODS.includes(method)) return res.status(400).json({ success: false, message: '无效的提现方式' });
    if (amount < 30) return res.status(400).json({ success: false, message: '单笔提现至少 RM30.00' });
    if (amount > 50000) return res.status(400).json({ success: false, message: '单笔提现不能超过 RM50,000' });
    if (!account) return res.status(400).json({ success: false, message: '请填写收款账号信息' });

    // 实时余额提示（不做扣款；审核通过时事务内再校验）
    const [bal] = await db.promise().query('SELECT cash_chips FROM users WHERE id = ?', [req.user.id]);
    const available = Number(bal[0] ? bal[0].cash_chips : 0);
    if (available < amount) return res.status(409).json({ success: false, code: 'INSUFFICIENT_FUNDS', message: '现金筹码余额不足' });

    const [result] = await db.promise().query(
      `INSERT INTO wallet_orders (user_id, order_no, order_type, currency_type, amount, method, account, remark, status)
       VALUES (?, ?, 'WITHDRAW', 'CASH_CHIPS', ?, ?, ?, ?, 'PENDING')`,
      [req.user.id, newOrderNo('W'), amount, method, account, remark || null]
    );
    return res.status(201).json({
      success: true, message: '提现申请已提交，等待管理员确认',
      data: { id: Number(result.insertId), amount, status: 'PENDING' }
    });
  } catch (err) {
    console.error('提现申请失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/wallet/orders - 我的充值/提现订单（含记录页展示）
// ============================================
router.get('/wallet/orders', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const type = (req.query.type || '').toUpperCase(); // DEPOSIT / WITHDRAW / 空=全部
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);

    const params = [userId];
    let where = 'user_id = ?';
    if (type === 'DEPOSIT' || type === 'WITHDRAW') {
      where += ' AND order_type = ?';
      params.push(type);
    }

    const [rows] = await db.promise().query(
      `SELECT id, order_no, order_type, currency_type, amount, method, account, status, remark, created_at
       FROM wallet_orders WHERE ${where} ORDER BY id DESC LIMIT ?`,
      params.concat([limit])
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('查询钱包订单失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/wallet/exchange - 兑换（已停用）
// 说明: 真实货币兑换功能未开放。此端点保留路径兼容性，永远返回「暂未开放」。
//       不做 game_balance 与 cash_chips 互转，不做真实货币兑换。
// ============================================
router.post('/wallet/exchange', auth, async (req, res) => {
  return res.status(503).json({
    success: false,
    code: 'EXCHANGE_UNAVAILABLE',
    message: '兑换暂未开放'
  });
});

// ============================================
// GET /api/wallet/transactions - 查询自己的交易记录（需登录）
// ============================================
router.get('/wallet/transactions', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);

    // 查询交易记录
    const [rows] = await db.promise().query(
      `SELECT id, currency_type, amount, balance_before, balance_after, type, reason, created_at
       FROM balance_transactions
       WHERE user_id = ?
       ORDER BY id DESC
       LIMIT ?`,
      [userId, limit]
    );

    res.json({
      success: true,
      data: rows
    });
  } catch (err) {
    console.error('查询交易记录失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/wallet/records?filter=all|income|expense|pending|completed|failed&limit=30
// 统一交易记录（余额变动 + 订单），供「钱包 → 交易记录」筛选使用
// 说明:
//   - 余额变动（balance_transactions）→ 收入 / 支出
//   - 订单（wallet_orders）→ 处理中 / 完成 / 失败
//   - 只返回自己的记录；金额取真实值，绝不伪造
// ============================================
const TX_TYPE_TEXT = {
  ADMIN_GRANT: '管理员发放',
  DEPOSIT: '充值',
  WITHDRAW: '提现',
  EXCHANGE: '兑换',
  ADJUST: '管理员调整',
  GAME_BET: '游戏下注',
  GAME_WIN: '游戏赢',
  GAME_LOSE: '游戏输',
  REFERRAL_REWARD: '推广奖励'
};
const ORDER_TYPE_TEXT = { DEPOSIT: '充值订单', WITHDRAW: '提款订单' };
const ORDER_STATUS_TEXT = {
  PENDING_PAYMENT: '待付款',
  PENDING_REVIEW: '待审核',
  PENDING: '待审核',
  PROCESSING: '处理中',
  APPROVED: '已通过',
  COMPLETED: '已完成',
  REJECTED: '失败',
  CANCELLED: '已取消'
};

router.get('/wallet/records', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const filter = String(req.query.filter || 'all');
    const limit = Math.min(parseInt(req.query.limit, 10) || 30, 100);

    const rows = [];

    // 1) 余额变动（收入 / 支出）
    if (filter === 'all' || filter === 'income' || filter === 'expense') {
      const [tx] = await db.promise().query(
        `SELECT id, currency_type, amount, balance_before, balance_after, type, reason, created_at
         FROM balance_transactions WHERE user_id = ? ORDER BY id DESC LIMIT ?`,
        [userId, limit]
      );
      tx.forEach(r => {
        const a = Number(r.amount || 0);
        if (filter === 'income' && a <= 0) return;
        if (filter === 'expense' && a >= 0) return;
        rows.push({
          kind: 'transaction',
          id: 't' + r.id,
          currency_type: r.currency_type,
          currency_text: r.currency_type === 'GAME_BALANCE' ? '游戏余额' : '现金筹码',
          amount: a,
          direction: a >= 0 ? 'income' : 'expense',
          balance_after: Number(r.balance_after || 0),
          type: r.type,
          type_text: TX_TYPE_TEXT[r.type] || r.type,
          status_text: a >= 0 ? '收入' : '支出',
          reason: r.reason || '',
          created_at: r.created_at
        });
      });
    }

    // 2) 订单（处理中 / 完成 / 失败）
    if (filter === 'all' || filter === 'pending' || filter === 'completed' || filter === 'failed') {
      const [od] = await db.promise().query(
        `SELECT id, order_no, order_type, currency_type, amount, method, status, remark, created_at
         FROM wallet_orders WHERE user_id = ? ORDER BY id DESC LIMIT ?`,
        [userId, limit]
      );
      od.forEach(r => {
        const s = String(r.status);
        const bucket = (s === 'PENDING' || s === 'PROCESSING') ? 'pending'
          : (s === 'COMPLETED') ? 'completed'
          : (s === 'REJECTED') ? 'failed' : 'cancelled';
        if (filter !== 'all' && bucket !== filter) return;
        rows.push({
          kind: 'order',
          id: 'o' + r.id,
          order_no: r.order_no,
          currency_type: r.currency_type,
          currency_text: r.currency_type === 'GAME_BALANCE' ? '游戏余额' : '现金筹码',
          amount: Number(r.amount || 0),
          direction: r.order_type === 'DEPOSIT' ? 'income' : 'expense',
          type: r.order_type,
          type_text: ORDER_TYPE_TEXT[r.order_type] || r.order_type,
          method: r.method,
          status: s,
          status_text: ORDER_STATUS_TEXT[s] || s,
          reason: r.remark || '',
          created_at: r.created_at
        });
      });
    }

    // 时间倒序合并
    rows.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return ok(res, {
      filter: filter,
      list: rows.slice(0, limit),
      filters: [
        { key: 'all', name: '全部' },
        { key: 'income', name: '收入' },
        { key: 'expense', name: '支出' },
        { key: 'pending', name: '处理中' },
        { key: 'completed', name: '完成' },
        { key: 'failed', name: '失败' }
      ]
    });
  } catch (err) {
    console.error('获取交易记录失败:', err.message);
    return fail(res, '交易记录加载失败', 500);
  }
});

// ============================================
// GET /api/wallet/summary - 钱包首页聚合（资产总览 + 统计 + 最近记录 + 功能开关）
// 说明:
//   - 游戏余额与现金筹码【完全独立】，不做任何混合计算
//   - 数据全部来自真实数据库；无数据时返回真实 0 / 空数组，绝不伪造
// ============================================
router.get('/wallet/summary', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    // 1) 资产总览（两个独立余额）
    const [uRows] = await db.promise().query(
      'SELECT game_balance, cash_chips FROM users WHERE id = ? LIMIT 1', [userId]
    );
    if (uRows.length === 0) return fail(res, '用户不存在，请重新登录', 404);

    // 2) 收支统计（按货币类型分别统计，互不混合）
    const [sumRows] = await db.promise().query(
      `SELECT currency_type,
              SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS income,
              SUM(CASE WHEN amount < 0 THEN -amount ELSE 0 END) AS expense,
              COUNT(*) AS cnt
       FROM balance_transactions WHERE user_id = ? GROUP BY currency_type`,
      [userId]
    );
    const stat = {
      GAME_BALANCE: { income: 0, expense: 0, count: 0 },
      CASH_CHIPS: { income: 0, expense: 0, count: 0 }
    };
    sumRows.forEach(r => {
      const k = r.currency_type === 'CASH_CHIPS' ? 'CASH_CHIPS' : 'GAME_BALANCE';
      stat[k] = {
        income: Number(r.income || 0),
        expense: Number(r.expense || 0),
        count: Number(r.cnt || 0)
      };
    });

    // 3) 订单状态统计（处理中 / 完成 / 失败）— 钱包订单 + 充值订单（真实计数，不伪造）
    const [ordRows] = await db.promise().query(
      'SELECT status, COUNT(*) AS c FROM wallet_orders WHERE user_id = ? GROUP BY status', [userId]
    );
    const [rcRows] = await db.promise().query(
      'SELECT status, COUNT(*) AS c FROM recharge_orders WHERE user_id = ? GROUP BY status', [userId]
    );
    const orders = { pending: 0, processing: 0, completed: 0, failed: 0, cancelled: 0, total: 0 };
    ordRows.forEach(r => {
      const c = Number(r.c) || 0;
      orders.total += c;
      const s = String(r.status);
      if (s === 'PENDING') orders.pending += c;
      else if (s === 'PROCESSING') orders.processing += c;
      else if (s === 'COMPLETED') orders.completed += c;
      else if (s === 'REJECTED') orders.failed += c;
      else if (s === 'CANCELLED') orders.cancelled += c;
    });
    rcRows.forEach(r => {
      const c = Number(r.c) || 0;
      orders.total += c;
      const s = String(r.status);
      if (s === 'PENDING') orders.pending += c;
      else if (s === 'COMPLETED') orders.completed += c;
      else if (s === 'CANCELLED' || s === 'EXPIRED') orders.cancelled += c;
    });

    // 4) 最近记录（最近 5 条交易 + 最近 3 条订单 + 最近 3 条充值订单）
    const [txRows] = await db.promise().query(
      `SELECT id, currency_type, amount, balance_after, type, reason, created_at
       FROM balance_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 5`, [userId]
    );
    const [ordList] = await db.promise().query(
      `SELECT id, order_no, order_type, currency_type, amount, method, status, created_at
       FROM wallet_orders WHERE user_id = ? ORDER BY id DESC LIMIT 3`, [userId]
    );
    const [rcList] = await db.promise().query(
      `SELECT id, order_id AS order_no, 'RECHARGE' AS order_type, 'GAME_BALANCE' AS currency_type,
              amount, '现金筹码' AS method, status,
              CASE status WHEN 'PENDING' THEN '待处理' WHEN 'COMPLETED' THEN '已完成'
                          WHEN 'CANCELLED' THEN '已取消' WHEN 'EXPIRED' THEN '已过期'
                          ELSE status END AS status_text,
              completed_at, created_at
       FROM recharge_orders WHERE user_id = ? ORDER BY id DESC LIMIT 3`, [userId]
    );

    // 5) 功能开关：如实反映后端是否已开放（不伪造成功）
    const features = {
      deposit: { available: true, note: '创建充值订单，管理员确认后现金筹码到账' },
      withdraw: { available: true, note: '可提交虚拟现金筹码提款申请，审核不代表真实出款' },
      exchange: { available: false, note: '兑换暂未开放' },
      transfer: { available: true, note: '向其他用户转账现金筹码（需支付密码，单日上限由后端校验）' }
    };

    return ok(res, {
      assets: {
        game_balance: Number(uRows[0].game_balance || 0),
        cash_chips: Number(uRows[0].cash_chips || 0),
        independent: true,
        note: '游戏余额与现金筹码相互独立，不合并计算'
      },
      stats: stat,
      orders: orders,
      recent_transactions: txRows.map(r => ({
        id: Number(r.id),
        currency_type: r.currency_type,
        amount: Number(r.amount || 0),
        balance_after: Number(r.balance_after || 0),
        type: r.type,
        type_text: TX_TYPE_TEXT[r.type] || r.type,
        reason: r.reason || '',
        created_at: r.created_at
      })),
      recent_orders: ordList.concat(rcList).map(r => ({
        id: Number(r.id),
        order_no: r.order_no,
        order_type: r.order_type,
        currency_type: r.currency_type,
        amount: Number(r.amount || 0),
        method: r.method || '',
        status: r.status,
        status_text: r.status_text || ORDER_STATUS_TEXT[r.status] || r.status,
        completed_at: r.completed_at || null,
        created_at: r.created_at
      })),
      features: features
    });
  } catch (err) {
    console.error('获取钱包概览失败:', err.message);
    return fail(res, '钱包数据加载失败', 500);
  }
});
// 导出路由
module.exports = router;