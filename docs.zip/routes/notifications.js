// ============================================
// 26牛牛 - 通知中心路由
// 包含:
//   - GET  /api/notifications                 通知列表（分类筛选 + 未读数）
//   - GET  /api/notifications/unread-count    未读数（大厅 / 我的 红点）
//   - POST /api/notifications/read            单条已读
//   - POST /api/notifications/read-all        全部已读
// 权限: 全部需要 JWT，只能操作自己的通知（user_id 取自 JWT）
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { ok, fail, safeInternalPath } = require('../utils/request');

const CATEGORIES = ['system', 'activity', 'referral', 'support', 'game'];
const CATEGORY_TEXT = {
  system: '系统通知',
  activity: '活动通知',
  referral: '推广通知',
  support: '客服通知',
  game: '游戏通知'
};

function out(r) {
  return {
    id: Number(r.id),
    category: r.category,
    category_text: CATEGORY_TEXT[r.category] || r.category,
    title: r.title,
    content: r.content || '',
    link: safeInternalPath(r.link),
    is_read: !!r.is_read,
    read_at: r.read_at || null,
    created_at: r.created_at
  };
}

// GET /api/notifications?category=all&limit=30
router.get('/notifications', auth, async (req, res) => {
  try {
    const userId = req.user.id;
    const category = String(req.query.category || 'all');
    const limit = Math.min(parseInt(req.query.limit, 10) || 30, 100);

    const params = [userId];
    let where = 'user_id = ?';
    if (category !== 'all' && CATEGORIES.includes(category)) {
      where += ' AND category = ?';
      params.push(category);
    }
    params.push(limit);

    const [rows] = await db.promise().query(
      `SELECT id, category, title, content, link, is_read, read_at, created_at
       FROM notifications WHERE ${where} ORDER BY id DESC LIMIT ?`,
      params
    );

    const [cnt] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0', [userId]
    );

    return ok(res, {
      list: rows.map(out),
      unread: Number(cnt[0].c) || 0,
      categories: CATEGORIES.map(c => ({ key: c, name: CATEGORY_TEXT[c] }))
    });
  } catch (err) {
    console.error('获取通知失败:', err.message);
    return fail(res, '通知加载失败', 500);
  }
});

// GET /api/notifications/unread-count
router.get('/notifications/unread-count', auth, async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0', [req.user.id]
    );
    return ok(res, { unread: Number(rows[0].c) || 0 });
  } catch (err) {
    console.error('获取未读数失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// POST /api/notifications/read { id }
router.post('/notifications/read', auth, async (req, res) => {
  try {
    const id = Number(req.body.id);
    if (!Number.isInteger(id) || id <= 0) return fail(res, '无效的通知ID');

    const [r] = await db.promise().query(
      'UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );
    if (!r.affectedRows) return fail(res, '通知不存在', 404);
    return ok(res, { id: id });
  } catch (err) {
    console.error('标记通知已读失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// POST /api/notifications/read-all
router.post('/notifications/read-all', auth, async (req, res) => {
  try {
    const category = String(req.body.category || 'all');
    const params = [req.user.id];
    let where = 'user_id = ? AND is_read = 0';
    if (category !== 'all' && CATEGORIES.includes(category)) {
      where += ' AND category = ?';
      params.push(category);
    }
    const [r] = await db.promise().query(
      `UPDATE notifications SET is_read = 1, read_at = NOW() WHERE ${where}`, params
    );
    return ok(res, { updated: r.affectedRows || 0 });
  } catch (err) {
    console.error('全部已读失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

module.exports = router;
module.exports.CATEGORY_TEXT = CATEGORY_TEXT;