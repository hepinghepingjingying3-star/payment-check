// ============================================
// 26牛牛 - 管理员资金后台（充值 / 提款 / 推广奖励）
// ============================================
// 接口（全部要求管理员 JWT，且经过 middleware/admin-boundary 双重校验）:
//   GET  /api/admin/deposits?status=&q=&limit=&offset=     充值订单列表（搜索/筛选/分页）
//   GET  /api/admin/deposits/:id                           充值订单详情（含流水与审计）
//   GET  /api/admin/deposits/:id/voucher                   查看凭证图片（非公开目录）
//   POST /api/admin/deposits/:id/review                    批准 / 拒绝（事务 + 幂等）
//   GET  /api/admin/withdrawals?...                        提款订单列表
//   GET  /api/admin/withdrawals/:id                        提款订单详情
//   POST /api/admin/withdrawals/:id/review                 批准 / 拒绝
//   POST /api/admin/withdrawals/:id/processing             标记处理中（不触碰余额）
//   GET  /api/admin/referrals?...                          推广管理（邀请码/直属/二级/奖励统计）
//   GET  /api/admin/referrals/rewards?...                  推广奖励台账（日期筛选/分页）
//   POST /api/admin/referrals/rewards/settle               按充值订单补结算奖励（幂等）
// 安全:
//   - 批准/拒绝全部在同一事务完成：订单状态 + 余额 + 流水 + 审计
//   - 只有可审核状态能通过；重复审核返回 409，绝不重复加减余额
//   - 列表与详情绝不返回密码 / password_hash / OTP / JWT 等敏感字段
// ============================================

const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const db = require('../config/db');
const { ok, fail } = require('../utils/request');
const FUNDS = require('../config/funds');
const FUND = require('../utils/funds');
const voucherStore = require('../utils/voucherStore');

function posInt(v) {
  const n = Number(v);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

function text(v, max) {
  return String(v === null || v === undefined ? '' : v).trim().slice(0, max);
}

function paging(req, def, max) {
  return {
    limit: Math.min(Math.max(parseInt(req.query.limit, 10) || def, 1), max),
    offset: Math.max(parseInt(req.query.offset, 10) || 0, 0)
  };
}

/** 关键字 LIKE 模式：转义通配符（下划线 / 百分号 / 反斜杠），保留用户输入的字符 */
function likePattern(q) {
  return '%' + String(q === null || q === undefined ? '' : q).replace(/[\\%_]/g, ch => '\\' + ch) + '%';
}

/** 审核入参解析：decision 支持 approved/approve/approved 与 rejected/reject */
function parseDecision(raw) {
  const s = String(raw || '').toLowerCase();
  if (s === 'approved' || s === 'approve') return 'approve';
  if (s === 'rejected' || s === 'reject') return 'reject';
  return null;
}

// ============================================
// 充值订单列表
// ============================================
router.get('/admin/deposits', async (req, res) => {
  try {
    const p = paging(req, 20, 100);
    const data = await FUND.listOrdersForAdmin({
      type: 'DEPOSIT',
      status: text(req.query.status, 20).toUpperCase(),
      q: text(req.query.q, 64),
      limit: p.limit,
      offset: p.offset
    });
    return ok(res, data);
  } catch (err) {
    console.error('读取充值订单失败:', err.message);
    return fail(res, '充值订单一览加载失败，请稍后重试', 500);
  }
});

router.get('/admin/deposits/:id', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const order = await FUND.findOrderForAdmin(id, 'DEPOSIT');
    if (!order) return fail(res, '充值订单不存在', 404, 'ORDER_NOT_FOUND');
    return ok(res, { order: order });
  } catch (err) {
    console.error('读取充值订单详情失败:', err.message);
    return fail(res, '订单详情加载失败，请稍后重试', 500);
  }
});

// 凭证图片（管理员专用；文件在 storage 内，不对外静态暴露）
router.get('/admin/deposits/:id/voucher', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return res.status(422).json({ success: false, message: '无效的订单ID' });
  try {
    const [rows] = await db.promise().query(
      "SELECT voucher_path FROM wallet_orders WHERE id = ? AND order_type = 'DEPOSIT' LIMIT 1", [id]
    );
    const abs = voucherStore.resolveVoucher(rows[0] ? rows[0].voucher_path : '');
    if (!abs || !fs.existsSync(abs)) return res.status(404).json({ success: false, message: '凭证不存在' });
    res.set('Cache-Control', 'no-store');
    const ext = path.extname(abs).toLowerCase();
    res.type(ext === '.png' ? 'image/png' : (ext === '.webp' ? 'image/webp' : 'image/jpeg'));
    return fs.createReadStream(abs).pipe(res);
  } catch (err) {
    console.error('读取凭证失败:', err.message);
    return res.status(500).json({ success: false, message: '凭证读取失败' });
  }
});

// ============================================
// 充值审核：批准 / 拒绝
// ============================================
router.post('/admin/deposits/:id/review', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  const decision = parseDecision((req.body || {}).decision);
  if (!decision) return fail(res, '无效的审核操作', 422, 'INVALID_DECISION');
  const note = text((req.body || {}).note || (req.body || {}).admin_note, 255);
  const reason = text((req.body || {}).reason || (req.body || {}).reject_reason, 255);

  const result = await FUND.reviewDeposit(id, req.user.id, decision, { note: note, reason: reason });
  if (!result.ok) return fail(res, result.message, result.status || 400, result.code);
  return ok(res, result);
});

// ============================================
// 提款订单列表 / 详情 / 审核
// ============================================
router.get('/admin/withdrawals', async (req, res) => {
  try {
    const p = paging(req, 20, 100);
    const data = await FUND.listOrdersForAdmin({
      type: 'WITHDRAW',
      status: text(req.query.status, 20).toUpperCase(),
      q: text(req.query.q, 64),
      limit: p.limit,
      offset: p.offset
    });
    return ok(res, data);
  } catch (err) {
    console.error('读取提款订单失败:', err.message);
    return fail(res, '提款订单一览加载失败，请稍后重试', 500);
  }
});

router.get('/admin/withdrawals/:id', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const order = await FUND.findOrderForAdmin(id, 'WITHDRAW');
    if (!order) return fail(res, '提款订单不存在', 404, 'ORDER_NOT_FOUND');
    return ok(res, { order: order });
  } catch (err) {
    console.error('读取提款订单详情失败:', err.message);
    return fail(res, '订单详情加载失败，请稍后重试', 500);
  }
});

router.post('/admin/withdrawals/:id/review', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  const decision = parseDecision((req.body || {}).decision);
  if (!decision) return fail(res, '无效的审核操作', 422, 'INVALID_DECISION');
  const note = text((req.body || {}).note || (req.body || {}).admin_note, 255);
  const reason = text((req.body || {}).reason || (req.body || {}).reject_reason, 255);

  const result = await FUND.reviewWithdrawal(id, req.user.id, decision, { note: note, reason: reason });
  if (!result.ok) return fail(res, result.message, result.status || 400, result.code);
  return ok(res, result);
});

router.post('/admin/withdrawals/:id/processing', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  const result = await FUND.adminSetProcessing(id, req.user.id, text((req.body || {}).note, 255));
  if (!result.ok) return fail(res, result.message, result.status || 400, result.code);
  return ok(res, result);
});

// ============================================
// 推广管理（管理员）
// ============================================
router.get('/admin/referrals', async (req, res) => {
  try {
    const p = paging(req, 20, 100);
    const q = text(req.query.q, 64);
    const where = ["u.status <> 'deleted'"];
    const params = [];
    if (q) {
      where.push('(u.username LIKE ? OR u.invite_code LIKE ? OR u.nickname LIKE ?)');
      const like = likePattern(q);
      params.push(like, like, like);
    }
    const clause = 'WHERE ' + where.join(' AND ');
    const [rows] = await db.promise().query(
      `SELECT u.id, u.username, u.nickname, u.invite_code, u.status, u.role, u.created_at,
              (SELECT COUNT(*) FROM referral_relations r WHERE r.referrer_id = u.id AND r.level = 1 AND r.status = 'active') AS direct_count,
              (SELECT COUNT(*) FROM referral_relations r WHERE r.referrer_id = u.id AND r.level = 2 AND r.status = 'active') AS second_count,
              (SELECT COALESCE(SUM(w.reward_amount), 0) FROM referral_rewards w WHERE w.user_id = u.id AND w.status = 'CREDITED') AS reward_total,
              (SELECT COUNT(*) FROM referral_rewards w WHERE w.user_id = u.id) AS reward_count
       FROM users u ${clause}
       ORDER BY direct_count DESC, u.id DESC LIMIT ? OFFSET ?`,
      params.concat([p.limit, p.offset])
    );
    const [cnt] = await db.promise().query(`SELECT COUNT(*) AS c FROM users u ${clause}`, params);
    const [totals] = await db.promise().query(
      `SELECT COUNT(*) AS records,
              COALESCE(SUM(CASE WHEN status = 'CREDITED' THEN reward_amount ELSE 0 END), 0) AS credited,
              COALESCE(SUM(CASE WHEN status = 'PENDING' THEN reward_amount ELSE 0 END), 0) AS pending
       FROM referral_rewards`
    );
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        username: r.username,
        nickname: r.nickname || null,
        invite_code: r.invite_code || null,
        status: r.status,
        role: r.role,
        direct: Number(r.direct_count) || 0,
        second: Number(r.second_count) || 0,
        reward_total: Number(r.reward_total) || 0,
        reward_count: Number(r.reward_count) || 0,
        created_at: r.created_at
      })),
      total: Number(cnt[0] ? cnt[0].c : 0),
      limit: p.limit,
      offset: p.offset,
      rates: require('../config/referral').publicRates(),
      rewards_summary: {
        records: Number(totals[0] ? totals[0].records : 0),
        credited: Number(totals[0] ? totals[0].credited : 0),
        pending: Number(totals[0] ? totals[0].pending : 0)
      }
    });
  } catch (err) {
    console.error('读取推广管理失败:', err.message);
    return fail(res, '推广数据加载失败，请稍后重试', 500);
  }
});



// 推广奖励台账（日期 / 状态 / 用户筛选 + 分页）
router.get('/admin/referrals/rewards', async (req, res) => {
  try {
    const p = paging(req, 20, 100);
    const where = [];
    const params = [];
    const status = text(req.query.status, 12).toUpperCase();
    if (['PENDING', 'CREDITED', 'VOID'].indexOf(status) >= 0) { where.push('w.status = ?'); params.push(status); }
    const level = parseInt(req.query.level, 10);
    if (level === 0 || level === 1 || level === 2) { where.push('w.level = ?'); params.push(level); }
    const userId = posInt(req.query.user_id);
    if (userId) { where.push('w.user_id = ?'); params.push(userId); }
    const from = text(req.query.from, 10);
    const to = text(req.query.to, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(from)) { where.push('w.created_at >= ?'); params.push(from + ' 00:00:00'); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(to)) { where.push('w.created_at <= ?'); params.push(to + ' 23:59:59'); }
    const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const [rows] = await db.promise().query(
      `SELECT w.id, w.user_id, w.source_user_id, w.level, w.rate, w.base_amount, w.reward_amount,
              w.asset_type, w.status, w.source_type, w.source_ref, w.created_at, w.credited_at,
              u.username, u.invite_code, s.username AS source_username
       FROM referral_rewards w
       LEFT JOIN users u ON u.id = w.user_id
       LEFT JOIN users s ON s.id = w.source_user_id
       ${clause} ORDER BY w.id DESC LIMIT ? OFFSET ?`,
      params.concat([p.limit, p.offset])
    );
    const [cnt] = await db.promise().query(`SELECT COUNT(*) AS c FROM referral_rewards w ${clause}`, params);
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        user: { id: Number(r.user_id), username: r.username || null, invite_code: r.invite_code || null },
        source_user: r.source_user_id ? { id: Number(r.source_user_id), username: r.source_username || null } : null,
        level: Number(r.level),
        level_text: r.level === 0 ? '自身游戏奖励' : (r.level === 1 ? '直属下线' : '二级下线'),
        rate: Number(r.rate),
        base_amount: Number(r.base_amount),
        reward_amount: Number(r.reward_amount),
        asset_type: r.asset_type,
        status: r.status,
        status_text: r.status === 'CREDITED' ? '已入账' : (r.status === 'PENDING' ? '待入账' : '已作废'),
        source_type: r.source_type,
        source_ref: r.source_ref || null,
        created_at: r.created_at,
        credited_at: r.credited_at || null
      })),
      total: Number(cnt[0] ? cnt[0].c : 0),
      limit: p.limit,
      offset: p.offset,
      rates: require('../config/referral').publicRates()
    });
  } catch (err) {
    console.error('读取推广奖励台账失败:', err.message);
    return fail(res, '推广奖励台账加载失败，请稍后重试', 500);
  }
});

// 补结算：按已通过的充值订单结算推广奖励（幂等，重复执行不会重复发奖）
router.post('/admin/referrals/rewards/settle', async (req, res) => {
  const orderId = posInt((req.body || {}).order_id);
  if (!orderId) return fail(res, '请填写充值订单ID', 422, 'INVALID_ORDER_ID');
  let conn;
  try {
    const [rows] = await db.promise().query(
      'SELECT id, user_id, order_no, order_type, status, amount FROM wallet_orders WHERE id = ? LIMIT 1', [orderId]
    );
    const order = rows[0];
    if (!order || order.order_type !== 'DEPOSIT') return fail(res, '充值订单不存在', 404, 'ORDER_NOT_FOUND');
    if (order.status !== 'APPROVED' && order.status !== 'COMPLETED') {
      return fail(res, '只有审核通过的充值订单才能结算推广奖励', 409, 'ORDER_NOT_APPROVED');
    }
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const { settleRewards } = require('../utils/referralRewards');
    const created = await settleRewards(conn, {
      sourceType: 'DEPOSIT', sourceRef: order.order_no, sourceUserId: order.user_id,
      baseAmountCents: Math.round(Number(order.amount) * 100), operatorId: req.user.id,
      assetType: 'CASH_CHIPS', remark: '管理员补结算推广奖励'
    });
    await conn.commit();
    return ok(res, { order_id: orderId, created: created.length, rewards: created });
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('补结算推广奖励失败:', err.message);
    return fail(res, '补结算失败，请稍后重试', 500);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;

