// ============================================
// 26牛牛 - 公告路由
// 包含:
//   - GET /api/announcements            公告列表（登录后可见）
//   - GET /api/announcements/banner     大厅轮播公告（置顶优先，最多 5 条）
//   - GET /api/announcements/:id        公告详情
// 说明:
//   - 数据来源统一由 utils/content.js 合并（config + announcements 表 + 旧 system_notices）
//   - 无公告时返回空数组，前端显示「暂无公告」
// ============================================

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const A = require('../config/announcements');
const content = require('../utils/content');
const { ok, fail } = require('../utils/request');

// GET /api/announcements
router.get('/announcements', auth, async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit, 10) || 30, 100);
    const list = await content.loadAnnouncements();
    return ok(res, {
      list: list.slice(0, limit).map(a => A.briefAnnouncement(a, 120)),
      total: list.length
    });
  } catch (err) {
    console.error('获取公告失败:', err.message);
    return fail(res, '公告加载失败', 500);
  }
});

// GET /api/announcements/banner （必须放在 /:id 之前，避免被吞掉）
router.get('/announcements/banner', auth, async (req, res) => {
  try {
    const list = await content.loadAnnouncements();
    const banners = list.slice(0, A.BANNER_LIMIT).map(a => A.briefAnnouncement(a, 80));
    return ok(res, { list: banners, total: banners.length });
  } catch (err) {
    console.error('获取轮播公告失败:', err.message);
    return fail(res, '公告加载失败', 500);
  }
});

// GET /api/announcements/:id
router.get('/announcements/:id', auth, async (req, res) => {
  try {
    const a = await content.getAnnouncement(req.params.id);
    if (!a) return fail(res, '公告不存在或已过期', 404);
    return ok(res, A.publicAnnouncement(a));
  } catch (err) {
    console.error('获取公告详情失败:', err.message);
    return fail(res, '公告加载失败', 500);
  }
});

module.exports = router;