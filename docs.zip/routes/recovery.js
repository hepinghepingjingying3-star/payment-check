'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('node:crypto');
const db = require('../config/db');
const router = express.Router();
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
// Single-process limiter; use a shared store before multi-instance deployment.
const attempts = new Map();
const timer = setInterval(() => {
  for (const [key, item] of attempts) if (item.until <= Date.now()) attempts.delete(key);
}, 60000);
timer.unref();
router.use('/auth/recovery', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  const key = req.socket.remoteAddress || 'unknown'; // Never trust client-supplied forwarding headers.
  const now = Date.now();
  let item = attempts.get(key);
  if (!item || item.until <= now) {
    if (attempts.size >= 10000) return res.status(429).json({ success: false, message: '请求过多，请稍后再试' });
    item = { count: 0, until: now + 600000 }; attempts.set(key, item);
  }
  if (++item.count > 10) {
    res.set('Retry-After', String(Math.ceil((item.until - now) / 1000)));
    return res.status(429).json({ success: false, message: '请求过多，请稍后再试' });
  }
  next();
});
const invalid = res => res.status(410).json({ success: false, code: 'RECOVERY_DISABLED', message: '自助找回已停用，请联系在线客服或管理员进行人工身份核验。' });
router.post('/auth/recovery/verify', async (req, res) => {
  return res.status(410).json({ success: false, code: 'RECOVERY_DISABLED', message: '自助找回已停用，请联系在线客服或管理员进行人工身份核验。' });
});
router.get('/auth/recovery/help', async (req, res) => {
  return res.json({
    success: true,
    data: {
      method: 'manual',
      steps: [
        '通过站内「在线客服」说明账号归属与注册资料。',
        '客服或管理员人工核验用户名、手机号、邮箱与注册信息。',
        '核验通过后，由管理员在后台按流程协助恢复账号。'
      ],
      contact: '/support-chat.html'
    }
  });
});
router.post('/auth/recovery/reset-password', async (req, res) => {
  return res.status(410).json({ success: false, code: 'RECOVERY_DISABLED', message: '自助重置密码已停用，请联系在线客服或管理员进行人工身份核验。' });
});
module.exports = router;
