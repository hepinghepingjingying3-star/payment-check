// ============================================
// 26牛牛 - 管理员后台 API（阶段 8）
// 包含:
//   - GET /api/admin/dashboard   后台首页统计
//   - GET /api/admin/users       用户查询（搜索 / 分页，只读）
// 权限:
//   - 路由级 auth + requireRole('admin')，独立于全局边界
//   - 普通用户与客服一律 403，未登录 401
// 安全:
//   - 绝不查询 / 返回 password_hash、OTP 明文、JWT
//   - 后台按用户名 / 手机号 / 邮箱 / 邀请码定位账号；忘记密码走人工客服核验
//   - 不支持的统计明确返回 supported:false，不编造数字
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const content = require('../utils/content');
const { writeAdminLog, listAdminLogs } = require('../utils/adminAudit');
const { ok, fail, maskPhone } = require('../utils/request');
const MODERATION = require('../config/moderation');
const { mutedSummary, expiringMutes, scopeRules } = require('../utils/moderation');
const approvals = require('../utils/approvals');
const userOps = require('../utils/userAdminOps');
const presence = require('../utils/presence');

// 后台响应一律禁止缓存；路由级权限校验（双重保护）
router.use('/admin', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
}, auth, requireRole('admin'));

/** 单个 COUNT 查询 */
async function countOf(sql, params) {
  const [rows] = await db.promise().query(sql, params || []);
  return Number(rows[0] && rows[0].c) || 0;
}

// ---------- 输入校验（统一返回中文提示，绝不回显 SQL） ----------
function text(value, max) {
  return String(value === null || value === undefined ? '' : value).trim().slice(0, max);
}
function validDateTime(value) {
  const s = text(value, 19);
  if (!s) return null;
  return /^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2})?)?$/.test(s) ? s.replace('T', ' ') : 'INVALID';
}
function isPositiveInt(value) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

// ============================================
// GET /api/admin/dashboard
// ============================================
router.get('/admin/dashboard', async (req, res) => {
  try {
    const [userRows] = await db.promise().query(
      `SELECT COUNT(*) AS total,
              SUM(status = 'active') AS active,
              SUM(status = 'banned') AS banned,
              SUM(created_at >= CURDATE()) AS today
       FROM users`
    );
    const u = userRows[0] || {};

    const [
      otpPending, otpToday, referralDirect, referralSecond, referralToday, referralMonth,
      supportThreads, support24h, login24h, loginFail24h, otpActionsToday
    ] = await Promise.all([
      countOf("SELECT COUNT(*) AS c FROM registration_otp WHERE status = 'pending' AND expires_at > NOW()"),
      countOf('SELECT COUNT(*) AS c FROM registration_otp WHERE created_at >= CURDATE()'),
      countOf("SELECT COUNT(*) AS c FROM referral_relations WHERE level = 1 AND status = 'active'"),
      countOf("SELECT COUNT(*) AS c FROM referral_relations WHERE level = 2 AND status = 'active'"),
      countOf('SELECT COUNT(*) AS c FROM referral_relations WHERE created_at >= CURDATE()'),
      countOf("SELECT COUNT(*) AS c FROM referral_relations WHERE created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01')"),
      countOf("SELECT COUNT(DISTINCT user_id) AS c FROM chat_messages WHERE channel = 'support' AND user_id IS NOT NULL AND is_recalled = 0"),
      countOf("SELECT COUNT(*) AS c FROM chat_messages WHERE channel = 'support' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"),
      countOf("SELECT COUNT(*) AS c FROM login_logs WHERE status = 'success' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"),
      countOf("SELECT COUNT(*) AS c FROM login_logs WHERE status = 'fail' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"),
      countOf('SELECT COUNT(*) AS c FROM otp_audit_logs WHERE created_at >= CURDATE()')
    ]);

    let announcementActive = null;
    try {
      announcementActive = (await content.loadAnnouncements()).length;
    } catch (e) { announcementActive = null; }

    // 实名审核统计（表不存在时返回 null，不伪造 0）
    let realName = { pending: null, approved: null, rejected: null, total: null };
    try {
      const [rnRows] = await db.promise().query(
        `SELECT status, COUNT(*) AS c FROM real_name_reviews GROUP BY status`
      );
      realName = { pending: 0, approved: 0, rejected: 0, total: 0 };
      rnRows.forEach(r => {
        if (r.status in realName) realName[r.status] = Number(r.c) || 0;
        realName.total += Number(r.c) || 0;
      });
    } catch (e) { /* 表不存在时保持 null */ }

    // 在线状态（user_presence 心跳）：表不可用时返回 null，绝不编造数字
    const onlineCount = await presence.onlineCount();

    // 禁言统计 + 到期提醒（MUTE.EXPIRE_REMIND_MINUTES 内的即将解禁账号）
    let muteStats = { muted_now: null, expiring_24h: null, expiring_1h: null };
    let expiringList = [];
    try {
      muteStats = await mutedSummary();
      expiringList = await expiringMutes(10);
    } catch (e) { /* 列缺失时保持 null / 空列表 */ }

    // 双人复核：待处理数量（不可用时 null）
    let pendingApprovals = null;
    try { pendingApprovals = await approvals.pendingCount(); } catch (e) { pendingApprovals = null; }

    return ok(res, {
      users: {
        total: Number(u.total) || 0,
        active: Number(u.active) || 0,
        banned: Number(u.banned) || 0,
        today: Number(u.today) || 0
      },
      otp: { pending: otpPending, created_today: otpToday },
      referrals: {
        direct: referralDirect,
        second: referralSecond,
        total: referralDirect + referralSecond,
        today: referralToday,
        month: referralMonth
      },
      support: { threads: supportThreads, messages_24h: support24h },
      login: { success_24h: login24h, failed_24h: loginFail24h },
      announcements: { active: announcementActive },
      real_name: realName,
      admin_activity: { otp_actions_today: otpActionsToday },
      online: {
        count: onlineCount,
        window_seconds: presence.WINDOW,
        sockets: presence.socketCount(),
        socket_users: presence.socketUserCount(),
        available: onlineCount !== null,
        note: onlineCount === null
          ? '在线状态表不可用（不会用账号总数冒充在线人数）'
          : '最近 ' + presence.WINDOW + ' 秒内有连接或聊天活跃的账号数'
      },
      moderation: {
        muted_now: muteStats.muted_now,
        expiring_24h: muteStats.expiring_24h,
        expiring_1h: muteStats.expiring_1h,
        expiring_remind_minutes: MUTE_EXPIRE_MINUTES,
        expiring_users: expiringList,
        scope: scopeRules(),
        note: '禁言联动范围由 config/moderation.js 集中配置；到期提醒窗口 ' + MUTE_EXPIRE_MINUTES + ' 分钟'
      },
      approvals: {
        pending: pendingApprovals,
        enabled: MODERATION.DUAL_APPROVAL.ENABLED && approvals.available(),
        actions: approvals.actionLabels(),
        note: '高风险动作（封禁 / 管理员权限 / 解除禁言）需另一名管理员复核后生效；' +
          '系统仅剩一名活跃管理员时按配置降级为单人执行'
      },
      unsupported: [
        { key: 'support_unread', label: '未读客服消息', note: '客服频道没有管理员已读游标，无法计算未读数；请参考会话数' }
      ]
    });
  } catch (err) {
    console.error('后台统计失败:', err.message);
    return fail(res, '后台统计加载失败，请稍后重试', 500);
  }
});
// ============================================
// GET /api/admin/users?q=&limit=&offset=
// 只读查询；不提供修改、删除或查看密码能力
// ============================================
router.get('/admin/users', async (req, res) => {
  try {
    const q = String(req.query.q || '').trim().slice(0, 64);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);

    const where = [];
    const params = [];
    if (q) {
      // 去掉 LIKE 通配符；清洗后为空则不使用模糊匹配，避免全表扫描或通配滥用
      const term = q.replace(/[%_\\]/g, '');
      where.push('u.invite_code = ?');
      params.push(q);
      if (term) {
        const like = '%' + term + '%';
        where.push('(u.username LIKE ? OR u.nickname LIKE ? OR u.phone LIKE ? OR u.email LIKE ? OR u.real_name LIKE ?)');
        params.push(like, like, like, like, like);
      }
    }
    let clause = where.length ? 'WHERE ' + where.join(' OR ') : '';
    // 禁言筛选（与关键字条件是 AND 关系，避免与搜索条件 OR 混淆）
    const mute = text(req.query.mute, 10);
    if (mute === 'active') {
      clause += (clause ? ' AND' : 'WHERE') + ' (u.muted_until IS NOT NULL AND u.muted_until > NOW())';
    } else if (mute === 'expiring') {
      clause += (clause ? ' AND' : 'WHERE') +
        ' (u.muted_until > NOW() AND u.muted_until <= DATE_ADD(NOW(), INTERVAL ' + MUTE_EXPIRE_MINUTES + ' MINUTE))';
    } else if (mute === 'expired') {
      clause += (clause ? ' AND' : 'WHERE') + ' (u.muted_until IS NOT NULL AND u.muted_until <= NOW())';
    }

    const [rows] = await db.promise().query(
      `SELECT u.id, u.username, u.nickname, u.avatar_url, u.role, u.status, u.created_at,
              u.invite_code, u.invited_by, u.phone, u.email, u.real_name,
              u.muted_until, u.mute_reason, (u.muted_until IS NOT NULL AND u.muted_until > NOW()) AS is_muted,
              TIMESTAMPDIFF(MINUTE, NOW(), u.muted_until) AS mute_minutes_left,
              inviter.username AS invited_by_username,
              (SELECT MAX(l.created_at) FROM login_logs l
                WHERE l.user_id = u.id AND l.status = 'success') AS last_login_at,
              (SELECT COUNT(*) FROM referral_relations r
                WHERE r.referrer_id = u.id AND r.level = 1 AND r.status = 'active') AS direct_count,
              (SELECT COUNT(*) FROM referral_relations r
                WHERE r.referrer_id = u.id AND r.level = 2 AND r.status = 'active') AS second_count
       FROM users u
       LEFT JOIN users inviter ON inviter.id = u.invited_by
       ${clause}
       ORDER BY u.id DESC LIMIT ? OFFSET ?`,
      params.concat([limit, offset])
    );

    const [totalRows] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM users u ${clause}`, params
    );

    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        username: r.username,
        nickname: r.nickname || null,
        avatar_url: r.avatar_url || null,
        role: r.role,
        status: r.status,
        created_at: r.created_at,
        last_login_at: r.last_login_at || null,
        invite_code: r.invite_code || null,
        invited_by: r.invited_by ? { id: Number(r.invited_by), username: r.invited_by_username || null } : null,
        direct_count: Number(r.direct_count) || 0,
        second_count: Number(r.second_count) || 0,
        phone: r.phone || null,
        phone_masked: r.phone ? maskPhone(r.phone) : null,
        email: r.email || null,
        real_name: r.real_name || null,
        muted: !!Number(r.is_muted),
        muted_until: r.muted_until || null,
        mute_reason: r.mute_reason || null,
        // 禁言到期提醒：分钟数 + 是否进入提醒窗口（供后台直接显示「即将解禁」）
        mute_minutes_left: Number(r.is_muted) && r.mute_minutes_left !== null
          ? Math.max(0, Number(r.mute_minutes_left)) : null,
        mute_expiring: !!Number(r.is_muted) && r.mute_minutes_left !== null &&
          Number(r.mute_minutes_left) <= MUTE_EXPIRE_MINUTES
      })),
      total: Number(totalRows[0].c) || 0,
      limit: limit,
      offset: offset,
      q: q,
      mute_filter: mute || null,
      mute_expiring_minutes: MUTE_EXPIRE_MINUTES,
      mute_scope: scopeRules(),
      note: '后台查询：不显示密码、密码哈希、OTP 或登录凭证；角色 / 禁言 / 封禁变更全部写审计，' +
        '高风险动作（封禁 / 管理员权限 / 解除禁言）需另一名管理员复核后生效'
    });
  } catch (err) {
    console.error('后台用户查询失败:', err.message);
    return fail(res, '用户查询失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/admin/audit-logs?limit=&offset=&action=
// 管理员操作审计（不含密码 / OTP / 凭证）
// ============================================
router.get('/admin/audit-logs', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 30, 1), 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const action = text(req.query.action, 50);
    const list = await listAdminLogs(limit, offset, action);
    return ok(res, { list: list, limit: limit, offset: offset, action: action || null });
  } catch (err) {
    console.error('读取审计日志失败:', err.message);
    return fail(res, '审计日志加载失败，请稍后重试', 500);
  }
});

// ============================================
// POST /api/admin/users/:id/status
// body: { status: 'active' | 'banned', reason }
// 说明:
//   - 只切换启用/禁用；绝不删除账号、绝不改动密码与余额
//   - 必须填写原因，操作与审计写入同一事务
//   - 被禁用账号的既有 JWT 会在下次请求时立即失效（认证中间件按数据库状态判定）
// ============================================
router.post('/admin/users/:id/status', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  const status = text(req.body.status, 10);
  const reason = text(req.body.reason, 200);
  if (status !== 'active' && status !== 'banned') return fail(res, '状态只能是 active 或 banned', 422, 'INVALID_STATUS');
  if (reason.length < 2) return fail(res, '请填写操作原因（至少 2 个字）', 422, 'REASON_REQUIRED');
  if (id === Number(req.user.id)) return fail(res, '不能修改自己的账号状态', 403, 'SELF_CHANGE_FORBIDDEN');

  try {
    // 双人复核：需要第二个管理员确认的动作先落请求，通过后才执行（不立即生效）
    const gate = await approvals.gate('user_status', req.user.id);
    if (gate.dual) {
      // 预校验：必然失败的动作（改自己 / 封管理员 / 状态未变等）直接返回 4xx，不占用复核队列
      const pre = await approvals.preflight('user_status', {
        adminId: req.user.id, targetUserId: id, payload: { status: status }
      });
      if (!pre.ok) return fail(res, pre.message, pre.status, pre.code);
      const created = await approvals.createRequest({
        action: 'user_status', adminId: req.user.id, targetUserId: id,
        payload: { status: status, reason: reason }, reason: reason
      });
      if (!created.ok) return fail(res, created.message, created.status, created.code);
      return res.status(202).json({
        success: true,
        data: {
          pending_approval: true,
          approval: created.request,
          note: '该动作需要另一名管理员复核后才生效（当前活跃管理员 ' + (gate.other_admins + 1) + ' 人）'
        }
      });
    }
    const result = await userOps.applyUserStatus({
      adminId: req.user.id, userId: id, status: status, reason: reason
    });
    if (!result.ok) return fail(res, result.message, result.status, result.code);
    const data = result.data;
    if (gate.degraded && gate.note) data.approval_note = gate.note;
    return ok(res, data);
  } catch (err) {
    console.error('修改用户状态失败:', err.message);
    return fail(res, '修改用户状态失败，请稍后重试', 500);
  }
});

// ============================================
// 账号治理：授予/取消管理员权限 + 禁言/解除禁言（阶段 8.12）
//   - POST /api/admin/users/:id/role    body { role: 'admin' | 'user', reason }
//   - POST /api/admin/users/:id/mute    body { minutes, reason }
//   - POST /api/admin/users/:id/unmute  body { reason }
// 规则（全部由后端强制，前端只是入口）:
//   - 只有当前数据库角色 admin 能调用（路由级守卫 + 全局边界双重校验）
//   - 不能操作自己；不能取消系统中最后一个活跃管理员
//   - 管理员账号不能被禁言 / 被封禁，必须先取消管理员权限
//   - 变更与审计写入同一事务；不删除账号、不改动密码与余额
//   - 禁言联动范围由 config/moderation.js 的 MUTE.SCOPE 集中配置：
//     默认禁言期内无法发消息、发红包、建房/进房、竞标下注、提交提款；
//     充值（资金流入）不在禁言范围内（配置可改）
//   - 禁止操作自己 / 不能取消最后一个活跃管理员 / 管理员不可被禁言封禁
//   - 封禁 / 管理员权限 / 解除禁言属于高风险动作，需另一名管理员双人复核后生效
//   - 具体执行统一在 utils/userAdminOps.js，单人执行与复核执行行为完全一致
// ============================================
const MUTE_MIN_MINUTES = MODERATION.MUTE.MIN_MINUTES;
const MUTE_MAX_MINUTES = MODERATION.MUTE.MAX_MINUTES;
const MUTE_EXPIRE_MINUTES = MODERATION.MUTE.EXPIRE_REMIND_MINUTES; // 「即将解禁」提醒窗口（24 小时）

router.post('/admin/users/:id/role', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  const role = text(req.body.role, 10);
  const reason = text(req.body.reason, 200);
  if (role !== 'admin' && role !== 'user') return fail(res, '角色只能是 admin 或 user', 422, 'INVALID_ROLE');
  if (reason.length < 2) return fail(res, '请填写操作原因（至少 2 个字）', 422, 'REASON_REQUIRED');
  if (id === Number(req.user.id)) return fail(res, '不能修改自己的角色', 403, 'SELF_CHANGE_FORBIDDEN');

  try {
    // 双人复核：管理员权限变更必须由另一名管理员确认后才生效
    const gate = await approvals.gate('user_role', req.user.id);
    if (gate.dual) {
      const pre = await approvals.preflight('user_role', {
        adminId: req.user.id, targetUserId: id, payload: { role: role }
      });
      if (!pre.ok) return fail(res, pre.message, pre.status, pre.code);
      const created = await approvals.createRequest({
        action: 'user_role', adminId: req.user.id, targetUserId: id,
        payload: { role: role, reason: reason }, reason: reason
      });
      if (!created.ok) return fail(res, created.message, created.status, created.code);
      return res.status(202).json({
        success: true,
        data: {
          pending_approval: true,
          approval: created.request,
          note: '该动作需要另一名管理员复核后才生效（当前活跃管理员 ' + (gate.other_admins + 1) + ' 人）'
        }
      });
    }
    const result = await userOps.applyUserRole({
      adminId: req.user.id, userId: id, role: role, reason: reason
    });
    if (!result.ok) return fail(res, result.message, result.status, result.code);
    const data = result.data;
    if (gate.degraded && gate.note) data.approval_note = gate.note;
    return ok(res, data);
  } catch (err) {
    console.error('修改用户角色失败:', err.message);
    return fail(res, '修改用户角色失败，请稍后重试', 500);
  }
});

router.post('/admin/users/:id/mute', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  const minutes = Number(req.body.minutes);
  const reason = text(req.body.reason, 200);
  if (!Number.isSafeInteger(minutes) || minutes < MUTE_MIN_MINUTES || minutes > MUTE_MAX_MINUTES) {
    return fail(res, '禁言时长需在 5 分钟到 30 天之间', 422, 'INVALID_MUTE_MINUTES');
  }
  if (reason.length < 2) return fail(res, '请填写禁言原因（至少 2 个字）', 422, 'REASON_REQUIRED');
  if (id === Number(req.user.id)) return fail(res, '不能禁言自己', 403, 'SELF_CHANGE_FORBIDDEN');

  try {
    // 禁言为可逆的轻度治理，直接执行（范围见 config/moderation.js → MUTE.SCOPE）
    const result = await userOps.applyMute({
      adminId: req.user.id, userId: id, minutes: minutes, reason: reason
    });
    if (!result.ok) return fail(res, result.message, result.status, result.code);
    const data = result.data;
    data.scope = scopeRules();
    data.scope_note = '禁言期内无法：' + scopeRules().filter(s => s.blocked).map(s => s.label).join('、');
    return ok(res, data);
  } catch (err) {
    console.error('禁言失败:', err.message);
    return fail(res, '禁言失败，请稍后重试', 500);
  }
});

router.post('/admin/users/:id/unmute', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  const reason = text(req.body.reason, 200) || '管理员解除禁言';

  try {
    // 双人复核：解除禁言属于放宽处罚，同样需要另一名管理员确认
    const gate = await approvals.gate('user_unmute', req.user.id);
    if (gate.dual) {
      const pre = await approvals.preflight('user_unmute', {
        adminId: req.user.id, targetUserId: id, payload: {}
      });
      if (!pre.ok) return fail(res, pre.message, pre.status, pre.code);
      const created = await approvals.createRequest({
        action: 'user_unmute', adminId: req.user.id, targetUserId: id,
        payload: { reason: reason }, reason: reason
      });
      if (!created.ok) return fail(res, created.message, created.status, created.code);
      return res.status(202).json({
        success: true,
        data: {
          pending_approval: true,
          approval: created.request,
          note: '该动作需要另一名管理员复核后才生效（当前活跃管理员 ' + (gate.other_admins + 1) + ' 人）'
        }
      });
    }
    const result = await userOps.applyUnmute({
      adminId: req.user.id, userId: id, reason: reason
    });
    if (!result.ok) return fail(res, result.message, result.status, result.code);
    const data = result.data;
    if (gate.degraded && gate.note) data.approval_note = gate.note;
    return ok(res, data);
  } catch (err) {
    console.error('解除禁言失败:', err.message);
    return fail(res, '解除禁言失败，请稍后重试', 500);
  }
});

// ============================================
// 公告管理（阶段 8.9）
//   - GET   /api/admin/announcements        全部公告（含已下线）
//   - POST  /api/admin/announcements        创建公告
//   - PATCH /api/admin/announcements/:id    编辑 / 发布 / 下线
// 说明:
//   - 只操作 announcements 表，不删除数据；下线 = status hidden
//   - 大厅读取仍走 utils/content.js 有效性过滤，下线后立即不再展示
// ============================================
const ANNOUNCEMENT_TYPES = ['text', 'image', 'activity', 'system'];

router.get('/admin/announcements', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 30, 1), 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const status = text(req.query.status, 10);
    const where = (status === 'active' || status === 'hidden') ? 'WHERE status = ?' : '';
    const params = where ? [status] : [];
    const [rows] = await db.promise().query(
      `SELECT id, type, title, summary, content, image, status, pinned, sort,
              start_at, end_at, created_by, created_at, updated_at
       FROM announcements ${where} ORDER BY id DESC LIMIT ? OFFSET ?`,
      params.concat([limit, offset])
    );
    const [totalRows] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM announcements ${where}`, params
    );
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        type: r.type,
        title: r.title,
        summary: r.summary || '',
        content: r.content || '',
        image: r.image || null,
        status: r.status,
        pinned: !!r.pinned,
        sort: Number(r.sort) || 0,
        start_at: r.start_at || null,
        end_at: r.end_at || null,
        created_by: r.created_by ? Number(r.created_by) : null,
        created_at: r.created_at,
        updated_at: r.updated_at
      })),
      total: Number(totalRows[0].c) || 0,
      limit: limit,
      offset: offset
    });
  } catch (err) {
    console.error('读取公告失败:', err.message);
    return fail(res, '公告加载失败，请稍后重试', 500);
  }
});

/** 校验公告输入；返回 { error } 或 { value } */
function validateAnnouncement(body, partial) {
  const value = {};
  const title = text(body.title, 120);
  const content = text(body.content, 5000);
  const summary = text(body.summary, 255);
  const image = text(body.image, 255);
  const type = text(body.type, 12) || 'text';
  if (!partial || body.title !== undefined) {
    if (title.length < 2) return { error: '标题至少 2 个字' };
    value.title = title;
  }
  if (!partial || body.content !== undefined) value.content = content;
  if (!partial || body.summary !== undefined) value.summary = summary;
  if (!partial || body.type !== undefined) {
    if (ANNOUNCEMENT_TYPES.indexOf(type) === -1) return { error: '公告类型不正确' };
    value.type = type;
  }
  if (body.image !== undefined) {
    if (image && !image.startsWith('/assets/')) return { error: '图片地址必须是站内 /assets/ 路径' };
    value.image = image || null;
  }
  if (body.status !== undefined) {
    const status = text(body.status, 10);
    if (status !== 'active' && status !== 'hidden') return { error: '状态只能是 active 或 hidden' };
    value.status = status;
  }
  if (body.pinned !== undefined) value.pinned = body.pinned ? 1 : 0;
  if (body.sort !== undefined) {
    const sort = Number(body.sort);
    if (!Number.isInteger(sort) || Math.abs(sort) > 100000) return { error: '排序值不正确' };
    value.sort = sort;
  }
  for (const key of ['start_at', 'end_at']) {
    if (body[key] !== undefined) {
      const parsed = validDateTime(body[key]);
      if (parsed === 'INVALID') return { error: '时间格式应为 YYYY-MM-DD HH:MM' };
      value[key] = parsed;
    }
  }
  return { value: value };
}

router.post('/admin/announcements', async (req, res) => {
  const checked = validateAnnouncement(req.body, false);
  if (checked.error) return fail(res, checked.error, 422, 'INVALID_ANNOUNCEMENT');
  const v = checked.value;
  try {
    const [result] = await db.promise().query(
      `INSERT INTO announcements (type, title, summary, content, image, status, pinned, sort, start_at, end_at, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [v.type, v.title, v.summary || null, v.content || null, v.image || null,
       v.status || 'active', v.pinned || 0, v.sort || 0, v.start_at || null, v.end_at || null, req.user.id]
    );
    await writeAdminLog({
      adminId: req.user.id, targetUserId: null, action: 'announcement_create',
      detail: 'id=' + result.insertId + ' title=' + v.title + ' status=' + (v.status || 'active')
    });
    return ok(res, { id: Number(result.insertId), title: v.title, status: v.status || 'active' });
  } catch (err) {
    console.error('创建公告失败:', err.message);
    return fail(res, '公告创建失败，请稍后重试', 500);
  }
});

router.patch('/admin/announcements/:id', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的公告ID', 422, 'INVALID_ANNOUNCEMENT_ID');
  const checked = validateAnnouncement(req.body, true);
  if (checked.error) return fail(res, checked.error, 422, 'INVALID_ANNOUNCEMENT');
  const v = checked.value;
  const fields = Object.keys(v);
  if (!fields.length) return fail(res, '没有需要更新的字段', 422, 'NOTHING_TO_UPDATE');
  try {
    const [rows] = await db.promise().query(
      'SELECT id, title, status FROM announcements WHERE id = ?', [id]
    );
    if (!rows[0]) return fail(res, '公告不存在', 404, 'ANNOUNCEMENT_NOT_FOUND');
    await db.promise().query(
      'UPDATE announcements SET ' + fields.map(f => f + ' = ?').join(', ') + ' WHERE id = ?',
      fields.map(f => v[f]).concat([id])
    );
    await writeAdminLog({
      adminId: req.user.id, targetUserId: null, action: 'announcement_update',
      detail: 'id=' + id + ' fields=' + fields.join(',') +
        (v.status ? ' status=' + v.status : '') + ' previous_status=' + rows[0].status
    });
    return ok(res, { id: id, updated: fields, status: v.status || rows[0].status });
  } catch (err) {
    console.error('更新公告失败:', err.message);
    return fail(res, '公告更新失败，请稍后重试', 500);
  }
});

// ============================================
// 实名认证审核（阶段 8.5）
//   - GET  /api/admin/real-name-reviews?status=
//   - POST /api/admin/real-name-reviews/:id/review  { decision, remark }
// 业务规则（后端强制）:
//   - 一个账号只能绑定一个收款人姓名（real_name_reviews 表 user_id 唯一）
//   - 同一个已通过的实名姓名不能再次绑定新账号（审核通过时同事务校验）
// 说明:
//   - 不改动 users.real_name（注册资料），实名绑定单独存于 real_name_reviews
// ============================================
router.get('/admin/real-name-reviews', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 30, 1), 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const status = text(req.query.status, 10);
    const allowed = ['pending', 'approved', 'rejected'];
    const where = allowed.indexOf(status) > -1 ? 'WHERE r.status = ?' : '';
    const params = where ? [status] : [];
    const [rows] = await db.promise().query(
      `SELECT r.id, r.user_id, r.real_name, r.status, r.remark, r.reviewed_by, r.reviewed_at, r.created_at,
              u.username, u.nickname, reviewer.username AS reviewer_username
       FROM real_name_reviews r
       LEFT JOIN users u ON u.id = r.user_id
       LEFT JOIN users reviewer ON reviewer.id = r.reviewed_by
       ${where} ORDER BY r.id DESC LIMIT ? OFFSET ?`,
      params.concat([limit, offset])
    );
    const [counts] = await db.promise().query(
      `SELECT status, COUNT(*) AS c FROM real_name_reviews GROUP BY status`
    );
    const summary = { pending: 0, approved: 0, rejected: 0, total: 0 };
    counts.forEach(c => {
      const key = c.status;
      if (key in summary) summary[key] = Number(c.c) || 0;
      summary.total += Number(c.c) || 0;
    });
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        user_id: Number(r.user_id),
        username: r.username || null,
        nickname: r.nickname || null,
        real_name: r.real_name,
        status: r.status,
        remark: r.remark || null,
        reviewed_by: r.reviewed_by ? { id: Number(r.reviewed_by), username: r.reviewer_username || null } : null,
        reviewed_at: r.reviewed_at || null,
        created_at: r.created_at
      })),
      summary: summary,
      limit: limit,
      offset: offset
    });
  } catch (err) {
    console.error('读取实名审核失败:', err.message);
    return fail(res, '实名审核列表加载失败，请稍后重试', 500);
  }
});

router.post('/admin/real-name-reviews/:id/review', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的审核ID', 422, 'INVALID_REVIEW_ID');
  const decision = text(req.body.decision, 10);
  const remark = text(req.body.remark, 255);
  if (decision !== 'approved' && decision !== 'rejected') {
    return fail(res, '审核结论只能是 approved 或 rejected', 422, 'INVALID_DECISION');
  }
  if (decision === 'rejected' && remark.length < 2) return fail(res, '拒绝时必须填写原因', 422, 'REMARK_REQUIRED');

  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, user_id, real_name, status FROM real_name_reviews WHERE id = ? FOR UPDATE', [id]
    );
    const review = rows[0];
    if (!review) { await conn.rollback(); return fail(res, '审核记录不存在', 404, 'REVIEW_NOT_FOUND'); }
    if (review.status !== 'pending') { await conn.rollback(); return fail(res, '该记录已审核完成', 409, 'REVIEW_DONE'); }

    if (decision === 'approved') {
      // 同一个实名姓名不能绑定第二个账号
      const [taken] = await conn.query(
        `SELECT id, user_id FROM real_name_reviews
         WHERE real_name = ? AND status = 'approved' AND id <> ? FOR UPDATE`,
        [review.real_name, id]
      );
      if (taken.length) {
        await conn.rollback();
        return fail(res, '该实名姓名已绑定其他账号，不能重复通过', 409, 'REAL_NAME_TAKEN');
      }
    }
    await conn.query(
      `UPDATE real_name_reviews
       SET status = ?, remark = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?`,
      [decision, remark || null, req.user.id, id]
    );
    await writeAdminLog({
      adminId: req.user.id, targetUserId: review.user_id, action: 'real_name_review',
      detail: 'review=' + id + ' decision=' + decision + ' name=' + review.real_name +
        (remark ? '; remark=' + remark : ''), conn: conn
    });
    await conn.commit();
    return ok(res, { id: id, status: decision, user_id: Number(review.user_id) });
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('实名审核失败:', err.message);
    return fail(res, '实名审核失败，请稍后重试', 500);
  } finally {
    if (conn) conn.release();
  }
});

// ============================================
// 资金管理（阶段 12/13）
//   - GET  /api/admin/wallet/orders?status=&type=
//   - POST /api/admin/wallet/orders/:id/review { decision: approved|rejected, note, reject_reason }
// 审核通过：
//   - 充值 → 事务内给用户 cash_chips 加金额 + 写 balance_transactions(related_request_id)
//   - 提现 → 事务内校验余额充足后扣除 + 写流水
// 状态机保护：只有 PENDING 可审核；FOR UPDATE 锁行，防并发/重复审核。
// 绝不接真实支付渠道；金额仅用于充值订单的记录字段。
// ============================================
router.get('/admin/wallet/orders', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 30, 1), 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const status = text(req.query.status, 12).toUpperCase();
    const type = text(req.query.type, 10).toUpperCase();
    const where = [];
    const params = [];
    if (['PENDING', 'PROCESSING', 'COMPLETED', 'REJECTED', 'CANCELLED'].includes(status)) { where.push('o.status = ?'); params.push(status); }
    if (['DEPOSIT', 'WITHDRAW'].includes(type)) { where.push('o.order_type = ?'); params.push(type); }
    const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const [rows] = await db.promise().query(
      `SELECT o.*, u.username, u.nickname, reviewer.username AS reviewer_username
       FROM wallet_orders o
       LEFT JOIN users u ON u.id = o.user_id
       LEFT JOIN users reviewer ON reviewer.id = o.reviewed_by
       ${clause} ORDER BY o.id DESC LIMIT ? OFFSET ?`,
      params.concat([limit, offset])
    );
    const [counts] = await db.promise().query(
      `SELECT order_type, status, COUNT(*) AS c FROM wallet_orders GROUP BY order_type, status`
    );
    const summary = { deposit: { PENDING: 0, COMPLETED: 0, REJECTED: 0 }, withdraw: { PENDING: 0, COMPLETED: 0, REJECTED: 0 }, total: 0 };
    counts.forEach(c => {
      const k = c.order_type === 'WITHDRAW' ? 'withdraw' : 'deposit';
      const s = String(c.status);
      if (summary[k] && s in summary[k]) summary[k][s] = Number(c.c) || 0;
      summary.total += Number(c.c) || 0;
    });
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        order_no: r.order_no,
        user: { id: Number(r.user_id), username: r.username || null, nickname: r.nickname || null },
        order_type: r.order_type,
        currency_type: r.currency_type,
        amount: Number(r.amount),
        method: r.method,
        account: r.account || null,
        status: r.status,
        remark: r.remark || null,
        reviewer: r.reviewed_by ? { id: Number(r.reviewed_by), username: r.reviewer_username || null } : null,
        reviewed_at: r.reviewed_at || null,
        reject_reason: r.reject_reason || null,
        admin_note: r.admin_note || null,
        created_at: r.created_at
      })),
      summary: summary,
      limit: limit, offset: offset
    });
  } catch (err) {
    console.error('读取资金订单失败:', err.message);
    return fail(res, '资金订单加载失败，请稍后重试', 500);
  }
});

router.post('/admin/wallet/orders/:id/review', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  const decision = text(req.body.decision, 10);
  const note = text(req.body.note, 255);
  const rejectReason = text(req.body.reject_reason, 255);
  if (decision !== 'approved' && decision !== 'rejected') {
    return fail(res, '审核结论只能是 approved 或 rejected', 422, 'INVALID_DECISION');
  }
  if (decision === 'rejected' && !rejectReason) return fail(res, '拒绝时必须填写原因', 422, 'REJECT_REASON_REQUIRED');

  // 统一走 utils/funds 的事务 + 幂等逻辑（与 /api/admin/deposits|withdrawals/:id/review 完全一致）
  const FUND = require('../utils/funds');
  const [rows] = await db.promise().query(
    'SELECT order_type FROM wallet_orders WHERE id = ? LIMIT 1', [id]
  );
  if (!rows[0]) return fail(res, '订单不存在', 404, 'ORDER_NOT_FOUND');
  const isWithdraw = rows[0].order_type === 'WITHDRAW';
  const result = isWithdraw
    ? await FUND.reviewWithdrawal(id, req.user.id, decision === 'approved' ? 'approve' : 'reject',
      { note: note, reason: rejectReason })
    : await FUND.reviewDeposit(id, req.user.id, decision === 'approved' ? 'approve' : 'reject',
      { note: note, reason: rejectReason });
  if (!result.ok) return fail(res, result.message, result.status || 400, result.code);
  return ok(res, {
    id: id,
    // 兼容旧调用：通过统一返回 COMPLETED，实际数据库状态为 APPROVED（同一事务已提交）
    status: result.approved ? 'COMPLETED' : 'REJECTED',
    internal_status: result.status,
    order_type: isWithdraw ? 'WITHDRAW' : 'DEPOSIT',
    order_no: result.order_no || null,
    balance_before: result.before_balance === undefined ? null : result.before_balance,
    balance_after: result.after_balance === undefined ? null : result.after_balance,
    rewards: result.rewards || []
  });
});

// GET /api/admin/wallet/transactions - 余额流水（全部用户，含关联订单/操作员）
router.get('/admin/wallet/transactions', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 200);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const userId = isPositiveInt(req.query.user_id);
    const where = userId ? 'WHERE t.user_id = ?' : '';
    const params = userId ? [userId] : [];
    const [rows] = await db.promise().query(
      `SELECT t.id, t.user_id, u.username, u.nickname, t.currency_type, t.amount,
              t.balance_before, t.balance_after, t.type, t.reason,
              t.related_request_id, t.operator_id, op.username AS operator_username, t.created_at
       FROM balance_transactions t
       LEFT JOIN users u ON u.id = t.user_id
       LEFT JOIN users op ON op.id = t.operator_id
       ${where} ORDER BY t.id DESC LIMIT ? OFFSET ?`,
      params.concat([limit, offset])
    );
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        user: { id: Number(r.user_id), username: r.username || null, nickname: r.nickname || null },
        currency_type: r.currency_type,
        amount: Number(r.amount),
        balance_before: Number(r.balance_before),
        balance_after: Number(r.balance_after),
        type: r.type,
        reason: r.reason || null,
        related_request_id: r.related_request_id ? Number(r.related_request_id) : null,
        operator: r.operator_id ? { id: Number(r.operator_id), username: r.operator_username || null } : null,
        created_at: r.created_at
      })),
      limit: limit, offset: offset
    });
  } catch (err) {
    console.error('读取余额流水失败:', err.message);
    return fail(res, '余额流水加载失败，请稍后重试', 500);
  }
});

// POST /api/admin/users/:id/adjust - 管理员余额调整（正=增加，负=减少）
// 必须填原因；事务内完成：余额更新 + 流水(ADJUST) + 审计；不允许调到自己；不允许负余额。
router.post('/admin/users/:id/adjust', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  if (id === req.user.id) return fail(res, '不能调整自己的余额', 422, 'SELF_ADJUST_DENIED');
  const currencyType = text(req.body.currency_type, 12).toUpperCase();
  const reason = text(req.body.reason, 255);
  const raw = Number(req.body.amount);
  if (currencyType !== 'GAME_BALANCE' && currencyType !== 'CASH_CHIPS') {
    return fail(res, '货币类型必须是 GAME_BALANCE 或 CASH_CHIPS', 422, 'INVALID_CURRENCY');
  }
  if (!reason || reason.length < 2) return fail(res, '必须填写调整原因（至少 2 个字符）', 422, 'REASON_REQUIRED');
  if (!Number.isFinite(raw) || raw === 0) return fail(res, '调整金额不能为 0', 422, 'INVALID_AMOUNT');
  const amountCents = Math.round(raw * 100);
  if (!Number.isSafeInteger(amountCents) || Math.abs(amountCents) > 5000000) {
    return fail(res, '单次调整不能超过 RM50,000', 422, 'AMOUNT_TOO_LARGE');
  }
  const field = currencyType === 'GAME_BALANCE' ? 'game_balance' : 'cash_chips';
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(`SELECT ${field} FROM users WHERE id = ? FOR UPDATE`, [id]);
    const user = rows[0];
    if (!user) { await conn.rollback(); return fail(res, '用户不存在', 404, 'USER_NOT_FOUND'); }
    const beforeCents = Math.round(Number(user[field]) * 100);
    const afterCents = beforeCents + amountCents;
    if (afterCents < 0) { await conn.rollback(); return fail(res, '调整后余额不能为负数', 422, 'NEGATIVE_BALANCE'); }
    const before = (beforeCents / 100).toFixed(2);
    const after = (afterCents / 100).toFixed(2);
    const amount = (amountCents / 100).toFixed(2);
    await conn.query(`UPDATE users SET ${field} = ? WHERE id = ?`, [after, id]);
    await conn.query(
      `INSERT INTO balance_transactions
       (user_id, currency_type, amount, balance_before, balance_after, type, reason, operator_id)
       VALUES (?, ?, ?, ?, ?, 'ADJUST', ?, ?)`,
      [id, currencyType, raw < 0 ? amount : amount, before, after, reason, req.user.id]
    );
    await writeAdminLog({
      adminId: req.user.id, targetUserId: id, action: 'balance_adjust', conn: conn,
      detail: 'currency=' + currencyType + ' amount=' + amount + ' balance_before=' + before +
        ' balance_after=' + after + ' reason=' + reason
    });
    await conn.commit();
    return ok(res, { user_id: id, currency_type: currencyType, amount: Number(amount), balance_before: Number(before), balance_after: Number(after) });
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('余额调整失败:', err.message);
    return fail(res, '余额调整失败，请稍后重试', 500);
  } finally {
    if (conn) conn.release();
  }
});

// ============================================
// 治理可观测：在线用户 / 禁言到期提醒 / 双人复核队列
//   - GET  /api/admin/online          当前在线用户（真实心跳，最多 100 条）
//   - GET  /api/admin/mute-expiring   即将解禁（到期提醒）名单
//   - GET  /api/admin/approvals       复核队列（PENDING / APPROVED / REJECTED）
//   - POST /api/admin/approvals/:id/decide  { decision: 'approve'|'reject', note }
// 权限：沿用本文件顶部的 /admin 路由守卫（auth + requireRole('admin') + 全局边界）
// ============================================
router.get('/admin/online', async (req, res) => {
  try {
    const list = await presence.onlineList(Number(req.query.limit) || 100);
    return ok(res, {
      supported: list !== null,
      window_seconds: presence.WINDOW,
      sockets: presence.socketCount(),
      socket_users: presence.socketUserCount(),
      count: list === null ? null : list.length,
      list: list || [],
      note: list === null
        ? '在线状态表不可用，无法统计在线人数（不会用账号总数冒充）'
        : '在线 = 最近 ' + presence.WINDOW + ' 秒内有 Socket 连接或聊天活跃'
    });
  } catch (err) {
    console.error('读取在线用户失败:', err.message);
    return fail(res, '在线用户加载失败，请稍后重试', 500);
  }
});

router.get('/admin/mute-expiring', async (req, res) => {
  try {
    const list = await expiringMutes(Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100));
    return ok(res, {
      list: list,
      remind_minutes: MUTE_EXPIRE_MINUTES,
      scope: scopeRules(),
      note: '到期提醒窗口 ' + MUTE_EXPIRE_MINUTES + ' 分钟（' + Math.round(MUTE_EXPIRE_MINUTES / 60) +
        ' 小时）；到期后禁言自动失效，无需人工解禁；如认为处罚不足可在到期前重新禁言'
    });
  } catch (err) {
    console.error('读取禁言到期提醒失败:', err.message);
    return fail(res, '禁言到期提醒加载失败，请稍后重试', 500);
  }
});

router.get('/admin/approvals', async (req, res) => {
  try {
    const data = await approvals.listRequests({
      status: text(req.query.status, 12),
      limit: req.query.limit,
      offset: req.query.offset,
      viewerId: req.user.id
    });
    return ok(res, data);
  } catch (err) {
    console.error('读取复核队列失败:', err.message);
    return fail(res, '复核队列加载失败，请稍后重试', 500);
  }
});

router.post('/admin/approvals/:id/decide', async (req, res) => {
  const id = isPositiveInt(req.params.id);
  if (!id) return fail(res, '无效的复核请求ID', 422, 'INVALID_APPROVAL_ID');
  const decision = text(req.body.decision, 10);
  if (decision !== 'approve' && decision !== 'reject') {
    return fail(res, '决议只能是 approve 或 reject', 422, 'INVALID_DECISION');
  }
  const note = text(req.body.note, 200);
  try {
    const result = await approvals.decide({
      id: id, adminId: req.user.id, decision: decision, note: note
    });
    if (!result.ok) {
      return res.status(result.status || 409).json({
        success: false, code: result.code, message: result.message,
        reverted: !!result.reverted, approval: result.approval || null
      });
    }
    return ok(res, {
      decision: result.decision,
      result: result.result || null,
      approval: result.approval
    });
  } catch (err) {
    console.error('复核处理失败:', err.message);
    return fail(res, '复核处理失败，请稍后重试', 500);
  }
});

module.exports = router;