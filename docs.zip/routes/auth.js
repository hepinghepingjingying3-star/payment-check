// ============================================
// 26牛牛 - 认证路由（注册、登录、个人中心、公开用户、客服查询）
// 包含:
//   - POST /api/auth/register  注册（bcrypt 加密密码）
//   - POST /api/auth/login     登录（JWT）
//   - GET  /api/auth/me        个人中心（需登录）
//   - GET  /api/users/:id      公开用户资料（只返回用户名）
//   - GET  /api/users          用户列表（只返回用户名）
//   - POST /api/support/lookup 客服按用户名/手机号/邮箱定位账号（需 support/admin 角色，记录日志）
// ============================================

// 引入 Express 路由
const express = require('express');
const router = express.Router();

// 引入 bcryptjs（密码哈希）
const bcrypt = require('bcryptjs');

// 引入 jsonwebtoken（JWT）
const jwt = require('jsonwebtoken');

// 引入数据库连接
const db = require('../config/db');

// 引入邀请码工具（生成 / 规范化 / 校验格式）
const { generateUniqueInviteCode, normalizeInviteCode, isValidInviteCodeFormat } = require('../utils/inviteCode');

// 引入认证中间件
const { auth, requireRole } = require('../middleware/auth');

// 引入请求工具（IP / 手机号标准化 / 统一响应）
const { clientIp, normalizePhone } = require('../utils/request');

// 引入 OTP 工具（校验注册凭证 otp_token；secondsLeft 判断凭证是否过期）
const { verifyRegisterToken, secondsLeft } = require('../utils/otp');

// 引入页面会话票据（仅用于「管理后台静态页面」准入；/api/** 依然只认 Bearer JWT）
const { setPageSession, clearPageSession } = require('../utils/pageSession');

// 从 .env 读取 JWT 配置
const JWT_SECRET = process.env.JWT_SECRET;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

// ============================================
// 工具函数
// ============================================

/**
 * 标准化字符串（去除首尾空格）
 * 用于用户名、邮箱、手机号、姓名等字段的统一处理
 */
function normalizeString(value) {
  return value ? value.trim() : '';
}

/**
 * 验证邮箱格式
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * 验证手机号格式（简单验证：10-15位数字，可包含 + 前缀）
 */
function isValidPhone(phone) {
  const phoneRegex = /^\+?[0-9]{10,15}$/;
  return phoneRegex.test(phone);
}

/**
 * 安全返回用户公开资料（只返回允许公开的字段）
 * 绝不返回: phone, email, real_name, password_hash
 */
function publicUser(user) {
  return {
    id: user.id,
    username: user.username,
    role: user.role,
    status: user.status,
    created_at: user.created_at
  };
}

/**
 * 安全返回用户个人资料（仅本人可见）
 * 包含自己的绑定资料，但绝不返回 password_hash
 */
function privateUser(user) {
  return {
    id: user.id,
    username: user.username,
    nickname: user.nickname || user.username,
    avatar_url: user.avatar_url || null,
    email: user.email,
    phone: user.phone,
    real_name: user.real_name,
    role: user.role,
    status: user.status,
    invite_code: user.invite_code || null,
    created_at: user.created_at,
    updated_at: user.updated_at
  };
}

/** 记录登录日志（绝不记录密码） */
async function writeLoginLog(userId, username, req, status, reason) {
  try {
    await db.promise().query(
      `INSERT INTO login_logs (user_id, username, ip, user_agent, status, reason)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        userId || null,
        String(username || '').slice(0, 50),
        clientIp(req),
        String(req.headers['user-agent'] || '').slice(0, 255),
        status === 'success' ? 'success' : 'fail',
        reason ? String(reason).slice(0, 60) : null
      ]
    );
  } catch (e) {
    console.error('写入登录记录失败:', e.message);
  }
}

// ============================================
// GET /api/auth/invite/check?code=XXXXXX - 邀请码即时校验（无需登录）
// 只返回「是否有效」，绝不返回邀请人的任何资料
// 最终有效性以注册接口的后端校验为准
// ============================================
router.get('/auth/invite/check', async (req, res) => {
  try {
    const code = normalizeInviteCode(req.query.code);
    if (!code || !isValidInviteCodeFormat(code)) {
      return res.json({ success: true, data: { valid: false, reason: 'format' } });
    }
    const [rows] = await db.promise().query(
      'SELECT status FROM users WHERE invite_code = ? LIMIT 1',
      [code]
    );
    if (rows.length === 0) {
      return res.json({ success: true, data: { valid: false, reason: 'not_found' } });
    }
    if (rows[0].status !== 'active') {
      return res.json({ success: true, data: { valid: false, reason: 'inactive' } });
    }
    return res.json({ success: true, data: { valid: true } });
  } catch (err) {
    console.error('邀请码校验失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/auth/register - 用户注册
// ============================================
router.post('/auth/register', async (req, res) => {
  try {
    // 1. 提取并标准化输入
    const username = normalizeString(req.body.username);
    const phone = normalizePhone(req.body.phone);
    const email = normalizeString(req.body.email);
    const real_name = normalizeString(req.body.real_name);
    const password = req.body.password || '';
    const confirm_password = req.body.confirm_password || '';
    const pay_password = String(req.body.pay_password == null ? '' : req.body.pay_password);
    const confirm_pay_password = String(req.body.confirm_pay_password == null ? '' : req.body.confirm_pay_password);
    const account_info = normalizeString(req.body.account_info);
    const invite_code = normalizeInviteCode(req.body.invite_code);

    // 邀请码必填校验（注册必须通过邀请码建立邀请关系）
    if (!invite_code) {
      return res.status(400).json({ success: false, message: '邀请码不能为空' });
    }
    if (!isValidInviteCodeFormat(invite_code)) {
      return res.status(400).json({ success: false, message: '邀请码格式不正确' });
    }

    // 2. 后端参数验证
    if (!username) {
      return res.status(400).json({ success: false, message: '用户名不能为空' });
    }
    if (username.length < 3 || username.length > 50) {
      return res.status(400).json({ success: false, message: '用户名长度必须在 3-50 个字符之间' });
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return res.status(400).json({ success: false, message: '用户名只能包含字母、数字和下划线' });
    }

    if (!phone) {
      return res.status(400).json({ success: false, message: '电话号码不能为空' });
    }
    if (!isValidPhone(phone)) {
      return res.status(400).json({ success: false, message: '电话号码格式不正确' });
    }

    // 手机号 OTP 验证（新增）：必须携带 /api/otp/verify 返回的注册凭证
    // 说明: 当前不接第三方短信，验证码由管理员通过 WhatsApp 手动发送
    const otpToken = normalizeString(req.body.otp_token);
    if (!otpToken) {
      return res.status(400).json({
        success: false,
        message: '请先完成手机号验证码验证',
        code: 'OTP_REQUIRED'
      });
    }
    const verified = verifyRegisterToken(otpToken);
    if (!verified) {
      return res.status(400).json({
        success: false,
        message: '手机号验证凭证已过期，请重新获取验证码',
        code: 'OTP_TOKEN_INVALID'
      });
    }
    const verifiedPhone = verified.phone;
    const otpRowId = verified.otpId;
    if (String(verifiedPhone) !== String(phone)) {
      return res.status(400).json({
        success: false,
        message: '验证的手机号与注册手机号不一致',
        code: 'OTP_PHONE_MISMATCH'
      });
    }
    // 凭证必须对应一条「本手机号 + 已验证 + 未消费 + 未过期」的真实 OTP 行。
    // 旧版只校验 JWT 签名，导致同一枚凭证可被反复重放（注册失败后无限重试），
    // 也无法区分是哪一次验证码验证发出的凭证。
    if (!otpRowId) {
      return res.status(400).json({
        success: false,
        message: '手机号验证凭证无效，请重新获取验证码',
        code: 'OTP_TOKEN_INVALID'
      });
    }
    const [otpRows] = await db.promise().query(
      `SELECT id, status, consumed_at, expires_at
         FROM registration_otp WHERE id = ? AND phone = ? LIMIT 1`,
      [otpRowId, verifiedPhone]
    );
    if (otpRows.length === 0 || otpRows[0].status !== 'verified') {
      return res.status(400).json({
        success: false,
        message: '手机号验证凭证无效，请重新获取验证码',
        code: 'OTP_TOKEN_INVALID'
      });
    }
    if (otpRows[0].consumed_at) {
      return res.status(400).json({
        success: false,
        message: '该验证码已用于注册，请重新获取验证码',
        code: 'OTP_TOKEN_USED'
      });
    }
    if (secondsLeft(otpRows[0].expires_at) <= 0) {
      return res.status(400).json({
        success: false,
        message: '手机号验证凭证已过期，请重新获取验证码',
        code: 'OTP_TOKEN_INVALID'
      });
    }

    if (!email) {
      return res.status(400).json({ success: false, message: '邮箱不能为空' });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ success: false, message: '邮箱格式不正确' });
    }

    if (!real_name) {
      return res.status(400).json({ success: false, message: '姓名不能为空' });
    }
    if (real_name.length < 2 || real_name.length > 50) {
      return res.status(400).json({ success: false, message: '姓名长度必须在 2-50 个字符之间' });
    }

    if (!password) {
      return res.status(400).json({ success: false, message: '密码不能为空' });
    }
    if (password.length < 6) {
      return res.status(400).json({ success: false, message: '密码至少需要 6 位' });
    }
    if (password !== confirm_password) {
      return res.status(400).json({ success: false, message: '两次输入的登录密码不一致' });
    }
    if (!/^\d{6}$/.test(pay_password)) {
      return res.status(400).json({ success: false, message: '支付密码必须为6位数字' });
    }
    if (pay_password !== confirm_pay_password) {
      return res.status(400).json({ success: false, message: '两次支付密码不一致' });
    }

    // 6. 校验邀请码必须存在，且邀请人账号有效（禁止自邀在注册时天然不成立）
    const [inviterRows] = await db.promise().query(
      'SELECT id, username, status FROM users WHERE invite_code = ? LIMIT 1',
      [invite_code]
    );
    if (inviterRows.length === 0) {
      return res.status(400).json({ success: false, message: '邀请码不存在' });
    }
    const inviter = inviterRows[0];
    if (inviter.status !== 'active') {
      return res.status(400).json({ success: false, message: '邀请码对应的账号状态异常，无法使用' });
    }

    // 6. 生成新邀请码；在注册事务中安全随机生成。
    let myInviteCode = null;

    // 8. 使用 bcrypt 哈希登录密码与支付密码（各 10 轮盐值，绝不存明文）
    const passwordHash = await bcrypt.hash(password, 10);
    const payPasswordHash = await bcrypt.hash(pay_password, 10);

    // 9. 事务：创建用户 + 写入邀请关系（一级 / 二级），任何一步失败全部回滚
    const conn = await db.promise().getConnection();
    let newUserId;
    try {
      await conn.beginTransaction();

      // 锁定并消费手机号验证凭证（FOR UPDATE + consumed_at 判定）
      // 必须放在事务内：并发提交同一个 otp_token 时只有一个能拿到锁并完成注册，
      // 另一个会看到 consumed_at 已非空而失败，绝不会建出两个账号。
      const [claimRows] = await conn.query(
        'SELECT id, consumed_at FROM registration_otp WHERE id = ? FOR UPDATE',
        [otpRowId]
      );
      if (claimRows.length === 0 || claimRows[0].consumed_at) {
        throw new Error('OTP_TOKEN_USED');
      }
      const [claimRes] = await conn.query(
        'UPDATE registration_otp SET consumed_at = NOW() WHERE id = ? AND consumed_at IS NULL',
        [otpRowId]
      );
      if (!claimRes.affectedRows) throw new Error('OTP_TOKEN_USED');

      // 锁定邀请人行，防止并发期间被删除/封禁
      const [lockRows] = await conn.query(
        'SELECT id, status, invited_by FROM users WHERE id = ? FOR UPDATE',
        [inviter.id]
      );
      if (lockRows.length === 0 || lockRows[0].status !== 'active') {
        throw new Error('INVITER_INVALID');
      }
      const grandInviterId = lockRows[0].invited_by || null;

      myInviteCode = await generateUniqueInviteCode(conn.query.bind(conn));

      // 创建用户（记录自己的邀请码 + 邀请人；支付密码只存哈希）
      const [result] = await conn.query(
        `INSERT INTO users (username, email, phone, real_name, password_hash, pay_password_hash, pay_password_set_at, invite_code, invited_by)
         VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, ?)`,
        [username, email, phone, real_name, passwordHash, payPasswordHash, myInviteCode, inviter.id]
      );
      newUserId = result.insertId;

      // 一级邀请关系（邀请人 → 新用户）
      await conn.query(
        'INSERT INTO referral_relations (referrer_id, referred_user_id, level) VALUES (?, ?, 1)',
        [inviter.id, newUserId]
      );

      // 二级邀请关系（邀请人的邀请人 → 新用户）
      if (grandInviterId) {
        await conn.query(
          'INSERT IGNORE INTO referral_relations (referrer_id, referred_user_id, level) VALUES (?, ?, 2)',
          [grandInviterId, newUserId]
        );
      }

      if (account_info) {
        try {
          await conn.query(
            `INSERT INTO real_name_reviews (user_id, real_name, status, remark)
             VALUES (?, ?, 'pending', ?)`,
            [newUserId, real_name, account_info.slice(0, 120)]
          );
        } catch (e) { /* 账户资料行写入失败不阻断注册 */ }
      }

      await conn.commit();
    } catch (txErr) {
      await conn.rollback();
      if (txErr && txErr.message === 'INVITER_INVALID') {
        return res.status(400).json({ success: false, message: '邀请码无效' });
      }
      if (txErr && txErr.message === 'OTP_TOKEN_USED') {
        return res.status(400).json({
          success: false,
          message: '该验证码已用于注册，请重新获取验证码',
          code: 'OTP_TOKEN_USED'
        });
      }
      // 并发抢占同一手机号时，数据库 UNIQUE(phone) 会抛出重复键，
      // 同样转成友好提示，避免暴露 500 与数据库细节。
      if (txErr && (txErr.code === 'ER_DUP_ENTRY' || txErr.errno === 1062)) {
        return res.status(409).json({
          success: false,
          message: '该手机号已注册，请直接登录或找回密码',
          code: 'PHONE_REGISTERED'
        });
      }
      throw txErr;
    } finally {
      conn.release();
    }

    // 10. 欢迎通知（真实数据，不使用假消息）
    try {
      require('../utils/content').pushNotification(
        newUserId, 'system', '欢迎加入 26 牛牛',
        '账号创建成功。建议先阅读「玩法介绍」，熟悉规则后再进入游戏群。',
        '/tutorial.html?id=newbie-guide'
      );
    } catch (e) { /* 通知失败不影响注册 */ }

    // 11. 返回注册成功（不返回 password_hash，只返回必要信息）
    res.status(201).json({
      success: true,
      message: '账号创建成功',
      data: {
        id: newUserId,
        username: username,
        invite_code: myInviteCode
      }
    });
  } catch (err) {
    console.error('注册失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/auth/login - 用户登录
// ============================================
router.post('/auth/login', async (req, res) => {
  try {
    // 1. 提取输入
    const username = normalizeString(req.body.username);
    const password = req.body.password || '';

    // 2. 参数验证
    if (!username || !password) {
      return res.status(400).json({ success: false, message: '用户名和密码不能为空' });
    }

    // 3. 查询用户
    const [rows] = await db.promise().query(
      'SELECT id, username, email, phone, real_name, password_hash, role, status, invite_code, created_at, updated_at, token_version FROM users WHERE username = ?',
      [username]
    );

    // 4. 用户不存在（返回安全且明确的错误信息）
    if (rows.length === 0) {
      await writeLoginLog(null, username, req, 'fail', 'user_not_found');
      return res.status(401).json({ success: false, message: '用户名或密码错误' });
    }

    const user = rows[0];

    // 5. 检查账号状态
    if (user.status === 'banned') {
      await writeLoginLog(user.id, username, req, 'fail', 'banned');
      return res.status(403).json({ success: false, message: '该账号已被封禁，请联系客服' });
    }
    if (user.status === 'deleted') {
      await writeLoginLog(user.id, username, req, 'fail', 'deleted');
      return res.status(403).json({ success: false, message: '该账号已被删除' });
    }

    // 6. 使用 bcrypt 验证密码
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);
    if (!isPasswordValid) {
      await writeLoginLog(user.id, username, req, 'fail', 'wrong_password');
      return res.status(401).json({ success: false, message: '用户名或密码错误' });
    }

    // 7. 生成 JWT Token
    //    tv = 令牌版本号：用户执行「退出其他设备」后 token_version +1，旧令牌立即失效
    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
        role: user.role,
        purpose: 'login',
        tv: Number(user.token_version || 0)
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );

    // 8. 记录登录记录（真实数据，供「我的 → 账户安全 → 登录记录」展示）
    await writeLoginLog(user.id, user.username, req, 'success', null);

    // 9. 下发页面会话票据（HttpOnly Cookie）
    //    浏览器地址栏访问管理后台页面时无法带 Authorization 头，只靠前端判断角色
    //    会让普通用户也能打开后台外壳；这里用同一份 JWT 作为「页面准入票据」。
    //    该 Cookie 不参与任何 /api 认证，因此不会带来 CSRF 数据面风险。
    setPageSession(res, token, req);

    // 10. 返回登录成功（不返回 password_hash）
    res.json({
      success: true,
      message: '登录成功',
      data: {
        token: token,
        user: privateUser(user)
      }
    });
  } catch (err) {
    console.error('登录失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/auth/logout - 退出登录
// 作用: 立即清除「页面会话票据」，避免退出后同一浏览器仍能打开管理后台页面
// 说明: 不写入 login_logs（退出不算登录失败），也不做任何敏感的账号变更
// ============================================
router.post('/auth/logout', auth, (req, res) => {
  clearPageSession(res, req);
  res.json({ success: true, message: '已退出登录' });
});

// ============================================
// GET /api/auth/me - 个人中心（需登录）
// ============================================
router.get('/auth/me', auth, async (req, res) => {
  try {
    // 查询当前用户完整资料
    const [rows] = await db.promise().query(
      'SELECT id, username, nickname, avatar_url, email, phone, real_name, role, status, invite_code, created_at, updated_at FROM users WHERE id = ?',
      [req.user.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }

    // 返回个人资料（包含自己的绑定资料，不包含 password_hash）
    res.json({
      success: true,
      data: privateUser(rows[0])
    });
  } catch (err) {
    console.error('获取个人资料失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/users/:id - 公开用户资料（只返回用户名）
// ============================================
router.get('/users/:id', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    const userId = parseInt(req.params.id, 10);
    if (isNaN(userId) || userId <= 0) {
      return res.status(400).json({ success: false, message: '无效的用户ID' });
    }

    // 查询用户（只查询公开字段）
    const [rows] = await db.promise().query(
      'SELECT id, username, role, status, created_at FROM users WHERE id = ?',
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }

    // 只返回公开资料（绝不返回 phone, email, real_name, password_hash）
    res.json({
      success: true,
      data: publicUser(rows[0])
    });
  } catch (err) {
    console.error('获取用户资料失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/users - 用户列表（只返回用户名）
// ============================================
router.get('/users', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    // 查询所有正常用户（只查询公开字段）
    const [rows] = await db.promise().query(
      'SELECT id, username, role, status, created_at FROM users WHERE status = "active" ORDER BY id DESC LIMIT 100'
    );

    // 只返回公开资料
    res.json({
      success: true,
      data: rows.map(publicUser)
    });
  } catch (err) {
    console.error('获取用户列表失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/support/lookup - 客服按用户名/手机号/邮箱定位账号（需 support/admin 角色）
// 忘记密码统一走人工客服 / 管理员身份核验流程
// ============================================
router.post('/support/lookup', auth, requireRole('support', 'admin'), async (req, res) => {
  try {
    // 1. 提取定位关键字并标准化
    const keyword = normalizeString(req.body.keyword || req.body.username);
    if (!keyword) {
      return res.status(400).json({ success: false, message: '请提供用户名、手机号或邮箱' });
    }

    // 2. 按用户名 / 手机号 / 邮箱查询用户
    const [rows] = await db.promise().query(
      'SELECT id, username, email, phone, real_name, role, status, created_at, updated_at FROM users WHERE username = ? OR phone = ? OR email = ? LIMIT 1',
      [keyword, keyword, keyword]
    );

    if (rows.length === 0) {
      // 记录查询日志（未找到）
      await db.promise().query(
        'INSERT INTO admin_logs (admin_id, target_user_id, action, detail) VALUES (?, NULL, ?, ?)',
        [req.user.id, 'account_lookup', JSON.stringify({ keyword: keyword, found: false })]
      );
      return res.status(404).json({ success: false, message: '未找到该账号' });
    }

    const user = rows[0];

    // 3. 记录查询日志（找到）
    await db.promise().query(
      'INSERT INTO admin_logs (admin_id, target_user_id, action, detail) VALUES (?, ?, ?, ?)',
      [req.user.id, user.id, 'account_lookup', JSON.stringify({ keyword: keyword, found: true })]
    );

    // 4. 返回客服可见的必要资料（不包含 password_hash）
    res.json({
      success: true,
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        phone: user.phone,
        real_name: user.real_name,
        role: user.role,
        status: user.status,
        created_at: user.created_at,
        updated_at: user.updated_at
      }
    });
  } catch (err) {
    console.error('客服查询失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/auth/login-records - 我的登录记录（需登录，仅本人）
// 只返回时间 / IP / 客户端 / 结果，绝不返回密码相关信息
// ============================================
router.get('/auth/login-records', auth, async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 50);
    const [rows] = await db.promise().query(
      `SELECT id, ip, user_agent, status, reason, created_at
       FROM login_logs WHERE user_id = ? ORDER BY id DESC LIMIT ?`,
      [req.user.id, limit]
    );
    res.json({
      success: true,
      data: {
        list: rows.map(r => ({
          id: Number(r.id),
          ip: r.ip || '',
          user_agent: r.user_agent || '',
          status: r.status,
          status_text: r.status === 'success' ? '登录成功' : '登录失败',
          reason: r.reason || null,
          created_at: r.created_at
        }))
      }
    });
  } catch (err) {
    console.error('获取登录记录失败:', err.message);
    res.status(500).json({ success: false, message: '登录记录加载失败' });
  }
});

// ============================================
// POST /api/auth/change-password - 修改自己的密码（需登录）
// 安全:
//   - 必须验证原密码（bcrypt.compare）
//   - 新密码 ≥ 6 位，且两次一致
//   - 只保存 bcrypt 哈希，绝不返回任何密码
// ============================================
router.post('/auth/change-password', auth, async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store');
    const { old_password: oldPassword, new_password: newPassword, confirm_password: confirmPassword } = req.body || {};
    if (typeof oldPassword !== 'string' || !oldPassword || Buffer.byteLength(oldPassword, 'utf8') > 72 ||
        typeof newPassword !== 'string' || newPassword.length < 6 || Buffer.byteLength(newPassword, 'utf8') > 72 ||
        typeof confirmPassword !== 'string') {
      return res.status(422).json({ success: false, message: '请填写原密码，新密码至少 6 个字符且不超过 72 字节' });
    }
    if (newPassword !== confirmPassword) {
      return res.status(422).json({ success: false, message: '两次输入的新密码不一致' });
    }
    if (newPassword === oldPassword) {
      return res.status(422).json({ success: false, message: '新密码不能与原密码相同' });
    }

    const [rows] = await db.promise().query(
      'SELECT id, password_hash FROM users WHERE id = ? LIMIT 1', [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }

    const okPwd = await bcrypt.compare(oldPassword, rows[0].password_hash);
    if (!okPwd) {
      return res.status(401).json({ success: false, message: '原密码不正确' });
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    const [updated] = await db.promise().query(
      "UPDATE users SET password_hash = ? WHERE id = ? AND password_hash = ? AND status = 'active'",
      [newHash, req.user.id, rows[0].password_hash]);
    if (!updated.affectedRows) return res.status(409).json({ success: false, message: '账号状态或密码已变更，请重新登录后重试' });

    res.json({ success: true, message: '密码已更新，请使用新密码登录' });
  } catch (err) {
    console.error('修改密码失败');
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// POST /api/auth/logout-other - 退出其它设备（需登录）
// 语义:
//   - users.token_version +1 → 所有旧 JWT（含其它设备、自己当前令牌）立即失效
//   - 当前请求随后签发一个携带新 tv 的令牌返回给前端，前端用新令牌继续在线
//   - 事务 + 行锁保证并发下 token_version 严格递增，不会丢失更新
//   - 全程只写 token_version，不改密码 / 其它资料；审计写入 admin_logs
// 说明: 不要在这里写 JWT Secret 等敏感内容到任何日志。
router.post('/auth/logout-other', auth, async (req, res) => {
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      'SELECT id, token_version FROM users WHERE id = ? FOR UPDATE', [req.user.id]);
    if (rows.length === 0) {
      await conn.rollback(); conn.release();
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    const nextVersion = Number(rows[0].token_version || 0) + 1;
    const [updated] = await conn.query(
      'UPDATE users SET token_version = ? WHERE id = ? AND token_version = ?',
      [nextVersion, req.user.id, rows[0].token_version || 0]);
    if (!updated.affectedRows) {
      await conn.rollback(); conn.release();
      return res.status(409).json({ success: false, message: '操作冲突，请重试' });
    }
    await conn.query(
      'INSERT INTO admin_logs (admin_id, target_user_id, action, detail) VALUES (?, ?, ?, ?)',
      [req.user.id, req.user.id, 'logout_other_devices',
        JSON.stringify({ token_version: nextVersion })]);
    await conn.commit(); conn.release(); conn = null;

    // 当前设备换发新令牌（其它设备手里的旧令牌 tv 不匹配，立即失效）
    const fresh = jwt.sign(
      { id: req.user.id, username: req.user.username, role: req.user.role, purpose: 'login', tv: nextVersion },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );
    setPageSession(res, fresh, req);
    return res.json({ success: true, message: '其它设备已退出', data: { token: fresh } });
  } catch (err) {
    try { if (conn) { await conn.rollback(); conn.release(); } } catch (_) { /* 忽略回滚错误 */ }
    // 绝不打印 err.message（可能含 SQL 片段）；固定服务侧日志
    console.error('退出其它设备失败');
    return res.status(500).json({ success: false, message: '操作失败，请稍后重试' });
  }
});

// 导出路由
module.exports = router;