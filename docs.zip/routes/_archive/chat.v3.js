// ============================================
// 26牛牛 - 聊天路由（V3）
// 包含:
//   - GET  /api/chat/channels            会话列表（游戏群 + 客服，固定两项）
//   - GET  /api/chat/messages            消息分页（cursor 向上翻页）
//   - POST /api/chat/messages            发送消息（text / sticker）
//   - POST /api/chat/read                标记已读
//   - POST /api/chat/recall/:id          撤回自己的消息
//   - POST /api/chat/report              举报消息
//   - GET  /api/chat/stickers            贴图列表
// 安全:
//   - 全部 JWT；身份取自 req.user，绝不信任前端传的 user_id
//   - 消息列表只返回 username，绝不返回手机号/邮箱/姓名等私密字段
//   - 不提供好友/私聊/搜索玩家能力
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');

const MAX_LEN = 500;          // 文本最大长度
const DEFAULT_LIMIT = 30;     // 默认分页大小
const MAX_LIMIT = 50;

// ---------- 工具 ----------
function okChannel(c) { return c === 'group' || c === 'support'; }

/** 消息行 → 安全 JSON（绝不带敏感字段） */
function msgOut(r, meId) {
  return {
    id: Number(r.id),
    channel: r.channel,
    message_type: r.message_type,
    content: r.is_recalled ? '' : r.content,
    meta: r.meta || null,
    is_recalled: !!r.is_recalled,
    is_mine: r.user_id != null && Number(r.user_id) === Number(meId),
    username: r.username || '',
    created_at: r.created_at
  };
}

const MSG_SELECT =
  `SELECT m.id, m.channel, m.user_id, m.message_type, m.content, m.meta, m.is_recalled, m.created_at, u.username
   FROM chat_messages m LEFT JOIN users u ON u.id = m.user_id`;

// ============================================
// GET /api/chat/channels - 会话列表（固定两项）
// ============================================
router.get('/chat/channels', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    const [rows] = await db.promise().query(
      MSG_SELECT +
      ` JOIN (SELECT channel, MAX(id) AS maxid FROM chat_messages
              WHERE channel IN ('group','support') GROUP BY channel) t
        ON t.channel = m.channel AND t.maxid = m.id`
    );
    const [reads] = await db.promise().query(
      'SELECT channel, last_read_id FROM chat_read_state WHERE user_id = ?', [userId]
    );
    const readMap = {};
    reads.forEach(r => { readMap[r.channel] = Number(r.last_read_id); });

    const [cntRows] = await db.promise().query(
      `SELECT channel, COUNT(*) AS c FROM chat_messages
       WHERE channel IN ('group','support') GROUP BY channel`
    );
    const cntMap = {};
    cntRows.forEach(r => { cntMap[r.channel] = Number(r.c); });

    const [onlineRows] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM users WHERE status = 'active'`
    );

    function lastOf(ch) {
      const r = rows.find(x => x.channel === ch);
      if (!r) return null;
      return {
        id: Number(r.id),
        preview: r.is_recalled ? '消息已撤回' : (
          r.message_type === 'text' || r.message_type === 'system' ? r.content :
          r.message_type === 'sticker' ? '[贴图]' : '[图片]'),
        time: r.created_at
      };
    }

    const groupLast = lastOf('group');
    const supportLast = lastOf('support');

    const list = [
      {
        channel: 'group',
        name: '26牛牛游戏群',
        avatar: '/assets/nav/game-group.svg',
        pinned: true,
        tag: '游戏',
        member_online: Number(onlineRows[0].c) || 1,
        unread: groupLast ? Math.max(0, (cntMap.group || 0) - (readMap.group || 0)) : 0,
        last: groupLast
      },
      {
        channel: 'support',
        name: '在线客服',
        avatar: '/assets/nav/support.svg',
        pinned: false,
        tag: '',
        online: false, // 客服后台尚未上线，如实显示留言模式，不伪造真人在线
        unread: supportLast ? Math.max(0, (cntMap.support || 0) - (readMap.support || 0)) : 0,
        last: supportLast
      }
    ];

    res.json({ success: true, data: { list: list } });
  } catch (err) {
    console.error('获取会话列表失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/chat/messages?channel=group&before=<id>&limit=30
// cursor 分页：before 为空=取最新一页；向上翻页传上一页最小 id
// ============================================
router.get('/chat/messages', auth, async (req, res) => {
  try {
    const channel = String(req.query.channel || '');
    if (!okChannel(channel)) {
      return res.status(400).json({ success: false, message: '无效的频道' });
    }
    const limit = Math.min(parseInt(req.query.limit, 10) || DEFAULT_LIMIT, MAX_LIMIT);
    const before = parseInt(req.query.before, 10);

    const params = [channel];
    let where = 'm.channel = ?';
    if (!isNaN(before) && before > 0) {
      where += ' AND m.id < ?';
      params.push(before);
    }
    params.push(limit);

    const [rows] = await db.promise().query(
      MSG_SELECT + ' WHERE ' + where + ' ORDER BY m.id DESC LIMIT ?',
      params
    );

    // 返回升序（旧→新），并带分页游标
    const list = rows.reverse().map(r => msgOut(r, req.user.id));
    res.json({
      success: true,
      data: {
        list: list,
        has_more: rows.length === limit,
        next_before: list.length > 0 ? list[0].id : null   // 更旧一页的游标
      }
    });
  } catch (err) {
    console.error('获取消息失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/chat/messages  { channel, message_type, content, meta }
// 只允许 text / sticker；身份取自 JWT
// ============================================
router.post('/chat/messages', auth, async (req, res) => {
  try {
    const channel = String(req.body.channel || '');
    const type = String(req.body.message_type || 'text');
    const content = String(req.body.content == null ? '' : req.body.content).trim();
    const meta = req.body.meta || null;

    if (!okChannel(channel)) {
      return res.status(400).json({ success: false, message: '无效的频道' });
    }
    if (type !== 'text' && type !== 'sticker') {
      return res.status(400).json({ success: false, message: '不支持的消息类型' });
    }
    if (type === 'text' && (!content || content.length > MAX_LEN)) {
      return res.status(400).json({ success: false, message: '消息内容为空或超过 ' + MAX_LEN + ' 字' });
    }
    if (type === 'sticker') {
      if (!meta || typeof meta !== 'object' || !String(meta.url || '').startsWith('/assets/')) {
        return res.status(400).json({ success: false, message: '无效的贴图' });
      }
    }

    const [result] = await db.promise().query(
      `INSERT INTO chat_messages (channel, user_id, message_type, content, meta)
       VALUES (?, ?, ?, ?, ?)`,
      [channel, req.user.id, type, type === 'text' ? content : '', meta ? JSON.stringify(meta) : null]
    );

    const [rows] = await db.promise().query(
      MSG_SELECT + ' WHERE m.id = ?', [result.insertId]
    );

    res.status(201).json({ success: true, data: msgOut(rows[0], req.user.id) });
  } catch (err) {
    console.error('发送消息失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/chat/read  { channel }  标记已读到当前最新
// ============================================
router.post('/chat/read', auth, async (req, res) => {
  try {
    const channel = String(req.body.channel || '');
    if (!okChannel(channel)) {
      return res.status(400).json({ success: false, message: '无效的频道' });
    }

    const [maxRows] = await db.promise().query(
      'SELECT COALESCE(MAX(id), 0) AS maxid FROM chat_messages WHERE channel = ?', [channel]
    );
    const maxId = Number(maxRows[0].maxid) || 0;

    await db.promise().query(
      `INSERT INTO chat_read_state (user_id, channel, last_read_id)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE last_read_id = GREATEST(last_read_id, VALUES(last_read_id))`,
      [req.user.id, channel, maxId]
    );

    res.json({ success: true, data: { channel: channel, last_read_id: maxId } });
  } catch (err) {
    console.error('标记已读失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/chat/recall/:id - 撤回自己的消息
// 后端强制验证：只能撤回自己的、未撤回的、2小时内的消息
// ============================================
router.post('/chat/recall/:id', auth, async (req, res) => {
  try {
    const msgId = Number(req.params.id);
    if (!Number.isInteger(msgId) || msgId <= 0) {
      return res.status(400).json({ success: false, message: '无效的消息' });
    }

    const [rows] = await db.promise().query(
      'SELECT id, user_id, is_recalled, message_type, created_at FROM chat_messages WHERE id = ?',
      [msgId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: '消息不存在' });
    }

    const m = rows[0];

    // 权限：只能撤回自己的消息（系统消息任何人不可撤回）
    if (m.user_id == null || Number(m.user_id) !== Number(req.user.id)) {
      return res.status(403).json({ success: false, message: '只能撤回自己的消息' });
    }
    if (m.is_recalled) {
      return res.status(400).json({ success: false, message: '该消息已撤回' });
    }
    if (m.message_type === 'system') {
      return res.status(403).json({ success: false, message: '系统消息不能撤回' });
    }

    // 时间窗口：发送后 2 小时内可撤回
    const sentAt = new Date(m.created_at).getTime();
    const WINDOW = 2 * 60 * 60 * 1000;
    if (Number.isFinite(sentAt) && Date.now() - sentAt > WINDOW) {
      return res.status(400).json({ success: false, message: '超过 2 小时的消息不能撤回' });
    }

    await db.promise().query(
      'UPDATE chat_messages SET is_recalled = 1, content = "" WHERE id = ?',
      [msgId]
    );

    res.json({ success: true, message: '已撤回', data: { id: msgId } });
  } catch (err) {
    console.error('撤回消息失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// POST /api/chat/report  { message_id, reason }
// 记录举报：举报人 / 目标消息 / 原因 / 时间
// ============================================
router.post('/chat/report', auth, async (req, res) => {
  try {
    const messageId = Number(req.body.message_id);
    const reason = String(req.body.reason || '').trim();

    if (!Number.isInteger(messageId) || messageId <= 0) {
      return res.status(400).json({ success: false, message: '无效的消息' });
    }
    if (!reason) {
      return res.status(400).json({ success: false, message: '请填写举报原因' });
    }
    if (reason.length > 200) {
      return res.status(400).json({ success: false, message: '举报原因最多 200 字' });
    }

    // 确认消息存在
    const [rows] = await db.promise().query(
      'SELECT id FROM chat_messages WHERE id = ?', [messageId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: '消息不存在' });
    }

    await db.promise().query(
      `INSERT INTO chat_reports (reporter_id, message_id, reason)
       VALUES (?, ?, ?)`,
      [req.user.id, messageId, reason]
    );

    res.status(201).json({ success: true, message: '举报已提交，感谢您的反馈' });
  } catch (err) {
    console.error('举报失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/chat/stickers - 贴图列表（官方贴图）
// 官方贴图为静态资源目录扫描结果；用户贴图功能预留
// ============================================
router.get('/chat/stickers', auth, async (req, res) => {
  try {
    // 官方贴图固定清单（等待正式素材后替换 URL 即可）
    const official = [
      { id: 'welcome',  name: '欢迎',   url: '/assets/stickers/welcome.svg' },
      { id: 'hello',    name: '你好',   url: '/assets/stickers/hello.svg' },
      { id: 'thanks',   name: '谢谢',   url: '/assets/stickers/thanks.svg' },
      { id: 'goodluck', name: '加油',   url: '/assets/stickers/goodluck.svg' },
      { id: 'win',      name: '赢了',   url: '/assets/stickers/win.svg' },
      { id: 'gg',       name: '下次再来', url: '/assets/stickers/gg.svg' }
    ];

    res.json({
      success: true,
      data: {
        official: official,
        mine: []      // 用户上传贴图：上传功能就绪后接入
      }
    });
  } catch (err) {
    console.error('获取贴图失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

module.exports = router;