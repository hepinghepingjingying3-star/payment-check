// ============================================
// 26牛牛 - 大厅聚合路由
//   - GET /api/home   大厅首屏一次性数据（减少重复请求）
// 返回:
//   user        顶部用户区域（仅 username / role / status —— 不返回手机号/邮箱/姓名）
//   assets      资产概览（游戏余额 / 现金筹码，两个资产完全独立）
//   banners     轮播公告（置顶优先）
//   games       平台推荐（GameCard）
//   tutorials   玩法介绍卡片
//   recent      最近访问
//   unread      未读数（通知 / 聊天）
//   entry       游戏群入口（直接进入真实聊天页面）
//   image_ready 官方图片素材是否已放入（未放入时前端使用无图占位，不产生 404）
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const GAMES = require('../config/games');
const T = require('../config/tutorials');
const A = require('../config/announcements');
const content = require('../utils/content');
const { getManifest } = require('./assets');
const { withLogo } = require('./games');
const { ok, fail } = require('../utils/request');
const { unreadCounts } = require('../utils/chatVisibility');

const RECENT_LIMIT = 10;

/** 与会话列表共用可见性、已读游标及撤回过滤规则；查询失败交由路由返回错误。 */
async function chatUnread(userId) {
  return unreadCounts(db, userId);
}

// GET /api/home
router.get('/home', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    // 1) 用户公开信息（绝不返回手机号 / 邮箱 / 姓名）
    const [uRows] = await db.promise().query(
      'SELECT id, username, role, status, game_balance, cash_chips, created_at FROM users WHERE id = ? LIMIT 1',
      [userId]
    );
    if (uRows.length === 0) return fail(res, '用户不存在，请重新登录', 401);
    const u = uRows[0];
    if (u.status === 'banned') return fail(res, '该账号已被封禁，请联系客服', 403);
    if (u.status === 'deleted') return fail(res, '该账号已被删除', 403);

    // 2) 公告轮播
    const annList = await content.loadAnnouncements();
    const banners = annList.slice(0, A.BANNER_LIMIT).map(a => A.briefAnnouncement(a, 70));

    // 3) 平台推荐 + 玩法介绍 + 最近访问（并行）
    const [recentRows] = await db.promise().query(
      `SELECT id, target_type, target_id, title, visited_at
       FROM recent_visits WHERE user_id = ? ORDER BY visited_at DESC LIMIT ?`,
      [userId, RECENT_LIMIT]
    );

    const games = GAMES.listGames().map(withLogo);
    const unreadNoti = await content.unreadNotificationCount(userId);
    const unreadChat = await chatUnread(userId);

    let manifest = {};
    try { manifest = getManifest(false); } catch (e) { manifest = {}; }

    return ok(res, {
      user: {
        id: u.id,
        username: u.username,
        role: u.role,
        status: u.status,
        created_at: u.created_at
      },
      assets: {
        // 两个资产完全独立，不做任何混合计算
        game_balance: Number(u.game_balance || 0),
        cash_chips: Number(u.cash_chips || 0),
        currency_note: '游戏余额与现金筹码相互独立'
      },
      banners: banners,
      games: games,
      tutorials: T.listTutorials(),
      recent: recentRows.map(r => ({
        id: Number(r.id),
        target_type: r.target_type,
        target_id: r.target_id,
        title: r.title || '',
        visited_at: r.visited_at
      })),
      unread: {
        notifications: unreadNoti,
        chat: unreadChat.total,
        chat_group: unreadChat.group,
        chat_support: unreadChat.support
      },
      entry: {
        game_group: {
          channel: 'group',
          name: '26牛牛游戏群',
          link: '/group-chat.html',
          label: '进入游戏群'
        },
        support: { channel: 'support', name: '在线客服', link: '/support-chat.html' }
      },
      // 官方图片素材是否已就位（站长放入 public/assets 后自动变 true）
      image_ready: {
        logo: !!manifest.logo_ready,
        logo_url: manifest.logo_url || null,
        avatars: !!manifest.avatars_ready,
        avatars_url: manifest.avatars_url || null,
        banners: !!manifest.banners_ready,
        stickers: !!manifest.stickers_ready,
        games: !!manifest.games_ready,
        tutorial: !!manifest.tutorial_ready
      },
      tutorials_title: '玩法介绍',
      recommend_title: '平台推荐'
    });
  } catch (err) {
    console.error('获取大厅数据失败:', err.message);
    return fail(res, '大厅数据加载失败，请重新加载', 500);
  }
});

module.exports = router;