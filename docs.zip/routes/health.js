'use strict';
// ============================================
// 26牛牛 - 健康检查 /api/health
// ============================================
// 用途:
//   1) npm test 在线用例探测服务是否已启动
//   2) 部署后的负载均衡 / Nginx / uptime 监控探针
//   3) 只返回服务状态与数据库连通性，绝不返回配置、密码、版本化内部信息
// ============================================

const router = require('express').Router();
const db = require('../config/db');

const STARTED_AT = Date.now();

router.get('/health', (req, res) => {
  const payload = {
    success: true,
    status: 'ok',
    uptime_seconds: Math.floor((Date.now() - STARTED_AT) / 1000),
    time: new Date().toISOString()
  };
  // 数据库探活：失败时返回 503，便于监控立刻发现
  const timer = setTimeout(() => {
    res.status(503).json({ success: false, status: 'degraded', db: 'timeout' });
  }, 2500);
  db.query('SELECT 1', (err) => {
    clearTimeout(timer);
    if (res.headersSent) return;
    if (err) return res.status(503).json({ success: false, status: 'degraded', db: 'down' });
    payload.db = 'up';
    res.set('Cache-Control', 'no-store');
    return res.status(200).json(payload);
  });
});

module.exports = router;
