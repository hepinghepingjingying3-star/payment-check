// ============================================
// 26牛牛 - 现金筹码转账（系统内虚拟资产）
// 说明:
//   - 不连接真实支付渠道，不可兑换 RM
//   - 6位数字支付密码（仅比对哈希）
//   - 事务 + 行锁 + 幂等流水，防重复提交 / 负余额
// ============================================
'use strict';
const express = require('express');
const crypto = require('node:crypto');
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { applyBalance } = require('../utils/ledger');
const { verifyPayPassword } = require('../utils/payPassword');
const { TRANSFER } = require('../config/cashChips');
const { hit } = require('../utils/rateLimit');
const { ok, fail } = require('../utils/request');

const router = express.Router();

/** 计算今日已转账累计（现金筹码转出流水，真实数据库统计） */
async function todayOutSum(userId) {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const dayStart = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} 00:00:00`;
  const [rows] = await db.promise().query(
    `SELECT COALESCE(SUM(amount), 0) AS s
     FROM cash_transfers
     WHERE from_user_id = ? AND created_at >= ?`,
    [userId, dayStart]
  );
  return Number(rows[0].s) || 0;
}

// POST /api/transfers - 转账
router.post('/transfers', auth, async (req, res) => {
  try {
    const fromId = req.user.id;
    const rl = hit('transfer:' + fromId, 10, 60 * 60 * 1000);
    if (!rl.allowed) return fail(res, '转账过于频繁，请稍后再试', 429);

    const toUid = String((req.body && req.body.to_uid) || '').trim();
    const amount = Number(req.body && req.body.amount);
    const payPassword = String((req.body && req.body.pay_password) || '');
    const idempotencyKey = String((req.body && req.body.idempotency_key) || '').slice(0, 64);

    if (!toUid) return fail(res, '请输入对方UID', 400);
    if (!Number.isFinite(amount) || amount <= 0) return fail(res, '请输入有效的转账金额', 400);
    if (amount !== Math.round(amount * 100) / 100) return fail(res, '转账金额最多两位小数', 400);
    if (amount > TRANSFER.MAX) {
      return fail(res, `单笔转账不能超过 ${TRANSFER.MAX} 现金筹码`, 400);
    }
    if (amount < TRANSFER.MIN) {
      return fail(res, `单笔转账至少 ${TRANSFER.MIN} 现金筹码`, 400);
    }

    // 支付密码校验（只比对哈希，明文不入库、不打日志）
    const pwCheck = await verifyPayPassword(fromId, payPassword);
    if (!pwCheck.ok) return fail(res, pwCheck.message || '支付密码错误', 400);

    // 查找收款方（UID = 用户ID 或 邀请码，均支持）
    let toUser = null;
    if (/^\d+$/.test(toUid)) {
      const [r] = await db.promise().query(
        'SELECT id, username, status FROM users WHERE id = ? LIMIT 1', [parseInt(toUid, 10)]
      );
      if (r.length) toUser = r[0];
    }
    if (!toUser) {
      const [r] = await db.promise().query(
        'SELECT id, username, status FROM users WHERE invite_code = ? LIMIT 1', [toUid]
      );
      if (r.length) toUser = r[0];
    }
    if (!toUser) return fail(res, '对方UID不存在', 404);
    if (Number(toUser.id) === Number(fromId)) return fail(res, '不能给自己转账', 400);
    if (toUser.status !== 'active') return fail(res, '对方账户状态异常，无法接收转账', 400);

    // 单日上限校验（真实数据库统计）
    const daySum = await todayOutSum(fromId);
    if (daySum + amount > TRANSFER.DAILY_LIMIT) {
      return fail(res, `今日转账已达上限 ${TRANSFER.DAILY_LIMIT} 现金筹码（今日已转 ${daySum}）`, 400);
    }

    const conn = await db.promise().getConnection();
    try {
      await conn.beginTransaction();

      // 行锁：先按 id 升序锁定两方，避免死锁
      const ids = [Number(fromId), Number(toUser.id)].sort((a, b) => a - b);
      const [uRows] = await conn.query(
        'SELECT id, cash_chips FROM users WHERE id IN (?, ?) ORDER BY id FOR UPDATE',
        ids
      );
      const fromRow = uRows.find(r => Number(r.id) === Number(fromId));
      const toRow = uRows.find(r => Number(r.id) === Number(toUser.id));
      if (!fromRow || !toRow) { await conn.rollback(); return fail(res, '用户不存在', 404); }

      const fromBal = Number(fromRow.cash_chips);
      if (fromBal < amount) { await conn.rollback(); return fail(res, '可用现金筹码不足', 400); }

      const txId = 'TX' + Date.now().toString(36).toUpperCase() + crypto.randomBytes(3).toString('hex').toUpperCase();

      // 幂等：同一 idempotency_key 只允许一次（cash_transfers.idempotency_key UNIQUE）
      const idemKey = idempotencyKey || (txId + ':' + Number(fromId) + '->' + Number(toUser.id));
      const [dup] = await conn.query(
        'SELECT id FROM cash_transfers WHERE idempotency_key = ? LIMIT 1',
        [idemKey.slice(0, 64)]
      );
      if (dup.length) {
        await conn.rollback();
        return fail(res, '请勿重复提交', 409);
      }
      const refKey = 'TRANSFER:' + (idempotencyKey || txId);

      // 扣除发送方（现金筹码）
      const out = await applyBalance(conn, {
        userId: Number(fromId),
        delta: -amount,
        currencyType: 'CASH_CHIPS',
        type: 'TRANSFER_OUT',
        reason: `转账给 ${toUser.username}`,
        referenceNo: refKey + ':OUT',
        operatorId: null
      });

      // 增加接收方（现金筹码）
      const into = await applyBalance(conn, {
        userId: Number(toUser.id),
        delta: amount,
        currencyType: 'CASH_CHIPS',
        type: 'TRANSFER_IN',
        reason: `收到 ${req.user.username || '用户'} 的转账`,
        referenceNo: refKey + ':IN',
        operatorId: null
      });

      // 转账记录（幂等键 UNIQUE，防重复提交）
      await conn.query(
        'INSERT INTO cash_transfers (transfer_no, from_user_id, to_user_id, amount, currency, remark, idempotency_key) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [txId, Number(fromId), Number(toUser.id), amount.toFixed(2), 'CASH_CHIPS', null, idemKey.slice(0, 64)]
      );

      await conn.commit();
      return ok(res, {
        transaction_id: txId,
        amount,
        to_uid: toUser.id,
        to_username: toUser.username
      }, '转账成功');
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error('转账失败:', err.message);
    return fail(res, '转账失败，请重试', 500);
  }
});

// GET /api/transfers/limits - 转账额度信息
router.get('/transfers/limits', auth, async (req, res) => {
  try {
    const daySum = await todayOutSum(req.user.id);
    return ok(res, {
      daily_limit: TRANSFER.DAILY_LIMIT,
      used_today: daySum,
      remaining_today: Math.max(0, TRANSFER.DAILY_LIMIT - daySum)
    });
  } catch (err) {
    console.error('查询转账额度失败:', err.message);
    return fail(res, '额度加载失败', 500);
  }
});

module.exports = router;