// ============================================
// 26牛牛 - 推广中心路由（V3）
// 包含:
//   - GET /api/promote/info     我的推广（邀请码/链接/统计/列表）
//   - GET /api/promote/summary?date=YYYY-MM-DD  按日推广数据（自身/直属/二级）
// 安全:
//   - 全部需要 JWT
//   - 列表只返回 username/status/created_at，绝不返回手机号/邮箱/姓名
//   - 奖励数值以真实记账记录为准（没有记录时显示 0），绝不伪造收益
// 比例配置: 集中在 config/referral.js，此文件不出现具体百分比数字
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const REFERRAL = require('../config/referral');
const { ok, fail } = require('../utils/request');

// ---------- 工具 ----------
function pad2(n) { return String(n).padStart(2, '0'); }
function todayStr() {
  const d = new Date();
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
}
function isValidDate(s) {
  return /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s + 'T00:00:00').getTime());
}
function toMaskedName(username) {
  // 列表中只显示用户名本身（用户名本身就是公开昵称），无手机号/姓名
  return String(username || '');
}
/** 账号状态中文（只暴露状态，不暴露任何资料） */
function statusText(s) {
  if (s === 'active') return '正常';
  if (s === 'banned') return '已封禁';
  if (s === 'deleted') return '已删除';
  return String(s || '');
}

// ============================================
// GET /api/promote/info - 我的推广信息
// 返回: 邀请码 / 邀请链接(相对路径) / 比例(来自 config/referral.js) / 统计 / 关系列表 / 规则
// 隐私: 列表只返回 username + 注册时间 + 关系层级 + 状态
//       绝不返回 phone / email / real_name / password_hash
// ============================================
router.get('/promote/info', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    // 我的资料（邀请码）
    const [me] = await db.promise().query(
      'SELECT id, username, invite_code, invited_by, created_at FROM users WHERE id = ? LIMIT 1',
      [userId]
    );
    if (me.length === 0) {
      return fail(res, '用户不存在', 404);
    }
    const my = me[0];

    const now = new Date();
    const monthStart = now.getFullYear() + '-' + pad2(now.getMonth() + 1) + '-01';
    const dayStart = todayStr() + ' 00:00:00';

    // 直属邀请（level=1）
    const [direct] = await db.promise().query(
      `SELECT id, username, status, created_at FROM users
       WHERE invited_by = ? AND status <> 'deleted' ORDER BY id DESC LIMIT 500`,
      [userId]
    );

    // 二级邀请（我的直属所邀请的人）
    const [second] = await db.promise().query(
      `SELECT s.id, s.username, s.status, s.created_at, d.username AS via_username
       FROM users s JOIN users d ON s.invited_by = d.id
       WHERE d.invited_by = ? AND s.status <> 'deleted'
       ORDER BY s.id DESC LIMIT 500`,
      [userId]
    );

    // 统计：今日新增 / 本月新增（直属 + 二级）
    const [todayDirect] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM users WHERE invited_by = ? AND status <> \'deleted\' AND created_at >= ?',
      [userId, dayStart]
    );
    const [todaySecond] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM users s JOIN users d ON s.invited_by = d.id
       WHERE d.invited_by = ? AND s.status <> 'deleted' AND s.created_at >= ?`,
      [userId, dayStart]
    );
    const [monthDirect] = await db.promise().query(
      'SELECT COUNT(*) AS c FROM users WHERE invited_by = ? AND status <> \'deleted\' AND created_at >= ?',
      [userId, monthStart]
    );
    const [monthSecond] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM users s JOIN users d ON s.invited_by = d.id
       WHERE d.invited_by = ? AND s.status <> 'deleted' AND s.created_at >= ?`,
      [userId, monthStart]
    );

    // 邀请关系列表（合并一级 / 二级，按注册时间倒序）
    const relations = direct.map(u => ({
      username: u.username,
      level: 1,
      level_text: '直属下线',
      status: u.status,
      status_text: statusText(u.status),
      created_at: u.created_at
    })).concat(second.map(u => ({
      username: u.username,
      level: 2,
      level_text: '二级下线',
      via_username: u.via_username,
      status: u.status,
      status_text: statusText(u.status),
      created_at: u.created_at
    }))).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    const directCount = direct.length;
    const secondCount = second.length;

    return ok(res, {
      invite_code: my.invite_code || '',
      // 只返回站内相对路径，不硬编码完整域名（前端自行拼接 origin）
      invite_link: my.invite_code ? ('/register.html?invite=' + encodeURIComponent(my.invite_code)) : '',
      rates: REFERRAL.publicRates(),      // 集中配置的三档比例
      rate_cards: REFERRAL.getRateCards(), // 供前端渲染，不在前端硬编码数字
      stats: {
        direct: directCount,
        second: secondCount,
        total: directCount + secondCount,
        today_new: Number(todayDirect[0].c || 0) + Number(todaySecond[0].c || 0),
        month_new: Number(monthDirect[0].c || 0) + Number(monthSecond[0].c || 0)
      },
      // 兼容旧字段（保留，避免破坏已有调用）
      total_invited: directCount,
      month_new: Number(monthDirect[0].c) || 0,
      second_total: secondCount,
      total_reward: 0,                    // 当前推广奖励为真实 0，不造假
      relations: relations.slice(0, 200),
      invited_list: direct.slice(0, 200).map(u => ({
        id: u.id,
        username: toMaskedName(u.username),
        level: 1,
        status: u.status,
        created_at: u.created_at
      })),
      rules: {
        title: '推广规则',
        items: [
          { key: 'direct', title: '直属下线奖励', rate: REFERRAL.REFERRAL_RATES.DIRECT, unit: '%' },
          { key: 'second', title: '二级下线奖励', rate: REFERRAL.REFERRAL_RATES.SECOND_LEVEL, unit: '%' },
          { key: 'self', title: '自身游戏奖励', rate: REFERRAL.REFERRAL_RATES.SELF, unit: '%' }
        ],
        notes: [
          '奖励比例由平台统一配置（虚拟现金筹码），修改后所有页面同步生效。',
          '奖励金额以实际发放记录为准，没有记录时显示为 0，不会伪造收益。',
          '邀请关系在注册完成后锁定，不能随意修改。'
        ]
      }
    });
  } catch (err) {
    console.error('获取推广信息失败:', err.message);
    return fail(res, '推广信息加载失败', 500);
  }
});

// ============================================
// GET /api/promote/summary?date=YYYY-MM-DD - 按日推广数据
// 说明: 奖励流水尚未开放，当前返回真实统计（人数）与 0.00 奖励，不伪造
// ============================================
router.get('/promote/summary', auth, async (req, res) => {
  try {
    const date = isValidDate(String(req.query.date || '')) ? String(req.query.date) : todayStr();
    const dayStart = date + ' 00:00:00';
    const dayEnd = date + ' 23:59:59';
    const userId = req.user.id;

    // 当日新增直属 / 二级
    const [d1] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM users WHERE invited_by = ? AND status <> 'deleted' AND created_at BETWEEN ? AND ?`,
      [userId, dayStart, dayEnd]
    );
    const [d2] = await db.promise().query(
      `SELECT COUNT(*) AS c FROM users s JOIN users d ON s.invited_by = d.id
       WHERE d.invited_by = ? AND s.status <> 'deleted' AND s.created_at BETWEEN ? AND ?`,
      [userId, dayStart, dayEnd]
    );

    res.json({
      success: true,
      data: {
        date: date,
        rates: REFERRAL.publicRates(),
        day_new_direct: Number(d1[0].c) || 0,
        day_new_second: Number(d2[0].c) || 0,
        // 按日奖励金额：本期不提供按日拆分，恒返回真实 0（不伪造）；明细请看 /api/promote/rewards
        reward_total: 0,
        reward_self: 0,
        reward_direct: 0,
        reward_second: 0
      }
    });
  } catch (err) {
    console.error('获取推广日数据失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// ============================================
// GET /api/promote/rewards?limit=&offset= - 我的推广奖励台账
// 说明: 奖励由后端在充值审核通过时按 config/referral.js 计算并写入 Ledger（幂等），
//       前端只能读取，不能计算或写入。
// ============================================
router.get('/promote/rewards', auth, async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const rewards = require('../utils/referralRewards');
    const range = { from: req.query.from, to: req.query.to };
    const list = await rewards.listMyRewards(req.user.id, limit, offset, range);
    const summary = await rewards.myRewardSummary(req.user.id);
    return ok(res, {
      list: list,
      summary: summary,
      range: { from: range.from || null, to: range.to || null },
      rates: REFERRAL.publicRates(),
      limit: limit,
      offset: offset
    });
  } catch (err) {
    console.error('读取推广奖励失败:', err.message);
    return fail(res, '推广奖励加载失败，请稍后重试', 500);
  }
});

module.exports = router;