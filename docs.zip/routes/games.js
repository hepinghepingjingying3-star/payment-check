// ============================================
// 26牛牛 - 游戏（平台推荐）路由
// 包含:
//   - GET /api/games       游戏列表（大厅「平台推荐」）
//   - GET /api/games/:id   单个游戏详情
// 说明:
//   - 数据来自 config/games.js（新增游戏只改配置，不需要重做大厅）
//   - logo 只返回站长真实放入 public/assets/games 的图片地址，未放入则 logo=null，
//     前端自动使用无图占位，不产生 404
//   - 不返回任何玩家资料
// ============================================

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const GAMES = require('../config/games');
const { getManifest } = require('./assets');
const { ok, fail } = require('../utils/request');

/** 依据资源清单解析 logo 地址 */
function resolveLogo(g) {
  try {
    const m = getManifest(false);
    const list = (m && m.games) || [];
    const cands = g.logo_candidates || [];
    for (const c of cands) {
      const found = list.find(x => x.file.toLowerCase() === String(c).toLowerCase());
      if (found) return found.url;
    }
    // 候选名未匹配时，用 id 作为文件名兜底
    const byId = list.find(x => x.key.toLowerCase() === String(g.id).toLowerCase());
    return byId ? byId.url : null;
  } catch (e) {
    return null;
  }
}

function withLogo(g) {
  const out = Object.assign({}, g);
  out.logo = resolveLogo(g);
  delete out.logo_candidates;     // 内部字段不外泄
  return out;
}

// GET /api/games
router.get('/games', auth, async (req, res) => {
  try {
    const list = GAMES.listGames().map(withLogo);
    return ok(res, { list: list });
  } catch (err) {
    console.error('获取游戏列表失败:', err.message);
    return fail(res, '游戏列表加载失败', 500);
  }
});

// GET /api/games/:id
router.get('/games/:id', auth, async (req, res) => {
  try {
    const g = GAMES.getGame(req.params.id);
    if (!g) return fail(res, '游戏不存在', 404);
    return ok(res, withLogo(g));
  } catch (err) {
    console.error('获取游戏详情失败:', err.message);
    return fail(res, '游戏信息加载失败', 500);
  }
});

module.exports = router;
module.exports.withLogo = withLogo;