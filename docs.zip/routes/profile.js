'use strict';
const express = require('express');
const multer = require('multer');
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024, files: 1, fields: 0 } });
const directory = path.join(__dirname, '..', 'public', 'assets', 'avatars', 'users');

async function active(req, res, next) {
  try {
    const [rows] = await db.promise().query('SELECT status FROM users WHERE id = ?', [req.user.id]);
    if (!rows[0] || rows[0].status !== 'active') return fail(res, '账号不可用', 403);
    next();
  } catch (_) { return fail(res, '资料服务暂不可用', 503); }
}
function imageType(b) {
  if (!b || b.length < 24) return null;
  if (b.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])) && b.toString('ascii',12,16) === 'IHDR') return { mime: 'image/png', ext: '.png' };
  if (b[0] === 255 && b[1] === 216 && b[2] === 255 && b[b.length-2] === 255 && b[b.length-1] === 217) return { mime: 'image/jpeg', ext: '.jpg' };
  if (b.toString('ascii',0,4) === 'RIFF' && b.toString('ascii',8,12) === 'WEBP') return { mime: 'image/webp', ext: '.webp' };
  return null;
}
router.patch('/profile', auth, active, async (req, res) => {
  const nickname = typeof req.body.nickname === 'string' ? req.body.nickname.trim() : '';
  if (Array.from(nickname).length < 2 || Array.from(nickname).length > 24 || /[<>\x00-\x1f\x7f]/.test(nickname)) {
    return fail(res, '昵称须为 2–24 个字符，不能包含尖括号或控制字符');
  }
  try {
    await db.promise().query('UPDATE users SET nickname = ? WHERE id = ? AND status = \'active\'', [nickname, req.user.id]);
    return ok(res, { nickname });
  } catch (_) { return fail(res, '昵称保存失败，请重试', 500); }
});
// ============================================
// 头像：用户不能自行上传（阶段 41 起）
//   - 头像唯一来源是后台「头像管理」发布的官方头像库
//   - 选择头像请调用 POST /api/avatars/select（只接受 avatar_id）
//   - 这里保留路径并明确拒绝，避免旧客户端继续写入 avatar_url
// ============================================
router.post('/profile/avatar', auth, active, (req, res) => {
  return fail(res, '不支持自行上传头像，请在「我的 - 更换头像」中从官方头像库选择', 403);
});
// ============================================
// 实名认证（用户侧，阶段 7 / 8.5）
//   - GET  /api/profile/real-name        本人实名状态
//   - POST /api/profile/real-name        提交/重新提交实名（进入待审核）
// 规则:
//   - 一个账号只能绑定一个收款人姓名（real_name_reviews.user_id 唯一）
//   - 同一个已通过实名姓名不能被第二个账号绑定（提交与审核两处都校验）
//   - 不做任何资金/提现操作，仅记录审核状态
// ============================================
const REAL_NAME_RE = /^[\u4e00-\u9fa5A-Za-z][\u4e00-\u9fa5A-Za-z .·']{1,49}$/;

function realNameStatusText(status) {
  return ({ pending: '审核中', approved: '已通过', rejected: '已拒绝' })[status] || '未提交';
}

router.get('/profile/real-name', auth, active, async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      'SELECT real_name, status, remark, reviewed_at, created_at FROM real_name_reviews WHERE user_id = ? LIMIT 1',
      [req.user.id]
    );
    const r = rows[0];
    return ok(res, {
      status: r ? r.status : 'unsubmitted',
      status_text: realNameStatusText(r ? r.status : 'unsubmitted'),
      real_name: r ? r.real_name : null,
      remark: r && r.remark ? r.remark : null,
      reviewed_at: r ? r.reviewed_at : null,
      submitted_at: r ? r.created_at : null,
      note: '实名信息仅用于账号审核，不会展示给其他玩家'
    });
  } catch (err) {
    console.error('读取实名状态失败:', err.message);
    return fail(res, '实名状态加载失败，请稍后重试', 500);
  }
});

router.post('/profile/real-name', auth, active, async (req, res) => {
  const realName = typeof req.body.real_name === 'string' ? req.body.real_name.trim() : '';
  if (!REAL_NAME_RE.test(realName)) {
    return fail(res, '请输入 2–50 个字符的真实姓名（中文或英文，可含空格与·）', 422, 'INVALID_REAL_NAME');
  }
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [mine] = await conn.query(
      'SELECT id, status FROM real_name_reviews WHERE user_id = ? FOR UPDATE', [req.user.id]
    );
    if (mine[0] && mine[0].status === 'approved') {
      await conn.rollback();
      return fail(res, '实名已通过，如需修改请联系客服', 409, 'REAL_NAME_LOCKED');
    }
    if (mine[0] && mine[0].status === 'pending') {
      await conn.rollback();
      return fail(res, '实名正在审核中，请等待审核结果', 409, 'REAL_NAME_PENDING');
    }
    // 该姓名是否已被其他账号通过
    const [taken] = await conn.query(
      `SELECT user_id FROM real_name_reviews
       WHERE real_name = ? AND status = 'approved' AND user_id <> ? FOR UPDATE`,
      [realName, req.user.id]
    );
    if (taken.length) {
      await conn.rollback();
      return fail(res, '该姓名已绑定其他账号，无法使用', 409, 'REAL_NAME_TAKEN');
    }
    if (mine[0]) {
      await conn.query(
        `UPDATE real_name_reviews
         SET real_name = ?, status = 'pending', remark = NULL, reviewed_by = NULL, reviewed_at = NULL
         WHERE user_id = ?`,
        [realName, req.user.id]
      );
    } else {
      await conn.query(
        'INSERT INTO real_name_reviews (user_id, real_name, status) VALUES (?, ?, \'pending\')',
        [req.user.id, realName]
      );
    }
    await conn.commit();
    return ok(res, { status: 'pending', status_text: realNameStatusText('pending'), real_name: realName });
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    console.error('提交实名失败:', err.message);
    return fail(res, '实名提交失败，请稍后重试', 500);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.imageType = imageType;
