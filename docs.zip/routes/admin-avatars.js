'use strict';
// ============================================
// 26牛牛 - 官方头像库管理端 API（仅管理员）
// 分类: GET/POST   /api/admin/avatar-categories
//       PUT        /api/admin/avatar-categories/:id
//       POST       /api/admin/avatar-categories/:id/status
// 头像: GET/POST   /api/admin/avatars
//       POST       /api/admin/avatars/upload
//       PUT        /api/admin/avatars/:id
//       POST       /api/admin/avatars/:id/status
//       DELETE     /api/admin/avatars/:id
// 说明:
//   - 普通用户不能上传 / 编辑 / 删除头像，只能挑选已启用头像（/api/avatars/select）
//   - 上传图片经 checkImage 校验（大小 + MIME + 魔数 + 尺寸），只允许 JPG/JPEG/PNG/WEBP
//   - 全部参数化 SQL；不返回、不记录任何密钥或哈希
// ============================================
const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');
const { checkImage } = require('../utils/imageCheck');
const { toPublicPath } = require('../utils/avatar');

const router = express.Router();
router.use(auth, requireRole('admin'));

const AVATAR_DIR = path.join(__dirname, '..', 'public', 'assets', 'avatars', 'official');
const PUBLIC_PREFIX = '/assets/avatars/official/';
const MAX_AVATARS = 500;
const MAX_CATEGORIES = 50;
const IMG_EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 3 * 1024 * 1024, files: 1, fields: 8 }
});

function toInt(v) { const n = Number(v); return Number.isSafeInteger(n) && n > 0 ? n : null; }
function toSort(v) { const n = Number(v); return Number.isFinite(n) ? Math.max(0, Math.min(9999, Math.trunc(n))) : 0; }
function toText(v, max) { return String(v == null ? '' : v).trim().slice(0, max); }
function toBool(v) { return (v === true || v === 1 || v === '1' || v === 'true') ? 1 : 0; }

// ---------- 头像分类 ----------
router.get('/admin/avatar-categories', async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      'SELECT id, name, sort_order, is_active, created_at, updated_at ' +
      'FROM avatar_categories ORDER BY sort_order ASC, id ASC LIMIT 200'
    );
    return ok(res, { categories: rows, max: MAX_CATEGORIES });
  } catch (e) {
    console.error('[admin/avatar-categories]', e.message);
    return fail(res, '获取头像分类失败', 500);
  }
});

router.post('/admin/avatar-categories', async (req, res) => {
  const name = toText(req.body.name, 32);
  if (!name) return fail(res, '分类名称不能为空');
  try {
    const [[cnt]] = await db.promise().query('SELECT COUNT(*) AS c FROM avatar_categories');
    if (cnt.c >= MAX_CATEGORIES) return fail(res, '分类数量已达上限（' + MAX_CATEGORIES + '）', 409);
    const [r] = await db.promise().query(
      'INSERT INTO avatar_categories (name, sort_order, is_active) VALUES (?, ?, ?)',
      [name, toSort(req.body.sort_order), req.body.is_active === undefined ? 1 : toBool(req.body.is_active)]
    );
    await writeAdminLog({ adminId: req.user.id, action: 'avatar_category_create', detail: { id: r.insertId, name } });
    return ok(res, { id: r.insertId });
  } catch (e) {
    console.error('[admin/avatar-categories:create]', e.message);
    return fail(res, '新增分类失败', 500);
  }
});

router.put('/admin/avatar-categories/:id', async (req, res) => {
  const id = toInt(req.params.id);
  if (!id) return fail(res, '分类不存在', 404);
  const name = toText(req.body.name, 32);
  if (!name) return fail(res, '分类名称不能为空');
  try {
    const [r] = await db.promise().query(
      'UPDATE avatar_categories SET name = ?, sort_order = ? WHERE id = ?',
      [name, toSort(req.body.sort_order), id]
    );
    if (!r.affectedRows) return fail(res, '分类不存在', 404);
    await writeAdminLog({ adminId: req.user.id, action: 'avatar_category_update', detail: { id, name } });
    return ok(res, { id, name });
  } catch (e) {
    console.error('[admin/avatar-categories:update]', e.message);
    return fail(res, '更新分类失败', 500);
  }
});

router.post('/admin/avatar-categories/:id/status', async (req, res) => {
  const id = toInt(req.params.id);
  if (!id) return fail(res, '分类不存在', 404);
  const active = toBool(req.body.is_active);
  try {
    const [r] = await db.promise().query('UPDATE avatar_categories SET is_active = ? WHERE id = ?', [active, id]);
    if (!r.affectedRows) return fail(res, '分类不存在', 404);
    await writeAdminLog({
      adminId: req.user.id,
      action: active ? 'avatar_category_enable' : 'avatar_category_disable',
      detail: { id }
    });
    return ok(res, { id, is_active: active });
  } catch (e) {
    console.error('[admin/avatar-categories:status]', e.message);
    return fail(res, '更新头像分类状态失败', 500);
  }
});

// ---------- 头像 ----------
router.get('/admin/avatars', async (req, res) => {
  try {
    const catId = toInt(req.query.category_id);
    const params = [];
    let sql = 'SELECT a.id, a.name, a.image_path, a.category_id, a.sort_order, a.is_active, a.allow_users, ' +
      'a.created_at, a.updated_at, c.name AS category_name, ' +
      '(SELECT COUNT(*) FROM users u WHERE u.avatar_id = a.id) AS used_count ' +
      'FROM avatars a LEFT JOIN avatar_categories c ON c.id = a.category_id WHERE 1=1';
    if (catId) { sql += ' AND a.category_id = ?'; params.push(catId); }
    sql += ' ORDER BY a.sort_order ASC, a.id ASC LIMIT 500';
    const [rows] = await db.promise().query(sql, params);
    return ok(res, { avatars: rows, max: MAX_AVATARS });
  } catch (e) {
    console.error('[admin/avatars]', e.message);
    return fail(res, '获取头像列表失败', 500);
  }
});

router.post('/admin/avatars', async (req, res) => {
  const name = toText(req.body.name, 80);
  const imagePath = toPublicPath(req.body.image_path);
  if (!name) return fail(res, '头像名称不能为空');
  if (!imagePath) return fail(res, '请填写头像图片路径（站内相对路径，如 /assets/avatars/official/xxx.jpg）');
  try {
    const [[cnt]] = await db.promise().query('SELECT COUNT(*) AS c FROM avatars');
    if (cnt.c >= MAX_AVATARS) return fail(res, '头像数量已达上限（' + MAX_AVATARS + '）', 409);
    const catId = toInt(req.body.category_id);
    const [r] = await db.promise().query(
      'INSERT INTO avatars (name, category_id, image_path, sort_order, is_active, allow_users) VALUES (?, ?, ?, ?, ?, ?)',
      [name, catId, imagePath, toSort(req.body.sort_order),
        req.body.is_active === undefined ? 1 : toBool(req.body.is_active),
        req.body.allow_users === undefined ? 1 : toBool(req.body.allow_users)]
    );
    await writeAdminLog({ adminId: req.user.id, action: 'avatar_create', detail: { id: r.insertId, name, image_path: imagePath } });
    return ok(res, { id: r.insertId });
  } catch (e) {
    console.error('[admin/avatars:create]', e.message);
    return fail(res, '新增头像失败', 500);
  }
});

// 上传图片 → 自动落盘到 public/assets/avatars/official/ 并入库
router.post('/admin/avatars/upload', function (req, res) {
  upload.single('file')(req, res, async function (err) {
    if (err) {
      const msg = err.code === 'LIMIT_FILE_SIZE' ? '头像图片不能超过 3MB' : '头像上传失败，请重新选择图片';
      return fail(res, msg);
    }
    if (!req.file || !req.file.buffer) return fail(res, '请选择要上传的头像图片');
    const chk = checkImage(req.file.buffer, { maxBytes: 3 * 1024 * 1024, mimeTypes: ['image/jpeg', 'image/png', 'image/webp'] });
    if (!chk.ok) return fail(res, chk.message || '头像上传失败，请重新选择图片');
    const name = toText(req.body.name, 80) || '官方头像';
    const ext = IMG_EXT[chk.mime];
    if (!ext) return fail(res, '仅支持 JPG / JPEG / PNG / WEBP 图片');
    const fileName = 'official_' + Date.now() + '_' + require('crypto').randomBytes(4).toString('hex') + ext;
    const dest = path.join(AVATAR_DIR, fileName);
    try {
      const [[cnt]] = await db.promise().query('SELECT COUNT(*) AS c FROM avatars');
      if (cnt.c >= MAX_AVATARS) return fail(res, '头像数量已达上限（' + MAX_AVATARS + '）', 409);
      await fs.promises.mkdir(AVATAR_DIR, { recursive: true });
      await fs.promises.writeFile(dest, req.file.buffer, { flag: 'wx' });
      const imagePath = PUBLIC_PREFIX + fileName;
      const catId = toInt(req.body.category_id);
      const [r] = await db.promise().query(
        'INSERT INTO avatars (name, category_id, image_path, sort_order, is_active, allow_users) VALUES (?, ?, ?, ?, ?, ?)',
        [name, catId, imagePath, toSort(req.body.sort_order),
          req.body.is_active === undefined ? 1 : toBool(req.body.is_active),
          req.body.allow_users === undefined ? 1 : toBool(req.body.allow_users)]
      );
      await writeAdminLog({ adminId: req.user.id, action: 'avatar_upload', detail: { id: r.insertId, name, image_path: imagePath } });
      return ok(res, { id: r.insertId, image_path: imagePath });
    } catch (e) {
      await fs.promises.unlink(dest).catch(function () {});
      console.error('[admin/avatars:upload]', e.message);
      return fail(res, '头像保存失败，请重试', 500);
    }
  });
});
router.put('/admin/avatars/:id', async (req, res) => {
  const id = toInt(req.params.id);
  if (!id) return fail(res, '头像不存在', 404);
  const name = toText(req.body.name, 80);
  if (!name) return fail(res, '头像名称不能为空');
  try {
    const [rows] = await db.promise().query('SELECT id FROM avatars WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return fail(res, '头像不存在', 404);
    const catId = toInt(req.body.category_id);
    const sets = ['name = ?', 'category_id = ?', 'sort_order = ?'];
    const params = [name, catId, toSort(req.body.sort_order)];
    if (req.body.image_path !== undefined) {
      const p = toPublicPath(req.body.image_path);
      if (!p) return fail(res, '头像图片路径不合法');
      sets.push('image_path = ?'); params.push(p);
    }
    if (req.body.allow_users !== undefined) { sets.push('allow_users = ?'); params.push(toBool(req.body.allow_users)); }
    params.push(id);
    await db.promise().query('UPDATE avatars SET ' + sets.join(', ') + ' WHERE id = ?', params);
    await writeAdminLog({ adminId: req.user.id, action: 'avatar_update', detail: { id, name } });
    return ok(res, { id, name });
  } catch (e) {
    console.error('[admin/avatars:update]', e.message);
    return fail(res, '更新头像失败', 500);
  }
});

router.post('/admin/avatars/:id/status', async (req, res) => {
  const id = toInt(req.params.id);
  if (!id) return fail(res, '头像不存在', 404);
  const active = toBool(req.body.is_active);
  try {
    const [r] = await db.promise().query('UPDATE avatars SET is_active = ? WHERE id = ?', [active, id]);
    if (!r.affectedRows) return fail(res, '头像不存在', 404);
    await writeAdminLog({
      adminId: req.user.id,
      action: active ? 'avatar_enable' : 'avatar_disable',
      detail: { id, note: active ? '已启用' : '已停用（普通用户不再可选，已使用该头像的用户保持不变）' }
    });
    return ok(res, { id, is_active: active });
  } catch (e) {
    console.error('[admin/avatars:status]', e.message);
    return fail(res, '更新头像状态失败', 500);
  }
});

// 删除头像：仍被用户使用时不允许删除，避免大量用户头像失效
router.delete('/admin/avatars/:id', async (req, res) => {
  const id = toInt(req.params.id);
  if (!id) return fail(res, '头像不存在', 404);
  try {
    const [[used]] = await db.promise().query('SELECT COUNT(*) AS c FROM users WHERE avatar_id = ?', [id]);
    if (used.c > 0) {
      return res.status(409).json({
        success: false,
        message: '该头像正在被 ' + used.c + ' 位用户使用，无法删除；建议改为「停用」（停用后用户头像不会失效）',
        data: { used_count: used.c }
      });
    }
    const [r] = await db.promise().query('DELETE FROM avatars WHERE id = ?', [id]);
    if (!r.affectedRows) return fail(res, '头像不存在', 404);
    await writeAdminLog({ adminId: req.user.id, action: 'avatar_delete', detail: { id } });
    return ok(res, { id });
  } catch (e) {
    console.error('[admin/avatars:delete]', e.message);
    return fail(res, '删除头像失败', 500);
  }
});

module.exports = router;
