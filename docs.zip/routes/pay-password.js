'use strict';
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const pay = require('../utils/payPassword');
const { writeAdminLog } = require('../utils/adminAudit');
router.get('/pay-password/status', auth, async function (req, res) {
  try {
    const r = (await db.promise().query('SELECT pay_password_hash FROM users WHERE id=? LIMIT 1', [req.user.id]))[0][0];
    return ok(res, { set: Boolean(r && r.pay_password_hash) });
  } catch (e) { return fail(res, '状态读取失败', 500); }
});
router.post('/pay-password/set', auth, async function (req, res) {
  const a = String((req.body && req.body.pay_password) == null ? '' : req.body.pay_password);
  const b = String((req.body && req.body.confirm_password) == null ? '' : req.body.confirm_password);
  if (!/^\d{6}$/.test(a)) return fail(res, '支付密码必须为6位数字', 422, 'INVALID_FORMAT');
  if (a !== b) return fail(res, '两次支付密码不一致', 422, 'MISMATCH');
  try {
    const hash = await bcrypt.hash(a, 10);
    await db.promise().query('UPDATE users SET pay_password_hash=?,pay_password_set_at=NOW() WHERE id=? LIMIT 1', [hash, req.user.id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: req.user.id, action: 'pay_password_set', detail: 'set' });
    return ok(res, null, '支付密码已设置');
  } catch (e) { return fail(res, '设置失败', 500); }
});
router.post('/pay-password/change', auth, async function (req, res) {
  const oldp = String((req.body && req.body.old_password) == null ? '' : req.body.old_password);
  const a = String((req.body && req.body.pay_password) == null ? '' : req.body.pay_password);
  const b = String((req.body && req.body.confirm_password) == null ? '' : req.body.confirm_password);
  if (!/^\d{6}$/.test(a)) return fail(res, '支付密码必须为6位数字', 422, 'INVALID_FORMAT');
  if (a !== b) return fail(res, '两次支付密码不一致', 422, 'MISMATCH');
  try {
    const chk = await pay.verifyPayPassword(req.user.id, oldp);
    if (!chk.ok) return fail(res, '原支付密码错误', 403, 'WRONG_OLD');
    const hash = await bcrypt.hash(a, 10);
    await db.promise().query('UPDATE users SET pay_password_hash=?,pay_password_set_at=NOW() WHERE id=? LIMIT 1', [hash, req.user.id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: req.user.id, action: 'pay_password_change', detail: 'change' });
    return ok(res, null, '支付密码已修改');
  } catch (e) { return fail(res, '修改失败', 500); }
});
module.exports = router;
