/* routes/support-guest.js — 游客在线客服（并入现有客服系统，channel='support'）
 *
 * 设计：
 * - 无需登录/注册。游客凭 32 位十六进制能力令牌（crypto 随机）读写自己的会话。
 * - 消息写入现有 chat_messages：channel='support'，user_id=NULL，guest_token=令牌，
 *   sender_role='guest'；管理员回复同令牌、sender_role='admin'。
 * - 不与任何登录用户的会话交叉（登录用户消息 user_id 非空，互不可见）。
 * - 自包含内存限流（IP / IP+token 维度），不依赖外部模块。
 */
const express = require('express');
const crypto = require('crypto');
const rawDb = require('../config/db');
const db = typeof rawDb.promise === 'function' ? rawDb.promise() : rawDb;

const router = express.Router();

const TOKEN_RE = /^[a-f0-9]{32}$/;
const GUEST_NAME = (token) => '游客' + token.slice(-4);

/* ---- 简单内存限流 ---- */
const buckets = new Map();
function allow(key, max, windowMs) {
  const now = Date.now();
  const b = buckets.get(key) || { count: 0, reset: now + windowMs };
  if (now > b.reset) { b.count = 0; b.reset = now + windowMs; }
  b.count += 1;
  buckets.set(key, b);
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) if (now > v.reset) buckets.delete(k);
  }
  return b.count <= max;
}
const clientIp = (req) => {
  const xff = req.headers && req.headers['x-forwarded-for'];
  if (typeof xff === 'string' && xff.length) return xff.split(',')[0].trim();
  return (req.socket && req.socket.remoteAddress) || 'unknown';
};

/* 创建游客会话：返回能力令牌（令牌本身不入库，凭它读写本线程） */
router.post('/session', (req, res) => {
  if (!allow('s:' + clientIp(req), 5, 60000)) {
    return res.status(429).json({ error: '请求过于频繁，请稍后再试' });
  }
  const token = crypto.randomBytes(16).toString('hex');
  res.json({ token, username: GUEST_NAME(token) });
});

/* 游客读取自己的会话消息（含管理员/客服回复） */
router.get('/messages', async (req, res) => {
  try {
    const token = String((req.query && req.query.token) || '');
    if (!TOKEN_RE.test(token)) {
      return res.status(422).json({ error: '会话无效，请重新开始咨询' });
    }
    if (!allow('r:' + clientIp(req) + ':' + token, 60, 60000)) {
      return res.status(429).json({ error: '请求过于频繁，请稍后再试' });
    }
    const [rows] = await db.query(
      `SELECT id, message_type, content, sender_role, created_at
         FROM chat_messages
        WHERE channel = 'support' AND guest_token = ?
        ORDER BY id ASC
        LIMIT 200`,
      [token]
    );
    res.json({
      messages: rows.map(row => Object.assign({}, row, {
        username: row.sender_role === 'guest' ? GUEST_NAME(token) : '客服'
      })),
      username: GUEST_NAME(token)
    });
  } catch (e) {
    console.error('guest messages error:', e.message);
    res.status(500).json({ error: '加载失败，请重试' });
  }
});

/* 游客发送消息 */
router.post('/messages', async (req, res) => {
  try {
    const token = String((req.body && req.body.token) || '');
    const content = String((req.body && req.body.content) || '').trim();
    if (!TOKEN_RE.test(token)) {
      return res.status(422).json({ error: '会话无效，请重新开始咨询' });
    }
    if (!content) return res.status(422).json({ error: '请输入内容' });
    if (content.length > 500) return res.status(422).json({ error: '内容过长（最多 500 字）' });
    if (!allow('m:' + clientIp(req) + ':' + token, 10, 60000)) {
      return res.status(429).json({ error: '发送太频繁，请稍后再试' });
    }
    const [r] = await db.query(
      `INSERT INTO chat_messages (channel, user_id, guest_token, message_type, content, sender_role)
       VALUES ('support', NULL, ?, 'text', ?, 'guest')`,
      [token, content]
    );
    res.json({ ok: true, id: r.insertId });
  } catch (e) {
    console.error('guest send error:', e.message);
    res.status(500).json({ error: '发送失败，请重试' });
  }
});

module.exports = router;
