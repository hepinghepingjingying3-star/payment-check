// ============================================
// 26牛牛 - 管理员 OTP 管理路由（手动 WhatsApp 发送模式）
// 包含:
//   - GET  /api/admin/otp                 验证码状态列表（不含明文）
//   - POST /api/admin/otp/:id/reveal      一次性领取（事务内审计并清除临时明文）
//   - GET  /api/admin/otp/logs            OTP 操作审计日志（不含明文）
//   - POST /api/admin/otp/:id/mark-sent   标记已发送（清空明文）
//   - POST /api/admin/otp/:id/regenerate  重新生成（旧码立即失效）
//   - POST /api/admin/otp/cleanup         清理过期记录明文
// 权限:
//   - 路由级统一守卫要求 JWT + 当前数据库角色 admin；客服不能访问 OTP 管理
//   - 普通用户访问一律 403
//   - 每次查看 / 操作都写入 otp_audit_logs（operator_id + 手机号 + 时间 + 类型）
//   - 日志中绝不保存 OTP 明文
// 明文策略:
//   - 明文领取成功即清除 otp_plain_tmp，后续列表和重复领取均不返回明文
//   - 用户验证成功、过期、锁定都会立即清空明文
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { OTP_CONFIG, OTP_STATUS_TEXT } = require('../config/otp');
const OTP = require('../utils/otp');
const { clientIp, maskPhone, ok, fail } = require('../utils/request');
const { audit, expireStale } = require('./otp');

function statusText(s) { return OTP_STATUS_TEXT[s] || s; }

/** 列表永不返回明文；是否可领取由服务端状态决定。 */
function otpOut(r) {
  return {
    id: Number(r.id),
    phone: r.phone,
    phone_masked: maskPhone(r.phone),
    code_available: !!(r.status === 'pending' && r.code_available && OTP.secondsLeft(r.expires_at) > 0),
    status: r.status,
    status_text: statusText(r.status),
    attempts: Number(r.attempts || 0),
    max_attempts: Number(r.max_attempts || OTP_CONFIG.MAX_ATTEMPTS),
    expires_at: r.expires_at,
    seconds_left: OTP.secondsLeft(r.expires_at),
    last_sent_at: r.last_sent_at,
    verified_at: r.verified_at || null,
    sent_by: r.sent_by || null,
    created_at: r.created_at
  };
}

// 管理端所有响应禁止浏览器/代理缓存（包括错误响应）。
router.use('/admin/otp', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// 明文领取与审计、清除必须原子提交；审计失败不得返回明文。
router.post('/admin/otp/:id/reveal', auth, requireRole('admin', 'support'), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return fail(res, '无效的验证码ID');
  let conn;
  try {
    conn = await db.promise().getConnection();
    await conn.beginTransaction();
    const [rows] = await conn.query(
      `SELECT id, phone, status, otp_plain_tmp, expires_at,
              (expires_at > NOW()) AS unexpired
       FROM registration_otp WHERE id = ? FOR UPDATE`, [id]
    );
    const row = rows[0];
    if (!row || row.status !== 'pending' || !row.unexpired || !row.otp_plain_tmp) {
      await conn.rollback();
      return fail(res, '验证码已领取、过期或不可用，请刷新列表', 409, 'OTP_NOT_AVAILABLE');
    }
    await conn.query(
      `INSERT INTO otp_audit_logs (operator_id, target_phone, otp_id, action, detail, ip)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [req.user.id, row.phone, row.id, 'view', '管理员一次性领取验证码', clientIp(req)]
    );
    await conn.query('UPDATE registration_otp SET otp_plain_tmp = NULL WHERE id = ?', [id]);
    await conn.commit();
    return ok(res, { id, code: row.otp_plain_tmp, seconds_left: OTP.secondsLeft(row.expires_at) });
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    // 不输出驱动错误，避免 SQL 参数中包含 OTP。
    console.error('OTP 领取事务失败');
    return fail(res, '验证码领取失败，请重新加载', 500);
  } finally {
    if (conn) conn.release();
  }
});

// ============================================
// GET /api/admin/otp?status=pending&limit=50
// ============================================
router.get('/admin/otp', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    await expireStale();
    const status = String(req.query.status || 'pending');
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
    const allowed = ['pending', 'sent', 'verified', 'expired', 'locked', 'all'];
    const st = allowed.includes(status) ? status : 'pending';

    const params = [];
    let where = '';
    if (st !== 'all') { where = 'WHERE status = ?'; params.push(st); }
    params.push(limit);

    const [rows] = await db.promise().query(
      `SELECT id, phone, (otp_plain_tmp IS NOT NULL) AS code_available, status, attempts, max_attempts,
              expires_at, last_sent_at, verified_at, sent_by, created_at
       FROM registration_otp ${where} ORDER BY id DESC LIMIT ?`,
      params
    );

    // 逐目标审计，失败时不返回列表中的手机号。
    if (rows.length) {
      await db.promise().query(
        `INSERT INTO otp_audit_logs (operator_id, target_phone, otp_id, action, detail, ip) VALUES ?`,
        [rows.map(r => [req.user.id, r.phone, r.id, 'list_view', '管理员查看验证码状态', clientIp(req)])]
      );
    }

    return ok(res, {
      list: rows.map(r => otpOut(r)),
      status: st,
      ttl_seconds: OTP_CONFIG.TTL_SECONDS,
      cooldown_seconds: OTP_CONFIG.RESEND_COOLDOWN_SECONDS,
      note: '验证码需手动领取一次；领取即清除数据库临时明文，页面隐藏后不可再次查看'
    });
  } catch (err) {
    console.error('获取OTP列表失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// GET /api/admin/otp/logs?limit=100  审计日志（不含明文）
// ============================================
router.get('/admin/otp/logs', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit, 10) || 100, 300);
    const [rows] = await db.promise().query(
      `SELECT l.id, l.operator_id, u.username AS operator_username, l.target_phone,
              l.otp_id, l.action, l.detail, l.ip, l.created_at
       FROM otp_audit_logs l
       LEFT JOIN users u ON u.id = l.operator_id
       ORDER BY l.id DESC LIMIT ?`,
      [limit]
    );
    return ok(res, {
      list: rows.map(r => ({
        id: Number(r.id),
        operator_id: r.operator_id,
        operator_username: r.operator_username || (r.operator_id ? '未知操作者' : '用户自助'),
        target_phone_masked: r.target_phone ? maskPhone(r.target_phone) : null,
        otp_id: r.otp_id,
        action: r.action,
        detail: r.detail,
        ip: r.ip,
        created_at: r.created_at
      })),
      note: '日志中不保存验证码明文'
    });
  } catch (err) {
    console.error('获取OTP日志失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// POST /api/admin/otp/:id/mark-sent  标记已发送（清空明文）
// ============================================
router.post('/admin/otp/:id/mark-sent', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return fail(res, '无效的验证码ID');

    const [rows] = await db.promise().query(
      'SELECT id, phone, status FROM registration_otp WHERE id = ?', [id]
    );
    if (rows.length === 0) return fail(res, '验证码记录不存在', 404);

    await db.promise().query(
      `UPDATE registration_otp
       SET status = CASE WHEN status = 'pending' THEN 'sent' ELSE status END,
           sent_by = ?, otp_plain_tmp = NULL
       WHERE id = ?`,
      [req.user.id, id]
    );
    await audit(req.user.id, rows[0].phone, id, 'mark_sent', '管理员标记已发送并清除明文', clientIp(req));

    return ok(res, { id: id, status: 'sent', status_text: statusText('sent') });
  } catch (err) {
    console.error('标记已发送失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// POST /api/admin/otp/:id/regenerate  重新生成（旧码立即失效）
// ============================================
router.post('/admin/otp/:id/regenerate', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return fail(res, '无效的验证码ID');

    const [rows] = await db.promise().query(
      'SELECT id, phone FROM registration_otp WHERE id = ?', [id]
    );
    if (rows.length === 0) return fail(res, '验证码记录不存在', 404);
    const phone = rows[0].phone;

    // 1) 旧码立即失效
    await db.promise().query(
      `UPDATE registration_otp SET status = 'expired', otp_plain_tmp = NULL
       WHERE phone = ? AND status IN ('pending','sent')`,
      [phone]
    );
    await audit(req.user.id, phone, id, 'expire', '管理员重新生成前作废旧验证码', clientIp(req));

    // 2) 生成新码
    const code = OTP.generateOtp();
    const expiresAt = OTP.sqlDateTime(new Date(Date.now() + OTP_CONFIG.TTL_SECONDS * 1000));
    const [ins] = await db.promise().query(
      `INSERT INTO registration_otp
        (phone, otp_hash, otp_plain_tmp, status, attempts, max_attempts, expires_at, last_sent_at, sent_by, created_ip)
       VALUES (?, ?, ?, 'pending', 0, ?, ?, NOW(), ?, ?)`,
      [phone, OTP.hashOtp(phone, code), code, OTP_CONFIG.MAX_ATTEMPTS, expiresAt, req.user.id, clientIp(req)]
    );
    await audit(req.user.id, phone, ins.insertId, 'regenerate', '管理员重新生成验证码', clientIp(req));

    return ok(res, {
      id: Number(ins.insertId),
      phone: phone,
      phone_masked: maskPhone(phone),
      code_available: true,
      status: 'pending',
      status_text: statusText('pending'),
      expires_at: expiresAt,
      seconds_left: OTP_CONFIG.TTL_SECONDS
    });
  } catch (err) {
    console.error('重新生成验证码失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// POST /api/admin/otp/cleanup  清理过期明文（维护用）
// ============================================
router.post('/admin/otp/cleanup', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    await expireStale();
    const [r] = await db.promise().query(
      `UPDATE registration_otp SET otp_plain_tmp = NULL
       WHERE otp_plain_tmp IS NOT NULL AND (status <> 'pending' OR expires_at < NOW())`
    );
    await audit(req.user.id, null, null, 'cleanup', '清理明文验证码 rows=' + (r.affectedRows || 0), clientIp(req));
    return ok(res, { cleaned: r.affectedRows || 0 });
  } catch (err) {
    console.error('清理验证码失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

module.exports = router;
module.exports.statusText = statusText;