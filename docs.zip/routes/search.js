// ============================================
// 26牛牛 - 全局搜索路由
//   - GET /api/search?q=关键词
// 范围（严格限制）:
//   - 游戏（config/games.js）
//   - 公告（utils/content.js 合并后的有效公告）
//   - 玩法介绍（config/tutorials.js）
// 禁止:
//   - 绝不搜索 / 返回其他玩家（用户名、手机号、邮箱等一律不可搜索）
//   - 不返回任何用户数据
// ============================================

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const GAMES = require('../config/games');
const T = require('../config/tutorials');
const content = require('../utils/content');
const { ok, fail } = require('../utils/request');

function hit(text, q) {
  return String(text || '').toLowerCase().indexOf(q) >= 0;
}

router.get('/search', auth, async (req, res) => {
  try {
    const raw = String(req.query.q || '').trim();
    const scope = String(req.query.scope || 'all');
    if (!raw) return ok(res, { q: '', results: [], total: 0 });
    if (raw.length > 40) return fail(res, '搜索关键词过长（最多 40 字）');

    const q = raw.toLowerCase();
    const results = [];

    // 1) 游戏
    if (scope === 'all' || scope === 'game') {
      GAMES.listGames().forEach(g => {
        if (hit(g.name, q) || hit(g.short_name, q) || hit(g.intro, q) || hit(g.description, q)) {
          results.push({
            type: 'game',
            type_text: '游戏',
            id: g.id,
            title: g.name,
            desc: g.intro || '',
            link: g.entry && g.entry.type === 'chat' ? '/group-chat.html' : '/lobby.html'
          });
        }
      });
    }

    // 2) 玩法介绍
    if (scope === 'all' || scope === 'tutorial') {
      T.listTutorials().forEach(t => {
        const full = T.getTutorial(t.id);
        const txt = full ? T.tutorialSearchText(full) : t.title;
        if (hit(t.title, q) || hit(t.subtitle, q) || hit(txt, q)) {
          results.push({
            type: 'tutorial',
            type_text: '玩法介绍',
            id: t.id,
            title: t.title,
            desc: t.subtitle || '',
            link: '/tutorial.html?id=' + encodeURIComponent(t.id)
          });
        }
      });
    }

    // 3) 公告
    if (scope === 'all' || scope === 'announcement') {
      const list = await content.loadAnnouncements();
      list.forEach(a => {
        if (hit(a.title, q) || hit(a.summary, q) || hit(a.content, q)) {
          results.push({
            type: 'announcement',
            type_text: '公告',
            id: a.id,
            title: a.title,
            desc: String(a.summary || a.content || '').replace(/\s+/g, ' ').slice(0, 60),
            link: '/announcement.html?id=' + encodeURIComponent(a.id)
          });
        }
      });
    }

    return ok(res, {
      q: raw,
      results: results.slice(0, 40),
      total: results.length,
      scope_note: '搜索范围仅包含游戏 / 玩法介绍 / 公告，不提供玩家搜索'
    });
  } catch (err) {
    console.error('搜索失败:', err.message);
    return fail(res, '搜索失败，请稍后重试', 500);
  }
});

module.exports = router;