'use strict';
// ============================================
// 26牛牛 - 管理后台扩展路由
// 覆盖：控制台运营统计 / 对局管理 / 游戏入口 / 系统通知 / 管理员管理 / 客服管理
//
// 权限：完全复用现有系统，不新建第二套权限体系
//   - 全局 middleware/admin-boundary.js 已对 /api/admin/** 强制 auth + requireRole('admin')
//   - 本文件再叠加一层 router.use('/admin', auth, requireRole('admin')) 纵深防御
//   - 角色来自数据库 users.role，绝不比较 username 字符串
//
// 数据原则：全部来自真实数据库；表缺失时返回 null 并说明原因，绝不编造数字。
// 隐私：响应不含 password_hash / pay_password_hash / OTP / 查询码 / 密钥。
// ============================================

const express = require('express');
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail, safeInternalPath } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');

const router = express.Router();

// ---------- 守卫（纵深防御） ----------
router.use('/admin', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
}, auth, requireRole('admin'));

// ---------- 工具 ----------
async function hasTable(name) {
  const [rows] = await db.promise().query(
    'SELECT TABLE_NAME FROM information_schema.tables WHERE table_schema = ? AND table_name = ?',
    [process.env.DB_NAME, name]
  );
  return rows.length > 0;
}

async function countOf(sql, params) {
  const [rows] = await db.promise().query(sql, params || []);
  return Number(rows[0] && rows[0].c) || 0;
}

function text(v, max) {
  return String(v === null || v === undefined ? '' : v).trim().slice(0, max);
}

function posInt(v) {
  const n = Number(v);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

function paging(req) {
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
  const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
  return { limit, offset };
}

/** 只接受站内 /assets/ 路径，禁止外链（防止后台被当成钓鱼跳板） */
function safeImage(v) {
  const p = safeInternalPath(String(v || '').trim());
  if (!p) return null;
  return p.indexOf('/assets/') === 0 ? p : null;
}

const ROUND_STATUS = {
  WAITING: '等待中', BANKER_BIDDING: '庄家竞价', BETTING: '下注中', RED_PACKET: '发包',
  CLAIMING: '抢包中', CALCULATING: '结算中', SETTLEMENT: '结算中', ENDED: '已结束'
};

const NOTICE_CATEGORY = ['system', 'activity', 'referral', 'support', 'game'];

// ============================================
// GET /api/admin/ops/overview —— 控制台扩展统计（全部真实查询）
// ============================================
router.get('/admin/ops/overview', async (req, res) => {
  try {
    const out = {
      rounds: { total: null, today: null, live: null, players_today: null },
      games: { total: null, active: null },
      notices: { total: null, sent: null, users_7d: null },
      staff: { admins: null, supports: null },
      support: { threads: null, messages_24h: null, reports: null },
      wallets: { recharge_pending: null, withdraw_pending: null, game_balance_total: null, cash_chips_total: null }
    };

    if (await hasTable('game_rounds')) {
      out.rounds.total = await countOf('SELECT COUNT(*) AS c FROM game_rounds');
      out.rounds.today = await countOf('SELECT COUNT(*) AS c FROM game_rounds WHERE created_at >= CURDATE()');
      out.rounds.live = await countOf("SELECT COUNT(*) AS c FROM game_rounds WHERE status NOT IN ('ENDED','WAITING')");
    }
    if (await hasTable('game_results')) {
      out.rounds.players_today = await countOf(
        'SELECT COUNT(DISTINCT user_id) AS c FROM game_results WHERE created_at >= CURDATE()');
    }
    if (await hasTable('games')) {
      out.games.total = await countOf('SELECT COUNT(*) AS c FROM games');
      out.games.active = await countOf('SELECT COUNT(*) AS c FROM games WHERE is_active = 1');
    }
    if (await hasTable('notifications')) {
      out.notices.total = await countOf('SELECT COUNT(*) AS c FROM notifications');
      out.notices.sent = await countOf('SELECT COUNT(*) AS c FROM notifications WHERE status = ?', ['published']);
      out.notices.users_7d = await countOf(
        'SELECT COUNT(DISTINCT user_id) AS c FROM notifications WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)');
    }
    out.staff.admins = await countOf("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'");
    out.staff.supports = await countOf("SELECT COUNT(*) AS c FROM users WHERE role = 'support'");
    if (await hasTable('chat_messages')) {
      out.support.messages_24h = await countOf(
        "SELECT COUNT(*) AS c FROM chat_messages WHERE channel = 'support' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
    }
    if (await hasTable('support_threads')) {
      out.support.threads = await countOf('SELECT COUNT(*) AS c FROM support_threads');
    }
    if (await hasTable('chat_reports')) {
      out.support.reports = await countOf("SELECT COUNT(*) AS c FROM chat_reports WHERE status = 'pending'");
    }
    if (await hasTable('recharge_orders')) {
      out.wallets.recharge_pending = await countOf("SELECT COUNT(*) AS c FROM recharge_orders WHERE status = 'PENDING'");
    }
    if (await hasTable('withdraw_requests')) {
      out.wallets.withdraw_pending = await countOf("SELECT COUNT(*) AS c FROM withdraw_requests WHERE status = 'PENDING'");
    }
    const [bal] = await db.promise().query(
      'SELECT COALESCE(SUM(game_balance),0) AS g, COALESCE(SUM(cash_chips),0) AS c FROM users');
    out.wallets.game_balance_total = Number(bal[0].g) || 0;
    out.wallets.cash_chips_total = Number(bal[0].c) || 0;

    return ok(res, out);
  } catch (err) {
    console.error('后台运营统计失败:', err.message);
    return fail(res, '运营统计加载失败，请稍后重试', 500);
  }
});

// ============================================
// 对局管理（只读，绝不修改历史结果）
// GET /api/admin/ops/rounds?q=&status=&from=&to=&limit=&offset=
// GET /api/admin/ops/rounds/:id
// ============================================
router.get('/admin/ops/rounds', async (req, res) => {
  try {
    if (!(await hasTable('game_rounds'))) {
      return ok(res, { available: false, list: [], total: 0, note: '当前系统没有对局表' });
    }
    const pg = paging(req);
    const where = [];
    const args = [];
    const q = text(req.query.q, 50);
    if (q) { where.push('(r.round_id LIKE ? OR r.id = ?)'); args.push('%' + q + '%', posInt(q) || -1); }
    const status = text(req.query.status, 20);
    if (status && ROUND_STATUS[status]) { where.push('r.status = ?'); args.push(status); }
    const from = text(req.query.from, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(from)) { where.push('r.created_at >= ?'); args.push(from + ' 00:00:00'); }
    const to = text(req.query.to, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(to)) { where.push('r.created_at <= ?'); args.push(to + ' 23:59:59'); }
    const sql = where.length ? ' WHERE ' + where.join(' AND ') : '';

    const total = await countOf('SELECT COUNT(*) AS c FROM game_rounds r' + sql, args);
    const [rows] = await db.promise().query(
      'SELECT r.id, r.round_id, r.room_id, r.status, r.banker_id, r.banker_bid, r.banker_pool, ' +
      'r.packet_type, r.created_at, r.updated_at, ' +
      '(SELECT COUNT(*) FROM game_results g WHERE g.round_id = r.round_id) AS player_count ' +
      'FROM game_rounds r' + sql + ' ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?',
      args.concat([pg.limit, pg.offset])
    );
    return ok(res, {
      available: true, total, limit: pg.limit, offset: pg.offset,
      list: rows.map((r) => ({
        id: Number(r.id), round_id: r.round_id,
        room_id: r.room_id === null ? null : Number(r.room_id),
        status: r.status, status_text: ROUND_STATUS[r.status] || r.status,
        banker_id: r.banker_id === null ? null : Number(r.banker_id),
        banker_bid: r.banker_bid === null ? null : String(r.banker_bid),
        banker_pool: r.banker_pool === null ? null : String(r.banker_pool),
        packet_type: r.packet_type,
        players: Number(r.player_count) || 0,
        created_at: r.created_at, updated_at: r.updated_at
      }))
    });
  } catch (err) {
    console.error('对局列表失败:', err.message);
    return fail(res, '对局列表加载失败，请稍后重试', 500);
  }
});

router.get('/admin/ops/rounds/:id', async (req, res) => {
  try {
    if (!(await hasTable('game_rounds'))) return fail(res, '当前系统没有对局表', 404);
    const id = posInt(req.params.id);
    if (!id) return fail(res, '对局不存在', 404);
    const [rows] = await db.promise().query('SELECT * FROM game_rounds WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return fail(res, '对局不存在', 404);
    const r = rows[0];
    let players = [];
    if (await hasTable('game_results')) {
      const [pr] = await db.promise().query(
        'SELECT g.user_id, u.username, g.role, g.packet_amount, g.is_winner, g.payout, g.net_payout, g.created_at ' +
        'FROM game_results g LEFT JOIN users u ON u.id = g.user_id ' +
        'WHERE g.round_id = ? ORDER BY g.id ASC LIMIT 200',
        [r.round_id]
      );
      players = pr.map((p) => ({
        user_id: p.user_id === null ? null : Number(p.user_id),
        username: p.username || null, role: p.role,
        packet_amount: String(p.packet_amount), is_winner: !!p.is_winner,
        payout: String(p.payout), net_payout: String(p.net_payout), created_at: p.created_at
      }));
    }
    return ok(res, {
      id: Number(r.id), round_id: r.round_id, room_id: r.room_id,
      status: r.status, status_text: ROUND_STATUS[r.status] || r.status,
      banker_id: r.banker_id === null ? null : Number(r.banker_id),
      banker_bid: r.banker_bid === null ? null : String(r.banker_bid),
      banker_pool: r.banker_pool === null ? null : String(r.banker_pool),
      packet_type: r.packet_type, result: r.result,
      created_at: r.created_at, updated_at: r.updated_at, players
    });
  } catch (err) {
    console.error('对局详情失败:', err.message);
    return fail(res, '对局详情加载失败，请稍后重试', 500);
  }
});


// ============================================
// 游戏管理：启用 / 停用 / 名称 / 排序 / 入口图片（不重建游戏核心）
// ============================================
router.get('/admin/ops/games', async (req, res) => {
  try {
    if (!(await hasTable('games'))) return ok(res, { available: false, list: [] });
    const [rows] = await db.promise().query(
      'SELECT id, game_key, name, description, entry_image, sort_order, is_active, created_at, updated_at ' +
      'FROM games ORDER BY sort_order ASC, id ASC'
    );
    return ok(res, {
      available: true,
      list: rows.map((g) => ({
        id: Number(g.id), key: g.game_key, name: g.name,
        description: g.description || null, entry_image: g.entry_image || null,
        sort_order: Number(g.sort_order) || 0, is_active: !!g.is_active,
        created_at: g.created_at, updated_at: g.updated_at
      }))
    });
  } catch (err) {
    console.error('游戏列表失败:', err.message);
    return fail(res, '游戏列表加载失败，请稍后重试', 500);
  }
});

router.post('/admin/ops/games', async (req, res) => {
  try {
    if (!(await hasTable('games'))) return fail(res, '游戏表不可用', 503);
    const key = text(req.body.key, 60);
    const name = text(req.body.name, 80);
    if (!key) return fail(res, '请填写游戏标识', 422);
    if (!name) return fail(res, '请填写游戏名称', 422);
    let image = null;
    if (req.body.entry_image) {
      image = safeImage(req.body.entry_image);
      if (!image) return fail(res, '入口图片必须是站内 /assets/ 路径', 422);
    }
    const [r] = await db.promise().query(
      'INSERT INTO games (game_key, name, description, entry_image, sort_order, is_active) VALUES (?,?,?,?,?,?)',
      [key, name, text(req.body.description, 255) || null, image,
        Number(req.body.sort_order) || 0, req.body.is_active === false ? 0 : 1]
    );
    await writeAdminLog({ adminId: req.user.id, action: 'game_create', targetUserId: null,
      detail: '新增游戏入口 ' + key + ' / ' + name });
    return ok(res, { id: Number(r.insertId) });
  } catch (err) {
    if (err && err.code === 'ER_DUP_ENTRY') return fail(res, '该游戏标识已存在', 409);
    console.error('新增游戏失败:', err.message);
    return fail(res, '新增游戏失败，请稍后重试', 500);
  }
});

router.put('/admin/ops/games/:id', async (req, res) => {
  try {
    if (!(await hasTable('games'))) return fail(res, '游戏表不可用', 503);
    const id = posInt(req.params.id);
    if (!id) return fail(res, '游戏不存在', 404);
    const name = text(req.body.name, 80);
    if (!name) return fail(res, '请填写游戏名称', 422);
    let image = null;
    if (req.body.entry_image) {
      image = safeImage(req.body.entry_image);
      if (!image) return fail(res, '入口图片必须是站内 /assets/ 路径', 422);
    }
    const [before] = await db.promise().query('SELECT name FROM games WHERE id = ? LIMIT 1', [id]);
    if (!before.length) return fail(res, '游戏不存在', 404);
    const [r] = await db.promise().query(
      'UPDATE games SET name = ?, description = ?, entry_image = ?, sort_order = ? WHERE id = ?',
      [name, text(req.body.description, 255) || null, image, Number(req.body.sort_order) || 0, id]
    );
    if (!r.affectedRows) return fail(res, '更新失败，请稍后重试', 500);
    await writeAdminLog({ adminId: req.user.id, action: 'game_update', targetUserId: null,
      detail: '修改游戏 #' + id + '：' + before[0].name + ' → ' + name });
    return ok(res, { id });
  } catch (err) {
    console.error('修改游戏失败:', err.message);
    return fail(res, '修改游戏失败，请稍后重试', 500);
  }
});

router.post('/admin/ops/games/:id/status', async (req, res) => {
  try {
    if (!(await hasTable('games'))) return fail(res, '游戏表不可用', 503);
    const id = posInt(req.params.id);
    if (!id) return fail(res, '游戏不存在', 404);
    const active = req.body.is_active ? 1 : 0;
    // 状态已一致时直接幂等返回，不报错（前端连点不会失败）
    const [r] = await db.promise().query('UPDATE games SET is_active = ? WHERE id = ?', [active, id]);
    if (!r.affectedRows) return fail(res, '游戏不存在', 404);
    await writeAdminLog({ adminId: req.user.id, action: active ? 'game_enable' : 'game_disable',
      targetUserId: null, detail: (active ? '启用' : '停用') + '游戏入口 #' + id });
    return ok(res, { id, is_active: !!active });
  } catch (err) {
    console.error('切换游戏状态失败:', err.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});

// ============================================
// 系统通知：全部用户 / 指定用户；创建 / 撤回 / 重新发布
// 与聊天消息完全分离（写 notifications，不写 chat_messages）
// ============================================
router.get('/admin/ops/notices', async (req, res) => {
  try {
    if (!(await hasTable('notifications'))) return ok(res, { available: false, list: [], total: 0 });
    const pg = paging(req);
    const total = await countOf('SELECT COUNT(*) AS c FROM notifications');
    const [rows] = await db.promise().query(
      'SELECT n.id, n.user_id, n.audience_id, n.target_scope, n.category, n.title, n.content, ' +
      'n.link, n.is_read, n.status, n.created_at, u.username AS audience_name ' +
      'FROM notifications n LEFT JOIN users u ON u.id = n.audience_id ' +
      'ORDER BY n.created_at DESC, n.id DESC LIMIT ? OFFSET ?',
      [pg.limit, pg.offset]
    );
    return ok(res, {
      available: true, total, limit: pg.limit, offset: pg.offset,
      list: rows.map((n) => ({
        id: String(n.id),
        scope: n.target_scope === 'all' ? 'all' : 'user',
        audience_id: n.audience_id === null ? null : Number(n.audience_id),
        audience_name: n.audience_name || null,
        category: n.category, title: n.title, content: n.content,
        link: n.link || null, is_read: !!n.is_read, status: n.status,
        created_at: n.created_at
      }))
    });
  } catch (err) {
    console.error('通知列表失败:', err.message);
    return fail(res, '通知列表加载失败，请稍后重试', 500);
  }
});

router.post('/admin/ops/notices', async (req, res) => {
  const conn = await db.promise().getConnection();
  let audienceId = null;
  try {
    if (!(await hasTable('notifications'))) { conn.release(); return fail(res, '通知功能不可用', 503); }
    const title = text(req.body.title, 120);
    const content = text(req.body.content, 2000);
    if (!title) { conn.release(); return fail(res, '请填写通知标题', 422); }
    if (!content) { conn.release(); return fail(res, '请填写通知内容', 422); }
    const scope = req.body.scope === 'all' ? 'all' : 'user';
    const category = NOTICE_CATEGORY.indexOf(req.body.category) >= 0 ? req.body.category : 'system';
    const link = req.body.link ? safeInternalPath(req.body.link) : null;
    if (req.body.link && !link) { conn.release(); return fail(res, '通知链接必须是站内路径', 422); }

    if (scope === 'user') {
      audienceId = posInt(req.body.user_id);
      if (!audienceId) { conn.release(); return fail(res, '请选择接收通知的用户', 422); }
      const [t] = await conn.query('SELECT id FROM users WHERE id = ? LIMIT 1', [audienceId]);
      if (!t.length) { conn.release(); return fail(res, '该用户不存在', 404); }
    }

    // notifications.user_id 为 NOT NULL 且外键指向 users(id)，不能写 NULL / 0。
    // 广播做法：同一事务内为每个活跃用户批量插入一行（分批避免超长 SQL）。
    const BATCH = 500;
    let inserted = 0;
    let firstId = null;
    await conn.beginTransaction();

    if (scope === 'user') {
      const [r] = await conn.execute(
        'INSERT INTO notifications (user_id, audience_id, target_scope, sender_id, category, title, content, link, status) ' +
        'VALUES (?,?,?,?,?,?,?,?,\'published\')',
        [audienceId, audienceId, 'user', req.user.id, category, title, content, link]
      );
      inserted = 1;
      firstId = String(r.insertId);
    } else {
      const [targets] = await conn.query("SELECT id FROM users WHERE status = 'active'");
      for (let i = 0; i < targets.length; i += BATCH) {
        const chunk = targets.slice(i, i + BATCH);
        const vals = [];
        const args = [];
        chunk.forEach((u) => {
          // 9 列：user_id, audience_id, target_scope, sender_id, category, title, content, link, status
          vals.push('(?,NULL,?,?,?,?,?,?,\'published\')');
          args.push(u.id, 'all', req.user.id, category, title, content, link);
        });
        const [r] = await conn.execute(
          'INSERT INTO notifications (user_id, audience_id, target_scope, sender_id, category, title, content, link, status) ' +
          'VALUES ' + vals.join(','),
          args
        );
        inserted += chunk.length;
        if (firstId === null) firstId = String(r.insertId);
      }
    }
    await conn.commit();
    conn.release();

    await writeAdminLog({ adminId: req.user.id, action: 'notice_create', targetUserId: audienceId,
      detail: (scope === 'all' ? '向 ' + inserted + ' 名活跃用户' : '向用户 #' + audienceId) + '发送通知：' + title });
    return ok(res, { id: firstId, recipients: inserted, scope: scope });
  } catch (err) {
    try { await conn.rollback(); } catch (_) { /* 已提交或已断开 */ }
    conn.release();
    console.error('发送通知失败:', err.message);
    return fail(res, '发送通知失败，请稍后重试', 500);
  }
});

router.post('/admin/ops/notices/:id/status', async (req, res) => {
  try {
    if (!(await hasTable('notifications'))) return fail(res, '通知功能不可用', 503);
    const id = text(req.params.id, 24);
    const status = req.body.status === 'withdrawn' ? 'withdrawn' : 'published';
    const [rows] = await db.promise().query(
      'SELECT id, sender_id, title, target_scope, created_at, status FROM notifications WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return fail(res, '通知不存在', 404);
    const head = rows[0];
    if (head.status === status) return fail(res, '通知已处于该状态', 409);

    // 广播在库中是一批同源行，撤回/重发必须整批处理，避免用户端状态不一致
    let ids = [head.id];
    if (head.target_scope === 'all') {
      const [b] = await db.promise().query(
        'SELECT id FROM notifications WHERE sender_id = ? AND title = ? AND created_at = ? AND target_scope = ?',
        [head.sender_id, head.title, head.created_at, 'all']
      );
      if (b.length) ids = b.map((x) => x.id);
    }
    const [r] = await db.promise().query('UPDATE notifications SET status = ? WHERE id IN (?)', [status, ids]);
    await writeAdminLog({ adminId: req.user.id, action: status === 'withdrawn' ? 'notice_withdraw' : 'notice_publish',
      targetUserId: null, detail: '通知 #' + id + '（' + ids.length + ' 条接收记录）→ ' + (status === 'withdrawn' ? '撤回' : '发布') });
    return ok(res, { id, status, affected: r.affectedRows });
  } catch (err) {
    console.error('通知状态切换失败:', err.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});

// ============================================
// 管理员管理：查看管理员 / 客服、启用停用（仅 status，永不含密码）
// 自我保护：不能停用自己、不能操作最后一个活跃管理员
// ============================================
router.get('/admin/ops/staff', async (req, res) => {
  try {
    const pg = paging(req);
    const where = ["role IN ('admin','support')"];
    const args = [];
    const q = text(req.query.q, 50);
    if (q) { where.push('(username LIKE ? OR id = ?)'); args.push('%' + q + '%', posInt(q) || -1); }
    const role = text(req.query.role, 20);
    if (role === 'admin' || role === 'support') { where.push('role = ?'); args.push(role); }
    const sql = ' WHERE ' + where.join(' AND ');

    const total = await countOf('SELECT COUNT(*) AS c FROM users' + sql, args);
    const [rows] = await db.promise().query(
      'SELECT id, username, role, status, created_at, updated_at FROM users' + sql +
      ' ORDER BY role ASC, id ASC LIMIT ? OFFSET ?',
      args.concat([pg.limit, pg.offset])
    );
    const [admins] = await db.promise().query("SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND status = 'active'");
    return ok(res, {
      total, limit: pg.limit, offset: pg.offset,
      active_admins: Number(admins[0].c) || 0,
      list: rows.map((u) => ({
        id: Number(u.id), username: u.username, role: u.role, status: u.status,
        created_at: u.created_at, updated_at: u.updated_at,
        is_self: Number(u.id) === Number(req.user.id)
      }))
    });
  } catch (err) {
    console.error('管理员列表失败:', err.message);
    return fail(res, '管理员列表加载失败，请稍后重试', 500);
  }
});

router.post('/admin/ops/staff/:id/status', async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '用户不存在', 404);
  const next = req.body.status === 'banned' ? 'banned' : 'active';
  const reason = text(req.body.reason, 200);
  if (next === 'banned' && !reason) return fail(res, '停用管理员必须填写原因', 422);
  if (id === Number(req.user.id)) return fail(res, '不能停用自己的管理员账号', 409);
  try {
    const [rows] = await db.promise().query(
      'SELECT id, role, status, username FROM users WHERE id = ? LIMIT 1', [id]);
    if (!rows.length) return fail(res, '用户不存在', 404);
    const u = rows[0];
    if (u.role !== 'admin' && u.role !== 'support') return fail(res, '只能管理管理员或客服账号', 403);
    if (u.status === next) return fail(res, '该账号已处于该状态', 409);
    if (u.role === 'admin' && next === 'banned') {
      const [c] = await db.promise().query("SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND status = 'active'");
      if ((Number(c[0].c) || 0) <= 1) return fail(res, '系统至少需要保留一名启用中的管理员', 409);
    }
    const [r] = await db.promise().query('UPDATE users SET status = ? WHERE id = ?', [next, id]);
    if (!r.affectedRows) return fail(res, '更新失败，请稍后重试', 500);
    await writeAdminLog({ adminId: req.user.id, action: next === 'banned' ? 'staff_disable' : 'staff_enable',
      targetUserId: id, detail: u.username + '：' + u.status + ' → ' + next + (reason ? '（' + reason + '）' : '') });
    return ok(res, { id, status: next });
  } catch (err) {
    console.error('切换管理员状态失败:', err.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});

// ============================================
// 客服管理：客服会话 + 聊天举报（只读；处理沿用现有客服模块）
// GET /api/admin/ops/support
// ============================================
router.get('/admin/ops/support', async (req, res) => {
  try {
    const pg = paging(req);
    const out = {
      threads: { available: false, list: [], total: 0 },
      reports: { available: false, list: [], total: 0 }
    };
    if (await hasTable('support_threads')) {
      out.threads.available = true;
      out.threads.total = await countOf('SELECT COUNT(*) AS c FROM support_threads');
      const [t] = await db.promise().query(
        'SELECT thread_key, status, updated_by, updated_at FROM support_threads ORDER BY updated_at DESC LIMIT ? OFFSET ?',
        [pg.limit, pg.offset]
      );
      out.threads.list = t.map((r) => ({
        thread_key: r.thread_key, status: r.status,
        updated_by: r.updated_by === null ? null : Number(r.updated_by), updated_at: r.updated_at
      }));
    }
    if (await hasTable('chat_reports')) {
      out.reports.available = true;
      out.reports.total = await countOf('SELECT COUNT(*) AS c FROM chat_reports');
      const [r] = await db.promise().query(
        'SELECT rp.id, rp.reason, rp.status, rp.created_at, u.username AS reporter, m.content AS message ' +
        'FROM chat_reports rp ' +
        'LEFT JOIN users u ON u.id = rp.reporter_id ' +
        'LEFT JOIN chat_messages m ON m.id = rp.message_id ' +
        'ORDER BY rp.created_at DESC LIMIT ? OFFSET ?',
        [pg.limit, pg.offset]
      );
      out.reports.list = r.map((x) => ({
        id: Number(x.id), reason: x.reason, status: x.status,
        reporter: x.reporter || null, message: x.message || null, created_at: x.created_at
      }));
    }
    return ok(res, out);
  } catch (err) {
    console.error('客服数据加载失败:', err.message);
    return fail(res, '客服数据加载失败，请稍后重试', 500);
  }
});

module.exports = router;
