'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');
function num(v) { const n = Number(v); return Number.isSafeInteger(n) && n > 0 ? n : null; }
function tx(v, m) { return String(v == null ? '' : v).trim().slice(0, m); }
async function sysMsg(text) {
  await db.promise().query('INSERT INTO chat_messages (channel,user_id,message_type,content,sender_role) VALUES (\'group\',NULL,\'system\',?,\'system\')', [text]);
}
router.get('/chat/moderation', auth, async function (req, res) {
  try {
    const g = (await db.promise().query('SELECT id,operator_id,reason,status,created_at FROM moderation_actions WHERE scope=\'GROUP\' AND action=\'MUTE\' ORDER BY id DESC LIMIT 1'))[0][0];
    const groupMuted = Boolean(g && g.status === 'ACTIVE');
    let mine = null;
    try {
      const r = (await db.promise().query('SELECT muted_until,mute_reason FROM users WHERE id=? LIMIT 1', [req.user.id]))[0][0];
      if (r && r.muted_until && new Date(r.muted_until).getTime() > Date.now()) mine = { muted: true, until: r.muted_until, reason: r.mute_reason || null };
    } catch (e2) {}
    return ok(res, { group_muted: groupMuted, group: g || null, my_mute: mine });
  } catch (e) { return fail(res, '禁言状态加载失败', 500); }
});
router.post('/chat/moderation/group/mute', auth, requireRole('admin'), async function (req, res) {
  const reason = tx(req.body && req.body.reason, 200);
  if (reason.length < 2) return fail(res, '请填写禁言原因', 422, 'REASON_REQUIRED');
  try {
    const ex = (await db.promise().query('SELECT id FROM moderation_actions WHERE scope=\'GROUP\' AND status=\'ACTIVE\' LIMIT 1'))[0][0];
    if (ex) return fail(res, '全体禁言已在生效中', 409, 'ALREADY_MUTED');
    await db.promise().query('INSERT INTO moderation_actions (scope,target_user_id,operator_id,action,reason,status) VALUES (\'GROUP\',NULL,?,\'MUTE\',?,\'ACTIVE\')', [req.user.id, reason]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: null, action: 'chat_group_mute', detail: 'reason=' + reason });
    await sysMsg('管理员已开启全体禁言，原因：' + reason);
    return ok(res, null, '已开启全体禁言');
  } catch (e) { return fail(res, '操作失败', 500); }
});
router.post('/chat/moderation/group/unmute', auth, requireRole('admin'), async function (req, res) {
  try {
    const upd = (await db.promise().query('UPDATE moderation_actions SET status=\'ENDED\',ended_at=NOW(),ended_by=? WHERE scope=\'GROUP\' AND status=\'ACTIVE\'', [req.user.id]))[0];
    if (!Number(upd.affectedRows)) return fail(res, '当前没有生效中的全体禁言', 409, 'NOT_MUTED');
    await writeAdminLog({ adminId: req.user.id, targetUserId: null, action: 'chat_group_unmute', detail: 'unmute' });
    await sysMsg('管理员已解除全体禁言');
    return ok(res, null, '已解除全体禁言');
  } catch (e) { return fail(res, '操作失败', 500); }
});
router.post('/chat/moderation/user/mute', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.body && (req.body.user_id || req.body.target_user_id));
  const reason = tx(req.body && req.body.reason, 200);
  const mins = Math.min(Math.max(parseInt((req.body && req.body.minutes) || 60, 10) || 60, 5), 43200);
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  if (reason.length < 2) return fail(res, '请填写禁言原因', 422, 'REASON_REQUIRED');
  if (id === Number(req.user.id)) return fail(res, '不能禁言自己', 403, 'SELF_FORBIDDEN');
  try {
    const u = (await db.promise().query('SELECT id,username,role FROM users WHERE id=? LIMIT 1', [id]))[0][0];
    if (!u) return fail(res, '用户不存在', 404, 'NOT_FOUND');
    if (u.role === 'admin') return fail(res, '不能禁言管理员', 403, 'ADMIN_FORBIDDEN');
    await db.promise().query('INSERT INTO moderation_actions (scope,target_user_id,operator_id,action,reason,status) VALUES (\'USER\',?,?,\'MUTE\',?,\'ACTIVE\')', [id, req.user.id, reason]);
    await db.promise().query('UPDATE users SET muted_until=DATE_ADD(NOW(),INTERVAL ? MINUTE),mute_reason=? WHERE id=?', [mins, reason, id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: id, action: 'chat_user_mute', detail: 'minutes=' + mins + ' reason=' + reason });
    await sysMsg('管理员已禁言 @' + u.username + '，原因：' + reason);
    return ok(res, null, '已禁言 @' + u.username);
  } catch (e) { return fail(res, '操作失败', 500); }
});
router.post('/chat/moderation/user/unmute', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.body && (req.body.user_id || req.body.target_user_id));
  if (!id) return fail(res, '无效的用户ID', 422, 'INVALID_USER_ID');
  try {
    await db.promise().query('UPDATE moderation_actions SET status=\'ENDED\',ended_at=NOW(),ended_by=? WHERE scope=\'USER\' AND target_user_id=? AND status=\'ACTIVE\'', [req.user.id, id]);
    await db.promise().query('UPDATE users SET muted_until=NULL,mute_reason=NULL WHERE id=?', [id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: id, action: 'chat_user_unmute', detail: 'unmute' });
    return ok(res, null, '已解除禁言');
  } catch (e) { return fail(res, '操作失败', 500); }
});
module.exports = router;
