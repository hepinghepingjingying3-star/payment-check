'use strict';
// ============================================
// 26牛牛 - 客服管理 API
// 范围：admin / support 仅可处理客服线程；不授予资金、用户管理、系统配置权限。
// 线程键：user:<用户ID> 或 guest:<32位游客令牌>。消息正文不写入审计日志。
// ============================================
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');

const THREAD_RE = /^(user:(\d+)|guest:([a-f0-9]{32}))$/;
const STATUSES = ['open', 'processing', 'replied', 'closed'];
const STATUS_TEXT = { open: '待处理', processing: '处理中', replied: '已回复', closed: '已关闭' };

router.use('/admin/support', auth, requireRole('admin', 'support'));

function parseThread(key) {
  const m = THREAD_RE.exec(String(key || ''));
  if (!m) return null;
  return m[2] ? { key: m[1], kind: 'user', userId: Number(m[2]) } : { key: m[1], kind: 'guest', token: m[3] };
}
function messageOut(r) {
  return {
    id: Number(r.id), username: r.sender_role === 'admin' ? '客服' : (r.username || '游客'),
    message_type: r.message_type, content: r.is_recalled ? '' : r.content,
    sender_role: r.sender_role || 'user', is_recalled: !!r.is_recalled, created_at: r.created_at
  };
}
function page(value, fallback) {
  const n = Number.parseInt(value, 10);
  return Number.isSafeInteger(n) && n > 0 ? n : fallback;
}

// GET /api/admin/support/threads?status=&q=&limit=&offset=
router.get('/admin/support/threads', async (req, res) => {
  try {
    const status = String(req.query.status || '').trim();
    if (status && !STATUSES.includes(status)) return fail(res, '无效的客服状态', 422, 'INVALID_STATUS');
    const q = String(req.query.q || '').trim().slice(0, 64);
    const limit = Math.min(page(req.query.limit, 20), 100);
    const offset = Math.max(Number.parseInt(req.query.offset, 10) || 0, 0);
    const where = ["m.channel = 'support'", '(m.user_id IS NOT NULL OR m.guest_token IS NOT NULL)'];
    const params = [];
    if (status) { where.push('COALESCE(t.status, \'open\') = ?'); params.push(status); }
    if (q) {
      const like = '%' + q.replace(/[\\%_]/g, '\\$&') + '%';
      where.push('(u.username LIKE ? ESCAPE \'\\\\\' OR m.guest_token LIKE ? ESCAPE \'\\\\\')');
      params.push(like, like);
    }
    const grouped = `
      SELECT CASE WHEN m.guest_token IS NOT NULL THEN CONCAT('guest:', m.guest_token) ELSE CONCAT('user:', m.user_id) END AS thread_key,
             MAX(m.id) AS last_id, MAX(m.created_at) AS updated_at, COUNT(*) AS message_count,
             MAX(CASE WHEN m.sender_role <> 'admin' THEN 1 ELSE 0 END) AS has_customer_message,
             MAX(u.username) AS username, MAX(m.guest_token) AS guest_token, COALESCE(t.status, 'open') AS status
      FROM chat_messages m
      LEFT JOIN users u ON u.id = m.user_id
      LEFT JOIN support_threads t ON t.thread_key = (CASE WHEN m.guest_token IS NOT NULL THEN CONCAT('guest:', m.guest_token) ELSE CONCAT('user:', m.user_id) END) COLLATE utf8mb4_unicode_ci
      WHERE ${where.join(' AND ')}
      GROUP BY m.guest_token, m.user_id, t.status
      ORDER BY updated_at DESC, last_id DESC`;
    const [rows] = await db.promise().query(`SELECT * FROM (${grouped}) AS threads LIMIT ? OFFSET ?`, params.concat([limit, offset]));
    const [countRows] = await db.promise().query(`SELECT COUNT(*) AS c FROM (${grouped}) AS threads`, params);
    return ok(res, {
      list: rows.map(r => ({
        key: r.thread_key, kind: r.guest_token ? 'guest' : 'user', username: r.guest_token ? ('游客' + String(r.guest_token).slice(-4)) : (r.username || '用户'),
        status: r.status, status_text: STATUS_TEXT[r.status] || r.status, message_count: Number(r.message_count),
        updated_at: r.updated_at, has_customer_message: Boolean(r.has_customer_message)
      })), total: Number(countRows[0].c), limit, offset
    });
  } catch (err) {
    console.error('读取客服线程失败:', err.message);
    return fail(res, '客服会话加载失败，请稍后重试', 500);
  }
});

// GET /api/admin/support/threads/:threadKey/messages
router.get('/admin/support/threads/:threadKey/messages', async (req, res) => {
  try {
    const thread = parseThread(req.params.threadKey);
    if (!thread) return fail(res, '无效的客服线程', 422, 'INVALID_THREAD');
    const where = thread.kind === 'user' ? 'm.channel = \'support\' AND m.user_id = ? AND m.guest_token IS NULL' : 'm.channel = \'support\' AND m.guest_token = ?';
    const value = thread.kind === 'user' ? thread.userId : thread.token;
    const [rows] = await db.promise().query(
      `SELECT m.id, COALESCE(u.username, '客服') AS username, m.message_type, m.content, m.sender_role, m.is_recalled, m.created_at
         FROM chat_messages m LEFT JOIN users u ON u.id = m.user_id
         WHERE ${where} ORDER BY m.id ASC LIMIT 200`, [value]);
    const [state] = await db.promise().query('SELECT status, updated_at FROM support_threads WHERE thread_key = ? LIMIT 1', [thread.key]);
    return ok(res, { thread: { key: thread.key, status: state[0] ? state[0].status : 'open', status_text: STATUS_TEXT[state[0] ? state[0].status : 'open'] }, messages: rows.map(messageOut) });
  } catch (err) {
    console.error('读取客服消息失败:', err.message);
    return fail(res, '客服消息加载失败，请稍后重试', 500);
  }
});

// POST /api/admin/support/threads/:threadKey/messages
router.post('/admin/support/threads/:threadKey/messages', async (req, res) => {
  try {
    const thread = parseThread(req.params.threadKey);
    const content = String((req.body && req.body.content) || '').trim();
    if (!thread) return fail(res, '无效的客服线程', 422, 'INVALID_THREAD');
    if (!content || content.length > 500) return fail(res, '回复内容不能为空且最多 500 个字符', 422, 'INVALID_CONTENT');
    const [states] = await db.promise().query('SELECT status FROM support_threads WHERE thread_key = ? LIMIT 1', [thread.key]);
    if (states[0] && states[0].status === 'closed') return fail(res, '该会话已关闭，请先重开', 409, 'THREAD_CLOSED');
    const fields = thread.kind === 'user'
      ? ['support', thread.userId, null, 'text', content, 'admin']
      : ['support', null, thread.token, 'text', content, 'admin'];
    const [result] = await db.promise().query(
      'INSERT INTO chat_messages (channel, user_id, guest_token, message_type, content, sender_role) VALUES (?, ?, ?, ?, ?, ?)', fields);
    await db.promise().query(
      "INSERT INTO support_threads (thread_key, status, updated_by) VALUES (?, 'replied', ?) ON DUPLICATE KEY UPDATE status = 'replied', updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP",
      [thread.key, req.user.id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: thread.kind === 'user' ? thread.userId : null, action: 'support_reply', detail: { thread: thread.key, message_id: Number(result.insertId) } });
    return res.status(201).json({ success: true, data: { id: Number(result.insertId), status: 'replied', status_text: STATUS_TEXT.replied } });
  } catch (err) {
    console.error('发送客服回复失败:', err.message);
    return fail(res, '客服回复发送失败，请稍后重试', 500);
  }
});

// PUT /api/admin/support/threads/:threadKey/status
router.put('/admin/support/threads/:threadKey/status', async (req, res) => {
  try {
    const thread = parseThread(req.params.threadKey);
    const status = String((req.body && req.body.status) || '').trim();
    if (!thread) return fail(res, '无效的客服线程', 422, 'INVALID_THREAD');
    if (!STATUSES.includes(status)) return fail(res, '无效的客服状态', 422, 'INVALID_STATUS');
    await db.promise().query(
      'INSERT INTO support_threads (thread_key, status, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP',
      [thread.key, status, req.user.id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: thread.kind === 'user' ? thread.userId : null, action: 'support_thread_status', detail: { thread: thread.key, status: status } });
    return ok(res, { key: thread.key, status, status_text: STATUS_TEXT[status] });
  } catch (err) {
    console.error('更新客服状态失败:', err.message);
    return fail(res, '客服状态更新失败，请稍后重试', 500);
  }
});

module.exports = router;