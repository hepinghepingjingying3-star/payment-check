// ============================================
// 26牛牛 - 图片资源清单路由
// GET /api/assets
// 说明:
//   - 扫描 public/assets 下各目录，返回「真实存在」的官方图片地址
//   - 前端只在文件存在时渲染 <img>，因此不会产生 404 请求
//   - 站长把正式素材放入对应目录（文件名见 config/assets.js 的 candidates），
//     刷新页面即自动生效，无需修改任何代码
//   - 本站不生成 / 不内置任何官方图片，不使用 emoji 作为贴图
// ============================================

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const ASSETS = require('../config/assets');
const { USER_STICKER_URL_BASE } = require('../config/assets');

// 清单缓存（10 秒），避免每次请求都读盘
let cache = { at: 0, data: null };
const CACHE_MS = 10 * 1000;

const IMAGE_EXT = ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.avif'];

function listDirFiles(dir) {
  try {
    const full = path.join(ASSETS.ASSETS_ROOT, dir);
    if (!fs.existsSync(full)) return [];
    return fs.readdirSync(full).filter(f => {
      const ext = path.extname(f).toLowerCase();
      return IMAGE_EXT.includes(ext);
    });
  } catch (e) {
    return [];
  }
}

function buildManifest() {
  const out = {};
  for (const key of Object.keys(ASSETS.GROUPS)) {
    const g = ASSETS.GROUPS[key];
    const files = listDirFiles(g.dir);
    // 按 candidates 顺序优先，其次按文件名排序
    const ordered = [];
    (g.candidates || []).forEach(c => { if (files.indexOf(c) >= 0) ordered.push(c); });
    files.forEach(f => { if (ordered.indexOf(f) < 0) ordered.push(f); });

    out[key] = ordered.map(f => ({
      key: path.basename(f, path.extname(f)),
      file: f,
      url: g.urlBase + '/' + encodeURIComponent(f)
    }));
    out[key + '_url'] = out[key].length ? out[key][0].url : null;   // 默认取第一个
    out[key + '_ready'] = out[key].length > 0;                       // 是否已放入素材
  }
  return out;
}

function getManifest(force) {
  const now = Date.now();
  if (!force && cache.data && (now - cache.at) < CACHE_MS) return cache.data;
  cache = { at: now, data: buildManifest() };
  return cache.data;
}

// GET /api/assets  （无需登录：只返回静态路径，不含任何用户数据）
router.get('/assets', (req, res) => {
  try {
    const manifest = getManifest(String(req.query.refresh || '') === '1');
    res.json({
      success: true,
      data: {
        manifest: manifest,
        sticker_categories: [
          { key: 'official', name: '官方贴图', ready: !!manifest.stickers_ready },
          { key: 'user', name: '我的贴图', ready: true }
        ],
        user_sticker_dir: USER_STICKER_URL_BASE,
        note: '官方图片素材由站长自行放入 public/assets 对应目录，站点不内置任何官方图片'
      }
    });
  } catch (err) {
    console.error('获取资源清单失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

module.exports = router;
module.exports.getManifest = getManifest;