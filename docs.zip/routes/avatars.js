'use strict';
/**
 * 官方头像库 - 用户端 API
 * 用户只能浏览启用的头像并提交 avatar_id 选择头像。
 * 不允许上传头像、不允许提交 avatar_url。
 */
const express = require('express');
const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { getAvatarForUser, toPublicPath } = require('../utils/avatar');

const router = express.Router();

// GET /api/avatars/mine - 当前用户头像（官方头像库 + 默认头像回退）
router.get('/avatars/mine', auth, async (req, res) => {
  const av = await getAvatarForUser(req.user.id);
  return ok(res, av);
});

// GET /api/avatars/categories - 头像分类（仅启用）
router.get('/avatars/categories', auth, async (req, res) => {
  try {
    const [cats] = await db.promise().query(
      'SELECT id, name, sort_order FROM avatar_categories WHERE is_active = 1 ORDER BY sort_order ASC, id ASC'
    );
    return ok(res, { categories: cats });
  } catch (e) {
    console.error('[avatars/categories]', e.message);
    return fail(res, '获取头像分类失败', 500);
  }
});

// GET /api/avatars - 已启用头像列表（可选分类过滤）
router.get('/avatars', auth, async (req, res) => {
  try {
    const catId = parseInt(req.query.category_id, 10);
    const params = [];
    let sql = 'SELECT a.id, a.name, a.image_path, a.category_id, a.sort_order, c.name AS category_name ' +
      'FROM avatars a LEFT JOIN avatar_categories c ON c.id = a.category_id ' +
      'WHERE a.is_active = 1';
    if (!Number.isNaN(catId) && catId > 0) {
      sql += ' AND a.category_id = ?';
      params.push(catId);
    }
    sql += ' ORDER BY a.sort_order ASC, a.id ASC LIMIT 200';
    const [rows] = await db.promise().query(sql, params);
    return ok(res, { avatars: rows, total: rows.length });
  } catch (e) {
    console.error('[avatars/list]', e.message);
    return fail(res, '获取头像列表失败', 500);
  }
});

// POST /api/avatars/select - 选择头像（只接受 avatar_id，后端验证）
router.post('/avatars/select', auth, async (req, res) => {
  try {
    // 任何情况下都不接受用户提交的头像链接
    if (req.body.avatar_url || req.body.url || req.body.image_path || req.body.file) {
      return fail(res, '不支持自定义头像或头像链接，请从官方头像库选择', 422);
    }
    const avatarId = parseInt(req.body.avatar_id, 10);
    if (Number.isNaN(avatarId) || avatarId <= 0) {
      return fail(res, '请选择一个头像', 422);
    }
    const [rows] = await db.promise().query(
      'SELECT id, image_path FROM avatars WHERE id = ? AND is_active = 1 AND allow_users = 1 LIMIT 1',
      [avatarId]
    );
    if (!rows.length) {
      return fail(res, '该头像不存在、已停用或不对普通用户开放', 404);
    }
    const imagePath = toPublicPath(rows[0].image_path);
    if (!imagePath) return fail(res, '该头像资源不可用，请选择其他头像', 409);
    if (req.body.avatar_url) {
      return fail(res, '不支持提交头像链接，请从官方头像库选择', 422);
    }
    // avatar_id 是真源；avatar_url 只是服务端计算的展示缓存（聊天等旧页面读取）
    await db.promise().query('UPDATE users SET avatar_id = ?, avatar_url = ? WHERE id = ?',
      [avatarId, imagePath, req.user.id]);
    return ok(res, { avatar_id: avatarId, avatar_url: imagePath });
  } catch (e) {
    console.error('[avatars/select]', e.message);
    return fail(res, '更换头像失败', 500);
  }
});

module.exports = router;