'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const CHIPS = require('../config/cashChips');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const pay = require('../utils/payPassword');
const led = require('../utils/ledger');
const audit = require('../utils/adminAudit');
const TEXT = Object.assign({}, CHIPS.WITHDRAW.STATUS_TEXT, { APPROVED: '审核通过', REJECTED: '审核拒绝' });
function num(v) { const n = Number(v); return Number.isSafeInteger(n) && n > 0 ? n : null; }
function tx(v, m) { return String(v == null ? '' : v).trim().slice(0, m); }
function bankAccount(v) { const s = String(v == null ? '' : v).trim(); return /^\d{6,24}$/.test(s) ? s : null; }
function bankName(v) { const s = String(v == null ? '' : v).trim(); return s.length >= 2 && s.length <= 100 ? s : null; }
function orderNo() { return 'WD' + Date.now().toString(36).toUpperCase() + require('crypto').randomBytes(4).toString('hex').toUpperCase(); }
function publicOrder(o) {
  const account = String(o.bank_account || o.account_ref || '');
  return { id: Number(o.id), withdrawal_id: o.withdrawal_id || o.order_id, order_id: o.withdrawal_id || o.order_id, order_no: o.withdrawal_id || o.order_id,
    amount: Number(o.amount), status: o.status, status_text: TEXT[o.status] || o.status,
    recipient_name: o.recipient_name || o.account_name || null, bank_name: o.bank_name || null,
    bank_account_masked: account ? '****' + account.slice(-4) : null,
    reason: o.status === 'REJECTED' ? (o.admin_remark || o.reject_reason || null) : null,
    admin_remark: o.admin_remark || null,
    created_at: o.created_at, updated_at: o.updated_at || null, approved_at: o.approved_at || null, rejected_at: o.rejected_at || null, completed_at: o.completed_at || null };
}
function adminOrder(o) { return Object.assign(publicOrder(o), { user_id: Number(o.user_id), username: o.username || null, user: { id: Number(o.user_id), username: o.username || null }, bank_account: o.bank_account || o.account_ref || null, recipient_name: o.recipient_name || o.account_name || null, operator_id: o.operator_id || null, operator_remark: o.admin_remark || null, account_reference: o.bank_account || o.account_ref || null, account_type: 'BANK', payment_method: '银行账户', reject_reason: o.admin_remark || null }); }
const COLS = 'id,order_id,withdrawal_id,user_id,amount,currency,account_type,account_name,account_ref,recipient_name,bank_name,bank_account,status,operator_id,admin_remark,created_at,updated_at,approved_at,rejected_at,completed_at,idempotency_key';
function adminOnly(req, res, next) { return auth(req, res, () => requireRole('admin')(req, res, next)); }
router.get('/withdrawals/config', auth, function (req, res) {
  return ok(res, { asset: CHIPS.ASSET, asset_text: CHIPS.ASSET_TEXT, min: CHIPS.WITHDRAW.MIN, max: CHIPS.WITHDRAW.MAX, status_text: TEXT });
});
router.get('/withdrawals/summary', auth, async function (req, res) {
  try {
    const [uRows] = await db.promise().query(
      `SELECT u.cash_chips, u.bank_name, u.bank_account, r.real_name, r.status AS review_status, r.remark AS review_reason
       FROM users u LEFT JOIN real_name_reviews r ON r.user_id=u.id
       WHERE u.id=? LIMIT 1`, [req.user.id]
    );
    const u = uRows[0] || {};
    const st = String(u.review_status || 'NONE').toUpperCase();
    return ok(res, { available: Number(u.cash_chips || 0), asset_text: CHIPS.ASSET_TEXT,
      account: { review_status: st, review_reason: u.review_reason || null, recipient_name: u.real_name || null,
        bank_name: u.bank_name || null, bank_account_masked: u.bank_account ? '****' + String(u.bank_account).slice(-4) : null } });
  } catch (e) { return fail(res, '加载失败', 500); }
});
router.post('/withdrawals', auth, async function (req, res) {
  try {
    const b = req.body || {};
    const rawAmount = String(b.amount == null ? '' : b.amount).trim();
    if (!rawAmount) return fail(res, '请输入提款金额', 422, 'AMOUNT_REQUIRED');
    const amt = led.parseAmount(rawAmount, 0.01);
    if (amt === null) return fail(res, '提款金额必须大于0，且最多两位小数', 422, 'INVALID_AMOUNT');
    const recipient = tx(b.recipient_name, 60);
    const bank = bankName(b.bank_name);
    const account = bankAccount(b.bank_account);
    if (!recipient) return fail(res, '请输入收款人姓名', 422, 'RECIPIENT_REQUIRED');
    if (!bank) return fail(res, '请输入银行名称', 422, 'BANK_REQUIRED');
    if (!account) return fail(res, '请输入6至24位数字银行账号', 422, 'INVALID_BANK_ACCOUNT');
    if (account !== bankAccount(b.confirm_bank_account)) return fail(res, '两次银行账号不一致', 422, 'BANK_ACCOUNT_MISMATCH');
    const idempotencyKey = tx(b.idempotency_key, 80);
    if (idempotencyKey.length < 16) return fail(res, '请求标识无效，请刷新页面重试', 422, 'IDEMPOTENCY_REQUIRED');
    if (!/^\d{6}$/.test(String(b.pay_password == null ? '' : b.pay_password))) return fail(res, '请输入6位支付密码', 422, 'INVALID_PAY_PASSWORD');
    const chk = await pay.verifyPayPassword(req.user.id, String(b.pay_password));
    if (!chk.ok) return fail(res, chk.message || '支付密码错误', 403, 'PAY_PASSWORD_WRONG');
    const bl = await require('../utils/moderation').scopeBlocked(req.user.id, 'withdraw');
    if (bl) return fail(res, bl.message, bl.status || 403, 'USER_MUTED');
    const conn = await db.promise().getConnection();
    try {
      await conn.beginTransaction();
      const [oldRows] = await conn.query('SELECT ' + COLS + ' FROM withdraw_requests WHERE user_id=? AND idempotency_key=? FOR UPDATE', [req.user.id, idempotencyKey]);
      if (oldRows[0]) { await conn.commit(); return ok(res, { order: publicOrder(oldRows[0]) }, '申请已提交'); }
      const [lRows] = await conn.query('SELECT cash_chips FROM users WHERE id=? FOR UPDATE', [req.user.id]);
      if (Number(lRows[0] ? lRows[0].cash_chips : 0) < amt) { await conn.rollback(); return fail(res, '余额不足', 409, 'INSUFFICIENT_BALANCE'); }
      const [nameRows] = await conn.query('SELECT real_name,status FROM real_name_reviews WHERE user_id=? FOR UPDATE', [req.user.id]);
      const nm0 = nameRows[0];
      if (!nm0 || String(nm0.status).toLowerCase() !== 'approved') { await conn.rollback(); return fail(res, '账户资料审核通过后方可提交提款申请', 403, 'ACCOUNT_NOT_APPROVED'); }
      if (recipient !== String(nm0.real_name || '').trim()) { await conn.rollback(); return fail(res, '收款人姓名必须与已审核姓名一致，如需修改请重新提交账户资料审核', 422, 'RECIPIENT_LOCKED'); }
      const oid = orderNo();
      await conn.query("INSERT INTO withdraw_requests (order_id,withdrawal_id,user_id,amount,currency,account_type,account_name,account_ref,recipient_name,bank_name,bank_account,status,idempotency_key) VALUES (?,?,?,?,'CASH_CHIPS','BANK',?,?,?,?,?,'PENDING',?)", [oid, oid, req.user.id, amt.toFixed(2), recipient, account, recipient, bank, account, idempotencyKey]);
      await led.applyBalance(conn, { userId: req.user.id, delta: -amt, type: 'WITHDRAW_REQUEST', reason: '提款申请冻结', referenceNo: oid, operatorId: null });
      await conn.query('UPDATE users SET bank_name=?,bank_account=? WHERE id=?', [bank, account, req.user.id]);
      const [created] = await conn.query('SELECT ' + COLS + ' FROM withdraw_requests WHERE user_id=? AND idempotency_key=? LIMIT 1', [req.user.id, idempotencyKey]);
      await conn.commit();
      return res.status(201).json({ success: true, message: '提款申请已提交，等待审核', data: { order: publicOrder(created[0]) } });
    } catch (e) { try { await conn.rollback(); } catch (e2) {} return fail(res, '提交失败', 500); }
    finally { try { conn.release(); } catch (e2) {} }
  } catch (e) { return fail(res, '提交失败', 500); }
});
router.post('/withdrawals/:id/cancel', auth, async function (req, res) {
  const id = num(req.params.id);
  if (!id) return fail(res, '无效的申请ID', 422, 'INVALID_ID');
  const conn = await db.promise().getConnection();
  try {
    await conn.beginTransaction();
    const o = (await conn.query('SELECT ' + COLS + ' FROM withdraw_requests WHERE id=? AND user_id=? FOR UPDATE', [id, req.user.id]))[0][0];
    if (!o) { await conn.rollback(); return fail(res, '申请不存在', 404, 'NOT_FOUND'); }
    if (o.status !== 'PENDING') { await conn.rollback(); return fail(res, '只有待审核申请可以取消', 409, 'INVALID_STATUS'); }
    await conn.query('UPDATE withdraw_requests SET status=\'CANCELLED\',completed_at=NOW() WHERE id=? AND status=\'PENDING\'', [id]);
    await led.applyBalance(conn, { userId: req.user.id, delta: Number(o.amount), type: 'ADJUSTMENT', reason: '提现申请取消解冻', referenceNo: (o.withdrawal_id || o.order_id) + ':CANCEL', operatorId: null });
    await conn.commit();
    return ok(res, null, '申请已取消，冻结金额已退回');
  } catch (e) { try { await conn.rollback(); } catch (e2) {} return fail(res, '取消失败', 500); }
  finally { try { conn.release(); } catch (e2) {} }
});
router.get('/admin/withdrawals', adminOnly, async function (req, res) {
  try {
    const st = tx(req.query.status, 20).toUpperCase(), q = tx(req.query.q, 64), where = [], args = [];
    if (['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'].indexOf(st) >= 0) { where.push('o.status=?'); args.push(st); }
    if (q) { where.push('(o.withdrawal_id LIKE ? OR o.order_id LIKE ? OR u.username LIKE ?)'); const like = '%' + q.replace(/[\\%_]/g, c => '\\' + c) + '%'; args.push(like, like, like); }
    const clause = where.length ? ' WHERE ' + where.join(' AND ') : '';
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const rows = (await db.promise().query('SELECT o.*,u.username FROM withdraw_requests o LEFT JOIN users u ON u.id=o.user_id' + clause + ' ORDER BY o.created_at DESC,o.id DESC LIMIT ? OFFSET ?', args.concat([limit, offset])))[0];
    const [countRows] = await db.promise().query('SELECT COUNT(*) AS total FROM withdraw_requests o LEFT JOIN users u ON u.id=o.user_id' + clause, args);
    const [summaryRows] = await db.promise().query('SELECT status,COUNT(*) AS total FROM withdraw_requests GROUP BY status');
    const summary = {}; summaryRows.forEach(function (r) { summary[String(r.status).toLowerCase()] = Number(r.total) || 0; });
    return ok(res, { list: rows.map(adminOrder), total: Number(countRows[0] && countRows[0].total) || 0, limit: limit, offset: offset, summary: summary });
  } catch (e) { return fail(res, '提款审核列表加载失败', 500); }
});
router.get('/admin/withdrawals/:id', adminOnly, async function (req, res) {
  const id = num(req.params.id); if (!id) return fail(res, '无效的申请ID', 422);
  try { const rows = (await db.promise().query('SELECT o.*,u.username FROM withdraw_requests o LEFT JOIN users u ON u.id=o.user_id WHERE o.id=? LIMIT 1', [id]))[0]; if (!rows[0]) return fail(res, '提款申请不存在', 404); return ok(res, { order: adminOrder(rows[0]) }); } catch (e) { return fail(res, '提款详情加载失败', 500); }
});
async function reviewWithdrawal(req, res, decision) {
  const id = num(req.params.id); if (!id) return fail(res, '无效的申请ID', 422);
  const reason = tx(req.body && req.body.reason, 255); if (decision === 'REJECTED' && reason.length < 2) return fail(res, '请填写拒绝原因（至少2个字）', 422, 'REASON_REQUIRED');
  let conn;
  try {
    conn = await db.promise().getConnection(); await conn.beginTransaction();
    const rows = (await conn.query('SELECT ' + COLS + ' FROM withdraw_requests WHERE id=? FOR UPDATE', [id]))[0]; const o = rows[0];
    if (!o) { await conn.rollback(); return fail(res, '申请不存在', 404); }
    if (o.status !== 'PENDING') { await conn.rollback(); return fail(res, '该申请已审核或已处理', 409, 'ALREADY_HANDLED'); }
    if (decision === 'REJECTED') {
      await conn.query("UPDATE withdraw_requests SET status='REJECTED',admin_remark=?,reject_reason=?,operator_id=?,rejected_at=NOW(),completed_at=NOW() WHERE id=? AND status='PENDING'", [reason, reason, req.user.id, id]);
      await led.applyBalance(conn, { userId: Number(o.user_id), delta: Number(o.amount), type: 'ADJUSTMENT', reason: '提款拒绝解冻', referenceNo: (o.withdrawal_id || o.order_id) + ':REJECT', operatorId: req.user.id });
    } else {
      await conn.query("UPDATE withdraw_requests SET status='APPROVED',operator_id=?,approved_at=NOW(),completed_at=NOW() WHERE id=? AND status='PENDING'", [req.user.id, id]);
    }
    const action = decision === 'APPROVED' ? 'WITHDRAWAL_APPROVED' : 'WITHDRAWAL_REJECTED';
    await audit.writeAdminLog({ conn, adminId: req.user.id, targetUserId: Number(o.user_id), action, detail: 'withdrawal_id=' + (o.withdrawal_id || o.order_id) + (reason ? ' reason=' + reason : '') });
    await conn.query('INSERT INTO audit_logs (operator_id,action,target_id,reason) VALUES (?,?,?,?)', [req.user.id, action, id, reason || null]);
    await conn.commit(); return ok(res, { order_id: o.withdrawal_id || o.order_id, status: decision === 'APPROVED' ? 'APPROVED' : 'REJECTED' }, decision === 'APPROVED' ? '审核通过（不执行真实出款）' : '已拒绝');
  } catch (e) { if (conn) await conn.rollback().catch(() => {}); return fail(res, '审核失败', 500); } finally { if (conn) conn.release(); }
}
router.post('/admin/withdrawals/:id/approve', adminOnly, (req, res) => reviewWithdrawal(req, res, 'APPROVED'));
router.post('/admin/withdrawals/:id/reject', adminOnly, (req, res) => reviewWithdrawal(req, res, 'REJECTED'));
router.post('/admin/withdrawals/:id/review', adminOnly, function (req, res) { const d = tx(req.body && (req.body.decision || req.body.action), 20).toLowerCase(); if (d === 'approve' || d === 'approved') return reviewWithdrawal(req, res, 'APPROVED'); if (d === 'reject' || d === 'rejected') return reviewWithdrawal(req, res, 'REJECTED'); return fail(res, '无效的审核操作', 422); });
router.get('/withdrawals', auth, async function (req, res) {
  try { const rows = (await db.promise().query('SELECT ' + COLS + ' FROM withdraw_requests WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 50', [req.user.id]))[0]; return ok(res, { list: rows.map(publicOrder), total: rows.length }); } catch (e) { return fail(res, '提款记录加载失败', 500); }
});
router.get('/withdrawals/:id', auth, async function (req, res) {
  const id = num(req.params.id); if (!id) return fail(res, '无效的申请ID', 422);
  try { const rows = (await db.promise().query('SELECT ' + COLS + ' FROM withdraw_requests WHERE id=? AND user_id=? LIMIT 1', [id, req.user.id]))[0]; if (!rows[0]) return fail(res, '提款申请不存在', 404); return ok(res, { order: publicOrder(rows[0]) }); } catch (e) { return fail(res, '提款详情加载失败', 500); }
});
module.exports = router;
