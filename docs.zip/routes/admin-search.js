'use strict';
// 管理员全局搜索：仅返回运营定位所需的脱敏字段。
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail, maskPhone } = require('../utils/request');

router.get('/admin/search', auth, requireRole('admin'), async (req, res) => {
  try {
    const q = String(req.query.q || '').trim().slice(0, 64);
    if (q.length < 2) return fail(res, '请输入至少 2 个字符进行搜索', 422, 'QUERY_TOO_SHORT');
    const like = '%' + q.replace(/[\\%_]/g, '\\$&') + '%';
    const [userResult, orderResult, referralResult, supportResult] = await Promise.all([
      db.promise().query('SELECT id, username, nickname, phone, email, status, invite_code, created_at FROM users WHERE username LIKE ? OR nickname LIKE ? OR invite_code LIKE ? ORDER BY id DESC LIMIT 15', [like, like, like]),
      db.promise().query('SELECT o.id, o.order_no, o.order_type, o.amount, o.currency_type, o.status, o.created_at, u.username FROM wallet_orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.order_no LIKE ? OR u.username LIKE ? ORDER BY o.id DESC LIMIT 15', [like, like]),
      db.promise().query('SELECT r.id, r.level, r.status, r.created_at, a.username AS inviter_username, b.username AS invitee_username FROM referral_relations r LEFT JOIN users a ON a.id = r.referrer_id LEFT JOIN users b ON b.id = r.referred_user_id WHERE a.username LIKE ? OR b.username LIKE ? OR a.invite_code LIKE ? ORDER BY r.id DESC LIMIT 15', [like, like, like]),
      db.promise().query("SELECT DISTINCT CASE WHEN m.guest_token IS NOT NULL THEN CONCAT('guest:', m.guest_token) ELSE CONCAT('user:', m.user_id) END AS thread_key, COALESCE(t.status, 'open') AS status, MAX(m.created_at) AS updated_at, MAX(u.username) AS username, MAX(m.guest_token) AS guest_token FROM chat_messages m LEFT JOIN users u ON u.id = m.user_id LEFT JOIN support_threads t ON t.thread_key = (CASE WHEN m.guest_token IS NOT NULL THEN CONCAT('guest:', m.guest_token) ELSE CONCAT('user:', m.user_id) END) COLLATE utf8mb4_unicode_ci WHERE m.channel = 'support' AND (u.username LIKE ? OR m.guest_token LIKE ?) GROUP BY m.guest_token, m.user_id, t.status ORDER BY updated_at DESC LIMIT 15", [like, like])
    ]);
    return ok(res, {
      query: q,
      users: userResult[0].map(u => ({ id: Number(u.id), username: u.username, nickname: u.nickname || null, phone: maskPhone(u.phone), email: u.email ? u.email.replace(/^(.{1,2}).*(@.*)$/, '$1***$2') : null, status: u.status, invite_code: u.invite_code || null, created_at: u.created_at })),
      orders: orderResult[0].map(o => ({ id: Number(o.id), order_no: o.order_no, order_type: o.order_type, amount: Number(o.amount), asset_type: o.currency_type, status: o.status, username: o.username || null, created_at: o.created_at })),
      referrals: referralResult[0].map(r => ({ id: Number(r.id), inviter: r.inviter_username || null, invitee: r.invitee_username || null, level: Number(r.level), status: r.status, created_at: r.created_at })),
      support: supportResult[0].map(s => ({ key: s.thread_key, username: s.guest_token ? ('游客' + String(s.guest_token).slice(-4)) : (s.username || '用户'), status: s.status, updated_at: s.updated_at }))
    });
  } catch (err) {
    console.error('管理员全局搜索失败:', err.message);
    return fail(res, '搜索失败，请稍后重试', 500);
  }
});

module.exports = router;