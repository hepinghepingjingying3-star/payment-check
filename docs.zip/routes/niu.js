'use strict';
// ============================================
// 26牛牛 - 26牛牛娱乐场 API（非现金化娱乐积分）
// ============================================
// 路径统一挂在 /api/game/niu/*（挂载顺序早于旧红包对战路由，旧路由保持只读兼容）
//
// GET  /api/game/niu/config        公开配置（场次 / 倍数 / 时长 / 牌型 / 免责声明）
// GET  /api/game/niu/rooms         场次列表（实时人数 + 我的座位）
// GET  /api/game/niu/state         单场实时状态（个人视角，只有自己的牌）
// POST /api/game/niu/join          入座
// POST /api/game/niu/leave         离座
// POST /api/game/niu/grab          抢庄 / 不抢
// POST /api/game/niu/bet           选择倍数
// GET  /api/game/niu/stats         我的战绩（真实统计，无数据即 0）
// GET  /api/game/niu/records       我的对局记录（分页）
// GET  /api/game/niu/leaderboard   娱乐积分排行榜
// POST /api/game/niu/daily-free    领取每日免费积分（低于下限才发，每日一次）
//
// 安全边界:
//   - 状态机、发牌、牌型、结算全部在服务器（utils/niuRoom + utils/niuEngine）
//   - 前端只提交 room_key / grab / bet_level，任何「结果」字段都不接受
//   - 积分只来自每日免费发放与管理员发放：不可充值、不可转账、不可提现
// ============================================

const express = require('express');
const router = express.Router();
const NG = require('../config/niuGame');
const niu = require('../utils/niuRoom');
const { auth } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { limiter } = require('../utils/rateLimit');
const { scopeBlocked } = require('../utils/moderation');

const PREFIX = '/game/niu';
const actLimit = limiter('niu-act', NG.LIMITS.ACTION_PER_MIN, 60000);

function toKey(v) {
  const s = String(v || '').trim().toLowerCase();
  return /^[a-z0-9_-]{1,20}$/.test(s) ? s : null;
}

/** 禁言 / 封禁联动：被限制账号不能参与游戏写操作 */
async function blocked(req, res) {
  for (const scope of ['game', 'room']) {
    const r = await scopeBlocked(req.user.id, scope);
    if (r) { fail(res, r.message, 403, r.code); return true; }
  }
  return false;
}

// ---------- 配置 ----------
router.get(PREFIX + '/config', auth, async (req, res) => {
  try {
    const enabled = await niu.isEnabled();
    const stats = await niu.myStats(req.user.id);
    return ok(res, Object.assign(NG.publicConfig(), {
      enabled: enabled,
      disabled_message: enabled ? null : NG.SWITCHES.DISABLED_MESSAGE,
      game_points: stats.game_points,
      daily_free_date: stats.daily_free_date,
      seated_room: niu.isSeated(req.user.id)
    }));
  } catch (e) {
    console.error('[niu/config]', e.message);
    return fail(res, '获取游戏配置失败', 500);
  }
});

// ---------- 场次列表 ----------
router.get(PREFIX + '/rooms', auth, async (req, res) => {
  try {
    return ok(res, await niu.listRooms(req.user.id));
  } catch (e) {
    console.error('[niu/rooms]', e.message);
    return fail(res, '获取场次失败', 500);
  }
});

// ---------- 单场状态 ----------
router.get(PREFIX + '/state', auth, async (req, res) => {
  try {
    const key = toKey(req.query.room);
    if (!key) return fail(res, '缺少场次参数', 422, 'INVALID_ROOM');
    const st = niu.stateFor(key, req.user.id);
    if (!st) return fail(res, '场次不存在', 404, 'ROOM_NOT_FOUND');
    return ok(res, st);
  } catch (e) {
    console.error('[niu/state]', e.message);
    return fail(res, '获取房间状态失败', 500);
  }
});

// ---------- 入座 ----------
router.post(PREFIX + '/join', auth, actLimit, async (req, res) => {
  try {
    const key = toKey(req.body && req.body.room);
    if (!key) return fail(res, '缺少场次参数', 422, 'INVALID_ROOM');
    if (await blocked(req, res)) return undefined;
    const r = await niu.join(key, req.user.id);
    if (!r.ok) return fail(res, r.message, r.code === 'NEED_POINTS' ? 409 : 400, r.code);
    return ok(res, r.snapshot);
  } catch (e) {
    console.error('[niu/join]', e.message);
    return fail(res, '入座失败，请稍后重试', 500);
  }
});

// ---------- 离座 ----------
router.post(PREFIX + '/leave', auth, actLimit, async (req, res) => {
  try {
    const key = toKey(req.body && req.body.room);
    if (!key) return fail(res, '缺少场次参数', 422, 'INVALID_ROOM');
    const r = await niu.leave(key, req.user.id);
    if (!r.ok) return fail(res, r.message, 400, r.code);
    return ok(res, null, { message: r.message });
  } catch (e) {
    console.error('[niu/leave]', e.message);
    return fail(res, '离开失败，请稍后重试', 500);
  }
});

// ---------- 抢庄 ----------
router.post(PREFIX + '/grab', auth, actLimit, async (req, res) => {
  try {
    const key = toKey(req.body && req.body.room);
    if (!key) return fail(res, '缺少场次参数', 422, 'INVALID_ROOM');
    if (await blocked(req, res)) return undefined;
    const flag = req.body && (req.body.grab === 1 || req.body.grab === true || req.body.grab === '1');
    const r = niu.setGrab(key, req.user.id, flag);
    if (!r.ok) return fail(res, r.message, r.code === 'WRONG_PHASE' ? 409 : 400, r.code);
    return ok(res, { grab: r.grab });
  } catch (e) {
    console.error('[niu/grab]', e.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});

// ---------- 选择倍数 ----------
router.post(PREFIX + '/bet', auth, actLimit, async (req, res) => {
  try {
    const key = toKey(req.body && req.body.room);
    if (!key) return fail(res, '缺少场次参数', 422, 'INVALID_ROOM');
    if (await blocked(req, res)) return undefined;
    const r = niu.setBet(key, req.user.id, req.body && req.body.bet_level);
    if (!r.ok) return fail(res, r.message, r.code === 'WRONG_PHASE' ? 409 : 400, r.code);
    return ok(res, { bet_level: r.bet_level });
  } catch (e) {
    console.error('[niu/bet]', e.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});


// ---------- 我的战绩 ----------
router.get(PREFIX + '/stats', auth, async (req, res) => {
  try {
    return ok(res, await niu.myStats(req.user.id));
  } catch (e) {
    console.error('[niu/stats]', e.message);
    return fail(res, '获取战绩失败', 500);
  }
});

// ---------- 我的对局记录（分页）----------
router.get(PREFIX + '/records', auth, async (req, res) => {
  try {
    const data = await niu.myRecords(req.user.id, {
      page: req.query.page, size: req.query.size, days: req.query.days
    });
    return ok(res, data);
  } catch (e) {
    console.error('[niu/records]', e.message);
    return fail(res, '获取对局记录失败', 500);
  }
});

// ---------- 排行榜（娱乐积分，不可兑换任何现金）----------
router.get(PREFIX + '/leaderboard', auth, async (req, res) => {
  try {
    return ok(res, await niu.leaderboard({ limit: req.query.limit, days: req.query.days }));
  } catch (e) {
    console.error('[niu/leaderboard]', e.message);
    return fail(res, '获取排行榜失败', 500);
  }
});

// ---------- 每日免费积分（玩家积分的唯一自动来源）----------
router.post(PREFIX + '/daily-free', auth, actLimit, async (req, res) => {
  try {
    if (!await niu.isEnabled()) return fail(res, NG.SWITCHES.DISABLED_MESSAGE, 503, 'GAME_DISABLED');
    const r = await niu.grantDailyFree(req.user.id);
    if (r.error) return fail(res, '积分发放失败，请稍后重试', 500, 'GRANT_FAILED');
    if (!r.granted) {
      return ok(res, { granted: 0, game_points: r.points }, {
        message: '当前积分已足够开局，积分不足时每日会自动补发'
      });
    }
    return ok(res, { granted: r.granted, game_points: r.points }, {
      message: '已发放 ' + r.granted + ' ' + NG.POINTS.TEXT
    });
  } catch (e) {
    console.error('[niu/daily-free]', e.message);
    return fail(res, '积分发放失败，请稍后重试', 500);
  }
});

module.exports = router;
