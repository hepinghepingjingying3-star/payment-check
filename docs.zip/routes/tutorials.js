// ============================================
// 26牛牛 - 玩法教学（Tutorial）路由
// 包含:
//   - GET /api/tutorials        教学列表（大厅「玩法介绍」卡片）
//   - GET /api/tutorials/:id    单个教学页内容（纯教学，无任何聊天数据）
// 说明:
//   - 数据来自 config/tutorials.js
//   - 教学页面绝对不包含: 聊天输入框 / 玩家聊天 / 红包 / 贴图 / 打赏客服 / 假玩家消息
//   - 插图只返回站长真实放入 public/assets/tutorial 的图片地址，未放入则为 null
// ============================================

const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const T = require('../config/tutorials');
const { getManifest } = require('./assets');
const { ok, fail } = require('../utils/request');

// GET /api/tutorials
router.get('/tutorials', auth, async (req, res) => {
  try {
    return ok(res, {
      list: T.listTutorials(),
      numbers: T.TUTORIAL_NUMBERS
    });
  } catch (err) {
    console.error('获取教学列表失败:', err.message);
    return fail(res, '玩法介绍加载失败', 500);
  }
});

// GET /api/tutorials/:id
router.get('/tutorials/:id', auth, async (req, res) => {
  try {
    const t = T.getTutorial(String(req.params.id));
    if (!t) return fail(res, '教学内容不存在', 404);

    let illustrations = [];
    try {
      const m = getManifest(false);
      illustrations = ((m && m.tutorial) || []).map(x => x.url);
    } catch (e) { illustrations = []; }

    return ok(res, {
      id: t.id,
      title: t.title,
      subtitle: t.subtitle,
      group: t.group,
      icon: t.icon,
      sections: t.sections || [],
      illustrations: illustrations,
      numbers: T.TUTORIAL_NUMBERS,
      notice: '本页面为纯玩法教学，不含聊天、红包或任何玩家消息'
    });
  } catch (err) {
    console.error('获取教学内容失败:', err.message);
    return fail(res, '玩法介绍加载失败', 500);
  }
});

module.exports = router;