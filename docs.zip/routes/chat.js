// ============================================
// 26牛牛 - 聊天路由（V4）
// 包含:
//   - GET    /api/chat/channels            会话列表（游戏群 + 在线客服）+ 真实在线人数 + 我的禁言状态
//   - GET    /api/chat/messages            消息分页（cursor 向上翻页，默认最近 30 条）
//   - POST   /api/chat/messages            发送消息（text / image / sticker）
//   - POST   /api/chat/read                标记已读
//   - POST   /api/chat/recall/:id          撤回自己的消息
//   - POST   /api/chat/report              举报消息
//   - GET    /api/chat/stickers            贴图列表（official + mine）
//   - POST   /api/chat/stickers            上传自定义贴图（multipart，服务端验证内容）
//   - DELETE /api/chat/stickers/:id        删除自己的贴图
//   - POST   /api/chat/redpackets          发聊天红包（平台现金筹码，非真实资金）
//   - GET    /api/chat/redpackets/:id      红包详情（领取记录 / 手气最佳 / 我能否领取）
//   - POST   /api/chat/redpackets/:id/claim 抢红包（事务 + 行锁，绝不超发）
//   - POST   /api/chat/system              （admin/support）写入系统 / 游戏消息
// 消息类型（与数据库一致，以后接入游戏系统消息无需重做架构）:
//   text / image / sticker / system / game / redpacket
// 安全:
//   - 全部 JWT；身份取自 req.user，绝不信任前端传的 user_id
//   - 消息列表只返回 username，绝不返回手机号 / 邮箱 / 姓名
//   - 不提供好友 / 私聊 / 搜索玩家能力
//   - 客服为留言模式：不伪造客服回复、不伪造在线状态
//   - 在线人数来自 user_presence 心跳（不可用时如实返回 null，不用账号数冒充）
//   - 禁言联动范围见 config/moderation.js（发消息 / 发红包都属于禁言范围）
// ============================================

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const ASSETS = require('../config/assets');
const RED_PACKET = require('../config/redPacket');
const { getManifest } = require('./assets');
const { ok, fail, safeInternalPath } = require('../utils/request');
const { visibleMessages, unreadCounts, chatRoom } = require('../utils/chatVisibility');
const { muteState, muteMessage, scopeBlocked, muteSummary } = require('../utils/moderation');
const presence = require('../utils/presence');
const chatRedPacket = require('../utils/chatRedPacket');


const MAX_LEN = 500;                              // 文本最大长度
const DEFAULT_LIMIT = 30;                         // 第一次只加载最近 30 条
const MAX_LIMIT = 50;
const RECALL_WINDOW_MS = 2 * 60 * 60 * 1000;      // 2 小时内可撤回
const GROUP_CHANNEL = 'group';
const SUPPORT_CHANNEL = 'support';
const USER_STICKER_MAX_BYTES = 2 * 1024 * 1024;   // 单张贴图最大 2MB

// ---------- 工具 ----------
function okChannel(c) { return c === GROUP_CHANNEL || c === SUPPORT_CHANNEL; }

/** 消息行 → 安全 JSON（只返回 username + avatar，绝不带敏感字段） */
function msgOut(r, meId) {
  return {
    id: Number(r.id),
    channel: r.channel,
    message_type: r.message_type,
    content: r.is_recalled ? '' : r.content,
    meta: r.meta || null,
    is_recalled: !!r.is_recalled,
    sender_role: r.sender_role || 'user',
    is_mine: r.user_id != null && Number(r.user_id) === Number(meId) && r.sender_role !== 'admin',
    is_system: r.message_type === 'system' || (r.user_id == null && r.message_type !== 'game'),
    username: r.username || '',
    avatar_url: r.avatar_url || null,
    created_at: r.created_at
  };
}

const MSG_SELECT =
  `SELECT m.id, m.channel, m.user_id, m.message_type, m.content, m.meta, m.sender_role, m.is_recalled, m.created_at, u.username, u.avatar_url
   FROM chat_messages m LEFT JOIN users u ON u.id = m.user_id`;

/** 官方贴图：只使用站长真实放入 public/assets/stickers/official 的图片（不使用 emoji） */
function officialStickers() {
  try {
    const m = getManifest(false);
    return (m.stickers || []).map(x => ({ id: x.key, name: x.key, url: x.url }));
  } catch (e) {
    return [];
  }
}

/** 我的贴图（数据库，仅本人可见） */
async function myStickers(userId) {
  const [rows] = await db.promise().query(
    `SELECT id, name, url, size_bytes, mime_type, created_at
     FROM user_stickers WHERE user_id = ? ORDER BY id DESC LIMIT 60`,
    [userId]
  );
  return rows.map(r => ({
    id: Number(r.id),
    name: r.name,
    url: r.url,
    size_bytes: Number(r.size_bytes || 0),
    mime_type: r.mime_type || '',
    created_at: r.created_at
  }));
}

/** 官方头像（站长放入后自动使用；未放入返回 null，前端用无图占位，不产生 404） */
function officialAvatar(kind) {
  try {
    const m = getManifest(false);
    const list = m.avatars || [];
    if (!list.length) return null;
    if (kind === 'support') {
      const s = list.find(x => x.key.toLowerCase().indexOf('support') >= 0);
      return (s || list[0]).url;
    }
    const g = list.find(x => x.key.toLowerCase().indexOf('group') >= 0);
    return (g || list[0]).url;
  } catch (e) {
    return null;
  }
}

// ============================================
// GET /api/chat/channels - 会话列表
// 只返回当前用户有权限访问的会话（游戏群 + 在线客服）
// ============================================
router.get('/chat/channels', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    const visible = visibleMessages(userId, 'v');
    const [rows] = await db.promise().query(
      MSG_SELECT +
      ` JOIN (SELECT v.channel, MAX(v.id) AS maxid FROM chat_messages v
               WHERE ${visible.sql} GROUP BY v.channel) t
         ON t.channel = m.channel AND t.maxid = m.id`, visible.params
    );
    const unread = await unreadCounts(db, userId);

    // 真实在线人数（Socket 心跳 / 聊天轮询心跳）；表不可用时为 null，不编造数字
    // 同时把本次请求当作一次心跳（内存节流，不会频繁写库）
    presence.touch(userId).catch(() => {});
    const online = await presence.onlineCount();
    const myMute = await muteSummary(userId);

    function lastOf(ch) {
      const r = rows.find(x => x.channel === ch);
      if (!r) return null;
      return {
        id: Number(r.id),
        preview: r.is_recalled ? '消息已撤回' : (
          r.message_type === 'text' || r.message_type === 'system' ? r.content :
          r.message_type === 'sticker' ? '[贴图]' :
          r.message_type === 'game' ? '[游戏消息]' :
          r.message_type === 'redpacket' ? '[红包]' : '[图片]'),
        time: r.created_at
      };
    }

    const groupLast = lastOf(GROUP_CHANNEL);
    const supportLast = lastOf(SUPPORT_CHANNEL);
    const groupAvatar = officialAvatar('group');
    const supportAvatar = officialAvatar('support');

    const list = [
      {
        channel: GROUP_CHANNEL,
        name: '26牛牛游戏群',
        avatar: groupAvatar,
        avatar_ready: !!groupAvatar,
        pinned: true,
        tag: '游戏',
        online: online === null ? null : online > 0,
        // 在线人数 = 最近 90 秒内有 Socket 连接或聊天心跳的活跃账号（表缺失时为 null）
        member_online: online,
        empty_text: '群里还没有消息，打个招呼吧',
        unread: unread.group,
        last: groupLast
      },
      {
        channel: SUPPORT_CHANNEL,
        name: '在线客服',
        avatar: supportAvatar,
        avatar_ready: !!supportAvatar,
        pinned: false,
        tag: '',
        // 客服实时系统尚未上线：如实显示留言模式，不伪造真人在线
        online: false,
        member_online: null,
        empty_text: '客服暂时离线，可以留言，客服上线后会回复',
        unread: unread.support,
        last: supportLast
      }
    ];

    return ok(res, {
      list: list,
      can_add_friend: false,
      online: {
        count: online,
        window_seconds: presence.WINDOW,
        available: online !== null,
        note: online === null
          ? '在线状态表不可用，无法统计在线人数（不会用账号总数冒充）'
          : '最近 ' + presence.WINDOW + ' 秒内有连接或聊天活跃的账号数'
      },
      my_mute: myMute,
      red_packet: {
        enabled: RED_PACKET.CHANNELS.indexOf(GROUP_CHANNEL) >= 0,
        channels: RED_PACKET.CHANNELS,
        asset_text: RED_PACKET.ASSET_TEXT,
        min_amount: RED_PACKET.MIN_AMOUNT,
        max_amount: RED_PACKET.MAX_AMOUNT,
        min_count: RED_PACKET.MIN_COUNT,
        max_count: RED_PACKET.MAX_COUNT,
        blessing_max: RED_PACKET.BLESSING_MAX,
        expire_hours: RED_PACKET.EXPIRE_HOURS,
        allow_sender_claim: RED_PACKET.ALLOW_SENDER_CLAIM,
        notice: RED_PACKET.NOTICE
      }
    });
  } catch (err) {
    console.error('获取会话列表失败:', err.message);
    return fail(res, '会话列表加载失败', 500);
  }
});

// ============================================
// GET /api/chat/messages?channel=group&before=<id>&limit=30
// cursor 分页：before 为空 → 最新一页；向上翻页传上一页最小 id
// ============================================
router.get('/chat/messages', auth, async (req, res) => {
  try {
    const channel = String(req.query.channel || '');
    if (!okChannel(channel)) return fail(res, '无效的频道');

    // 聊天轮询同时作为在线心跳（节流写入 user_presence）
    presence.touch(req.user.id).catch(() => {});

    const limit = Math.min(parseInt(req.query.limit, 10) || DEFAULT_LIMIT, MAX_LIMIT);
    const before = parseInt(req.query.before, 10);

    const params = [channel];
    let where = 'm.channel = ?';
    // 客服当前为私人留言模式；身份只取自 JWT，不接受客户端指定用户。
    if (channel === SUPPORT_CHANNEL) {
      where += ' AND m.user_id = ?';
      params.push(req.user.id);
    }
    if (!isNaN(before) && before > 0) {
      where += ' AND m.id < ?';
      params.push(before);
    }
    params.push(limit);

    const [rows] = await db.promise().query(
      MSG_SELECT + ' WHERE ' + where + ' ORDER BY m.id DESC LIMIT ?', params
    );

    const list = rows.reverse().map(r => msgOut(r, req.user.id));
    return ok(res, {
      list: list,
      has_more: rows.length === limit,
      next_before: list.length > 0 ? list[0].id : null,
      channel: channel,
      support_offline: channel === SUPPORT_CHANNEL
    });
  } catch (err) {
    console.error('获取消息失败:', err.message);
    return fail(res, '消息加载失败，请重新加载', 500);
  }
});

// ============================================
// POST /api/chat/messages  { channel, message_type, content, meta }
// 用户只允许 text / sticker / image；system 与 game 只能由后台写入
// ============================================
router.post('/chat/messages', auth, async (req, res) => {
  try {
    const channel = String(req.body.channel || '');
    const type = String(req.body.message_type || 'text');
    const content = String(req.body.content == null ? '' : req.body.content).trim();
    const meta = req.body.meta || null;

    if (!okChannel(channel)) return fail(res, '无效的频道');
    if (type === 'system' || type === 'game' || type === 'redpacket') {
      return fail(res, type === 'redpacket' ? '红包请使用发红包接口' : '系统消息只能由后台发送', 403);
    }
    if (type !== 'text' && type !== 'sticker' && type !== 'image') return fail(res, '不支持的消息类型');

    // 禁言联动（以数据库为准）：被禁言用户仍可查看消息，但不能发送
    // 范围由 config/moderation.js 的 MUTE.SCOPE.chat 控制
    // 全体禁言（moderation_actions GROUP/ACTIVE）：普通用户禁言，管理员仍可发
    if (req.user.role !== 'admin') {
      try {
        const g = (await db.promise().query(
          'SELECT id FROM moderation_actions WHERE scope = ? AND action = ? AND status = ? LIMIT 1',
          ['GROUP', 'MUTE', 'ACTIVE']
        ))[0][0];
        if (g) return fail(res, '管理员已开启全体禁言，暂时无法发送消息', 403, 'GROUP_MUTED');
      } catch (e) { /* 禁言表不可用时不阻断聊天 */ }
    }
    const muted = await scopeBlocked(req.user.id, 'chat');
    if (muted) return fail(res, muted.message, muted.status, muted.code);
    if (type === 'text' && (!content || content.length > MAX_LEN)) {
      return fail(res, '消息内容为空或超过 ' + MAX_LEN + ' 字');
    }
    if (type === 'sticker' || type === 'image') {
      const url = meta && typeof meta === 'object' ? String(meta.url || '') : '';
      // 只允许站内资源地址，防止外链注入
      const safeUrl = safeInternalPath(url);
      if (!safeUrl || !url.startsWith('/assets/') || /[%?#]/.test(url) || url.split('/').includes('..')) return fail(res, '无效的图片地址');
      if (url.startsWith('/assets/stickers/official/')) {
        const [users] = await db.promise().query('SELECT role, status FROM users WHERE id = ?', [req.user.id]);
        if (!users[0] || users[0].role !== 'admin' || users[0].status !== 'active') {
          return fail(res, '官方贴图仅管理员可以发送', 403);
        }
        if (!officialStickers().some(s => s.url === url)) return fail(res, '贴图不存在', 404);
      } else {
        const [owned] = await db.promise().query('SELECT id FROM user_stickers WHERE user_id = ? AND url = ? LIMIT 1', [req.user.id, url]);
        if (!owned.length || !url.startsWith(ASSETS.USER_STICKER_URL_BASE + '/')) return fail(res, '只能发送自己的上传图片', 403);
      }
    }

    const [result] = await db.promise().query(
      `INSERT INTO chat_messages (channel, user_id, message_type, content, meta)
       VALUES (?, ?, ?, ?, ?)`,
      [channel, req.user.id, type, type === 'text' ? content : '', meta ? JSON.stringify(meta) : null]
    );

    const [rows] = await db.promise().query(MSG_SELECT + ' WHERE m.id = ?', [result.insertId]);
    const msg = msgOut(rows[0], req.user.id);

    // 实时推送（Socket.IO 可用时；失败不影响 REST 返回）
    try {
      const io = req.app.get('io');
      if (io) io.to('chat:' + channel).emit('chat:message', msg);
    } catch (e) { /* 实时推送失败不影响消息已入库 */ }

    return res.status(201).json({ success: true, data: msg });
  } catch (err) {
    console.error('发送消息失败:', err.message);
    return fail(res, '发送失败，请重试', 500);
  }
});

// ============================================
// POST /api/chat/read { channel } - 标记已读到当前最新
// ============================================
router.post('/chat/read', auth, async (req, res) => {
  try {
    const channel = String(req.body.channel || '');
    if (!okChannel(channel)) return fail(res, '无效的频道');

    const visible = visibleMessages(req.user.id);
    const [maxRows] = await db.promise().query(
      `SELECT COALESCE(MAX(m.id), 0) AS maxid FROM chat_messages m
       WHERE m.channel = ? AND ${visible.sql}`, [channel, ...visible.params]
    );
    const maxId = Number(maxRows[0].maxid) || 0;

    await db.promise().query(
      `INSERT INTO chat_read_state (user_id, channel, last_read_id)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE last_read_id = GREATEST(last_read_id, VALUES(last_read_id))`,
      [req.user.id, channel, maxId]
    );

        // 推送已读状态到聊天频道（用于实时「已读」标记）
    try {
      const io = req.app.get('io');
      if (io) {
        io.to('chat:' + channel).emit('chat:read', {
          channel: channel,
          user_id: req.user.id,
          username: req.user.username,
          last_read_id: maxId
        });
      }
    } catch (e) { /* 推送失败不影响主流程 */ }

    return ok(res, { channel: channel, last_read_id: maxId });
  } catch (err) {
    console.error('标记已读失败:', err.message);
    return fail(res, '服务器内部错误，请稍后重试', 500);
  }
});

// ============================================
// POST /api/chat/recall/:id - 撤回自己的消息
// 后端强制验证：只能撤回自己的、未撤回的、2 小时内的消息；系统消息不可撤回
// ============================================
router.post('/chat/recall/:id', auth, async (req, res) => {
  try {
    const msgId = Number(req.params.id);
    if (!Number.isInteger(msgId) || msgId <= 0) return fail(res, '无效的消息');

    const [rows] = await db.promise().query(
      'SELECT id, channel, user_id, is_recalled, message_type, created_at FROM chat_messages WHERE id = ?',
      [msgId]
    );
    if (rows.length === 0) return fail(res, '消息不存在', 404);

    const m = rows[0];
    if (m.user_id == null || Number(m.user_id) !== Number(req.user.id)) {
      return fail(res, '只能撤回自己的消息', 403);
    }
    if (m.is_recalled) return fail(res, '该消息已撤回');
    if (m.message_type === 'system') return fail(res, '系统消息不能撤回', 403);
    // 红包消息涉及资产（发送即已扣款、他人可能已领取），一律不允许撤回
    if (m.message_type === 'redpacket') return fail(res, '红包消息不能撤回，未领取部分会到期自动退回', 403, 'RED_PACKET_NO_RECALL');

    const sentAt = new Date(m.created_at).getTime();
    if (Number.isFinite(sentAt) && Date.now() - sentAt > RECALL_WINDOW_MS) {
      return fail(res, '超过 2 小时的消息不能撤回');
    }

    await db.promise().query(
      'UPDATE chat_messages SET is_recalled = 1, content = "" WHERE id = ?', [msgId]
    );

    try {
      const io = req.app.get('io');
      if (io) io.to('chat:' + m.channel).emit('chat:recall', { id: msgId, channel: m.channel });
    } catch (e) { /* 忽略 */ }

    return ok(res, { id: msgId });
  } catch (err) {
    console.error('撤回消息失败:', err.message);
    return fail(res, '撤回失败，请重试', 500);
  }
});

// ============================================
// POST /api/chat/report { message_id, reason }
// ============================================
router.post('/chat/report', auth, async (req, res) => {
  try {
    const messageId = Number(req.body.message_id);
    const reason = String(req.body.reason || '').trim();

    if (!Number.isInteger(messageId) || messageId <= 0) return fail(res, '无效的消息');
    if (!reason) return fail(res, '请填写举报原因');
    if (reason.length > 200) return fail(res, '举报原因最多 200 字');

    const [rows] = await db.promise().query('SELECT id FROM chat_messages WHERE id = ?', [messageId]);
    if (rows.length === 0) return fail(res, '消息不存在', 404);

    await db.promise().query(
      'INSERT INTO chat_reports (reporter_id, message_id, reason) VALUES (?, ?, ?)',
      [req.user.id, messageId, reason]
    );

    return ok(res, { reported: true, tip: '举报已提交，感谢您的反馈' });
  } catch (err) {
    console.error('举报失败:', err.message);
    return fail(res, '举报提交失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/chat/stickers - 贴图列表（官方 + 我的）
// 官方贴图必须使用真实图片（不使用 emoji）；未放入素材时返回空数组
// ============================================
router.get('/chat/stickers', auth, async (req, res) => {
  try {
    const [users] = await db.promise().query('SELECT role, status FROM users WHERE id = ?', [req.user.id]);
    const canUseOfficial = !!(users[0] && users[0].role === 'admin' && users[0].status === 'active');
    const official = canUseOfficial ? officialStickers() : [];
    const mine = await myStickers(req.user.id);
    return ok(res, {
      can_use_official: canUseOfficial,
      official: official,
      mine: mine,
      official_ready: official.length > 0,
      upload_limits: {
        max_bytes: USER_STICKER_MAX_BYTES,
        accept: ['image/png', 'image/jpeg', 'image/webp', 'image/gif']
      },
      note: official.length === 0
        ? '官方贴图目录尚未放入素材（public/assets/stickers/official）'
        : ''
    });
  } catch (err) {
    console.error('获取贴图失败:', err.message);
    return fail(res, '贴图加载失败', 500);
  }
});

// ============================================
// 用户自定义贴图上传
// 安全:
//   - 只允许 png / jpg / jpeg / webp / gif，单张 ≤ 2MB
//   - 服务端二次校验文件头（magic bytes），防止伪造扩展名上传脚本
//   - 文件名由服务端生成（不使用用户提供的文件名）
//   - 只保存到 public/assets/stickers/user/ 下，只返回站内路径
// ============================================
const stickerUploadDir = path.join(__dirname, '..', 'public', ASSETS.USER_STICKER_DIR);
try { fs.mkdirSync(stickerUploadDir, { recursive: true }); } catch (e) { /* 目录已存在 */ }

const EXT_BY_MIME = {
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/webp': '.webp',
  'image/gif': '.gif'
};

const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) { cb(null, stickerUploadDir); },
    filename: function (req, file, cb) {
      const ext = EXT_BY_MIME[file.mimetype] || '.png';
      const rnd = require('crypto').randomBytes(4).toString('hex');
      cb(null, 'u' + req.user.id + '_' + Date.now() + '_' + rnd + ext);
    }
  }),
  limits: { fileSize: USER_STICKER_MAX_BYTES, files: 1 },
  fileFilter: function (req, file, cb) {
    if (EXT_BY_MIME[file.mimetype]) return cb(null, true);
    cb(new Error('UNSUPPORTED_TYPE'));
  }
});

/** 文件头校验（magic bytes） */
function sniffImage(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  if (buf.toString('ascii', 0, 3) === 'GIF') return 'image/gif';
  return null;
}

// POST /api/chat/stickers  (multipart/form-data: file, name?)
router.post('/chat/stickers', auth, function (req, res) {
  upload.single('file')(req, res, async function (err) {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') return fail(res, '图片过大，请选择小于 2MB 的图片', 413);
      if (err.message === 'UNSUPPORTED_TYPE') return fail(res, '只支持 PNG / JPG / WEBP / GIF 图片');
      console.error('贴图上传失败:', err.message);
      return fail(res, '上传失败，请重试', 400);
    }
    if (!req.file) return fail(res, '请选择要上传的图片');

    const abs = req.file.path;
    try {
      // 服务端内容校验：读取文件头确认真实图片类型
      const fd = fs.openSync(abs, 'r');
      const buf = Buffer.alloc(16);
      fs.readSync(fd, buf, 0, 16, 0);
      fs.closeSync(fd);
      const sniffed = sniffImage(buf);
      if (!sniffed) {
        fs.unlinkSync(abs);
        return fail(res, '文件内容不是有效图片，已拒绝保存');
      }

      const [countRows] = await db.promise().query(
        'SELECT COUNT(*) AS c FROM user_stickers WHERE user_id = ?', [req.user.id]
      );
      if (Number(countRows[0].c) >= 60) {
        fs.unlinkSync(abs);
        return fail(res, '我的贴图已达上限（60 张），请先删除部分贴图');
      }

      const name = String(req.body.name || '').trim().slice(0, 50) || '我的贴图';
      const url = ASSETS.USER_STICKER_URL_BASE + '/' + req.file.filename;

      const [ins] = await db.promise().query(
        `INSERT INTO user_stickers (user_id, name, url, size_bytes, mime_type) VALUES (?, ?, ?, ?, ?)`,
        [req.user.id, name, url, req.file.size, sniffed]
      );

      return res.status(201).json({
        success: true,
        data: {
          id: Number(ins.insertId),
          name: name,
          url: url,
          size_bytes: req.file.size,
          mime_type: sniffed
        }
      });
    } catch (e) {
      console.error('保存贴图失败:', e.message);
      try { fs.unlinkSync(abs); } catch (e2) { /* 忽略 */ }
      return fail(res, '保存失败，请重试', 500);
    }
  });
});

// DELETE /api/chat/stickers/:id - 删除自己的贴图（同时删除文件）
router.delete('/chat/stickers/:id', auth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return fail(res, '无效的贴图ID');

    const [rows] = await db.promise().query(
      'SELECT id, user_id, url FROM user_stickers WHERE id = ?', [id]
    );
    if (rows.length === 0) return fail(res, '贴图不存在', 404);
    if (Number(rows[0].user_id) !== Number(req.user.id)) return fail(res, '只能删除自己的贴图', 403);

    await db.promise().query('DELETE FROM user_stickers WHERE id = ? AND user_id = ?', [id, req.user.id]);

    // 删除物理文件（只允许删除本站用户贴图目录内的文件，防路径穿越）
    try {
      const rel = String(rows[0].url || '');
      if (rel.indexOf(ASSETS.USER_STICKER_URL_BASE + '/') === 0) {
        const abs = path.join(stickerUploadDir, path.basename(rel));
        if (abs.indexOf(stickerUploadDir) === 0 && fs.existsSync(abs)) fs.unlinkSync(abs);
      }
    } catch (e) { /* 文件删除失败不影响数据删除 */ }

    return ok(res, { id: id, removed: true });
  } catch (err) {
    console.error('删除贴图失败:', err.message);
    return fail(res, '删除失败，请重试', 500);
  }
});

// ============================================
// POST /api/chat/system  (admin / support)
// 写入系统消息或游戏阶段消息，供未来游戏模块直接调用
// body: { channel, message_type: 'system'|'game', content, meta }
// 示例: { channel:'group', message_type:'game', content:'抢庄阶段开始',
//         meta:{ stage:'banker_bidding' } }
// ============================================
router.post('/chat/system', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    const channel = String(req.body.channel || GROUP_CHANNEL);
    const type = String(req.body.message_type || 'system');
    const content = String(req.body.content || '').trim();
    const meta = req.body.meta || null;

    if (!okChannel(channel)) return fail(res, '无效的频道');
    if (type !== 'system' && type !== 'game') return fail(res, '只支持 system / game 类型');
    if (!content || content.length > MAX_LEN) return fail(res, '消息内容为空或过长');

    const [result] = await db.promise().query(
      `INSERT INTO chat_messages (channel, user_id, message_type, content, meta)
       VALUES (?, NULL, ?, ?, ?)`,
      [channel, type, content, meta ? JSON.stringify(meta) : null]
    );

    const [rows] = await db.promise().query(MSG_SELECT + ' WHERE m.id = ?', [result.insertId]);
    const msg = msgOut(rows[0], req.user.id);

    try {
      const io = req.app.get('io');
      if (io) io.to('chat:' + channel).emit('chat:message', msg);
    } catch (e) { /* 忽略 */ }

    return res.status(201).json({ success: true, data: msg });
  } catch (err) {
    console.error('发送系统消息失败:', err.message);
    return fail(res, '发送失败，请重试', 500);
  }
});

// ============================================
// POST /api/chat/redpackets  发聊天红包
// body: { channel, amount, count, blessing }
// 资金: 扣发送者平台现金筹码（users.cash_chips），写余额流水，非真实资金
// ============================================
router.post('/chat/redpackets', auth, async (req, res) => {
  try {
    const channel = String(req.body.channel || GROUP_CHANNEL);
    if (RED_PACKET.CHANNELS.indexOf(channel) === -1) {
      return fail(res, '该频道暂不支持发红包', 400, 'CHANNEL_NOT_ALLOWED');
    }
    // 禁言联动：被禁言账号不能发红包（范围见 config/moderation.js）
    const blocked = await scopeBlocked(req.user.id, RED_PACKET.SCOPE_KEY);
    if (blocked) return fail(res, blocked.message, blocked.status, blocked.code);

    const created = await chatRedPacket.createPacket({
      senderId: req.user.id,
      channel: channel,
      amount: req.body.amount,
      count: req.body.count,
      blessing: req.body.blessing
    });
    if (!created.ok) return fail(res, created.message, created.status, created.code);

    // 以标准聊天消息结构返回并实时推送（其它端无需刷新即可看到红包）
    const [rows] = await db.promise().query(MSG_SELECT + ' WHERE m.id = ?', [created.message_id]);
    const msg = msgOut(rows[0], req.user.id);
    try {
      const io = req.app.get('io');
      if (io) {
        io.to('chat:' + channel).emit('chat:message', msg);
        io.to('chat:' + channel).emit('chat:redpacket_created', {
          packet_id: created.packet_id,
          packet_no: created.packet.packet_no,
          sender_name: created.packet.sender_name,
          total_amount: created.packet.total_amount,
          total_count: created.packet.total_count
        });
      }
    } catch (e) { /* 实时推送失败不影响红包已生成 */ }

    return res.status(201).json({
      success: true,
      data: {
        message: msg,
        packet: created.packet,
        balance_before: created.balance_before,
        balance_after: created.balance_after,
        notice: RED_PACKET.NOTICE
      }
    });
  } catch (err) {
    console.error('发送聊天红包失败:', err.message);
    return fail(res, '红包发送失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/chat/redpackets/:id  红包详情（含领取记录 / 手气最佳 / 我能否领取）
// ============================================
router.get('/chat/redpackets/:id', auth, async (req, res) => {
  try {
    const result = await chatRedPacket.getPacket(req.user.id, Number(req.params.id));
    if (!result.ok) return fail(res, result.message, result.status, result.code);
    presence.touch(req.user.id).catch(() => {});
    return ok(res, { packet: result.packet });
  } catch (err) {
    console.error('读取聊天红包失败:', err.message);
    return fail(res, '红包详情加载失败，请稍后重试', 500);
  }
});

/** 抢到后返回完整红包详情（含领取记录 / 手气最佳）；详情读取失败时退回领取结果里的 packet */
async function fullPacketOrFallback(userId, packetId, fallback) {
  try {
    const detail = await chatRedPacket.getPacket(userId, packetId);
    return detail && detail.ok ? detail.packet : fallback;
  } catch (e) {
    return fallback;
  }
}

// ============================================
// POST /api/chat/redpackets/:id/claim  抢红包
// 事务 + 行锁 + 唯一键，绝不超发、绝不重复发
// ============================================
router.post('/chat/redpackets/:id/claim', auth, async (req, res) => {
  try {
    const packetId = Number(req.params.id);
    const blocked = await scopeBlocked(req.user.id, RED_PACKET.SCOPE_KEY);
    if (blocked) return fail(res, blocked.message, blocked.status, blocked.code);

    const result = await chatRedPacket.claim({ packetId: packetId, userId: req.user.id });
    if (!result.ok) {
      // 已抢过 / 已抢光 / 已过期：仍返回最新红包状态，方便前端刷新气泡
      const info = await chatRedPacket.getPacket(req.user.id, packetId);
      return res.status(result.status || 409).json({
        success: false,
        code: result.code,
        message: result.message,
        amount: result.amount === undefined ? null : result.amount,
        packet: info.ok ? info.packet : null
      });
    }

    try {
      const io = req.app.get('io');
      if (io && result.packet) {
        io.to('chat:' + result.packet.channel).emit('chat:redpacket_claimed', {
          packet_id: packetId,
          username: req.user.username,
          amount: result.amount,
          claimed_count: result.packet.claimed_count,
          total_count: result.packet.total_count,
          status: result.packet.status
        });
      }
    } catch (e) { /* 实时推送失败不影响已入账 */ }

    return ok(res, {
      amount: result.amount,
      // 领取成功后统一返回「完整详情」（含领取记录 / 手气最佳），
      // 否则「已抢到红包」弹层拿到的 packet 缺 claims / claims_total，会显示成「领取记录（undefined 人）」
      packet: await fullPacketOrFallback(req.user.id, packetId, result.packet),
      balance_after: result.balance_after,
      finished: result.finished,
      notice: RED_PACKET.NOTICE
    });
  } catch (err) {
    console.error('抢聊天红包失败:', err.message);
    return fail(res, '抢红包失败，请稍后重试', 500);
  }
});

module.exports = router;
module.exports.msgOut = msgOut;