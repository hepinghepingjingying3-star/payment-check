// ============================================
// 26牛牛 - 充值（用户端）route
// ============================================
// 接口:
//   GET  /api/deposit/config                      充值配置（金额上下限/快捷金额/付款方式/测试收款资料）
//   POST /api/deposits/orders                     创建唯一充值订单（PENDING_PAYMENT）
//   GET  /api/deposits/orders                     我的充值订单（分页）
//   GET  /api/deposits/orders/:id                 我的订单详情
//   POST /api/deposits/orders/:id/voucher         上传转账凭证（JPG/PNG/WEBP，服务端二次校验）
//   GET  /api/deposits/orders/:id/voucher         查看自己的凭证（图片流，非公开目录）
//   POST /api/deposits/orders/:id/cancel          取消未审核订单
// 安全:
//   - 全部需要 JWT；只能操作自己的订单（越权一律 404）
//   - 金额前后端双重校验：最低 RM30 / 最高 RM50,000，拒绝 0 / 负数 / NaN / Infinity / 科学计数法
//   - 提交凭证只把状态改为 PENDING_REVIEW，绝不自动加余额
//   - 凭证不落 public，文件名由服务器生成，读取前做路径穿越校验
//   - 非现金化测试资产，不接任何真实收款渠道
// ============================================

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const router = express.Router();

const db = require('../config/db');
const { auth } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { limiter } = require('../utils/rateLimit');
const FUNDS = require('../config/funds');
const FUND = require('../utils/funds');
const { checkImage } = require('../utils/imageCheck');
const voucherStore = require('../utils/voucherStore');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: FUNDS.VOUCHER.MAX_BYTES, files: 1, fields: 8 }
});

/** 统一处理 multer 错误（不泄露内部堆栈） */
function uploadSingle(req, res, next) {
  upload.single('voucher')(req, res, err => {
    if (!err) return next();
    if (err.code === 'LIMIT_FILE_SIZE') {
      return fail(res, '图片过大，请压缩后重试（最大 ' +
        Math.round(FUNDS.VOUCHER.MAX_BYTES / 1024 / 1024) + 'MB）', 413, 'FILE_TOO_LARGE');
    }
    if (err.code === 'LIMIT_UNEXPECTED_FILE') return fail(res, '上传字段不正确', 422, 'UNEXPECTED_FILE');
    return fail(res, '上传失败，请重试', 400, 'UPLOAD_FAILED');
  });
}

function posInt(v) {
  const n = Number(v);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

// ============================================
// GET /api/deposit/config
// ============================================
router.get('/deposit/config', auth, (req, res) => {
  const d = FUNDS.DEPOSIT;
  return ok(res, {
    currency: 'RM',
    min: d.MIN,
    max: d.MAX,
    quick_amounts: d.QUICK_AMOUNTS,
    payment_methods: d.PAYMENT_METHODS.filter(m => m.enabled),
    default_method: d.DEFAULT_METHOD,
    test_mode: true,
    test_mode_notice: d.TEST_MODE_NOTICE,
    test_receiving: d.TEST_RECEIVING,
    declaration: d.DECLARATION,
    remark: { note: d.REMARK_NOTE, hints: d.REMARK_HINTS },
    usdt_entry: d.USDT_ENTRY,
    voucher: {
      mime_types: FUNDS.VOUCHER.MIME_TYPES,
      max_mb: Math.round(FUNDS.VOUCHER.MAX_BYTES / 1024 / 1024),
      requirements: FUNDS.VOUCHER.REQUIREMENTS
    },
    status_text: FUNDS.STATUS_TEXT
  });
});

// ============================================
// POST /api/deposits/orders - 创建充值订单
// 禁言联动说明：充值属于「资金流入」，对用户无风险，
// 因此 config/moderation.js 的 MUTE.SCOPE.deposit 默认关闭（被禁言也可充值）；
// 需要改成禁止时只改配置即可，无需改本文件。
// ============================================
router.post('/deposits/orders', auth, limiter('deposit.create', 20, 60 * 1000), async (req, res) => {
  const body = req.body || {};
  const rawMethod = String(body.payment_method || '').toUpperCase();
  const methods = FUNDS.DEPOSIT.PAYMENT_METHODS.filter(m => m.enabled).map(m => m.code);
  if (methods.indexOf(rawMethod) === -1) {
    return fail(res, '请选择付款方式', 422, 'INVALID_METHOD');
  }
  const cents = FUNDS.parseAmountToCents(body.amount, FUNDS.DEPOSIT.MIN, FUNDS.DEPOSIT.MAX);
  if (cents === null) {
    const num = Number(body.amount);
    if (!Number.isFinite(num) || num <= 0) return fail(res, '请输入充值金额', 422, 'AMOUNT_REQUIRED');
    if (num < FUNDS.DEPOSIT.MIN) {
      return fail(res, '最低充值金额为 RM' + FUNDS.DEPOSIT.MIN, 422, 'AMOUNT_BELOW_MIN');
    }
    if (num > FUNDS.DEPOSIT.MAX) {
      return fail(res, '单笔最高充值金额为 RM' + FUNDS.DEPOSIT.MAX.toLocaleString('en-US'), 422, 'AMOUNT_ABOVE_MAX');
    }
    return fail(res, '金额格式不正确（最多 2 位小数）', 422, 'AMOUNT_INVALID');
  }

  const created = await FUND.createDepositOrder(req.user.id, cents, rawMethod);
  if (!created.ok) return fail(res, created.message, created.status || 500, created.code);
  return ok(res, {
    order: created.order,
    next: '/deposit-detail.html?id=' + created.order.id
  });
});

// ============================================
// GET /api/deposits/orders - 我的充值订单
// ============================================
router.get('/deposits/orders', auth, async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    const status = String(req.query.status || '').toUpperCase();
    const data = await FUND.listMyOrders(req.user.id, 'DEPOSIT', status, limit, offset);
    return ok(res, data);
  } catch (err) {
    console.error('读取充值订单失败:', err.message);
    return fail(res, '充值记录加载失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/deposits/orders/:id - 我的订单详情
// ============================================
router.get('/deposits/orders/:id', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const order = await FUND.findMyOrder(req.user.id, id, 'DEPOSIT');
    if (!order) return fail(res, '订单不存在', 404, 'ORDER_NOT_FOUND');
    return ok(res, {
      order: order,
      test_mode: true,
      test_receiving: FUNDS.DEPOSIT.TEST_RECEIVING,
      declaration: FUNDS.DEPOSIT.DECLARATION,
      remark: { note: FUNDS.DEPOSIT.REMARK_NOTE, hints: FUNDS.DEPOSIT.REMARK_HINTS }
    });
  } catch (err) {
    console.error('读取充值订单详情失败:', err.message);
    return fail(res, '订单详情加载失败，请稍后重试', 500);
  }
});

// ============================================
// POST /api/deposits/orders/:id/voucher - 上传转账凭证
// ============================================
router.post('/deposits/orders/:id/voucher', auth, limiter('deposit.voucher', 10, 60 * 1000),
  uploadSingle, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  if (!req.file || !req.file.buffer) return fail(res, '请选择转账凭证图片', 422, 'FILE_REQUIRED');

  const check = checkImage(req.file.buffer);
  if (!check.ok) return fail(res, check.message, 422, check.code);

  let savedPath = null;
  try {
    savedPath = voucherStore.saveVoucher(req.file.buffer, check.ext, req.user.id);
    const result = await FUND.attachVoucher(req.user.id, id, 'DEPOSIT', savedPath);
    if (!result.ok) {
      try { fs.unlinkSync(voucherStore.resolveVoucher(savedPath) || ''); } catch (_) {}
      return fail(res, result.message, result.status || 400, result.code);
    }
    return ok(res, {
      order: result.order,
      message: '充值申请已提交，请等待管理员审核。',
      voucher: { width: check.width, height: check.height, mime: check.mime }
    });
  } catch (err) {
    if (savedPath) { try { fs.unlinkSync(voucherStore.resolveVoucher(savedPath) || ''); } catch (_) {} }
    console.error('凭证上传失败:', err.message);
    return fail(res, '凭证上传失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/deposits/orders/:id/voucher - 查看自己的凭证（图片流）
// ============================================
router.get('/deposits/orders/:id/voucher', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return res.status(422).json({ success: false, message: '无效的订单ID' });
  try {
    const [rows] = await db.promise().query(
      'SELECT voucher_path FROM wallet_orders WHERE id = ? AND user_id = ? AND order_type = \'DEPOSIT\' LIMIT 1',
      [id, req.user.id]
    );
    const abs = voucherStore.resolveVoucher(rows[0] ? rows[0].voucher_path : '');
    if (!abs || !fs.existsSync(abs)) return res.status(404).json({ success: false, message: '凭证不存在' });
    res.set('Cache-Control', 'no-store');
    const ext = path.extname(abs).toLowerCase();
    res.type(ext === '.png' ? 'image/png' : (ext === '.webp' ? 'image/webp' : 'image/jpeg'));
    return fs.createReadStream(abs).pipe(res);
  } catch (err) {
    console.error('读取凭证失败:', err.message);
    return res.status(500).json({ success: false, message: '凭证读取失败' });
  }
});

// ============================================
// POST /api/deposits/orders/:id/cancel - 取消未审核订单
// ============================================
router.post('/deposits/orders/:id/cancel', auth, async (req, res) => {
  const id = posInt(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  const r = await FUND.cancelMyOrder(req.user.id, id, 'DEPOSIT');
  if (!r.ok) return fail(res, r.message, r.status || 400, r.code);
  return ok(res, { status: r.status });
});

module.exports = router;


