// ============================================
// 26牛牛 - 系统配置中心 API（阶段 37 / 36 / 34）
// 包含:
//   - GET  /api/settings                        公开配置（未登录可读，不含敏感项）
//   - GET  /api/admin/settings                  管理员：全部配置定义 + 当前值
//   - PUT  /api/admin/settings                  管理员：批量保存 + 审计
//   - GET  /api/support/quick-replies           客服/管理员：快捷回复列表
//   - GET  /api/admin/support/quick-replies     管理员：全部快捷回复
//   - POST /api/admin/support/quick-replies     管理员：新增
//   - DELETE /api/admin/support/quick-replies/:id 管理员：下线（软删除）
// 权限:
//   - 公开接口不带 auth；管理接口走 /api/admin/** 全局边界 + 路由级 requireRole
// 安全:
//   - 公开接口只返回 config/site.js 的 PUBLIC_KEYS，绝不泄露密钥 / 内部配置
// ============================================

const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');
const siteSettings = require('../utils/siteSettings');
const { DEPOSIT_QUICK } = require('../config/site');

// ============================================
// GET /api/settings —— 公开配置
// 说明: 前端（登录页 / 大厅 / 钱包 / 聊天）统一从这里取站点名称、客服名称、
//       充值区间等，避免散落在各页面硬编码。
// ============================================
router.get('/settings', async (req, res) => {
  try {
    const pub = await siteSettings.getPublic();
    return ok(res, {
      settings: pub,
      deposit_quick: DEPOSIT_QUICK,
      maintenance: {
        on: pub.maintenance_mode === true,
        notice: pub.maintenance_notice || ''
      }
    });
  } catch (err) {
    console.error('读取公开配置失败:', err.message);
    return fail(res, '配置加载失败，请稍后重试', 500);
  }
});

// ============================================
// GET /api/admin/settings —— 管理员读取全部配置
// ============================================
router.get('/admin/settings', auth, requireRole('admin'), async (req, res) => {
  try {
    const all = await siteSettings.getAll();
    return ok(res, {
      values: all,
      definitions: siteSettings.definitions(),
      groups: [
        { key: 'basic', label: '基础信息' },
        { key: 'funds', label: '充值 / 提款' },
        { key: 'referral', label: '推广比例' },
        { key: 'limits', label: '上传 / 聊天限制' },
        { key: 'system', label: '系统状态' }
      ],
      notice: '全部为虚拟现金筹码相关配置；维护模式开启后普通用户会被挡在维护页之外，管理员与客服不受影响。'
    });
  } catch (err) {
    console.error('读取系统配置失败:', err.message);
    return fail(res, '系统配置加载失败，请稍后重试', 500);
  }
});

// ============================================
// PUT /api/admin/settings —— 管理员保存配置
// body: { values: { key: value, ... }, reason? }
// ============================================
router.put('/admin/settings', auth, requireRole('admin'), async (req, res) => {
  try {
    const patch = (req.body && req.body.values) || {};
    if (!Object.keys(patch).length) return fail(res, '没有需要保存的配置项');

    let result;
    try {
      result = await siteSettings.save(patch, req.user.id);
    } catch (e) {
      if (e.validation) return fail(res, e.message, 422);
      throw e;
    }

    // 审计：只记录「改了哪些键」，不记录任何密钥（本模块也不含密钥）
    if (result.changed.length) {
      await writeAdminLog({
        adminId: req.user.id,
        action: 'settings_update',
        detail: {
          changed: result.changed,
          values: result.changed.reduce((acc, k) => { acc[k] = result.values[k]; return acc; }, {}),
          reason: String((req.body && req.body.reason) || '').slice(0, 200) || null
        }
      });
    }

    const all = await siteSettings.getAll();
    return ok(res, {
      changed: result.changed,
      values: all,
      message: result.changed.length ? ('已保存 ' + result.changed.length + ' 项配置') : '配置没有变化'
    });
  } catch (err) {
    console.error('保存系统配置失败:', err.message);
    return fail(res, '系统配置保存失败，请稍后重试', 500);
  }
});

// ============================================
// 客服快捷回复（阶段 34）
// 说明: 管理员维护短语，客服点击后「插入输入框」，绝不自动发送
// ============================================
function replyOut(r) {
  return {
    id: Number(r.id), content: r.content, sort: Number(r.sort || 0),
    status: r.status, created_at: r.created_at
  };
}

/** 客服 / 管理员：读取可用快捷回复 */
router.get('/support/quick-replies', auth, requireRole('admin', 'support'), async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      "SELECT id, content, sort, status, created_at FROM support_quick_replies WHERE status = 'active' ORDER BY sort ASC, id ASC LIMIT 50"
    );
    return ok(res, { list: rows.map(replyOut) });
  } catch (err) {
    // 表不可用时前端隐藏快捷回复区，不影响客服正常发言
    console.error('读取快捷回复失败:', err.message);
    return ok(res, { list: [], unavailable: true });
  }
});

/** 管理员：全部快捷回复 */
router.get('/admin/support/quick-replies', auth, requireRole('admin'), async (req, res) => {
  try {
    const [rows] = await db.promise().query(
      'SELECT id, content, sort, status, created_at FROM support_quick_replies ORDER BY status ASC, sort ASC, id ASC LIMIT 200'
    );
    return ok(res, { list: rows.map(replyOut) });
  } catch (err) {
    console.error('读取快捷回复失败:', err.message);
    return fail(res, '快捷回复加载失败，请稍后重试', 500);
  }
});

/** 管理员：新增快捷回复 */
router.post('/admin/support/quick-replies', auth, requireRole('admin'), async (req, res) => {
  try {
    const content = String((req.body && req.body.content) || '').trim();
    if (content.length < 2) return fail(res, '快捷回复内容至少 2 个字符');
    if (content.length > 300) return fail(res, '快捷回复内容最多 300 个字符');
    const sort = Number.isFinite(Number(req.body && req.body.sort)) ? Number(req.body.sort) : 0;

    const [r] = await db.promise().query(
      "INSERT INTO support_quick_replies (content, sort, status, created_by) VALUES (?, ?, 'active', ?)",
      [content, Math.trunc(sort), req.user.id]
    );
    await writeAdminLog({
      adminId: req.user.id, action: 'support_quick_reply_add',
      detail: { id: Number(r.insertId), content: content }
    });
    return ok(res, { id: Number(r.insertId) });
  } catch (err) {
    console.error('新增快捷回复失败:', err.message);
    return fail(res, '快捷回复保存失败，请稍后重试', 500);
  }
});

/** 管理员：下线（软删除，保留审计痕迹） */
router.delete('/admin/support/quick-replies/:id', auth, requireRole('admin'), async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return fail(res, '无效的快捷回复ID');
    const [r] = await db.promise().query(
      "UPDATE support_quick_replies SET status = 'hidden', updated_at = NOW() WHERE id = ? AND status = 'active'",
      [id]
    );
    if (!r.affectedRows) return fail(res, '快捷回复不存在或已下线', 404);
    await writeAdminLog({ adminId: req.user.id, action: 'support_quick_reply_hide', detail: { id: id } });
    return ok(res, { id: id });
  } catch (err) {
    console.error('下线快捷回复失败:', err.message);
    return fail(res, '操作失败，请稍后重试', 500);
  }
});

module.exports = router;