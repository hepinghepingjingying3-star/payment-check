// ============================================
// 26牛牛 - 大厅路由（Phase 4A）
// 包含:
//   - GET /api/lobby/info  大厅信息（需登录，返回当前用户公开信息）
// 安全要求:
//   - 必须通过 JWT 验证
//   - 用户身份来自 JWT，不能由前端指定
//   - 不返回 password_hash、phone、email、real_name
// ============================================

// 引入 Express 路由
const express = require('express');
const router = express.Router();

// 引入数据库连接
const db = require('../config/db');

// 引入认证中间件
const { auth } = require('../middleware/auth');

// ============================================
// GET /api/lobby/info - 大厅信息（需登录）
// 返回当前登录用户的公开信息
// ============================================
router.get('/lobby/info', auth, async (req, res) => {
  try {
    // 从 JWT 中获取用户 ID（用户身份来自后端验证的 JWT）
    const userId = req.user.id;

    // 查询用户（只查询公开字段，不查询敏感字段）
    const [rows] = await db.promise().query(
      'SELECT id, username, role, status, created_at, game_balance, cash_chips FROM users WHERE id = ?',
      [userId]
    );

    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: '用户不存在，请重新登录' });
    }

    const user = rows[0];

    // 检查账号状态
    if (user.status === 'banned') {
      return res.status(403).json({ success: false, message: '该账号已被封禁，请联系客服' });
    }
    if (user.status === 'deleted') {
      return res.status(403).json({ success: false, message: '该账号已被删除' });
    }

    // 返回公开信息（绝不返回敏感字段）
    res.json({
      success: true,
      data: {
        id: user.id,
        username: user.username,
        role: user.role,
        status: user.status,
        created_at: user.created_at,
        // 资产概览：两个独立余额（DECIMAL → 数字，前端格式化显示）
        game_balance: Number(user.game_balance || 0),
        cash_chips: Number(user.cash_chips || 0)
      }
    });
  } catch (err) {
    console.error('获取大厅信息失败:', err.message);
    res.status(500).json({ success: false, message: '服务器内部错误，请稍后重试' });
  }
});

// 导出路由
module.exports = router;