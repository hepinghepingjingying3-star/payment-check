'use strict';
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const CHIPS = require('../config/cashChips');
const { auth, requireRole } = require('../middleware/auth');
const { ok, fail } = require('../utils/request');
const { writeAdminLog } = require('../utils/adminAudit');

const TEXT = CHIPS.RECHARGE.STATUS_TEXT;
const RC = CHIPS.RECEIVING;
function num(v) { const n = Number(v); return Number.isSafeInteger(n) && n > 0 ? n : null; }
function tx(v, m) { return String(v == null ? '' : v).trim().slice(0, m); }
function like(q) { return '%' + String(q == null ? '' : q).replace(/[\\%_]/g, function (c) { return '\\' + c; }) + '%'; }
const COLS = 'o.id,o.order_id,o.user_id,u.username,o.amount,o.currency,o.status,o.remark,o.reject_reason,o.receipt_path,o.operator_id,o.created_at,o.updated_at,o.completed_at,o.submitted_at,o.receiving_account_id,o.receiving_account_type,o.receiving_account_name,o.receiving_account_holder,o.receiving_account_no,o.payment_reference,o.admin_remark';
function out(o) {
  const hasAccount = Boolean(o.receiving_account_id || o.receiving_account_no);
  return {
    id: Number(o.id), order_id: o.order_id, order_no: o.order_id,
    user_id: Number(o.user_id), username: o.username || null,
    amount: Number(o.amount), currency: o.currency || CHIPS.ASSET, asset_text: CHIPS.ASSET_TEXT,
    status: o.status, status_text: TEXT[o.status] || o.status,
    remark: o.remark || '', reject_reason: o.reject_reason || '', admin_remark: o.admin_remark || '',
    payment_reference: o.payment_reference || '',
    // 管理员可查看订单绑定的收款账户完整资料（订单快照，停用/修改账户后历史不变）
    receiving_account: hasAccount ? {
      id: o.receiving_account_id == null ? null : Number(o.receiving_account_id),
      type: o.receiving_account_type || '',
      type_text: RC.TYPE_TEXT[o.receiving_account_type] || '',
      name: o.receiving_account_name || '',
      holder: o.receiving_account_holder || '',
      account_no: o.receiving_account_no || ''
    } : null,
    has_receipt: Boolean(o.receipt_path),
    receipt_url: o.receipt_path ? ('/api/admin/recharge/' + Number(o.id) + '/receipt') : null,
    operator_id: o.operator_id == null ? null : Number(o.operator_id),
    created_at: o.created_at, updated_at: o.updated_at || null,
    completed_at: o.completed_at || null, reviewed_at: o.completed_at || null,
    submitted_at: o.submitted_at || null
  };
}

// ---------- 后台收款账户：输出与输入校验（仅管理员） ----------
function accountOut(a) {
  return {
    id: Number(a.id), account_type: a.account_type,
    account_type_text: RC.TYPE_TEXT[a.account_type] || a.account_type,
    account_name: a.account_name, holder_name: a.holder_name, account_no: a.account_no,
    remark: a.remark || '', is_active: Number(a.is_active) ? 1 : 0,
    active_text: Number(a.is_active) ? '启用' : '停用',
    sort_order: Number(a.sort_order) || 0,
    created_at: a.created_at, updated_at: a.updated_at || null
  };
}
function parseAccountBody(body) {
  const b = body || {};
  const type = tx(b.account_type, 20).toUpperCase() || 'BANK';
  if (!RC.TYPE_TEXT[type]) return { error: '账户类型只能是银行或电子钱包' };
  const name = tx(b.account_name, RC.NAME_MAX);
  const holder = tx(b.holder_name, RC.HOLDER_MAX);
  const no = tx(b.account_no, RC.ACCOUNT_NO_MAX).replace(/\s+/g, '');
  if (!name) return { error: '请填写银行或电子钱包名称' };
  if (!holder) return { error: '请填写户名' };
  if (!no) return { error: '请填写账号或钱包号码' };
  if (no.length < RC.ACCOUNT_NO_MIN || no.length > RC.ACCOUNT_NO_MAX) {
    return { error: '账号或钱包号码长度须在 ' + RC.ACCOUNT_NO_MIN + '-' + RC.ACCOUNT_NO_MAX + ' 位之间' };
  }
  const remark = tx(b.remark, RC.REMARK_MAX);
  const isActive = (b.is_active === undefined || b.is_active === null || b.is_active === '')
    ? 1 : (b.is_active === 1 || b.is_active === true || b.is_active === '1' || b.is_active === 'true' ? 1 : 0);
  let sort = Number((b.sort_order === undefined || b.sort_order === null || b.sort_order === '') ? 0 : b.sort_order);
  if (!Number.isFinite(sort)) sort = 0;
  sort = Math.max(RC.SORT_MIN, Math.min(RC.SORT_MAX, Math.trunc(sort)));
  return { value: { type, name, holder, no, remark, isActive, sort } };
}
// ============================================
// 后台收款账户管理：列表 / 新增 / 修改 / 启用停用
// 权限：仅 admin（路由级 auth + requireRole，另有全局 /api/admin 边界）
// 安全：全部使用参数化 SQL；普通用户没有任何接口可以列出全部收款账户
// ============================================
router.get('/admin/receiving-accounts', auth, requireRole('admin'), async function (req, res) {
  try {
    const w = []; const p = [];
    const st = tx(req.query.status, 10);
    if (st === 'active') w.push('is_active = 1');
    else if (st === 'disabled') w.push('is_active = 0');
    const q = tx(req.query.q, 64);
    if (q) { w.push('(account_name LIKE ? OR holder_name LIKE ? OR account_no LIKE ?)'); p.push(like(q), like(q), like(q)); }
    const [rows] = await db.promise().query(
      'SELECT * FROM recharge_receiving_accounts ' + (w.length ? 'WHERE ' + w.join(' AND ') + ' ' : '') +
      'ORDER BY sort_order ASC, id ASC LIMIT 200', p);
    const [cnt] = await db.promise().query('SELECT COUNT(*) AS c, SUM(is_active = 1) AS active FROM recharge_receiving_accounts');
    return ok(res, {
      list: rows.map(accountOut),
      total: Number(cnt[0] && cnt[0].c) || 0,
      active_count: Number(cnt[0] && cnt[0].active) || 0,
      max_accounts: RC.MAX_ACCOUNTS,
      types: RC.TYPES
    });
  } catch (e) { return fail(res, '收款账户加载失败', 500); }
});

router.post('/admin/receiving-accounts', auth, requireRole('admin'), async function (req, res) {
  const parsed = parseAccountBody(req.body);
  if (parsed.error) return fail(res, parsed.error, 422, 'INVALID_ACCOUNT');
  const v = parsed.value;
  try {
    const [cnt] = await db.promise().query('SELECT COUNT(*) AS c FROM recharge_receiving_accounts');
    if (Number(cnt[0] && cnt[0].c) >= RC.MAX_ACCOUNTS) {
      return fail(res, '收款账户最多支持 ' + RC.MAX_ACCOUNTS + ' 个', 409, 'ACCOUNT_LIMIT');
    }
    const [r] = await db.promise().query(
      'INSERT INTO recharge_receiving_accounts (account_type, account_name, holder_name, account_no, remark, is_active, sort_order, created_by, updated_by) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [v.type, v.name, v.holder, v.no, v.remark || null, v.isActive, v.sort, req.user.id, req.user.id]);
    const [rows] = await db.promise().query('SELECT * FROM recharge_receiving_accounts WHERE id = ? LIMIT 1', [r.insertId]);
    await writeAdminLog({ adminId: req.user.id, action: 'receiving_account_create', detail: 'id=' + r.insertId + ' type=' + v.type + ' name=' + v.name });
    return ok(res, { account: accountOut(rows[0]) }, '收款账户已添加');
  } catch (e) { return fail(res, '收款账户添加失败', 500); }
});

router.put('/admin/receiving-accounts/:id', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.params.id);
  if (!id) return fail(res, '无效的账户ID', 422, 'INVALID_ID');
  const parsed = parseAccountBody(req.body);
  if (parsed.error) return fail(res, parsed.error, 422, 'INVALID_ACCOUNT');
  const v = parsed.value;
  try {
    const [r] = await db.promise().query(
      'UPDATE recharge_receiving_accounts SET account_type=?, account_name=?, holder_name=?, account_no=?, remark=?, is_active=?, sort_order=?, updated_by=? WHERE id=?',
      [v.type, v.name, v.holder, v.no, v.remark || null, v.isActive, v.sort, req.user.id, id]);
    if (Number(r.affectedRows) !== 1) return fail(res, '收款账户不存在', 404, 'NOT_FOUND');
    const [rows] = await db.promise().query('SELECT * FROM recharge_receiving_accounts WHERE id = ? LIMIT 1', [id]);
    await writeAdminLog({ adminId: req.user.id, action: 'receiving_account_update', detail: 'id=' + id + ' active=' + v.isActive });
    return ok(res, { account: accountOut(rows[0]) }, '收款账户已更新');
  } catch (e) { return fail(res, '收款账户更新失败', 500); }
});

router.post('/admin/receiving-accounts/:id/status', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.params.id);
  if (!id) return fail(res, '无效的账户ID', 422, 'INVALID_ID');
  const active = (req.body && (req.body.is_active === 1 || req.body.is_active === true || req.body.is_active === '1')) ? 1 : 0;
  try {
    const [r] = await db.promise().query(
      'UPDATE recharge_receiving_accounts SET is_active=?, updated_by=? WHERE id=?', [active, req.user.id, id]);
    if (Number(r.affectedRows) !== 1) return fail(res, '收款账户不存在', 404, 'NOT_FOUND');
    await writeAdminLog({ adminId: req.user.id, action: active ? 'receiving_account_enable' : 'receiving_account_disable', detail: 'id=' + id });
    return ok(res, { id: id, is_active: active }, active ? '已启用' : '已停用');
  } catch (e) { return fail(res, '操作失败', 500); }
});

router.get('/admin/recharge', auth, requireRole('admin'), async function (req, res) {
  try {
    const st = tx(req.query.status, 20).toUpperCase();
    const w = []; const p = [];
    if (['PENDING', 'COMPLETED', 'REJECTED', 'CANCELLED', 'EXPIRED'].indexOf(st) >= 0) { w.push('o.status=?'); p.push(st); }
    const q = tx(req.query.q, 64);
    if (q) {
      w.push('(o.order_id LIKE ? OR o.payment_reference LIKE ? OR u.username LIKE ?)');
      p.push(like(q), like(q), like(q));
    }
    const rows = (await db.promise().query('SELECT ' + COLS + ' FROM recharge_orders o LEFT JOIN users u ON u.id=o.user_id ' + (w.length ? 'WHERE ' + w.join(' AND ') : '') + ' ORDER BY o.id DESC LIMIT 50', p))[0];
    return ok(res, { list: rows.map(out), total: rows.length });
  } catch (e) { return fail(res, '充值订单加载失败', 500); }
});
router.get('/admin/recharge/:id', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const rows = (await db.promise().query('SELECT ' + COLS + ' FROM recharge_orders o LEFT JOIN users u ON u.id=o.user_id WHERE o.id=? LIMIT 1', [id]))[0];
    if (!rows[0]) return fail(res, '订单不存在', 404, 'ORDER_NOT_FOUND');
    const txr = (await db.promise().query('SELECT id,user_id,amount,balance_before,balance_after,type,reason,reference_no,operator_id,created_at FROM balance_transactions WHERE reference_no=? ORDER BY id DESC LIMIT 20', [rows[0].order_id]))[0];
    return ok(res, { order: out(rows[0]), ledger: txr });
  } catch (e) { return fail(res, '订单详情加载失败', 500); }
});
router.get('/admin/recharge/:id/receipt', auth, requireRole('admin', 'support'), async function (req, res) {
  const id = num(req.params.id);
  if (!id) return res.status(422).json({ success: false, message: '无效的订单ID' });
  try {
    const rows = (await db.promise().query('SELECT receipt_path FROM recharge_orders WHERE id=? LIMIT 1', [id]))[0];
    if (!rows[0] || !rows[0].receipt_path) return res.status(404).json({ success: false, message: '该订单还没有上传凭证' });
    const vs = require('../utils/voucherStore');
    const abs = vs.resolveVoucher(rows[0].receipt_path);
    const fs = require('fs');
    if (!abs || !fs.existsSync(abs)) return res.status(404).json({ success: false, message: '凭证文件不存在' });
    res.set('Cache-Control', 'private, no-store');
    res.set('Content-Type', /\.png$/i.test(abs) ? 'image/png' : (/\.webp$/i.test(abs) ? 'image/webp' : 'image/jpeg'));
    return fs.createReadStream(abs).pipe(res);
  } catch (e) { return res.status(500).json({ success: false, message: '凭证读取失败' }); }
});
router.post('/admin/recharge/:id/complete', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  const remark = tx(req.body && (req.body.admin_remark !== undefined ? req.body.admin_remark : req.body.remark), 255);
  const conn = await db.promise().getConnection();
  try {
    await conn.beginTransaction();
    const o = (await conn.query('SELECT * FROM recharge_orders WHERE id=? FOR UPDATE', [id]))[0][0];
    if (!o) { await conn.rollback(); return fail(res, '订单不存在', 404, 'ORDER_NOT_FOUND'); }
    if (o.status !== 'PENDING') { await conn.rollback(); return fail(res, '只有待审核订单可以确认', 409, 'INVALID_STATUS'); }
    if (!o.receipt_path) { await conn.rollback(); return fail(res, '该订单尚未上传凭证，无法确认', 409, 'RECEIPT_REQUIRED'); }
    const amt = Number(o.amount);
    const r = await require('../utils/ledger').applyBalance(conn, { userId: Number(o.user_id), delta: amt, type: 'RECHARGE', reason: '现金筹码充值', referenceNo: o.order_id, operatorId: req.user.id });
    // 状态条件 + 行锁 + 同一事务入账，重复审核只会命中 INVALID_STATUS，绝不会重复加余额
    const upd = (await conn.query("UPDATE recharge_orders SET status='COMPLETED',operator_id=?,completed_at=NOW(),admin_remark=? WHERE id=? AND status='PENDING'", [req.user.id, remark || null, id]))[0];
    if (Number(upd.affectedRows) !== 1) { await conn.rollback(); return fail(res, '订单已被处理', 409, 'ALREADY_HANDLED'); }
    await writeAdminLog({ conn: conn, adminId: req.user.id, targetUserId: Number(o.user_id), action: 'recharge_complete', detail: 'order=' + o.order_id + ' account_id=' + (o.receiving_account_id == null ? '-' : o.receiving_account_id) + ' amount=' + amt.toFixed(2) });
    await conn.commit();
    return ok(res, { ledger_id: r.ledger_id }, '已确认，现金筹码已到账');
  } catch (e) { try { await conn.rollback(); } catch (e2) {} return fail(res, '确认失败', 500); }
  finally { try { conn.release(); } catch (e2) {} }
});
router.post('/admin/recharge/:id/reject', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.params.id);
  const reason = tx(req.body && req.body.reason, 200);
  const adminRemark = tx(req.body && req.body.admin_remark, 255);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  if (reason.length < 2) return fail(res, '请填写拒绝原因（至少2个字）', 422, 'REASON_REQUIRED');
  try {
    const upd = (await db.promise().query("UPDATE recharge_orders SET status='REJECTED',reject_reason=?,admin_remark=COALESCE(NULLIF(?, ''), admin_remark),operator_id=?,completed_at=NOW() WHERE id=? AND status='PENDING'", [reason, adminRemark, req.user.id, id]))[0];
    if (Number(upd.affectedRows) !== 1) return fail(res, '只有待审核订单可以拒绝', 409, 'INVALID_STATUS');
    const [row] = await db.promise().query('SELECT user_id, order_id FROM recharge_orders WHERE id=? LIMIT 1', [id]);
    await writeAdminLog({ adminId: req.user.id, targetUserId: row[0] ? Number(row[0].user_id) : null, action: 'recharge_reject', detail: 'order=' + (row[0] ? row[0].order_id : id) + ' reason=' + reason });
    return ok(res, null, '已拒绝该订单');
  } catch (e) { return fail(res, '操作失败', 500); }
});
router.post('/admin/recharge/:id/cancel', auth, requireRole('admin'), async function (req, res) {
  const id = num(req.params.id);
  if (!id) return fail(res, '无效的订单ID', 422, 'INVALID_ORDER_ID');
  try {
    const upd = (await db.promise().query('UPDATE recharge_orders SET status=\'CANCELLED\',operator_id=?,completed_at=NOW() WHERE id=? AND status=\'PENDING\'', [req.user.id, id]))[0];
    if (Number(upd.affectedRows) !== 1) return fail(res, '只有待审核订单可以取消', 409, 'INVALID_STATUS');
    return ok(res, null, '订单已取消');
  } catch (e) { return fail(res, '取消失败', 500); }
});
module.exports = router;
