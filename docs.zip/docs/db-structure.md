# 26牛牛 - 数据库结构清单

> 由 `node scripts/db-inventory.js` 自动生成（只读扫描 information_schema），请勿手工编辑。
> 数据库：`26niuniu` · 表数量：**47** · 生成时间：2026-09-30T18:28:10.371Z

## 说明

- 所有结构变更只能通过 `database/migrations/*.js` 增量迁移完成（全部为安全增量，不 DROP、不 TRUNCATE）。
- 一次性执行全部迁移：`node database/migrations/run-all.js`
- 行数为 InnoDB 估算值（`information_schema.TABLE_ROWS`），仅用于判断「是否有真实数据」。
- `niu_*` 三张表属于 26牛牛娱乐场（非现金化游戏积分），与旧红包对战表（`game_*`）互不复用。

## 表清单

| 表 | 估算行数 | 说明 |
| --- | --- | --- |
| `admin_approvals` | 13 | 26牛牛 后台高风险动作双人复核 |
| `admin_logs` | 109 | 管理员/客服操作日志表 |
| `announcements` | 0 | 公告表 |
| `audit_logs` | 0 | 敏感业务审计日志 |
| `avatar_categories` | 2 |  |
| `avatars` | 26 |  |
| `balance_transactions` | 69 | 余额交易记录表 |
| `banker_bids` | 3 |  |
| `cash_transfers` | 0 | 现金筹码用户间转账记录 |
| `chat_messages` | 1127 | 聊天消息表 |
| `chat_read_state` | 5 | 聊天已读状态表 |
| `chat_red_packet_claims` | 0 | 26牛牛 聊天红包领取明细 |
| `chat_red_packets` | 1 | 26牛牛 聊天红包（测试资产，非现金） |
| `chat_reports` | 2 | 聊天消息举报表 |
| `favorites` | 0 | 收藏表 |
| `game_results` | 4 |  |
| `game_rooms` | 5 |  |
| `game_rounds` | 3 |  |
| `games` | 0 |  |
| `login_logs` | 150 | 登录记录表 |
| `moderation_actions` | 0 | 聊天禁言记录（全体/单独） |
| `niu_round_players` | 589 | 26牛牛娱乐场对局明细（每局每人一条，防重复结算） |
| `niu_rounds` | 262 | 26牛牛娱乐场对局 |
| `niu_user_stats` | 3 | 26牛牛娱乐场玩家统计 |
| `notifications` | 46 | 通知中心表 |
| `otp_audit_logs` | 17 | OTP 审计日志表 |
| `password_reset_tokens` | 0 |  |
| `player_bets` | 2 |  |
| `real_name_reviews` | 4 | 实名认证审核表 |
| `recent_visits` | 14 | 最近访问表 |
| `recharge_orders` | 13 | 虚拟游戏积分充值订单表 |
| `recharge_receiving_accounts` | 0 |  |
| `red_packet_claims` | 4 |  |
| `red_packets` | 2 |  |
| `referral_relations` | 3 | 邀请关系表 |
| `referral_rewards` | 1 | 26牛牛 推广奖励台账（非现金化测试资产） |
| `registration_otp` | 3 | 注册手机号验证码表 |
| `room_players` | 9 |  |
| `support_quick_replies` | 0 | 客服快捷回复短语 |
| `support_threads` | 1 |  |
| `system_notices` | 0 | 系统公告表 |
| `system_settings` | 1 | 系统配置中心（站点名称 / 充值区间 / 推广比例 / 维护模式等） |
| `user_presence` | 6 | 26牛牛 在线状态（不记录 IP / 设备指纹） |
| `user_stickers` | 0 | 用户自定义贴图表 |
| `users` | 11 | 用户表 |
| `wallet_orders` | 24 | 钱包订单表（充值/提现） |
| `withdraw_requests` | 0 | 现金筹码提现申请（本阶段不执行真实出款） |

## 索引

### `admin_approvals`

- `idx_approval_requester` (requested_by,id)
- `idx_approval_status` (status,id)
- `idx_approval_target` (target_user_id,id)
- **唯一** `PRIMARY` (id)

### `admin_logs`

- `idx_action` (action)
- `idx_admin_id` (admin_id)
- `idx_target_user_id` (target_user_id)
- **唯一** `PRIMARY` (id)

### `announcements`

- `idx_created_by` (created_by)
- `idx_sort` (sort,created_at)
- `idx_status_time` (status,start_at,end_at)
- **唯一** `PRIMARY` (id)

### `audit_logs`

- `idx_audit_action` (action)
- `idx_audit_operator` (operator_id)
- `idx_audit_target` (target_id)
- **唯一** `PRIMARY` (id)

### `avatar_categories`

- `idx_avatar_categories_sort` (sort_order,id)
- **唯一** `PRIMARY` (id)

### `avatars`

- `idx_avatars_category` (category_id)
- `idx_avatars_sort` (sort_order,id)
- **唯一** `PRIMARY` (id)

### `balance_transactions`

- `fk_balance_tx_operator` (operator_id)
- `idx_created_at` (created_at)
- `idx_currency_type` (currency_type)
- `idx_reference_no` (reference_no)
- `idx_type` (type)
- `idx_user_id` (user_id)
- **唯一** `PRIMARY` (id)

### `banker_bids`

- `idx_round` (round_id)
- `idx_user` (user_id)
- **唯一** `PRIMARY` (id)

### `cash_transfers`

- **唯一** `idempotency_key` (idempotency_key)
- `idx_from` (from_user_id,created_at)
- `idx_to` (to_user_id,created_at)
- **唯一** `PRIMARY` (id)
- **唯一** `transfer_no` (transfer_no)

### `chat_messages`

- `idx_channel_id` (channel,id)
- `idx_chat_game_room` (room_id,id)
- `idx_chat_game_round` (round_id,id)
- `idx_reply_to` (reply_to_id)
- `idx_user` (user_id)
- **唯一** `PRIMARY` (id)

### `chat_read_state`

- **唯一** `PRIMARY` (user_id,channel)

### `chat_red_packet_claims`

- `idx_chat_claim_user` (user_id,id)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_chat_claim_user` (packet_id,user_id)

### `chat_red_packets`

- `idx_chat_packet_channel` (channel,id)
- `idx_chat_packet_sender` (sender_id,id)
- `idx_chat_packet_status` (status,expired_at)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_chat_packet_no` (packet_no)

### `chat_reports`

- `idx_message` (message_id)
- `idx_reporter` (reporter_id)
- **唯一** `PRIMARY` (id)

### `favorites`

- `idx_user_time` (user_id,created_at)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_user_target` (user_id,target_type,target_id)

### `game_results`

- `idx_result_user_time` (user_id,created_at)
- `idx_round` (round_id)
- `idx_user` (user_id)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_result_round_user` (round_id,user_id)

### `game_rooms`

- `idx_banker` (banker_id)
- `idx_round_id` (round_id)
- `idx_status` (status)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_game_rooms_key` (room_key)

### `game_rounds`

- `idx_room` (room_id)
- `idx_round_id` (round_id)
- `idx_status` (status)
- **唯一** `PRIMARY` (id)
- **唯一** `round_id` (round_id)

### `games`

- `idx_games_active_sort` (is_active,sort_order)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_games_key` (game_key)

### `login_logs`

- `idx_status` (status,created_at)
- `idx_user_time` (user_id,created_at)
- **唯一** `PRIMARY` (id)

### `moderation_actions`

- `fk_modop_ended_by` (ended_by)
- `fk_modop_operator` (operator_id)
- `idx_scope_status` (scope,status)
- `idx_target` (target_user_id,status)
- **唯一** `PRIMARY` (id)

### `niu_round_players`

- `idx_niu_rp_round` (round_id)
- `idx_niu_rp_user_time` (user_id,created_at)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_niu_round_user` (round_id,user_id)

### `niu_rounds`

- `idx_niu_round_banker` (banker_user_id)
- `idx_niu_round_created` (created_at)
- `idx_niu_round_room_time` (room_key,ended_at)
- `idx_niu_round_status` (status)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_niu_round_no` (round_no)

### `niu_user_stats`

- `idx_niu_stats_delta` (total_delta)
- `idx_niu_stats_rounds` (total_rounds)
- **唯一** `PRIMARY` (user_id)

### `notifications`

- `idx_category` (category)
- `idx_notifications_target` (target_scope,audience_id,status)
- `idx_user_read` (user_id,is_read,id)
- **唯一** `PRIMARY` (id)

### `otp_audit_logs`

- `idx_action` (action,created_at)
- `idx_operator` (operator_id,created_at)
- `idx_phone` (target_phone,created_at)
- **唯一** `PRIMARY` (id)

### `password_reset_tokens`

- `idx_reset_expiry` (expires_at)
- `idx_reset_user` (user_id)
- **唯一** `PRIMARY` (token_hash)

### `player_bets`

- `idx_round` (round_id)
- `idx_user` (user_id)
- **唯一** `PRIMARY` (id)

### `real_name_reviews`

- `idx_real_name` (real_name,status)
- `idx_status` (status,created_at)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_user` (user_id)

### `recent_visits`

- `idx_user_time` (user_id,visited_at)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_user_target` (user_id,target_type,target_id)

### `recharge_orders`

- `fk_recharge_operator` (operator_id)
- **唯一** `idempotency_key` (idempotency_key)
- `idx_recharge_orders_account` (receiving_account_id)
- `idx_status` (status,created_at)
- `idx_user` (user_id,created_at)
- **唯一** `order_id` (order_id)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_recharge_payment_reference` (payment_reference)

### `recharge_receiving_accounts`

- `idx_receiving_active_sort` (is_active,sort_order,id)
- **唯一** `PRIMARY` (id)

### `red_packet_claims`

- `idx_packet` (packet_id)
- `idx_round` (round_id)
- `idx_user` (user_id)
- **唯一** `PRIMARY` (id)

### `red_packets`

- `idx_round` (round_id)
- `idx_status` (status)
- **唯一** `packet_id` (packet_id)
- **唯一** `PRIMARY` (id)

### `referral_relations`

- `idx_referrer` (referrer_id)
- `idx_referrer_level` (referrer_id,level)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_referred_level` (referred_user_id,level)

### `referral_rewards`

- `idx_reward_source` (source_type,source_ref)
- `idx_reward_status` (status,created_at)
- `idx_reward_user` (user_id,created_at)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_referral_reward` (unique_key)

### `registration_otp`

- `idx_created_ip` (created_ip,created_at)
- `idx_phone_status` (phone,status,id)
- `idx_status_expire` (status,expires_at)
- **唯一** `PRIMARY` (id)

### `room_players`

- `idx_room` (room_id)
- `idx_round` (round_id)
- `idx_user` (user_id)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_room_player` (room_id,user_id)

### `support_quick_replies`

- `idx_sort` (status,sort)
- **唯一** `PRIMARY` (id)

### `support_threads`

- **唯一** `PRIMARY` (thread_key)

### `system_notices`

- `idx_status` (status,created_at)
- **唯一** `PRIMARY` (id)

### `system_settings`

- **唯一** `PRIMARY` (setting_key)

### `user_presence`

- `idx_presence_last_seen` (last_seen)
- **唯一** `PRIMARY` (user_id)

### `user_stickers`

- `idx_user` (user_id)
- `idx_user_time` (user_id,created_at)
- **唯一** `PRIMARY` (id)

### `users`

- **唯一** `email` (email)
- `idx_invited_by` (invited_by)
- `idx_users_avatar` (avatar_id)
- **唯一** `invite_code` (invite_code)
- **唯一** `phone` (phone)
- **唯一** `PRIMARY` (id)
- **唯一** `username` (username)

### `wallet_orders`

- `idx_status` (status)
- `idx_user` (user_id)
- `idx_user_type` (user_id,order_type)
- `idx_wallet_order_status` (order_type,status,created_at)
- `idx_wallet_order_user` (user_id,created_at)
- **唯一** `order_no` (order_no)
- **唯一** `PRIMARY` (id)
- **唯一** `uk_wallet_order_no` (order_no)

### `withdraw_requests`

- `fk_withdraw_operator` (operator_id)
- `idx_status` (status,created_at)
- `idx_user` (user_id,created_at)
- **唯一** `order_id` (order_id)
- **唯一** `PRIMARY` (id)
- **唯一** `uq_withdraw_idempotency` (idempotency_key)
- **唯一** `uq_withdraw_user_idempotency` (user_id,idempotency_key)
- **唯一** `uq_withdrawal_id` (withdrawal_id)

## 关键字段

### `users`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `username` | varchar(50) | NO | NULL |  |
| `email` | varchar(100) | YES | NULL |  |
| `phone` | varchar(20) | YES | NULL |  |
| `real_name` | varchar(50) | NO | `` |  |
| `password_hash` | varchar(255) | NO | NULL |  |
| `pay_password_hash` | varchar(255) | YES | NULL |  |
| `invite_code` | varchar(20) | YES | NULL |  |
| `invited_by` | int unsigned | YES | NULL |  |
| `role` | enum('user','admin','support') | NO | `user` |  |
| `status` | enum('active','banned','deleted') | NO | `active` |  |
| `game_balance` | decimal(20,2) | NO | `0.00` |  |
| `cash_chips` | decimal(20,2) | NO | `0.00` |  |
| `game_points` | decimal(20,2) | NO | `0.00` |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
| `nickname` | varchar(32) | YES | NULL |  |
| `avatar_url` | varchar(255) | YES | NULL |  |
| `muted_until` | datetime | YES | NULL |  |
| `mute_reason` | varchar(255) | YES | NULL |  |
| `token_version` | int unsigned | NO | `0` |  |
| `pay_password_set_at` | datetime | YES | NULL |  |
| `bank_name` | varchar(100) | YES | NULL |  |
| `bank_account` | varchar(120) | YES | NULL |  |
| `avatar_id` | int unsigned | YES | NULL |  |

### `balance_transactions`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `user_id` | int unsigned | NO | NULL |  |
| `currency_type` | enum('GAME_BALANCE','CASH_CHIPS','GAME_POINTS') | NO | NULL |  |
| `amount` | decimal(20,2) | NO | NULL |  |
| `balance_before` | decimal(20,2) | NO | NULL |  |
| `balance_after` | decimal(20,2) | NO | NULL |  |
| `type` | varchar(30) | NO | NULL |  |
| `reason` | varchar(255) | YES | NULL |  |
| `reference_no` | varchar(64) | YES | NULL |  |
| `operator_id` | int unsigned | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `related_request_id` | int unsigned | YES | NULL |  |

### `wallet_orders`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `order_no` | varchar(32) | NO | NULL |  |
| `user_id` | int unsigned | NO | NULL |  |
| `order_type` | enum('DEPOSIT','WITHDRAW') | NO | NULL |  |
| `currency_type` | enum('GAME_BALANCE','CASH_CHIPS') | NO | `CASH_CHIPS` |  |
| `amount` | decimal(20,2) | NO | NULL |  |
| `method` | varchar(40) | NO | NULL |  |
| `account` | varchar(120) | YES | NULL |  |
| `status` | enum('PENDING','PROCESSING','COMPLETED','REJECTED','CANCELLED','PENDING_PAYMENT','PENDING_REVIEW','APPROVED') | NO | `PENDING_PAYMENT` |  |
| `remark` | varchar(255) | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
| `reviewed_by` | int unsigned | YES | NULL |  |
| `reviewed_at` | datetime | YES | NULL |  |
| `reject_reason` | varchar(255) | YES | NULL |  |
| `admin_note` | varchar(255) | YES | NULL |  |
| `account_type` | varchar(40) | YES | NULL |  |
| `account_reference` | varchar(120) | YES | NULL |  |
| `voucher_path` | varchar(255) | YES | NULL |  |
| `voucher_uploaded_at` | datetime | YES | NULL |  |
| `payer_remark` | varchar(255) | YES | NULL |  |
| `before_balance` | decimal(20,2) | YES | NULL |  |
| `after_balance` | decimal(20,2) | YES | NULL |  |
| `review_reason` | varchar(255) | YES | NULL |  |

### `recharge_orders`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `order_id` | varchar(40) | NO | NULL |  |
| `user_id` | int unsigned | NO | NULL |  |
| `amount` | decimal(20,2) | NO | NULL |  |
| `currency` | varchar(20) | NO | `POINTS` |  |
| `status` | enum('PENDING','COMPLETED','REJECTED','CANCELLED','EXPIRED') | NO | `PENDING` |  |
| `idempotency_key` | varchar(64) | NO | NULL |  |
| `operator_id` | int unsigned | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `completed_at` | datetime | YES | NULL |  |
| `receipt_path` | varchar(255) | YES | NULL |  |
| `remark` | varchar(255) | YES | NULL |  |
| `reject_reason` | varchar(255) | YES | NULL |  |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
| `submitted_at` | datetime | YES | NULL |  |
| `receiving_account_id` | int unsigned | YES | NULL |  |
| `receiving_account_type` | varchar(20) | YES | NULL |  |
| `receiving_account_name` | varchar(100) | YES | NULL |  |
| `receiving_account_holder` | varchar(100) | YES | NULL |  |
| `receiving_account_no` | varchar(120) | YES | NULL |  |
| `payment_reference` | varchar(40) | YES | NULL |  |
| `admin_remark` | varchar(255) | YES | NULL |  |

### `withdraw_requests`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `order_id` | varchar(40) | NO | NULL |  |
| `user_id` | int unsigned | NO | NULL |  |
| `amount` | decimal(20,2) | NO | NULL |  |
| `currency` | varchar(20) | NO | `CASH_CHIPS` |  |
| `account_type` | varchar(40) | NO | NULL |  |
| `account_name` | varchar(60) | YES | NULL |  |
| `account_ref` | varchar(120) | NO | NULL |  |
| `status` | enum('PENDING','APPROVED','REJECTED','CANCELLED') | NO | `PENDING` |  |
| `remark` | varchar(255) | YES | NULL |  |
| `reject_reason` | varchar(255) | YES | NULL |  |
| `operator_id` | int unsigned | YES | NULL |  |
| `completed_at` | datetime | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
| `withdrawal_id` | varchar(40) | YES | NULL |  |
| `recipient_name` | varchar(60) | YES | NULL |  |
| `bank_name` | varchar(100) | YES | NULL |  |
| `bank_account` | varchar(120) | YES | NULL |  |
| `approved_at` | datetime | YES | NULL |  |
| `rejected_at` | datetime | YES | NULL |  |
| `idempotency_key` | varchar(80) | YES | NULL |  |
| `admin_remark` | varchar(255) | YES | NULL |  |

### `referral_relations`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `referrer_id` | int unsigned | NO | NULL |  |
| `referred_user_id` | int unsigned | NO | NULL |  |
| `level` | tinyint unsigned | NO | `1` |  |
| `status` | enum('active','invalid') | NO | `active` |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |

### `chat_messages`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | bigint unsigned | NO | NULL | auto_increment |
| `channel` | varchar(40) | NO | NULL |  |
| `room_id` | int unsigned | YES | NULL |  |
| `round_id` | varchar(50) | YES | NULL |  |
| `phase` | varchar(20) | YES | NULL |  |
| `game_round_pk` | int unsigned | YES | NULL |  |
| `user_id` | int unsigned | YES | NULL |  |
| `message_type` | enum('text','image','sticker','system','game','redpacket') | NO | `text` |  |
| `content` | text | NO | NULL |  |
| `guest_token` | varchar(64) | YES | NULL |  |
| `sender_role` | varchar(20) | NO | `user` |  |
| `meta` | json | YES | NULL |  |
| `is_recalled` | tinyint(1) | NO | `0` |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `reply_to_id` | bigint unsigned | YES | NULL |  |

### `notifications`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | bigint unsigned | NO | NULL | auto_increment |
| `user_id` | int unsigned | NO | NULL |  |
| `category` | enum('system','activity','referral','support','game') | NO | `system` |  |
| `target_scope` | varchar(20) | NO | `user` |  |
| `sender_id` | int unsigned | YES | NULL |  |
| `audience_id` | int unsigned | YES | NULL |  |
| `status` | varchar(20) | NO | `published` |  |
| `title` | varchar(120) | NO | NULL |  |
| `content` | text | YES | NULL |  |
| `link` | varchar(255) | YES | NULL |  |
| `is_read` | tinyint(1) | NO | `0` |  |
| `read_at` | datetime | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |

### `registration_otp`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | bigint unsigned | NO | NULL | auto_increment |
| `phone` | varchar(20) | NO | NULL |  |
| `otp_hash` | char(64) | NO | NULL |  |
| `otp_plain_tmp` | varchar(12) | YES | NULL |  |
| `status` | enum('pending','sent','verified','expired','locked') | NO | `pending` |  |
| `attempts` | tinyint unsigned | NO | `0` |  |
| `max_attempts` | tinyint unsigned | NO | `5` |  |
| `expires_at` | datetime | NO | NULL |  |
| `last_sent_at` | datetime | YES | NULL |  |
| `verified_at` | datetime | YES | NULL |  |
| `sent_by` | int unsigned | YES | NULL |  |
| `created_ip` | varchar(45) | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |

### `avatars`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `name` | varchar(80) | NO | NULL |  |
| `category_id` | int unsigned | YES | NULL |  |
| `image_path` | varchar(255) | NO | NULL |  |
| `sort_order` | int | NO | `0` |  |
| `is_active` | tinyint(1) | NO | `1` |  |
| `allow_users` | tinyint(1) | NO | `1` |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |

### `niu_rounds`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | int unsigned | NO | NULL | auto_increment |
| `round_no` | varchar(40) | NO | NULL |  |
| `room_key` | varchar(20) | NO | NULL |  |
| `base_stake` | decimal(20,2) | NO | NULL |  |
| `banker_user_id` | int unsigned | YES | NULL |  |
| `player_count` | int | NO | `0` |  |
| `status` | enum('WAITING','GRABBING','BETTING','DEALING','RESULT','SETTLEMENT','FINISHED','ABORTED') | NO | `WAITING` |  |
| `started_at` | timestamp | YES | NULL |  |
| `ended_at` | timestamp | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |

### `niu_round_players`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `id` | bigint unsigned | NO | NULL | auto_increment |
| `round_id` | int unsigned | NO | NULL |  |
| `user_id` | int unsigned | NO | NULL |  |
| `role` | enum('BANKER','PLAYER') | NO | NULL |  |
| `seat_no` | int | NO | `0` |  |
| `grab_flag` | tinyint(1) | NO | `0` |  |
| `bet_level` | int | NO | `1` |  |
| `cards` | json | YES | NULL |  |
| `hand_key` | varchar(20) | YES | NULL |  |
| `point_value` | int | NO | `0` |  |
| `multiplier` | int | NO | `1` |  |
| `expect_amount` | decimal(20,2) | NO | `0.00` |  |
| `amount` | decimal(20,2) | NO | `0.00` |  |
| `delta` | decimal(20,2) | NO | `0.00` |  |
| `balance_before` | decimal(20,2) | NO | `0.00` |  |
| `balance_after` | decimal(20,2) | NO | `0.00` |  |
| `result` | enum('BANKER','PLAYER','DRAW') | YES | NULL |  |
| `is_capped` | tinyint(1) | NO | `0` |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |

### `niu_user_stats`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `user_id` | int unsigned | NO | NULL |  |
| `total_rounds` | int | NO | `0` |  |
| `win_rounds` | int | NO | `0` |  |
| `banker_rounds` | int | NO | `0` |  |
| `grab_rounds` | int | NO | `0` |  |
| `total_delta` | decimal(20,2) | NO | `0.00` |  |
| `best_multiplier` | int | NO | `0` |  |
| `daily_free_date` | date | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
| `updated_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |

### `system_settings`

| 字段 | 类型 | 可空 | 默认 | 备注 |
| --- | --- | --- | --- | --- |
| `setting_key` | varchar(60) | NO | NULL |  |
| `setting_value` | text | YES | NULL |  |
| `updated_by` | int unsigned | YES | NULL |  |
| `updated_at` | datetime | YES | NULL |  |
| `created_at` | timestamp | NO | `CURRENT_TIMESTAMP` | DEFAULT_GENERATED |
