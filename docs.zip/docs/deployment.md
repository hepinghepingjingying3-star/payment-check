# 26牛牛 - 部署与运维手册

> 面向正式服务器（Node.js + MySQL + HTTPS）的部署说明。
> 项目结构保持「Express + 静态 HTML/CSS/JS」，未使用 React/Vue，前端可直接原样部署。

---

## 1. 项目结构

```
C:\26niuniu
├─ server.js                 服务入口（挂载全部路由 / Socket.IO / 全局中间件）
├─ package.json              npm start / npm run dev / npm test / npm run restart
├─ .env                      真实环境变量（不提交版本库）
├─ .env.example              环境变量模板（无真实密码）
├─ config/                   集中配置（数值唯一来源，禁止散落到页面与路由）
│   ├─ db.js                 MySQL 连接池
│   ├─ site.js               站点信息 / 官方频道 / 游戏入口
│   ├─ games.js              游戏入口注册
│   ├─ niuGame.js            26牛牛娱乐场：场次 / 倍数 / 时长 / 牌型 / 开关
│   ├─ cashChips.js          现金筹码资产定义
│   ├─ funds.js              资金规则（限额 / 状态）
│   ├─ referral.js           推广奖励比例（0.5% / 0.3% / 0.7% 唯一来源）
│   └─ upload.js             上传白名单（MIME / 扩展名 / 体积）
├─ middleware/
│   ├─ auth.js               JWT 校验 + requireRole（读数据库真实 role）
│   ├─ admin-boundary.js     /api/admin/** 与 admin.html 的统一准入
│   ├─ maintenance.js        维护模式（管理员/客服不受影响）
│   └─ errorHandler.js       /api 404 + 统一错误格式（不外泄 SQL / 堆栈）
├─ routes/                   35 个路由文件（清单见 docs/api-list.md）
├─ socket/                   Socket.IO 通道（聊天 / 通知 / 26牛牛娱乐场）
├─ utils/                    业务工具（账本 ledger、牌局引擎 niuEngine、
│                             房间状态机 niuRoom、上传校验 imageCheck 等）
├─ database/
│   ├─ schema.sql            初始结构（仅首次建库使用）
│   └─ migrations/           001~024 安全增量迁移（不 DROP / 不 TRUNCATE）
├─ public/                   前端页面（35 个 HTML + public/js 页面脚本）
├─ assets/                   正式静态资源（头像库 / 图标 / 牌桌素材）
├─ uploads/                  用户上传（凭证 / 图片；由 config/upload.js 管控）
├─ scripts/                  运维脚本（重启、API 清单、数据库结构清单）
├─ tests/                    自动化测试（npm test 统一入口）
└─ docs/                     业务规则 / 阶段状态 / API 清单 / 数据库结构 / 部署手册
```

---

## 2. 环境变量

真实值只写在 `.env`（已在 `.gitignore` 中，绝不提交）。模板见 `.env.example`。

| 变量 | 必填 | 说明 |
| --- | --- | --- |
| `DB_HOST` | 是 | MySQL 主机 |
| `DB_PORT` | 否 | 默认 `3306` |
| `DB_USER` | 是 | 数据库账号 |
| `DB_PASSWORD` | 是 | 数据库密码 |
| `DB_NAME` | 是 | 数据库名 |
| `JWT_SECRET` | 是 | JWT 签名密钥，**生产必须换成随机长字符串** |
| `PORT` | 否 | 监听端口，默认 `3000` |
| `PUBLIC_BASE_URL` | 否 | 站点对外地址（用于分享链接 / 邀请链接），留空则按请求头自动推断 |
| `MAINTENANCE` | 否 | 兜底维护开关；日常由管理后台的系统设置控制 |

生成生产密钥：

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

> 代码中不存在任何写死的数据库密码、JWT 密钥或域名；前端 API 全部走同源相对路径 `/api/...`，
> 换域名后无需改代码。

---

## 3. 启动命令

```bash
npm install                 # 安装依赖
node database/migrations/run-all.js   # 执行全部安全增量迁移（可重复执行）
npm start                   # 启动（node server.js）
npm run dev                 # 开发模式（node --watch）
npm run restart             # Windows：结束占用端口的旧进程后用当前代码重启
npm test                    # 自动化测试（离线用例 + 需要端口的在线用例）
```

在线测试可通过环境变量指定被测地址（默认 `http://127.0.0.1:3000`）：

```bash
set TEST_BASE=http://127.0.0.1:3001 && npm test
```

健康检查（部署后自检、负载均衡探活均可用）：

```
GET /api/health  ->  {"success":true,"data":{"status":"ok","time":"...","uptime":秒}}
```

---

## 4. 上线步骤（正式服务器）

1. **准备服务器**：Node.js 20+ 、MySQL 8.x、Nginx（或 Caddy）。
2. **放置代码**：克隆 / 上传到 `/var/www/26niuniu`，`npm install --omit=dev`。
3. **写入 `.env`**：填入生产库账号与新的 `JWT_SECRET`（不要用示例值）。
4. **建库 + 迁移**：
   ```bash
   mysql -u root -p -e "CREATE DATABASE niuniu26 CHARACTER SET utf8mb4;"
   mysql -u root -p niuniu26 < database/schema.sql     # 仅全新空库需要
   node database/migrations/run-all.js                 # 已有库直接跑，安全增量
   ```
5. **启动进程守护**（pm2 示例）：
   ```bash
   pm2 start server.js --name 26niuniu
   pm2 save && pm2 startup
   ```
   Socket.IO 使用 WebSocket，多实例部署时必须开启 sticky session，
   或把 `socket` 相关流量固定到同一实例（单实例部署无需处理）。
6. **Nginx + HTTPS**（证书用 certbot 签发）：
   ```nginx
   server {
     listen 443 ssl http2;
     server_name 26niuniu.com www.26niuniu.com;   # 域名备案后填写
     ssl_certificate     /etc/letsencrypt/live/26niuniu.com/fullchain.pem;
     ssl_certificate_key /etc/letsencrypt/live/26niuniu.com/privkey.pem;

     client_max_body_size 12m;          # 上传凭证留余量（应用层限制更小）
     location / {
       proxy_pass http://127.0.0.1:3000;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;        # Socket.IO
       proxy_set_header Connection "upgrade";
       proxy_set_header Host $host;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
       proxy_read_timeout 120s;
     }
   }
   server { listen 80; server_name 26niuniu.com www.26niuniu.com; return 301 https://$host$request_uri; }
   ```
7. **后台校验**：用正式管理员账号登录 `/admin.html`，确认 Dashboard、充值审核、
   OTP 待办、头像库、26牛牛娱乐场面板均能读到真实数据。

> 若以后拆分域名：前端 `26niuniu.com`、API `api.26niuniu.com`、后台 `admin.26niuniu.com`。
> 当前代码不硬编码域名，只需在 Nginx 层做转发/反代即可；如果 API 与页面不同源，
> 需要额外把 `config.cors` 收紧为白名单，并让前端把接口基址改为读环境变量注入的配置。

---

## 5. 备份与回滚

- **每日备份**：`mysqldump --single-transaction -u USER -p DBNAME | gzip > backup.sql.gz`
- **上传目录**：`uploads/` 与 `assets/` 一起打包（凭证与正式素材都在里面）。
- **迁移只增不减**：所有 `database/migrations/*.js` 都不 DROP、不 TRUNCATE、不删数据，
  出现问题时回滚代码即可，不需要回滚数据库结构。

---

## 6. APK 打包（后续阶段）

当前保持「移动端响应式 Web App」，不做前端重写。以后用 Capacitor 直接包裹：

```bash
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init "26牛牛" com.niuniu26.app --web-dir=public
npx cap add android
```

要求（本仓库均已满足）：

- 全部页面走相对路径 `/api/...`，打包时把 `server.url` 指向正式 HTTPS 站点即可；
- 底部导航使用 `env(safe-area-inset-bottom)`，不被原生状态栏/导航条遮挡；
- 上传、Socket.IO 均走 HTTPS/WSS，无需改代码。

---

## 7. 业务边界（不得越线）

- 26牛牛娱乐场使用**游戏积分**：只能由「每日免费发放」与「管理员发放」产生，
  **不可充值、不可转账、不可提现、不可兑换现金或现金筹码**。
- 钱包 / 订单 / 凭证 / 审核为通用结构，当前**不接任何真实支付网关**，
  不做赌博资金结算、筹码兑现或现金提现。
- 推广比例（0.5% / 0.3% / 0.7%）只作为配置与展示存在，**未连接真实投注流水结算**。
