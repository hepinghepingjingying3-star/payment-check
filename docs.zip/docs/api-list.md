# 26牛牛 - API 清单

> 由 `node scripts/api-inventory.js` 自动生成，请勿手工编辑。
> 全部接口统一挂在 `/api` 前缀下；`/api/admin/*` 由 `middleware/admin-boundary.js`
> 在进入路由之前统一要求 `role = admin`（OTP 与客服线程允许 `support`），普通用户一律 403。

## 认证 / OTP / 账号安全（routes/auth.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/auth/change-password` | 公开 |
| GET | `/api/auth/invite/check` | 公开 |
| GET | `/api/auth/login-records` | 公开 |
| POST | `/api/auth/login` | 公开 |
| POST | `/api/auth/logout-other` | 公开 |
| POST | `/api/auth/logout` | 公开 |
| GET | `/api/auth/me` | 公开 |
| POST | `/api/auth/register` | 公开 |
| POST | `/api/support/lookup` | 公开 |
| GET | `/api/users/:id` | 公开 |
| GET | `/api/users` | 公开 |

## 找回密码（routes/recovery.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/auth/recovery/help` | 公开 |
| POST | `/api/auth/recovery/reset-password` | 公开 |
| POST | `/api/auth/recovery/verify` | 公开 |

## 个人资料 / 头像 / 客服（routes/profile.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/profile/avatar` | 公开 |
| GET | `/api/profile/real-name` | 公开 |
| POST | `/api/profile/real-name` | 公开 |
| PATCH | `/api/profile` | 公开 |

## 大厅聚合（公告 / 通知）（routes/lobby.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/lobby/info` | 公开 |

## 大厅首页数据（routes/home.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/home` | 公开 |

## 公告（routes/announcements.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/announcements/:id` | 公开 |
| GET | `/api/announcements/banner` | 公开 |
| GET | `/api/announcements` | 公开 |

## 通知（铃铛 / 我的消息）（routes/notifications.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/notifications/read-all` | 公开 |
| POST | `/api/notifications/read` | 公开 |
| GET | `/api/notifications/unread-count` | 公开 |
| GET | `/api/notifications` | 公开 |

## 钱包（余额 / 流水）（routes/wallet.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/wallet/admin/grant` | 公开 |
| GET | `/api/wallet/balance` | 公开 |
| POST | `/api/wallet/deposit` | 公开 |
| POST | `/api/wallet/exchange` | 公开 |
| GET | `/api/wallet/orders` | 公开 |
| GET | `/api/wallet/records` | 公开 |
| GET | `/api/wallet/summary` | 公开 |
| GET | `/api/wallet/transactions` | 公开 |
| POST | `/api/wallet/withdraw` | 公开 |

## 充值下单（routes/deposits.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/deposit/config` | 公开 |
| POST | `/api/deposits/orders/:id/cancel` | 公开 |
| GET | `/api/deposits/orders/:id/voucher` | 公开 |
| POST | `/api/deposits/orders/:id/voucher` | 公开 |
| GET | `/api/deposits/orders/:id` | 公开 |
| GET | `/api/deposits/orders` | 公开 |
| POST | `/api/deposits/orders` | 公开 |

## 充值向导（订单 / 凭证）（routes/recharge.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/recharge/config` | 公开 |
| POST | `/api/recharge/orders/:id/cancel` | 公开 |
| GET | `/api/recharge/orders/:id/receipt` | 公开 |
| POST | `/api/recharge/orders/:id/receipt` | 公开 |
| POST | `/api/recharge/orders/:id/submit` | 公开 |
| GET | `/api/recharge/orders/:id` | 公开 |
| GET | `/api/recharge/orders` | 公开 |
| POST | `/api/recharge/orders` | 公开 |

## 提现申请（routes/withdrawals.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/withdrawals/:id/approve` | 公开 |
| POST | `/api/admin/withdrawals/:id/reject` | 公开 |
| POST | `/api/admin/withdrawals/:id/review` | 公开 |
| GET | `/api/admin/withdrawals/:id` | 公开 |
| GET | `/api/admin/withdrawals` | 公开 |
| POST | `/api/withdrawals/:id/cancel` | 公开 |
| GET | `/api/withdrawals/:id` | 公开 |
| GET | `/api/withdrawals/config` | 公开 |
| GET | `/api/withdrawals/summary` | 公开 |
| GET | `/api/withdrawals` | 公开 |
| POST | `/api/withdrawals` | 公开 |

## 筹码转账（routes/transfers.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/transfers/limits` | 公开 |
| POST | `/api/transfers` | 公开 |

## 支付密码（routes/pay-password.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/pay-password/change` | 公开 |
| POST | `/api/pay-password/set` | 公开 |
| GET | `/api/pay-password/status` | 公开 |

## 26牛牛娱乐场（非现金化娱乐积分）（routes/niu.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/game/niu/bet` | 公开 |
| GET | `/api/game/niu/config` | 公开 |
| POST | `/api/game/niu/daily-free` | 公开 |
| POST | `/api/game/niu/grab` | 公开 |
| POST | `/api/game/niu/join` | 公开 |
| GET | `/api/game/niu/leaderboard` | 公开 |
| POST | `/api/game/niu/leave` | 公开 |
| GET | `/api/game/niu/records` | 公开 |
| GET | `/api/game/niu/rooms` | 公开 |
| GET | `/api/game/niu/state` | 公开 |
| GET | `/api/game/niu/stats` | 公开 |

## 旧红包对战（只读兼容）（routes/game.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/game/bet` | 公开 |
| POST | `/api/game/bid` | 公开 |
| GET | `/api/game/group-state` | 公开 |
| GET | `/api/game/history` | 公开 |
| POST | `/api/game/redpacket/claim` | 公开 |
| POST | `/api/game/redpacket` | 公开 |
| POST | `/api/game/rooms/:id/banker` | 公开 |
| POST | `/api/game/rooms/:id/end` | 公开 |
| POST | `/api/game/rooms/:id/join` | 公开 |
| POST | `/api/game/rooms/:id/leave` | 公开 |
| POST | `/api/game/rooms/:id/redpacket` | 公开 |
| GET | `/api/game/rooms/:id` | 公开 |
| GET | `/api/game/rooms` | 公开 |
| POST | `/api/game/rooms` | 公开 |
| POST | `/api/game/rounds/:id/start` | 公开 |
| GET | `/api/game/rounds/:roundId/packet` | 公开 |
| POST | `/api/game/settle` | 公开 |

## 推广 / 邀请（routes/promote.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/promote/info` | 公开 |
| GET | `/api/promote/rewards` | 公开 |
| GET | `/api/promote/summary` | 公开 |

## 聊天（游戏群 / 在线客服）（routes/chat.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/chat/channels` | 公开 |
| GET | `/api/chat/messages` | 公开 |
| POST | `/api/chat/messages` | 公开 |
| POST | `/api/chat/read` | 公开 |
| POST | `/api/chat/recall/:id` | 公开 |
| POST | `/api/chat/redpackets/:id/claim` | 公开 |
| GET | `/api/chat/redpackets/:id` | 公开 |
| POST | `/api/chat/redpackets` | 公开 |
| POST | `/api/chat/report` | 公开 |
| DELETE | `/api/chat/stickers/:id` | 公开 |
| GET | `/api/chat/stickers` | 公开 |
| POST | `/api/chat/stickers` | 公开 |
| POST | `/api/chat/system` | 公开 |

## 聊天禁言 / 举报（routes/chat-moderation.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/chat/moderation/group/mute` | 公开 |
| POST | `/api/chat/moderation/group/unmute` | 公开 |
| POST | `/api/chat/moderation/user/mute` | 公开 |
| POST | `/api/chat/moderation/user/unmute` | 公开 |
| GET | `/api/chat/moderation` | 公开 |

## 官方头像库（用户端）（routes/avatars.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/avatars/categories` | 公开 |
| GET | `/api/avatars/mine` | 公开 |
| POST | `/api/avatars/select` | 公开 |
| GET | `/api/avatars` | 公开 |

## 用户协议 / 隐私 / 语言（routes/settings.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/admin/settings` | 公开 |
| PUT | `/api/admin/settings` | 公开 |
| DELETE | `/api/admin/support/quick-replies/:id` | 公开 |
| GET | `/api/admin/support/quick-replies` | 公开 |
| POST | `/api/admin/support/quick-replies` | 公开 |
| GET | `/api/settings` | 公开 |
| GET | `/api/support/quick-replies` | 公开 |

## 游客客服（routes/support-guest.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/messages` | 公开 |
| POST | `/api/messages` | 公开 |
| POST | `/api/session` | 公开 |

## 管理后台（核心）（routes/admin.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| PATCH | `/api/admin/announcements/:id` | 公开 |
| GET | `/api/admin/announcements` | 公开 |
| POST | `/api/admin/announcements` | 公开 |
| POST | `/api/admin/approvals/:id/decide` | 公开 |
| GET | `/api/admin/approvals` | 公开 |
| GET | `/api/admin/audit-logs` | 公开 |
| GET | `/api/admin/dashboard` | 公开 |
| GET | `/api/admin/mute-expiring` | 公开 |
| GET | `/api/admin/online` | 公开 |
| POST | `/api/admin/real-name-reviews/:id/review` | 公开 |
| GET | `/api/admin/real-name-reviews` | 公开 |
| POST | `/api/admin/users/:id/adjust` | 公开 |
| POST | `/api/admin/users/:id/mute` | 公开 |
| POST | `/api/admin/users/:id/role` | 公开 |
| POST | `/api/admin/users/:id/status` | 公开 |
| POST | `/api/admin/users/:id/unmute` | 公开 |
| GET | `/api/admin/users` | 公开 |
| POST | `/api/admin/wallet/orders/:id/review` | 公开 |
| GET | `/api/admin/wallet/orders` | 公开 |
| GET | `/api/admin/wallet/transactions` | 公开 |

## 管理后台（资金 / 审核）（routes/admin-funds.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/deposits/:id/review` | 公开 |
| GET | `/api/admin/deposits/:id/voucher` | 公开 |
| GET | `/api/admin/deposits/:id` | 公开 |
| GET | `/api/admin/deposits` | 公开 |
| POST | `/api/admin/referrals/rewards/settle` | 公开 |
| GET | `/api/admin/referrals/rewards` | 公开 |
| GET | `/api/admin/referrals` | 公开 |
| POST | `/api/admin/withdrawals/:id/processing` | 公开 |
| POST | `/api/admin/withdrawals/:id/review` | 公开 |
| GET | `/api/admin/withdrawals/:id` | 公开 |
| GET | `/api/admin/withdrawals` | 公开 |

## 管理后台（充值审核）（routes/admin-recharge.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/receiving-accounts/:id/status` | 公开 |
| PUT | `/api/admin/receiving-accounts/:id` | 公开 |
| GET | `/api/admin/receiving-accounts` | 公开 |
| POST | `/api/admin/receiving-accounts` | 公开 |
| POST | `/api/admin/recharge/:id/cancel` | 公开 |
| POST | `/api/admin/recharge/:id/complete` | 公开 |
| GET | `/api/admin/recharge/:id/receipt` | 公开 |
| POST | `/api/admin/recharge/:id/reject` | 公开 |
| GET | `/api/admin/recharge/:id` | 公开 |
| GET | `/api/admin/recharge` | 公开 |

## 管理后台 / 客服（OTP）（routes/admin-otp.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/otp/:id/mark-sent` | 公开 |
| POST | `/api/admin/otp/:id/regenerate` | 公开 |
| POST | `/api/admin/otp/:id/reveal` | 公开 |
| POST | `/api/admin/otp/cleanup` | 公开 |
| GET | `/api/admin/otp/logs` | 公开 |
| GET | `/api/admin/otp` | 公开 |

## 管理后台（客服线程）（routes/admin-support.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/admin/support/threads/:threadKey/messages` | 公开 |
| POST | `/api/admin/support/threads/:threadKey/messages` | 公开 |
| PUT | `/api/admin/support/threads/:threadKey/status` | 公开 |
| GET | `/api/admin/support/threads` | 公开 |

## 管理后台（头像库）（routes/admin-avatars.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/avatar-categories/:id/status` | 公开 |
| PUT | `/api/admin/avatar-categories/:id` | 公开 |
| GET | `/api/admin/avatar-categories` | 公开 |
| POST | `/api/admin/avatar-categories` | 公开 |
| POST | `/api/admin/avatars/:id/status` | 公开 |
| DELETE | `/api/admin/avatars/:id` | 公开 |
| PUT | `/api/admin/avatars/:id` | 公开 |
| POST | `/api/admin/avatars/upload` | 公开 |
| GET | `/api/admin/avatars` | 公开 |
| POST | `/api/admin/avatars` | 公开 |

## 管理后台（运营 / 对局 / 游戏入口 / 通知）（routes/admin-ops.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/ops/games/:id/status` | 公开 |
| PUT | `/api/admin/ops/games/:id` | 公开 |
| GET | `/api/admin/ops/games` | 公开 |
| POST | `/api/admin/ops/games` | 公开 |
| POST | `/api/admin/ops/notices/:id/status` | 公开 |
| GET | `/api/admin/ops/notices` | 公开 |
| POST | `/api/admin/ops/notices` | 公开 |
| GET | `/api/admin/ops/overview` | 公开 |
| GET | `/api/admin/ops/rounds/:id` | 公开 |
| GET | `/api/admin/ops/rounds` | 公开 |
| POST | `/api/admin/ops/staff/:id/status` | 公开 |
| GET | `/api/admin/ops/staff` | 公开 |
| GET | `/api/admin/ops/support` | 公开 |

## 管理后台（26牛牛娱乐场）（routes/admin-niu.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| POST | `/api/admin/niu/grant-points` | 公开 |
| GET | `/api/admin/niu/rounds/:id` | 公开 |
| GET | `/api/admin/niu/rounds` | 公开 |
| GET | `/api/admin/niu/status` | 公开 |
| POST | `/api/admin/niu/switch` | 公开 |

## 管理后台（搜索）（routes/admin-search.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/admin/search` | 公开 |

## 健康检查（routes/health.js）

| 方法 | 路径 | 权限 |
| --- | --- | --- |
| GET | `/api/health` | 公开 |

---

合计 211 个接口（不含 Socket.IO 事件通道）。
