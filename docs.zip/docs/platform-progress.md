# 平台优化续作记录 — 2026-09-17

## 本轮实际改动

- `C:\26niuniu\public\app.css`：修复 FAQ 箭头损坏字符；增加原生 `details[open]` 答案显示规则；CSS 边框箭头旋转；键盘焦点可见。
- `C:\26niuniu\_test_tutorial_browser.js`：增加 FAQ 点击与计算样式断言，先导航至真实 FAQ 教学条目。修正后真实 Chrome 复测 17/17 通过（隔离 API 数据）。
- `C:\26niuniu\tests\faq-static.js`：新增无服务、无数据库的静态回归脚本。
- `C:\26niuniu\tests\faq-static-report.json`：静态检查报告，6/6 通过。
- 本文为新增交接文档。未删除文件、图片、用户、数据库表或测试数据；未执行 migration；未修改密码、Secret、监听地址或系统设置。

## 验证证据与边界

- `C:\26niuniu\tests\platform-smoke-report.json`：本次运行时间 2026-09-17T13:25:02Z；completed/passed 为 true。覆盖 HTML 内联脚本语法、外部脚本存在性、公共 JS 语法、实际服务四个静态资源 GET 200，以及两个管理 OTP API 未登录返回 401。不代表数据库或注册闭环通过。
- `C:\26niuniu\tests\navigation-wallet-report.json`：本次运行时间 2026-09-17T13:25:11Z；4/4 通过。钱包测试使用隔离数据库依赖，不是真实账务集成。
- `C:\26niuniu\tests\faq-static-report.json`：本次运行时间 2026-09-17T13:28:31Z；6/6 通过。验证结构、展开规则、合法箭头、焦点样式、损坏字符和语法。不是浏览器计算样式测试。
- 本轮浏览器测试首次新增 FAQ 断言失败：基础教学条目没有 FAQ，结果为 null。调整为先访问 FAQ 条目后，于 2026-09-17T13:29:39Z 复测 17/17 通过。报告：`C:\26niuniu\_tutorial_browser_report.json`；完整输出：`C:\26niuniu\tests\faq-browser-diag.txt`。真实 Chrome 验证展开后 display=block、高度约 52.6px、再次点击关闭；FAQ 页五种屏宽无横向溢出、导航在视口内、无捕获的 JS 异常/Console error/网络加载失败。API 使用隔离数据，不是数据库集成，也不代表全平台移动端验收。
- 终端 shell integration 不可靠，工具经常返回无法观测退出；以已落盘报告及文件内容核对，不把 exit code 1 简单解释为所有业务测试失败。
- 未找到用户提供的 `/mnt/data/1000715118.mp4`；没有观看参考视频。
- 当前终端未找到 git 命令，不能提供历史全量 diff。

## 现有模块（存在不等于全部验收）

项目已有 Express/MySQL/bcryptjs/JWT/Socket.IO，保留原认证入口。已有大厅、钱包、推广、聊天列表、游戏群、客服、我的、教学、公告、通知、收藏、搜索、注册和 OTP 管理页面；已有平台模块路由及集中配置。后续应复用，而非重写。

管理员 OTP 页面为 `/admin-otp.html`；API 使用 JWT 加 admin/support 角色校验。用户申请后，管理员在 pending 列表点击「领取一次」，复制并手动 WhatsApp 发送，再标记已发送。领取即清空数据库临时明文，刷新或隐藏页面不可再次查看。用户验证后拿注册凭证。未接 SMS API。

### 本轮 OTP 后续改动与验证

- 修改 `C:\26niuniu\routes\admin-otp.js`、`C:\26niuniu\public\js\admin-otp.js`、`C:\26niuniu\public\admin-otp.html`。
- 新增 `C:\26niuniu\tests\otp-reveal-integration.js` 及报告 `C:\26niuniu\tests\otp-reveal-integration-report.json`、诊断输出 `C:\26niuniu\tests\otp-reveal-diag.txt`。
- 2026-09-17T13:36:00Z，真实 HTTP + MySQL 会话临时表测试 8/8 通过：列表无明文、首次领取、no-store、数据库明文清空、重复领取拒绝、逐目标审计无验证码、玩家 403、匿名 401。使用生产路由与 JWT 中间件源码，专用测试 JWT key；过期清理/公共审计辅助函数被隔离。不是完整应用或注册闭环测试。
- 本次无需新 migration，复用 otp_plain_tmp 与现有审计列；没有修改持久用户/OTP 数据。测试临时表随连接关闭自动消失。
- 前端已检查代码与语法，新增领取按钮尚需真实后台浏览器交互验收。
- 2026-09-17T13:38:58Z，`C:\26niuniu\tests\otp-reveal-realrow.js` 在真实 `registration_otp` 插入一行完成 5/5 验证（真实 schema 列表无明文、领取一次、MySQL 明文清空、重复 409、按目标审计无验证码），随后仅删除本测试插入的行与审计行，`cleanup_error` 未出现。测试用 JWT 声明的 admin 身份未经用户表校验，仅用于路由级权限模拟；JWT_SECRET 从现有 .env 读取，未修改。冒烟 `PLATFORM_SMOKE_PASS`（`tests\platform-smoke-diag.txt`）。剩余：真实管理员账号浏览器验收领取按钮；多连接并发与审计写入失败回滚路径仍未验证。

## 必须继续完成的重点（未验收）

1. 已修复 OTP 一次性领取：列表与重新生成响应不含明文，新增 `POST /api/admin/otp/:id/reveal`，事务锁定记录、写审计、清空临时明文后返回一次；重复领取返回 409。后台页面增加领取按钮与过期/隐藏清除。尚需验证长期未领取记录清理及真实多连接并发。
2. 已修复列表逐目标审计及领取事务审计；审计失败不返回列表或验证码。数据库故障回滚测试仍待补充。
3. 请求冷却、错误次数、验证消费、管理员重新生成的事务/并发保证，以及注册凭证一次性消费需要进一步检查与修复；不得把目前顺序查询当作并发安全。
4. 真实数据库 schema 尚未全面核对。本项目已有 `C:\26niuniu\database\migrations\001-platform.js`、`002-otp.js`、`003-chat.js`；检查现库后决定迁移，不盲跑、不 reset。
5. 用户要求的注册、OTP 过期/次数/60 秒/消费、管理员与普通用户权限、邀请码、登录/JWT/me、聊天分页与重试、上传内容验证、自定义贴图、未读、通知、收藏等真实集成测试仍需完成。
6. 全平台 360/375/390/412/430px 布局、Console、Network 与页面返回需要浏览器验收；不能用 FAQ 静态检查替代。
7. 正式 Logo/头像/官方贴图仍待用户提供；本轮没有生成替代图片，也没有验证历史临时图片清理是否完成。
8. 钱包真实充值/提现等未接通时继续明确显示暂未开放，不能伪造账务成功；客服不能伪造回复。

## 快速续作

先阅读本文，避免再次重复目录扫描。复测命令：

```bat
node C:\26niuniu\tests\faq-static.js
node C:\26niuniu\tests\otp-reveal-integration.js
node C:\26niuniu\tests\otp-reveal-realrow.js
node C:\26niuniu\tests\platform-smoke.js
```

下一批建议：用真实管理员账号在浏览器验收「领取一次」交互；再核查 OTP 请求冷却、错误锁定、验证消费、注册凭证一次性消费的并发与事务，编写隔离回归测试，不访问真实用户敏感数据。

## 2026-09-19 本轮改动（UI 修复：白色输入框 / 注册按钮不可点 / 头像更换）

### 一、白色输入框（根因：`.input` 无全局样式）

- `public/app.css`：新增「10b. 独立输入控件」，定义全局 `.input`：深色底 `var(--surface-2)`、`1px solid var(--border)`、`var(--r-md)` 圆角、浅色文字与 placeholder、焦点转 `var(--gold)` 边框 + `var(--surface-3)` 底、`min-height: var(--control-h)`。修复前 `.input` 在 app.css 中**完全没有定义**，只在 `admin.html` / `me.html` 的页内 `<style>` 里有 `display/width/box-sizing` 等布局声明，因此所有 `class="input"` 控件都渲染成浏览器默认白底黑字。
- 同段落新增 `select.input`（原生箭头被 `appearance:none` 去掉后补回 SVG 箭头，右侧留白 38px）与 `input:-webkit-autofill / :hover / :focus / :active`、`textarea:-webkit-autofill` 兜底规则（`-webkit-text-fill-color` + `0 0 0 1000px inset` 大内阴影 + `caret-color`），避免 Chrome 自动填充把深色输入框刷成白底 / 黄底。
- `public/search.html`：`<div class="search-row">` 改为复用既有 `<div class="search-bar">`。`.search-row` 在项目中从未定义（搜索页一直是裸样式），`.search-bar` 是大厅已有的深色胶囊搜索框。
- `public/admin.html`：`#ledgerUser`、`#adjustCurrency`、`#anType` 补 `class="input"`。
- `public/admin-otp.html`：`#otpStatus` 补 `class="input"`。

### 二、注册按钮不可点击（根因：验证码按钮被自己隐藏）

- `public/register.html` 关键缺陷：`#otpMeta`（内含「获取验证码」按钮与倒计时）原本是内联 `style="display:none"`，唯一会把它改成 `flex` 的 `showOtpArea()` 只在 `/api/otp/request` **成功之后**才被调用 —— 而触发它的按钮就在这个隐藏容器里。结果：用户永远看不到、也点不到「获取验证码」，`phoneVerified` 永远为 `false`，`#regBtn` 永久 `disabled`，且页面没有任何原因提示。
- 修复：移除 `#otpMeta` 的内联隐藏；`showOtpArea()` 只负责显隐 6 格验证码输入行；手机号失焦时若未验证则保持验证码区可见。倒计时与 60 秒冷却逻辑沿用原有 `App.cooldown(sendBtn, 60, '重试 ')`。
- 新增 `<p id="readyHint">`：`checkReady()` 改为基于 `missingItems()` 列表输出「还需完成：用户名、手机号验证码、邮箱…」，全部完成时改为绿色「信息已填写完整，可以提交注册。」，解决「按钮灰掉但不知道缺什么」。
- 邀请码：带 `?invite=` 进入时立即触发一次 `checkInvite()`，不再等用户手动编辑才出校验结果。
- 已确认既有正确行为保持不变：`#regBtn` 仍保持禁用直到全部必填项与 OTP 完成（防误提交），提交仍携带 `otp_token`，`OTP_TOKEN_INVALID` 仍会重置验证状态。
### 三、头像更换改为「点击头像」（`public/me.html` + `public/js/me-page.js`）

- `me.html`：`#userAvatar` 从 `<div class="avatar" aria-hidden="true">` 改为 `<button type="button" class="avatar avatar-lg avatar-edit" title="点击更换头像" aria-label="更换头像">`，并新增 `.me-avatar-hint` 文案「点击头像即可更换（JPG / PNG / WEBP，最大 2MB）」。`.avatar-edit` 负责 `cursor:pointer`、去掉 button 默认 padding/appearance、金色描边、焦点可见轮廓。
- 移除旧的「可见 file input + 上传头像按钮」，改为隐藏 `<input id="avatarInput" type="file" hidden>`（程序化 `.click()` 触发，桌面端与移动端相册都能拉起）＋ 一个「更换头像」按钮作为可发现入口。
- 新增裁剪弹层 `#avatarCrop`（300×300 canvas + 缩放拉杆 + 旋转/取消/确定）：点击头像 → `App.openSheet({ title:'更换头像', items:[{ label:'从手机相册 / 文件中选择', icon:'i-image' }] })` → 选图后校验类型与 2MB 上限 → 打开裁剪层（默认 `coverScale` 铺满）→ 拖动 / 拉杆缩放 / 90° 旋转（带边界 clamp，图片不会被拖出裁剪框）→ `canvas.toBlob('image/jpeg', 0.92)` → 复用 `POST /api/profile/avatar` 上传（`FormData` + Bearer token，401 走 `App.logout()`）。
- 兼容性：导出固定为 300×300 JPEG，远低于后端 2MB 限制，并通过后端魔数 + `mimetype` 双重校验；透明 PNG 会先填充 `#07080a` 底色再绘制，避免透明区域变黑块异常。
- 交互细节：裁剪过程中 `#cropConfirm` 禁用防重复提交；`Esc`、点击遮罩、取消按钮均可关闭；关闭时 `URL.revokeObjectURL` 并清空 file input（保证同一张图可再次选择）。
- `load()` 仍负责渲染头像（首字母占位 / `avatar_url` 的 `<img>`），上传成功后重新 `load()` 刷新页面头像。

### 四、验证证据（真实 Chrome）

- 新增 `tests/ui-fix-browser.js`：复用项目既有的真实 Chrome + CDP 脚手架风格（`C:/Program Files/Google/Chrome/Application/chrome.exe --headless=new`，Node 内置 WebSocket），express 提供**隔离 API fixture** + `express.static(public)`，只读生产 HTML/CSS/JS，不写数据库、不改业务文件；每完成一条断言即把报告落盘，避免终端中断丢结果。
- 运行结果：`started=2026-09-18T16:56:36Z`，`passed=true`，`checks=40`，`failed=0`，`errors=[]`（无 JS 异常 / console error / 资源加载失败），`assets={cssLoaded:true, cardStyleLoaded:"rgb(7, 8, 10)", assetLog:["/app.css:200","/js/app-common.js:200"]}`。报告：`tests/ui-fix-browser-report.json`。
- 覆盖要点：
  - 注册页：`#otpMeta` 计算样式 `flex`、高 44px（修复前 `display:none`）；「获取验证码」`offsetParent` 非空、可点击；点击后 6 格输入框展开并进入「重试 60s」倒计时；真实发起 `/api/otp/request`；`#regBtn` 初始禁用且提示「还需完成：用户名、手机号及验证码验证、邮箱…」；仅剩验证码时提示收敛为「还需完成：手机号验证码」；输入框计算样式 `rgb(27,30,35)` 底 + `rgb(242,244,247)` 文字。
  - 我的页：昵称输入框深色底 + 浅色文字；`#userAvatar` 为 `BUTTON`、`cursor:pointer`、64×64；点击弹出 ActionSheet 且含「从手机相册 / 文件中选择」；用 canvas 生成真实 PNG 注入 file input 后裁剪层弹出、`canvas 300×300` 且 `getImageData` 证明已绘制；旋转 + 缩放后画布仍有内容；取消后弹层关闭且 file input 清空。
  - 搜索页 / 后台 / OTP 管理：`.search-bar` 为 flex 深色胶囊且 `#q` 可输入；`#ledgerUser`、`#adjustUserId`、`#adjustAmount`、`#adjustReason`、`#anContent` 全部深色底 + 浅色文字；`#adjustCurrency`、`#anType`、`#otpStatus` 深色底 + 38px 右内边距。
  - 布局：360/375/390/412/430px 五档 `scrollWidth <= 视口`、头像 64px 且在视口内；360px 视口下裁剪弹层 `stageW=290 / boxW=324` 不溢出。
- 踩坑记录（避免复现）：该脚本的 `goto()` 必须等 `document.readyState === 'complete'`，否则会在 `app.css` / `app-common.js` 生效前断言，出现「白底输入框 + `typeof App === 'undefined'`」的假失败；本轮已实测复现并修正。
- 边界：fixture 数据隔离，**不是**真实后端 / 数据库集成；未验证真实 OTP 收发闭环、头像真实落库与 CDN 访问。

### 五、本轮清理

- 删除历史误建的垃圾文件（全部为 shell 重定向误产物）：`$null`（599B，PowerShell 报错输出）、`0))`、`0){const`、`{const`、`{if(child)child.kill()`、`0){console.log('STUB_LINE'`、`0){console.log('STUB_LINE')`（均 0 字节）。
- 删除本轮产生的临时输出与临时脚本（`_v1~_v17.txt`、`_run_ui*`、`_ui2*`、`_vcheck.js`、`_slice.js` 等）。
- 未删除任何业务文件、图片、用户数据、数据库表或既有测试报告；未执行 migration。

### 六、仍未完成 / 待确认

1. 注册页仍强制「真实姓名 + 邮箱 + 邀请码」必填；是否精简为后端校验一致的最小集合，需业务确认。
2. 头像「恢复默认」后端没有对应接口（`routes/profile.js` 只有 `POST /api/profile/avatar`），前端因此未提供该选项。
3. 钱包 / 推广 / 聊天 / 通知 / 日志仍缺真实账号 + 数据库的端到端验收；`server.log` 里的 `EADDRINUSE` 是历史上重复启动产生的，3000 端口现由单个进程正常监听。

### 七、复测命令（本轮新增）

```bat
node C:\26niuniu\tests\ui-fix-browser.js
```

输出 `UI_FIX_BROWSER_PASS (40 checks)` 即通过；失败详情看 `tests\ui-fix-browser-report.json` 的 `checks[].detail`。该命令会临时启动隔离端口与独立 Chrome 用户目录，不影响 3000 端口的开发服务器。

## 2026-09-19 管理后台权限与账号治理（第二轮）

### 一、问题根因（为什么普通用户能看到「管理后台」「OTP 管理」）

1. `/admin.html`、`/admin-otp.html` 是 `public/` 下的**静态文件**，`server.js` 用 `express.static` 直接对外提供；鉴权只做在 `/api/admin/**`（`auth + requireRole('admin')`）。→ 任何登录用户（甚至未登录）只要知道网址就能打开后台外壳。
2. `admin-otp.html` 连前端门禁都没有：不校验角色就渲染整个 OTP 控制台，只在 API 返回 403 后显示「加载失败或无访问权限」，所以看起来「普通用户也能用这个功能」（数据本身仍被 403 挡住）。
3. 后台也缺少「给管理员权限 / 禁言」能力：`routes/admin.js` 只有只读用户查询 + 启停；`users` 表没有任何禁言字段。

### 二、本轮改动

**1) 服务端管理页面门禁（核心修复）**
- `middleware/admin-boundary.js`：在原有 `/api/admin` 守卫之外新增**静态页面门禁**，`server.js` 中仍挂在 `express.static` 之前。GET/HEAD `/admin.html`、`/admin-otp.html` 时校验「页面票据 Cookie + 当前数据库角色」，不是活跃管理员一律 `302 → /me.html?admin=denied`，并对管理页面下发 `Cache-Control: no-store`；校验服务异常返回 503 而不是放行。
- `utils/pageSession.js`（新增）：登录成功时下发 HttpOnly Cookie `nn_page`（同一份 JWT，`SameSite=Lax`，`secure` 按请求自动判定，可用 `COOKIE_SECURE=1/0` 强制，有效期与 `JWT_EXPIRES_IN` 对齐）。Cookie **只**被页面门禁读取，`/api/**` 仍只认 `Authorization: Bearer`，因此不会带来数据层的 CSRF 风险。
- `routes/auth.js`：登录成功 `setPageSession()`；新增 `POST /api/auth/logout`（`auth`）清除票据。
- `public/js/app-common.js`：`logout()` 先用 `keepalive` 请求 `POST /api/auth/logout` 清票据，再清 localStorage 并跳登录页（否则退出后同一浏览器仍能打开后台页面）。

**2) 前端兜底门禁（防止静态托管绕过）**
- `public/admin-otp.html`：新增 `#otpGate`，把提示 / 工具栏 / 列表整体包进 `#otpBody hidden`；`public/js/admin-otp.js` 先 `GET /api/auth/me` 校验角色，非管理员只显示「无权访问 + 返回我的」，不请求任何 OTP 接口。
- `public/js/admin-page.js`：「无权访问」页面补「返回我的」按钮；`public/js/me-page.js` 对被挡回时的 `?admin=denied` 弹出「该功能仅管理员可以使用」并清理地址栏参数。

**3) 注册人数可点进用户列表**
- `public/js/admin-page.js`：`tile()` 支持 `data-go`，概览的「用户总数 / 今日注册」渲染为 `<button class="stat-link" data-go="users">`（`cursor:pointer` + 「点击查看用户」提示），点击即切到「用户」Tab；`public/admin.html` 增加 `.stat-link` / `.user-name` / `.admin-tag.muted|admin` 样式。

**4) 用户管理面板（点用户名即可操作）**
- 用户列表把用户名渲染成 `.user-name[data-user=ID]` 按钮，卡片显示「角色 / 状态 / 禁言至…」标签，并常驻「管理账号」按钮。
- 点击后弹出 ActionSheet：设为管理员 / 取消管理员权限 / 禁言该账号…（1 小时 / 1 天 / 7 天 / 30 天）/ 解除禁言 / 封禁账号 / 解除封禁。所有变更必须填写原因（写入审计）；管理员账号只提供「取消管理员权限」（后端禁止禁言/封禁管理员，避免必然失败的入口）。

**5) 后端能力（`routes/admin.js`）**
- 新增 `POST /api/admin/users/:id/role`（`admin` / `user`）、`POST /api/admin/users/:id/mute`（5 分钟~30 天 + 原因）、`POST /api/admin/users/:id/unmute`。
- `GET /api/admin/users` 增加 `muted / muted_until / mute_reason`；`POST /api/admin/users/:id/status` 增加「管理员不可被封禁」。
- 规则（后端强制）：不能操作自己；不能取消最后一个活跃管理员；管理员账号不能禁言/封禁（先降级）；余额、密码、账号数据一律不动；每个变更与审计在同一事务（`user_role` / `user_mute` / `user_unmute` / `user_status`）。
- 审计筛选按钮新增「管理员权限 / 禁言 / 解除禁言」。

**6) 禁言真正生效**
- `database/migrations/004-moderation.js`（新增，已执行）：`users.muted_until DATETIME NULL`、`users.mute_reason VARCHAR(255) NULL`；`database/migrations/run-all.js` 已纳入 004。
- `utils/moderation.js`（新增）：读取禁言状态；迁移未执行时降级为「未禁言」并打印一次明确提示，不会把整站聊天打挂。
- `routes/chat.js`：`POST /api/chat/messages` 在写库前校验禁言 → `403 USER_MUTED`，提示含解禁时间与原因；读消息、钱包、游戏等其它功能不受影响。

### 三、验证证据（真实环境）

- `node tests/admin-access-browser.js` → **`ADMIN_ACCESS_BROWSER_PASS (84 checks, temp accounts removed: 2)`**
  - 真实 `server.js`（临时端口 fork）+ 真实 MySQL + 真实 Chrome（CDP），报告 `tests/admin-access-browser-report.json`，每步断言即落盘。
  - 匿名/普通用户访问两个管理页面 → 302 → `/me.html?admin=denied`，且响应体不含 `id="adminBody"` / `id="otpBody"`；`/api/admin/**` 匿名 401、普通用户 403。
  - 登录下发 `nn_page`（HttpOnly + SameSite=Lax），`POST /api/auth/logout` 清除后无效票据立即被挡。
  - 管理员：两个页面 200 且 `no-store`；授予/取消管理员、禁言 60 分钟、解除禁言、封禁、解封全部数据库核对；被禁言用户发消息 403、解除后可发送（真实入库）；被封禁账号登录 403、解封后可登录。
  - 安全护栏：不能改自己角色 / 不能封自己 403；非法角色、原因过短、时长越界 422；管理员不能被禁言/封禁 403。
  - 真实浏览器 UI：管理员在「我的」看到两个入口 → 概览「用户总数 / 今日注册」可点击 → 用户列表出现用户名按钮 → 点击用户名弹出「设为管理员 / 禁言 / 封禁」→ 通过 UI 依次完成禁言、解除禁言、封禁（随后登录 403）、解封（可登录）、设为管理员、取消管理员，全部数据库核对通过。
  - 审计日志包含 `user_role / user_mute / user_unmute / user_status` 且不含密码 / OTP / 凭证。
  - 临时账号（`zzperm_*`）及其审计、登录、聊天记录在结束时全部删除（`deleted_users: 2`）。
- `node tests/ui-fix-browser.js` → **`UI_FIX_BROWSER_PASS (48 checks)`**（比上轮 +8），新增：普通用户在「我的」看不到两个入口、打开 `/admin.html` 只剩「无权访问」、打开 `/admin-otp.html` 看不到任何控制台内容。
- `node tests/platform-smoke.js` → **`PLATFORM_SMOKE_PASS`**，新增 4 项：匿名请求两个管理页面必须 302 且响应体不含后台标记。
- 3000 端口开发服务器原先仍在跑改动前的代码（`/admin.html` 返回 200），已重启为单进程（新 PID）：`curl -w "%{http_code} %{redirect_url}" /admin.html` → `302 http://127.0.0.1:3000/me.html?admin=denied`。
- `node tests/admin-real-account.js`（真实管理员账号 `37491058`（UID 10）+ 3000 端口真实服务 + 真实 Chrome；只读，口令由环境变量 `NN_ADMIN_PASSWORD` 传入，仓库内不保存口令）→ **`ADMIN_REAL_ACCOUNT PASS (46/46)`**，报告 `tests/admin-real-account-report.json`：
  - 真实登录 200 且角色 admin，下发 `nn_page`（HttpOnly + SameSite=Lax）；两个管理页面 200 且 `no-store`；`/api/admin/dashboard` 返回 `{total:9, active:9, banned:0, today:1}`；`/api/admin/users` 含 `muted / muted_until / mute_reason / role`。
  - 普通用户票据、匿名、伪造签名访问两个管理页面均 302 → `/me.html?admin=denied`，且不含 `id="otpList"` 等后台标记；退出登录清除票据。
  - 真实 Chrome：点「我的」页「管理后台」入口进入 `/admin.html`（未被拦回）→ 「用户总数 / 今日注册」统计卡 `cursor:pointer` 可点击 → 进入用户列表（9 个可点击用户名）→ 查询 `37491058` 的面板只有「取消管理员权限」（管理员禁言/封禁入口不出现）→ 查询 `dodo` 的面板含「设为管理员（授予后台权限）/ 禁言该账号… / 封禁账号（禁止登录）」→ `/admin-otp.html` 正常打开且未领取任何验证码 → 全程无 JS 异常 / console.error。
  - 账号事实：真实管理员是 `37491058`（UID 10）；`bobo`（UID 3）是早前联调遗留的管理员测试账号，如需收敛权限可将其降级。

### 四、边界 / 仍未完成

1. 禁言只拦「发送聊天消息」；游戏下注、建房、钱包等入口未纳入禁言范围（如需请明确规则）。
2. 封禁不主动断开已建立的 Socket 连接，但任何后续 HTTP 请求都会被 `auth` 中间件按数据库状态拒绝（已有测试覆盖登录 403）。
3. 管理员操作没有双人复核、没有禁言到期提醒。
4. 上一轮遗留未变：注册页必填项是否精简、头像「恢复默认」接口、钱包/推广/聊天/通知的端到端验收。

### 五、复测命令（本轮）

```bat
node C:\26niuniu\tests\admin-access-browser.js
node C:\26niuniu\tests\ui-fix-browser.js
node C:\26niuniu\tests\platform-smoke.js
```

- `admin-access-browser.js` 会创建 `zzperm_*` 临时账号，结束后自动删除（报告里 `cleanup.deleted_users` 应等于 2）；使用临时端口，不影响 3000 端口。
- 数据库若换新环境，先执行 `node C:\26niuniu\database\migrations\004-moderation.js`（幂等）。





## 阶段 V5：钱包 / 充值 / 提款 / 推广奖励（2026-09-19）

### 交付范围

| 模块 | 状态 | 关键实现 |
| --- | --- | --- |
| 钱包首页 | 完成 | `public/wallet.html`：双资产独立展示 + 充值/提款/交易记录入口 |
| 充值金额页 | 完成 | `public/deposit.html` + `public/js/deposit-page.js`：RM30–50,000、9 档快捷金额、自定义输入、双端校验 |
| 充值详情页 | 完成 | `public/deposit-detail.html` + `js/deposit-detail-page.js`：订单号/金额/付款方式/状态、测试收款资料、充值声明、备注提示、下一步/取消 |
| 上传凭证页 | 完成 | `public/deposit-voucher.html` + `js/deposit-voucher-page.js`：选择/预览/压缩/提交；提交后状态 `PENDING_REVIEW`，绝不自动加余额 |
| 提款页 | 完成 | `public/withdraw.html`（重写）+ `js/withdraw-page.js`：可用测试资产、资产类型、金额校验、收款资料、我的申请 |
| 管理员充值管理 | 完成 | 后台「充值管理」面板 + `GET/POST /api/admin/deposits*` |
| 管理员提款管理 | 完成 | 后台「提款管理」面板 + `GET/POST /api/admin/withdrawals*` |
| 推广奖励 Ledger | 完成 | 表 `referral_rewards` + `utils/referralRewards.js`（幂等 `unique_key`，充值批准时同事务结算） |
| 管理员推广管理 | 完成 | 后台「推广管理」面板 + `GET /api/admin/referrals`、`GET /api/admin/referrals/rewards`、`POST .../rewards/settle` |
| 推广页奖励台账 | 完成 | `public/promote.html` 新增奖励汇总 + 日期筛选 + 记录列表 |
| Audit Log | 完成 | 审核/补结算/处理中全部写 `admin_logs`（充值提款用 `wallet_order_review`），不含口令/OTP/凭证内容 |
| support 权限 | 完成 | support 可访问 OTP 管理与 `/admin-otp.html`；充值/提款/推广管理仍仅 admin |

### 数据库变更（只新增，可重复执行）

```bat
node C:\26niuniu\database\migrations\005-funds-referral.js
node C:\26niuniu\database\backfill-invite-codes.js
```

- `wallet_orders`：状态枚举扩展（新增 `PENDING_PAYMENT` / `PENDING_REVIEW` / `APPROVED`）、8 个新列、3 个索引（含订单号唯一键）
- 新表 `referral_rewards`：`user_id / source_user_id / level / rate / base_amount / reward_amount / asset_type / status / source_type / source_ref / unique_key(UNIQUE) / remark / operator_id / created_at / credited_at`
- 未删除任何用户、任何订单、任何流水；历史 20 笔订单状态原样保留

### 状态机与幂等

- 充值：`PENDING_PAYMENT` →（上传凭证）`PENDING_REVIEW` →（管理员批准）`APPROVED` /（拒绝）`REJECTED`；未审核可 `CANCELLED`
- 提款：`PENDING` →（可标记）`PROCESSING` → `APPROVED` / `REJECTED`；未审核可 `CANCELLED`
- 批准流程：`SELECT ... FOR UPDATE` 锁定订单 → 校验状态在可审核集合内 → 锁定用户行 → 校验余额（提款）→ 更新余额 + 写 `balance_transactions` + 更新订单快照（`before_balance` / `after_balance` / `reviewed_by` / `reviewed_at`）→ 写审计 → 提交；重复批准返回 409，绝不重复加减余额
- 推广奖励：`INSERT ... ON DUPLICATE KEY UPDATE` + 以 `insertId` 判定新插入（MySQL 对重复键原值更新可能返回 affectedRows=1），`unique_key = 来源类型:来源单号:层级:受益人`

### 测试与运行方式

```bat
node C:\26niuniu\tests\deposit-withdraw-e2e.js   REM 隔离 MySQL + 真实 HTTP，92/92
node C:\26niuniu\tests\funds-browser.js          REM 真实 Chrome + 真实 MySQL（zzfunds_* 临时账号结束即删），81/81
node C:\26niuniu\tests\funds-flow.js             REM 隔离 mock 状态机回归，34/34
node C:\26niuniu\tests\structure-check.js        REM 新增文件结构自检（防止函数被误嵌套）
node C:\26niuniu\tests\platform-smoke.js
node C:\26niuniu\tests\admin-access-browser.js   REM 84/84（权限边界回归）
```

- 开发服务：`npm start`（默认 3000 端口，`.env` 的 `PORT` 可改）
- `tests/deposit-withdraw-e2e.js` 会新建并在结束时删除隔离测试库 `nn_test_funds`，不触碰主库
- `tests/funds-browser.js` 只创建 `zzfunds_*` 临时账号与订单，结束时按外键关系递归清理并删除账号；若上次运行被中断，下一次运行会先自愈清理残留的 `zzfunds_*` 账号

### 测试中发现并修复的问题

1. 管理员列表关键字搜索把 `_` 当通配符删除，导致含下划线的用户名搜不到 → 改为正确转义 `\`、`%`、`_`
2. 推广奖励幂等判定依赖 `affectedRows`，本机 MySQL 对重复键原值更新返回 1 → 改用 `insertId`
3. `referral_rewards` 排序规则与库默认不一致，JOIN 报 collation 冲突 → 迁移内自动对齐
4. `middleware/auth.js` 需要 `config/db`，旧的 OTP 集成测试未注入 → 测试补会话级临时 `users` 表隔离
5. 真实库里 UID 10 的 `invite_code` 为空 → 新增补发脚本并执行



### 本地服务端口说明（本轮实测）

- 默认端口：`.env` 的 `PORT=3000`（`npm start`）。
- 本轮验证期间，3000 端口被一个**本轮之前启动、且不在当前会话内**的旧进程占用（`netstat -ano` 显示 PID 4120，`taskkill /F /PID 4120` 返回「Not found」，说明它属于其它会话），该进程仍是旧代码（`GET /api/deposit/config` → 404）。
- 新代码已实测运行于 `http://127.0.0.1:3001`：
  - 启动方式：`set PORT=3001 && node server.js`（或 `set PORT=3001 && npm start`）
  - 实测：`/api/deposit/config`、`/api/withdraw/config`、`/api/admin/deposits` → 401（路由存在，需登录）；`/deposit.html`、`/deposit-detail.html`、`/deposit-voucher.html`、`/withdraw.html` → 200；`/admin.html` → 302（未登录被页面票据门禁挡回，符合预期）
- 若要让 3000 端口提供新功能：先在该端口对应的终端里停止旧进程（Ctrl+C 或关闭那个终端），再执行 `npm start`。

## 阶段 V6（治理闭环 + 聊天红包）本轮进展

- 迁移（幂等、只新增，未删除任何数据）：
  - `database/migrations/006-presence-approval.js`：新增 `user_presence`（在线状态：`last_seen` / `sockets`）与 `admin_approvals`（双人复核队列）。
  - `database/migrations/007-chat-redpacket.js`：`chat_messages.message_type` 扩展 `redpacket`（原 5 种保留）并新增 `chat_red_packets`（红包主表：编号 / 频道 / 发送者 / 总额 / 个数 / 已领 / 状态 / 有效期）与 `chat_red_packet_claims`（领取明细，`packet_id + user_id` 唯一）。
  - `database/migrations/run-all.js` 已加入 006 / 007。
- 在线状态（`utils/presence.js`）：Socket 连接/断开与聊天轮询都会写心跳（同一用户 20 秒内存节流），在线 = 最近 90 秒内有活跃；表/列不可用时返回 `null` 并给出原因，绝不用账号总数冒充。进程内维护 Socket 注册表，供「封禁主动断开」与「当前连接数」使用。
- 禁言联动（`config/moderation.js` + `utils/moderation.js`）：`MUTE.SCOPE` 集中开关，默认禁止「发消息 / 发红包 / 建房进房 / 竞标下注抢包 / 提交提款」，充值（资金流入）默认不禁止；`scopeBlocked()` 统一返回 `USER_MUTED` 403，命中范围在聊天、聊天红包、`/api/game` 写接口、提款接口四处强制执行。用户端 `/api/chat/channels` 返回 `my_mute`（解禁时间 + 原因），游戏群顶部显示禁言横幅。
- 双人复核（`utils/approvals.js` + `utils/userAdminOps.js`）：封禁/解封、管理员权限变更、解除禁言走「提交 202 → 另一名管理员 `POST /api/admin/approvals/:id/decide` 通过 → 执行」。要点：申请人不能复核自己（403）、原子占用保证并发下只有一人能通过（重复 409）、拒绝必须填原因且不改数据、执行失败自动退回待复核（绝不留下「已通过但未生效」）、提交前预校验（改自己 / 封管理员 / 状态未变 / 取消最后一个管理员等直接 4xx 且不占用队列）、仅剩一名活跃管理员时按配置降级为单人执行并在审计标注。账号治理动作统一收敛到 `utils/userAdminOps.js`，单人执行与复核执行行为完全一致。
- 封禁断开连接：封禁生效后 `presence.kickUser()` 推送 `account:revoked` 并断开该账号全部 Socket；闲聊/空闲连接仍由既有 15 秒重认证兜底。
- 禁言到期提醒：`GET /api/admin/mute-expiring`、概览「禁言中 / 24 小时内解禁 / 即将解禁名单」、用户列表 `?mute=expiring` 筛选与「（N 小时后解禁）」标签；到期自动失效，无需人工解禁。
- 聊天红包（`config/redPacket.js` + `utils/chatRedPacket.js` + `routes/chat.js`）：
  - 接口：`POST /api/chat/redpackets`（发红包）、`GET /api/chat/redpackets/:id`（详情 + 领取记录 + 手气最佳 + 我能否领取）、`POST /api/chat/redpackets/:id/claim`（抢红包）。
  - 资金：一律「分」为整数运算，使用平台测试资产 `users.cash_chips`；发送即扣款并写 `RED_PACKET_SEND` 流水，领取写 `RED_PACKET_CLAIM`，未领完（默认 24 小时）由懒清扫 + 5 分钟定时任务写 `RED_PACKET_REFUND` 原路退回发送者。
  - 规则：事务 + 行锁 + 唯一键，绝不超发；不能抢自己发的红包；不能重复领取；红包消息禁止撤回（403 `RED_PACKET_NO_RECALL`）；仅游戏群开放（客服频道 400）；金额 1–500 RM、个数 1–100。
  - 前端：游戏群输入栏新增红包按钮（`App.openFormSheet` 表单弹层：金额 / 个数 / 祝福语，含测试资产说明与退回规则），红包以气泡卡片渲染（待领取 / 已抢光 / 已过期 / 已抢 X），点击可抢或查看详情（领取记录、手气最佳）。
- 后台 UI：概览新增「在线人数 / 待复核 / 禁言中」统计卡与「治理提醒（禁言到期 / 在线）」区块，「当前系统暂不支持」不再列在线人数；新增「复核」Tab（待复核 / 已通过 / 已拒绝 + 通过并执行 / 拒绝），用户 Tab 新增「已禁言 / 即将解禁」筛选；审计筛选新增复核申请 / 复核通过 / 复核拒绝。
- 本轮验证（真实环境，全部通过）：
  - 新增 `tests/moderation-redpacket-live.js` 110/110：真实临时端口 server + 真实 MySQL + 真实 Socket.IO；临时 `zzmt_*` 账号结束即删（`cleanup` 按外键关系清理并核对）。覆盖在线心跳与人数、禁言联动四处拦截与充值不拦、双人复核（202 → 他人通过 → 生效 / 自审 403 / 重复 409 / 拒绝不改数据 / 审计 requested_by+approved_by）、封禁 `account:revoked` + 连接断开 + `presence.sockets` 归零 + 旧 JWT 立即 403、红包全流程（扣款精确、随机分配、不能抢自己的、重复领取 409、红包消息禁止撤回、过期退款分位精确、1.00 RM 拆 100 份、参数边界与权限）。
  - 回归：`tests/admin-access-browser.js` 87/87（按双人复核语义更新，新增第二管理员用于复核，UI 流程在复核后刷新列表缓存）、`tests/admin-dashboard.js` 20/20（补齐 V6 依赖桩，保持隔离、不连真实库）、`tests/platform-smoke.js` PASS、`tests/socket-auth.js` PASS、`tests/funds-flow.js` 34/34。
- 注意：`tests/admin-access-browser.js`、`tests/admin-dashboard.js` 已随本轮契约变化同步更新；如后续把双人复核改为「关闭」或调整动作清单，只需改 `config/moderation.js`。

#### 聊天「说话人名字 + 红包」收尾（2026-09-19）

- 前端（`public/js/chat-page.js`）：
  - 新增 `speakerName()` / `nameHtml()`，每条消息都显示说话人名字：自己 =「我 · 用户名」（右对齐、金色），别人 = 对方用户名，系统消息 =「系统」，游戏消息 =「游戏助手」；用户名取不到时兜底「玩家 / 我」，杜绝空白名字气泡。系统消息改为「来源 + 气泡」结构（`sys-line`），游戏消息同理（`game-line`），样式见 `public/app.css` 第 28 节。
  - 红包：`rpCardHtml()` 渲染气泡卡片（祝福语 / 已领进度 / 状态），`updateRpBubble()` 用最新详情刷新单个气泡；`sendRedPacket()` 走 `App.openFormSheet` 表单（金额 / 个数 / 祝福语 + 测试资产与退回规则说明）；`openRedPacket()` 能领则确认后抢、不能领则直接看详情；`ensureRedPacketConfig()` 在页面未传配置时补拉一次 `/api/chat/channels`，保证入口不会因一次请求失败而消失。
- 后端修复（`routes/chat.js`）：`POST /api/chat/redpackets/:id/claim` 成功后改为回读完整详情（`fullPacketOrFallback()`，失败时退回领取结果里的 packet），否则前端拿到的 packet 缺 `claims` / `claims_total`，会显示「领取记录（undefined 人）」。
- 数据清理（历史测试遗留）：红包消息没有外键约束，旧测试只删了 `chat_red_packets` 而留下聊天里的红包消息 → 群里出现「待领取但点开报错」的幽灵卡片。已清理库中 18 条幽灵消息与 6 条 2026-09-16 的历史测试文案；`tests/moderation-redpacket-live.js` 的 `cleanup()` 补上 `chat_messages` 删除与残留核对，后续跑测试不再留垃圾。
- 启动与端口排查：新增 `utils/portOwner.js`（只读探测监听端口的进程）与 `scripts/restart.js`（`npm run restart`：结束旧 node 进程后以当前代码启动；占用者为未知进程时默认拒绝误杀，`-- --force` 才结束）；`server.js` 在 `EADDRINUSE` 时打印占用进程 PID + 结束命令 + 一键重启提示。
- 验证（真实环境）：`tests/chat-name-redpacket-browser.js` 51/51（真实临时端口 server + 真实 MySQL + 真实 Chrome 无头；`zzui_*` 临时账号结束即删，残留 0），截图 `tests/chat-name-redpacket-ui.png`；回归 `tests/moderation-redpacket-live.js` 110/110、`tests/admin-access-browser.js` 87/87。

