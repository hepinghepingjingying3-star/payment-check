'use strict';
// Additive, rerunnable migration. Never changes account names, credentials or balances.
const fs = require('node:fs');
const path = require('node:path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const db = require('../config/db');
(async () => {
  const [columns] = await db.promise().query('SHOW COLUMNS FROM users');
  const additions = [];
  if (!columns.some(c => c.Field === 'nickname')) additions.push('ADD COLUMN nickname VARCHAR(32) NULL');
  if (!columns.some(c => c.Field === 'avatar_url')) additions.push('ADD COLUMN avatar_url VARCHAR(255) NULL');
  if (additions.length) await db.promise().query('ALTER TABLE users ' + additions.join(', '));
  const [after] = await db.promise().query('SHOW COLUMNS FROM users');
  const passed = ['nickname', 'avatar_url'].every(name => after.some(c => c.Field === name));
  fs.writeFileSync(path.join(__dirname, '..', 'tests', 'profile-migration-report.json'), JSON.stringify({ passed, added: additions.length, date: new Date().toISOString() }, null, 2));
  if (!passed) throw new Error('Profile columns unavailable');
  console.log('PROFILE_MIGRATION_PASS');
})().catch(e => { console.error(e.code || e.message); process.exitCode = 1; }).finally(() => db.end());
