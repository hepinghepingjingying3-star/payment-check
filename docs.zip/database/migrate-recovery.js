'use strict';
// Only adds reset-token storage; never changes existing users or credentials.
const path = require('node:path');
const fs = require('node:fs');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const db = require('../config/db');
(async () => {
  await db.promise().query(fs.readFileSync(path.join(__dirname, 'migrations', 'password-reset.sql'), 'utf8'));
  const [columns] = await db.promise().query('SHOW COLUMNS FROM password_reset_tokens');
  const required = ['token_hash', 'user_id', 'credential_hash', 'expires_at', 'used_at', 'created_at'];
  if (!required.every(name => columns.some(c => c.Field === name))) throw Error('Reset schema mismatch');
  fs.writeFileSync(path.join(__dirname, '..', 'tests', 'recovery-migration-report.json'), JSON.stringify({ passed: true, checkedAt: new Date().toISOString() }, null, 2));
  console.log('RECOVERY_MIGRATION_PASS');
})().catch(e => { console.error(e.code || e.message); process.exitCode = 1; }).finally(() => db.end());
