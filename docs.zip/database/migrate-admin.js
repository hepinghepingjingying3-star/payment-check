// ============================================
// 26牛牛 - 管理后台增量迁移（安全、可重复执行）
// 新增:
//   - announcements.created_by  （公告创建人，便于审计）
//   - real_name_reviews 表      （实名认证审核，阶段 8.5）
// 说明:
//   - 只做 ADD COLUMN / CREATE TABLE IF NOT EXISTS，绝不 DROP、绝不改动已有数据
//   - 重复执行安全（先查 information_schema）
// 运行: node database/migrate-admin.js
// ============================================

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const TABLES = [
  {
    name: 'real_name_reviews',
    sql: `CREATE TABLE IF NOT EXISTS real_name_reviews (
      id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '审核ID',
      user_id      INT UNSIGNED NOT NULL COMMENT '用户ID（一个账号只能有一条）',
      real_name    VARCHAR(50) NOT NULL COMMENT '提交的实名姓名',
      status       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending' COMMENT '审核状态',
      remark       VARCHAR(255) NULL COMMENT '审核备注（拒绝原因）',
      reviewed_by  INT UNSIGNED NULL COMMENT '审核管理员ID',
      reviewed_at  DATETIME NULL COMMENT '审核时间',
      created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
      updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      UNIQUE KEY uk_user (user_id),
      INDEX idx_status (status, created_at),
      INDEX idx_real_name (real_name, status),
      CONSTRAINT fk_rnr_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='实名认证审核表'`
  }
];

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
  const report = { added: [], tables: [], passed: false };
  try {
    const [cols] = await conn.query(
      `SELECT COLUMN_NAME FROM information_schema.columns
       WHERE table_schema = ? AND table_name = 'announcements' AND column_name = 'created_by'`,
      [process.env.DB_NAME]
    );
    if (cols.length === 0) {
      await conn.query(
        `ALTER TABLE announcements
           ADD COLUMN created_by INT UNSIGNED NULL COMMENT '创建公告的管理员ID' AFTER status,
           ADD INDEX idx_created_by (created_by)`
      );
      report.added.push('announcements.created_by');
    }
    for (const t of TABLES) {
      await conn.query(t.sql);
      report.tables.push(t.name);
    }
    const [check] = await conn.query(
      `SELECT COLUMN_NAME FROM information_schema.columns
       WHERE table_schema = ? AND table_name = 'announcements' AND column_name = 'created_by'`,
      [process.env.DB_NAME]
    );
    const [rt] = await conn.query(
      `SELECT TABLE_NAME FROM information_schema.tables
       WHERE table_schema = ? AND table_name = 'real_name_reviews'`, [process.env.DB_NAME]
    );
    report.passed = check.length === 1 && rt.length === 1;
  } finally {
    await conn.end();
  }
  fs.writeFileSync(path.join(__dirname, '..', 'tests', 'admin-migration-report.json'),
    JSON.stringify(Object.assign(report, { finished: new Date().toISOString() }), null, 2));
  console.log(report.passed ? 'ADMIN_MIGRATION_PASS' : 'ADMIN_MIGRATION_FAIL');
  process.exitCode = report.passed ? 0 : 1;
}

main().catch(e => { console.error(e.code || e.message); process.exitCode = 1; });