const fs = require('fs');
const out = [];
function section(name, fn) {
  out.push('=====' + name + '=====');
  try { out.push(fn()); } catch (e) { out.push('ERR: ' + e.message); }
}
function dump(f, a, b) {
  const L = fs.readFileSync(f, 'utf8').split('\n');
  return L.slice((a || 1) - 1, b || L.length).map((l, i) => (a + i) + '| ' + l).join('\n');
}

section('MIGRATION 003-chat.js', () => fs.readFileSync('database/migrations/003-chat.js', 'utf8'));
section('RATE LIMIT FULL', () => fs.readFileSync('utils/rateLimit.js', 'utf8'));
section('AUTH MIDDLEWARE', () => fs.readFileSync('middleware/auth.js', 'utf8'));
section('ADMIN OTP HEAD 1-80', () => dump('routes/admin-otp.js', 1, 80));
section('SERVER MOUNTS', () => {
  const L = fs.readFileSync('server.js', 'utf8').split('\n');
  return L.filter(l => /app\.use|require\(\.\/routes/.test(l)).join('\n');
});
section('ADMIN AUDIT EXPORTS', () => {
  const s = fs.readFileSync('utils/adminAudit.js', 'utf8');
  const i = s.indexOf('async function writeAdminLog');
  return s.slice(i, i + 900);
});
section('ADMIN.HTML SUPPORT TAB', () => {
  const s = fs.readFileSync('public/admin.html', 'utf8');
  const i = s.indexOf('data-tab="support"');
  return i < 0 ? 'NO TAB data-tab=support' : s.slice(i - 200, i + 1500);
});
section('ADMIN-PAGE.JS SUPPORT SECTION', () => {
  const s = fs.readFileSync('public/js/admin-page.js', 'utf8');
  const i = s.indexOf('support');
  const j = s.indexOf("function loadSupport");
  return 'first support idx=' + i + ' loadSupport idx=' + j + '\n' + (j >= 0 ? s.slice(j, j + 3000) : s.slice(Math.max(0, i - 100), i + 1200));
});
section('APP-COMMON API SURFACE', () => {
  const s = fs.readFileSync('public/js/app-common.js', 'utf8');
  const names = ['App.api', 'App.getUser', 'App.requireLogin', 'App.toast', 'App.escapeHtml', 'App.fmtTime', 'App.fmtDateTime', 'App.openSheet', 'App.openFormSheet', 'App.confirm', 'App.mountNav', 'App.token', 'App.saveToken', 'App.clearToken'];
  return names.map(n => {
    const k = n.split('.')[1];
    const m = s.match(new RegExp(k + '\\s*[:=]\\s*(async )?function[^{]*\\{'));
    return m ? n + ' -> ' + m[0] : n + ' -> NOT FOUND';
  }).join('\n');
});
section('CHAT-PAGE.JS INIT 1-90', () => dump('public/js/chat-page.js', 1, 90));

fs.writeFileSync('_ga_out2.txt', out.join('\n'), 'utf8');
console.log('WROTE _ga_out2.txt bytes=' + fs.statSync('_ga_out2.txt').size);

