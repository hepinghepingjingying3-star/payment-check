const fs = require('fs');
const O = [];
const P = (s) => O.push(s);

function grab(f, from, count, tag) {
  try {
    const L = fs.readFileSync(f, 'utf8').split(/\r?\n/);
    P('\n##### FILE ' + f + ' [' + from + ' +' + count + '] ' + (tag || ''));
    for (let i = from; i <= Math.min(L.length, from + count - 1); i++) P(i + ': ' + L[i - 1]);
  } catch (e) { P('ERR ' + f + ': ' + e.message); }
}
function sec(f, needle, n) {
  const L = fs.readFileSync(f, 'utf8').split(/\r?\n/);
  for (let i = 0; i < L.length; i++) {
    if (L[i].includes(needle)) {
      P('\n##### ' + f + ' @' + (i + 1) + ' ~ ' + needle);
      for (let j = i; j < Math.min(L.length, i + n); j++) P((j + 1) + ': ' + L[j]);
      return;
    }
  }
  P('MISS "' + needle + '" in ' + f);
}
function grep(f, needles, ctx) {
  try {
    const L = fs.readFileSync(f, 'utf8').split(/\r?\n/);
    L.forEach((l, i) => {
      for (const nd of needles) {
        if (l.includes(nd)) {
          P('\n## ' + f + ':' + (i + 1) + ' :: ' + l.trim());
          for (let j = Math.max(1, i + 1 - (ctx || 0)); j <= Math.min(L.length, i + 1 + (ctx || 0)); j++) P(j + ': ' + L[j - 1]);
          break;
        }
      }
    });
  } catch (e) { P('ERR ' + f + ': ' + e.message); }
}

(async () => {
  require('dotenv').config();
  const mysql = require('mysql2/promise');
  try {
    const c = await mysql.createConnection({
      host: process.env.DB_HOST, port: +(process.env.DB_PORT || 3306),
      user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME
    });
    for (const t of ['chat_messages', 'support_threads', 'notifications']) {
      try {
        const [r] = await c.query('SHOW COLUMNS FROM `' + t + '`');
        P('\nTABLE ' + t + ' :: ' + r.map(x => x.Field + '|' + x.Type + '|' + (x.Null === 'NO' ? 'NN' : 'NULL') + (x.Key ? '|K:' + x.Key : '')).join('  '));
      } catch (e) { P('\nTABLE ' + t + ' :: ERR ' + e.code); }
    }
    try {
      const [cnt] = await c.query("SELECT COUNT(*) n FROM chat_messages WHERE channel='support'");
      P('SUPPORT_MSG_COUNT=' + cnt[0].n);
    } catch (e) { P('SUPPORT_MSG_COUNT ERR ' + e.code); }
    await c.end();
  } catch (e) { P('DBERR ' + e.message); }

  const cl = fs.readFileSync('routes/chat.js', 'utf8').split(/\r?\n/);
  cl.forEach((l, i) => { if (/router\.(get|post|delete|put)\(/.test(l)) P('ROUTELINE ' + (i + 1) + ': ' + l.trim()); });

  sec('routes/chat.js', "router.get('/messages'", 240);
  sec('routes/chat.js', "router.post('/messages'", 150);
  sec('routes/chat.js', "router.post('/system'", 120);
  sec('routes/chat.js', "router.get('/channels'", 70);

  grab('utils/rateLimit.js', 1, 150);
  grab('utils/adminAudit.js', 1, 95);
  grab('database/migrations/_helper.js', 1, 150);
  grab('middleware/auth.js', 1, 150);
  grab('routes/admin-otp.js', 1, 75);
  grab('middleware/admin-boundary.js', 1, 110);
  grab('server.js', 95, 115);

  grab('public/support-chat.html', 1, 240);
  sec('public/admin.html', 'data-tab="support"', 90);
  sec('public/js/admin-page.js', 'renderSupport', 160);
  grep('public/js/admin-page.js', ['quickRepl', '快捷回复'], 4);
  grep('public/js/app-common.js', ['getToken', 'requireLogin', 'openFormSheet', 'function api', 'escapeHtml', 'fmtTime', 'function toast', 'openSheet'], 2);

  grab('tests/moderation-redpacket-live.js', 1, 150);
  grab('database/migrations/007-chat-redpacket.js', 1, 70);

  fs.writeFileSync('_dump2.txt', O.join('\n'));
  console.log('DUMP_OK lines=' + O.length);
})().catch(e => { console.error('DUMP_FAIL ' + e.stack); process.exit(1); });
