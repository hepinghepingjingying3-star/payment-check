'use strict';
// 已停用的一次性运维脚本：原账号恢复辅助系统已整体删除。
// 保留文件仅为避免历史引用报错，不再执行任何数据库变更。
async function main() {
  throw new Error('该脚本已停用：相关系统已删除，请使用人工客服身份核验流程。');
}
main().catch(e => { console.error(e.message); process.exitCode = 1; });
