// ============================================
// 26牛牛 - 补发邀请码（安全增量，绝不删除 / 修改其它字段）
// ============================================
// 运行方式: node database/backfill-invite-codes.js
// 背景:
//   - 邀请码是推广系统的唯一标识，注册流程会写入（见 utils/inviteCode.js）
//   - 早期创建的账号（早于邀请码功能）invite_code 为 NULL，无法分享邀请链接
// 本脚本只做一件事:
//   - 为 invite_code 为空的历史账号补一个 8 位安全随机邀请码（与现有码不重复）
// 不做:
//   - 不修改已有邀请码、不改动任何用户资料、不删除任何数据、不改余额
//   - 不改变 invited_by / referral_relations 已锁定的邀请关系
// ============================================

require('dotenv').config();
const db = require('../config/db');
const { generateUniqueInviteCode } = require('../utils/inviteCode');

(async () => {
  const conn = db.promise();
  try {
    const [rows] = await conn.query(
      "SELECT id, username FROM users WHERE invite_code IS NULL OR invite_code = '' ORDER BY id"
    );
    if (rows.length === 0) {
      console.log('无需补发：所有账号都已有邀请码');
      return;
    }
    let done = 0;
    for (const u of rows) {
      const code = await generateUniqueInviteCode((sql, params) => conn.query(sql, params));
      await conn.query('UPDATE users SET invite_code = ? WHERE id = ? AND (invite_code IS NULL OR invite_code = \'\')', [code, u.id]);
      done++;
      console.log('  ✓ UID ' + u.id + '（' + u.username + '）补发邀请码');
    }
    console.log('\n补发完成：' + done + ' 个账号（未改动其它任何字段）');
  } catch (err) {
    console.error('补发邀请码失败:', err.message);
    process.exitCode = 1;
  } finally {
    await conn.end();
  }
})();
