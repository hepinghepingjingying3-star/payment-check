// ============================================
// 26牛牛 - 数据库初始化脚本
// 运行方式: node database/setup.js
// 作用: 读取 schema.sql 并执行，创建数据库和 users 表
// ============================================

// 加载环境变量（读取 .env 文件中的数据库配置）
require('dotenv').config();

// 引入 mysql2 库
const mysql = require('mysql2');

// 引入文件系统模块（用于读取 schema.sql 文件）
const fs = require('fs');
const path = require('path');

// 创建数据库连接（注意：这里不指定 database，因为数据库可能还不存在）
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  multipleStatements: true // 允许一次执行多条 SQL 语句
});

// 读取 schema.sql 文件内容
const schemaPath = path.join(__dirname, 'schema.sql');
const schemaSQL = fs.readFileSync(schemaPath, 'utf8');

console.log('📦 正在初始化 26牛牛 数据库...');

// 执行 SQL 语句
connection.query(schemaSQL, (err, results) => {
  if (err) {
    console.error('❌ 数据库初始化失败:', err.message);
    console.error('   请检查 .env 文件中的数据库配置是否正确');
    console.error('   并确认 MySQL 服务已启动');
    connection.end();
    process.exit(1);
  }

  console.log('✅ 数据库 26niuniu 创建成功（或已存在）');
  console.log('✅ users 表创建成功（或已存在）');

  // 验证 users 表是否存在
  connection.query(
    'SELECT COUNT(*) AS table_count FROM information_schema.tables WHERE table_schema = ? AND table_name = ?',
    [process.env.DB_NAME, 'users'],
    (verifyErr, verifyResults) => {
      if (verifyErr) {
        console.error('❌ 验证 users 表失败:', verifyErr.message);
        connection.end();
        process.exit(1);
      }

      if (verifyResults[0].table_count > 0) {
        console.log('✅ 验证通过: users 表已存在于数据库 26niuniu 中');
      } else {
        console.error('❌ 验证失败: users 表不存在');
        connection.end();
        process.exit(1);
      }

      // 查看 users 表结构
      connection.query(
        'DESCRIBE `26niuniu`.users',
        (descErr, descResults) => {
          if (descErr) {
            console.error('❌ 查看 users 表结构失败:', descErr.message);
            connection.end();
            process.exit(1);
          }

          console.log('\n📋 users 表结构:');
          console.log('----------------------------------------');
          console.log('字段名          | 类型            | 说明');
          console.log('----------------------------------------');
          descResults.forEach((col) => {
            console.log(
              `${col.Field.padEnd(15)} | ${col.Type.padEnd(15)} | ${col.Comment || ''}`
            );
          });
          console.log('----------------------------------------');

          console.log('\n🎉 Phase 2 数据库初始化完成！');
          connection.end();
        }
      );
    }
  );
});