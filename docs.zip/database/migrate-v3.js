// ============================================
// 26牛牛 - V3 数据库迁移（安全增量 · 不删除任何数据）
// ============================================
// 运行方式: node database/migrate-v3.js
//
// 本脚本只做「新增」：
//   1. users 补充 invite_code / invited_by（已存在则复用）
//   2. 新建 referral_relations（邀请关系，支持一级/二级）
//   3. 新建 wallet_orders（充值/提现订单）
//   4. 新建 chat_messages / chat_read_state / chat_reports / user_stickers
//   5. 新建 system_notices（系统公告）
//   6. 为缺少邀请码的已有用户生成随机邀请码
//
// 禁止: DROP DATABASE / DROP TABLE / DELETE FROM users
// ============================================

require('dotenv').config();
const mysql = require('mysql2');
const { generateUniqueInviteCode } = require('../utils/inviteCode');

const conn = mysql.createConnection({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  multipleStatements: true
});

// ---------- 工具：列是否存在 ----------
async function hasColumn(table, column) {
  const [rows] = await conn.promise().query(
    `SELECT COLUMN_NAME FROM information_schema.columns
     WHERE table_schema = ? AND table_name = ? AND column_name = ?`,
    [process.env.DB_NAME, table, column]
  );
  return rows.length > 0;
}

// ---------- 工具：安全新增列 ----------
async function addColumn(table, column, definition) {
  if (await hasColumn(table, column)) {
    console.log(`  · ${table}.${column} 已存在，跳过`);
    return;
  }
  await conn.promise().query(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  console.log(`  ✓ 已新增 ${table}.${column}`);
}

// ---------- 工具：安全新增索引 ----------
async function addIndex(table, indexName, definition) {
  const [rows] = await conn.promise().query(
    `SELECT INDEX_NAME FROM information_schema.statistics
     WHERE table_schema = ? AND table_name = ? AND index_name = ?`,
    [process.env.DB_NAME, table, indexName]
  );
  if (rows.length > 0) { console.log(`  · ${table}.${indexName} 已存在，跳过`); return; }
  await conn.promise().query(`ALTER TABLE ${table} ADD ${definition}`);
  console.log(`  ✓ 已新增索引 ${table}.${indexName}`);
}

// ---------- 待创建的数据表 ----------
const TABLES = [
  {
    name: 'referral_relations',
    sql: `CREATE TABLE IF NOT EXISTS referral_relations (
      id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '关系ID',
      referrer_id      INT UNSIGNED NOT NULL COMMENT '邀请人用户ID',
      referred_user_id INT UNSIGNED NOT NULL COMMENT '被邀请人用户ID',
      level            TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '邀请层级: 1=直属, 2=二级',
      status           ENUM('active','invalid') NOT NULL DEFAULT 'active' COMMENT '关系状态',
      created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立时间',
      UNIQUE KEY uk_referred_level (referred_user_id, level),
      INDEX idx_referrer (referrer_id),
      INDEX idx_referrer_level (referrer_id, level),
      CONSTRAINT fk_rr_referrer FOREIGN KEY (referrer_id) REFERENCES users(id),
      CONSTRAINT fk_rr_referred FOREIGN KEY (referred_user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邀请关系表'`
  },
  {
    name: 'wallet_orders',
    sql: `CREATE TABLE IF NOT EXISTS wallet_orders (
      id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '订单ID',
      order_no      VARCHAR(32) NOT NULL UNIQUE COMMENT '订单号',
      user_id       INT UNSIGNED NOT NULL COMMENT '用户ID',
      order_type    ENUM('DEPOSIT','WITHDRAW') NOT NULL COMMENT '订单类型',
      currency_type ENUM('GAME_BALANCE','CASH_CHIPS') NOT NULL DEFAULT 'CASH_CHIPS' COMMENT '资产类型',
      amount        DECIMAL(20,2) NOT NULL COMMENT '金额',
      method        VARCHAR(40) NOT NULL COMMENT '支付/收款方式',
      account       VARCHAR(120) NULL COMMENT '收款账户（提现时）',
      status        ENUM('PENDING','PROCESSING','COMPLETED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING' COMMENT '订单状态',
      remark        VARCHAR(255) NULL COMMENT '备注',
      created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      INDEX idx_user (user_id),
      INDEX idx_user_type (user_id, order_type),
      INDEX idx_status (status),
      CONSTRAINT fk_wo_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='钱包订单表（充值/提现）'`
  },
  {
    name: 'chat_messages',
    sql: `CREATE TABLE IF NOT EXISTS chat_messages (
      id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '消息ID',
      channel      VARCHAR(40) NOT NULL COMMENT '频道: group=26牛牛游戏群, support=在线客服',
      user_id      INT UNSIGNED NULL COMMENT '发送者用户ID（系统消息为NULL）',
      message_type ENUM('text','image','sticker','system','game') NOT NULL DEFAULT 'text' COMMENT '消息类型',
      content      TEXT NOT NULL COMMENT '消息内容',
      meta         JSON NULL COMMENT '附加数据（如贴图地址）',
      is_recalled  TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否已撤回',
      created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
      INDEX idx_channel_id (channel, id),
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='聊天消息表'`
  },
  {
    name: 'chat_read_state',
    sql: `CREATE TABLE IF NOT EXISTS chat_read_state (
      user_id      INT UNSIGNED NOT NULL COMMENT '用户ID',
      channel      VARCHAR(40)  NOT NULL COMMENT '频道',
      last_read_id BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '已读到的最后消息ID',
      updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (user_id, channel),
      CONSTRAINT fk_crs_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='聊天已读状态表'`
  },
  {
    name: 'chat_reports',
    sql: `CREATE TABLE IF NOT EXISTS chat_reports (
      id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '举报ID',
      reporter_id   INT UNSIGNED NOT NULL COMMENT '举报人用户ID',
      message_id    BIGINT UNSIGNED NOT NULL COMMENT '被举报消息ID',
      reason        VARCHAR(255) NOT NULL COMMENT '举报原因',
      status        ENUM('pending','resolved') NOT NULL DEFAULT 'pending' COMMENT '处理状态',
      created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '举报时间',
      INDEX idx_reporter (reporter_id),
      INDEX idx_message (message_id),
      CONSTRAINT fk_crep_reporter FOREIGN KEY (reporter_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='聊天消息举报表'`
  },
  {
    name: 'user_stickers',
    sql: `CREATE TABLE IF NOT EXISTS user_stickers (
      id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '贴图ID',
      user_id    INT UNSIGNED NOT NULL COMMENT '所属用户ID',
      name       VARCHAR(50) NOT NULL COMMENT '贴图名称',
      url        VARCHAR(255) NOT NULL COMMENT '贴图文件地址',
      size_bytes INT UNSIGNED NULL COMMENT '文件大小（字节）',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      INDEX idx_user (user_id),
      CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户自定义贴图表'`
  },
  {
    name: 'system_notices',
    sql: `CREATE TABLE IF NOT EXISTS system_notices (
      id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '公告ID',
      title      VARCHAR(100) NOT NULL COMMENT '公告标题',
      content    TEXT NULL COMMENT '公告内容',
      status     ENUM('active','hidden') NOT NULL DEFAULT 'active' COMMENT '状态',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
      INDEX idx_status (status, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统公告表'`
  }
];

async function main() {
  console.log('=== 26牛牛 V3 数据库迁移（安全增量，不删除任何数据） ===');
  let conn;
  try {
    conn = mysql.createConnection({
      host: process.env.DB_HOST,
      port: process.env.DB_PORT,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      multipleStatements: true
    }).promise();

    // 1. users 补充邀请码字段（幂等）
    console.log('[1/4] 检查 users 表邀请字段...');
    await addColumn('users', 'invite_code', "VARCHAR(20) NULL UNIQUE COMMENT '邀请码'");
    await addColumn('users', 'invited_by', "INT UNSIGNED NULL COMMENT '邀请人用户ID'");
    await addIndex('users', 'idx_invited_by', 'INDEX idx_invited_by (invited_by)');

    // 2. 为缺少邀请码的已有用户生成随机唯一邀请码（不删除/不修改任何现有数据）
    console.log('[2/4] 为缺少邀请码的已有用户生成邀请码...');
    const [missing] = await conn.query('SELECT id FROM users WHERE invite_code IS NULL');
    for (const u of missing) {
      const { generateUniqueInviteCode } = require('../utils/inviteCode');
      const code = await generateUniqueInviteCode((sql, params) => conn.query(sql, params));
      await conn.query('UPDATE users SET invite_code = ? WHERE id = ?', [code, u.id]);
      console.log(`  ✓ 用户 #${u.id} → ${code}`);
    }
    if (missing.length === 0) console.log('  · 所有用户均已有邀请码');

    // 3. 创建新表（IF NOT EXISTS，绝不 DROP）
    console.log('[3/4] 创建数据表...');
    for (const t of TABLES) {
      await conn.query(t.sql);
      console.log(`  ✓ ${t.name}`);
    }

    // 4. 处理已有用户的 invited_by：根据旧 migrate-promote 生成的 N+id 码无法反查关系，
    //    仅对已存在 invited_by 的用户补建一级关系（保证关系表完整）
    console.log('[4/4] 同步已有 invited_by 到 referral_relations...');
    const [withRef] = await conn.query(
      'SELECT id, invited_by FROM users WHERE invited_by IS NOT NULL'
    );
    let synced = 0;
    for (const u of withRef) {
      const [dup] = await conn.query(
        'SELECT id FROM referral_relations WHERE referred_user_id = ? AND level = 1',
        [u.id]
      );
      if (dup.length === 0 && u.invited_by !== u.id) {
        await conn.query(
          'INSERT IGNORE INTO referral_relations (referrer_id, referred_user_id, level) VALUES (?, ?, 1)',
          [u.invited_by, u.id]
        );
        synced++;
      }
    }
    console.log(`  · 同步 ${synced} 条一级关系`);

    console.log('=== 迁移完成（未删除任何数据） ===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    if (conn && conn.end) { try { await conn.end(); } catch (e) {} }
    process.exit(1);
  }
}

main();