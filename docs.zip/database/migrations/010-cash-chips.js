// ============================================
// 26牛牛 - 迁移 010：现金筹码体系
//   users 支付密码 / recharge_orders 凭证与拒绝原因 /
//   balance_transactions 引用号 / 提现申请 / 转账 / 禁言记录
// ============================================
// 原则:
//   - 只新增列 / 新增表 / 枚举扩容，绝不 DROP、绝不 DELETE 现有数据
//   - 旧字段保留；旧数据做「字段映射」（recharge_orders.currency POINTS → CASH_CHIPS）
//   - 可重复执行（幂等）
// 运行方式: node database/migrations/010-cash-chips.js
// ============================================

require('dotenv').config();
const { addColumn, addIndex, hasTable, connect } = require('./_helper');

async function addTable(conn, name, sql) {
  if (await hasTable(conn, name)) {
    console.log('  · 表 ' + name + ' 已存在，跳过');
    return false;
  }
  await conn.query(sql);
  console.log('  ✓ 新建表 ' + name);
  return true;
}

/** 枚举扩容（幂等）：只有当前定义不含目标值时才 MODIFY */
async function ensureEnum(conn, table, column, definition, mustContain) {
  const [rows] = await conn.query(
    'SELECT COLUMN_TYPE FROM information_schema.columns WHERE table_schema = ? AND table_name = ? AND column_name = ?',
    [process.env.DB_NAME, table, column]
  );
  if (!rows.length) { console.log('  ! ' + table + '.' + column + ' 不存在，跳过'); return; }
  const type = String(rows[0].COLUMN_TYPE || '');
  if (mustContain.every(v => type.indexOf("'" + v + "'") >= 0)) {
    console.log('  · ' + table + '.' + column + ' 枚举已含目标值，跳过');
    return;
  }
  await conn.query('ALTER TABLE ' + table + ' MODIFY COLUMN ' + column + ' ' + definition);
  console.log('  ✓ 扩容枚举 ' + table + '.' + column);
}

async function main() {
  const conn = connect();
  console.log('=== 010 现金筹码体系迁移（安全增量）===');
  try {
    // ---------- users：6 位支付密码 ----------
    await addColumn(conn, 'users', 'pay_password_hash',
      "VARCHAR(255) NULL COMMENT '6位支付密码的 bcrypt 哈希（绝不存明文）' AFTER password_hash");
    await addColumn(conn, 'users', 'pay_password_set_at',
      "DATETIME NULL COMMENT '支付密码设置时间'");

    // ---------- recharge_orders：凭证 / 备注 / 拒绝原因 / updated_at ----------
    await addColumn(conn, 'recharge_orders', 'receipt_path',
      "VARCHAR(255) NULL COMMENT '充值凭证在 storage/vouchers 下的相对路径（非公开目录）'");
    await addColumn(conn, 'recharge_orders', 'remark',
      "VARCHAR(255) NULL COMMENT '用户提交订单时的备注'");
    await addColumn(conn, 'recharge_orders', 'reject_reason',
      "VARCHAR(255) NULL COMMENT '管理员拒绝原因（必填，写入审计）'");
    await addColumn(conn, 'recharge_orders', 'updated_at',
      "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'");
    await addColumn(conn, 'recharge_orders', 'submitted_at',
      "DATETIME NULL COMMENT '用户提交凭证时间'");

    // ---------- recharge_orders：状态枚举扩容（新增 REJECTED）----------
    await ensureEnum(conn, 'recharge_orders', 'status',
      "ENUM('PENDING','COMPLETED','REJECTED','CANCELLED','EXPIRED') NOT NULL DEFAULT 'PENDING' COMMENT '订单状态'",
      ['REJECTED']);

    // ---------- recharge_orders：旧字段映射（POINTS → CASH_CHIPS，不删数据）----------
    const [mapRes] = await conn.query(
      "UPDATE recharge_orders SET currency = 'CASH_CHIPS' WHERE currency IS NULL OR currency <> 'CASH_CHIPS'");
    console.log('  ✓ 字段映射 recharge_orders.currency → CASH_CHIPS（影响 ' + (mapRes.affectedRows || 0) + ' 行）');

    // ---------- balance_transactions：字符串引用号 ----------
    await addColumn(conn, 'balance_transactions', 'reference_no',
      "VARCHAR(64) NULL COMMENT '业务引用号（充值订单号 / 转账号 / 提现单号）' AFTER reason");
    await addIndex(conn, 'balance_transactions', 'idx_reference_no', 'INDEX idx_reference_no (reference_no)');

    await createTables(conn);

    console.log('=== 010 完成（未删除任何数据）===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

/** 新增表（提现申请 / 转账记录 / 禁言记录） */
async function createTables(conn) {
  await addTable(conn, 'withdraw_requests', `CREATE TABLE IF NOT EXISTS withdraw_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '申请ID',
    order_id VARCHAR(40) NOT NULL UNIQUE COMMENT '唯一提现单号',
    user_id INT UNSIGNED NOT NULL COMMENT '用户ID',
    amount DECIMAL(20,2) NOT NULL COMMENT '提现数量（现金筹码）',
    currency VARCHAR(20) NOT NULL DEFAULT 'CASH_CHIPS' COMMENT '资产类型',
    account_type VARCHAR(40) NOT NULL COMMENT '账户类型（BANK/TNG/DUITNOW/OTHER）',
    account_name VARCHAR(60) NULL COMMENT '账户姓名',
    account_ref VARCHAR(120) NOT NULL COMMENT '收款账号 / 参考',
    status ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING' COMMENT '申请状态',
    remark VARCHAR(255) NULL COMMENT '用户备注',
    reject_reason VARCHAR(255) NULL COMMENT '管理员拒绝原因（必填）',
    operator_id INT UNSIGNED NULL COMMENT '审核管理员ID',
    completed_at DATETIME NULL COMMENT '审核完成时间',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_user (user_id, created_at),
    INDEX idx_status (status, created_at),
    CONSTRAINT fk_withdraw_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_withdraw_operator FOREIGN KEY (operator_id) REFERENCES users(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='现金筹码提现申请（本阶段不执行真实出款）'`);

  await addTable(conn, 'cash_transfers', `CREATE TABLE IF NOT EXISTS cash_transfers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '转账ID',
    transfer_no VARCHAR(40) NOT NULL UNIQUE COMMENT '唯一转账单号（transaction_id）',
    from_user_id INT UNSIGNED NOT NULL COMMENT '发送方',
    to_user_id INT UNSIGNED NOT NULL COMMENT '接收方',
    amount DECIMAL(20,2) NOT NULL COMMENT '转账数量（现金筹码）',
    currency VARCHAR(20) NOT NULL DEFAULT 'CASH_CHIPS' COMMENT '资产类型',
    remark VARCHAR(120) NULL COMMENT '备注',
    idempotency_key VARCHAR(64) NOT NULL UNIQUE COMMENT '幂等键（防重复提交）',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '转账时间',
    INDEX idx_from (from_user_id, created_at),
    INDEX idx_to (to_user_id, created_at),
    CONSTRAINT fk_transfer_from FOREIGN KEY (from_user_id) REFERENCES users(id),
    CONSTRAINT fk_transfer_to FOREIGN KEY (to_user_id) REFERENCES users(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='现金筹码用户间转账记录'`);

  await addTable(conn, 'moderation_actions', `CREATE TABLE IF NOT EXISTS moderation_actions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
    scope ENUM('GROUP','USER') NOT NULL COMMENT '范围: GROUP=全体禁言, USER=单独禁言',
    target_user_id INT UNSIGNED NULL COMMENT '被禁言用户（GROUP 时为 NULL）',
    operator_id INT UNSIGNED NOT NULL COMMENT '操作管理员',
    action ENUM('MUTE','UNMUTE') NOT NULL COMMENT '动作',
    reason VARCHAR(255) NOT NULL COMMENT '原因（必填）',
    status ENUM('ACTIVE','ENDED') NOT NULL DEFAULT 'ACTIVE' COMMENT '状态',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    ended_at DATETIME NULL COMMENT '解除时间',
    ended_by INT UNSIGNED NULL COMMENT '解除人',
    INDEX idx_scope_status (scope, status),
    INDEX idx_target (target_user_id, status),
    CONSTRAINT fk_modop_operator FOREIGN KEY (operator_id) REFERENCES users(id),
    CONSTRAINT fk_modop_target FOREIGN KEY (target_user_id) REFERENCES users(id),
    CONSTRAINT fk_modop_ended_by FOREIGN KEY (ended_by) REFERENCES users(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='聊天禁言记录（全体/单独）'`);
}

main();

