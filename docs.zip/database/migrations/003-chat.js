// ============================================
// 26牛牛 - 聊天扩展迁移（003）
// 说明:
//   - chat_messages.message_type 已支持 text/image/sticker/system/game，
//     本迁移只做「检查 + 补齐 + 索引」，绝不重建表、绝不删除消息
//   - 补充频道权限所需的复合索引，保证分页查询性能
// 运行方式: node database/migrations/003-chat.js
// ============================================

require('dotenv').config();
const { hasColumn, addColumn, addIndex, connect } = require('./_helper');

async function main() {
  const conn = connect();
  console.log('=== 003 聊天扩展迁移（安全增量）===');
  try {
    // chat_messages 表必须存在（由 V3 迁移创建）
    const [rows] = await conn.query(
      `SELECT COLUMN_TYPE FROM information_schema.columns
       WHERE table_schema = ? AND table_name = 'chat_messages' AND column_name = 'message_type'`,
      [process.env.DB_NAME]
    );
    if (rows.length === 0) {
      throw new Error('chat_messages.message_type 不存在，请先运行 database/migrate-v3.js');
    }
    console.log('  · message_type 当前定义: ' + rows[0].COLUMN_TYPE);

    // ---- 绝不做「收窄」：只把缺失的类型补进去，现有值一个都不许丢----
    // 旧写法是直接 MODIFY 成 5 个值，那在库已经存在 'redpacket' 数据时（007 扩展过）
    // 会抛 Data truncated 并中止整条迁移链，新服务器部署直接失败。
    // 现在改为：把当前枚举里已有的值与本迁移需要的值取并集后重建。
    const REQUIRED = ['text', 'image', 'sticker', 'system', 'game'];
    const current = String(rows[0].COLUMN_TYPE || '');
    const curList = current.replace(/^enum\(/i, '').replace(/\)$/, '')
      .split(',').map(s => s.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean);
    const merged = curList.slice();
    REQUIRED.forEach(t => { if (merged.indexOf(t) < 0) merged.push(t); });
    const target = 'enum(' + merged.map(t => "'" + t.replace(/'/g, "''") + "'").join(',') + ')';

    if (current.replace(/\s+/g, '').toLowerCase() !== target.replace(/\s+/g, '').toLowerCase()) {
      await conn.query(
        `ALTER TABLE chat_messages MODIFY COLUMN message_type
         ${target} NOT NULL DEFAULT 'text' COMMENT '消息类型'`
      );
      console.log('  ✓ message_type 已扩展为: ' + merged.join('/') + '（保留已有取值，不收窄）');
    } else {
      console.log('  · message_type 已是最新定义，跳过');
    }

    // 幂等补充列 / 索引
    await addColumn(conn, 'chat_messages', 'meta', 'JSON NULL COMMENT \'附加数据（贴图地址/游戏阶段等）\'');
    await addIndex(conn, 'chat_messages', 'idx_channel_id', 'INDEX idx_channel_id (channel, id)');

    // 用户贴图表字段补齐（mime_type 供上传校验展示）
    await addColumn(conn, 'user_stickers', 'mime_type', "VARCHAR(60) NULL COMMENT '文件MIME类型'");
    console.log('=== 003 完成 ===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

main();