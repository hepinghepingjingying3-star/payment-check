// ============================================
// 26牛牛 - 迁移 026：游戏机器人状态 + 阶段截止时间 + 活动局唯一闸门
// ============================================
// 原则（与 025 一致）：
//   - 纯增量：只 CREATE TABLE IF NOT EXISTS / ADD COLUMN / ADD UNIQUE KEY
//   - 不 DROP、不 DELETE、不改写任何既有用户 / 聊天 / 对局数据
//   - 可重复执行（幂等）
//
// 为什么需要：
//   1) niu_bot_state —— 机器人「运行 / 停止」状态必须持久化在后端，
//      管理员网页关掉、浏览器刷新、服务器重启都不能影响游戏是否推进。
//   2) game_rounds.phase_ends_at —— 服务器重启后要能算出「当前阶段还剩多久」。
//   3) uq_game_rounds_active —— 数据库层保证「同一房间同一时间只有一个活动局」，
//      杜绝重复启动 / 重复点击 / 多实例部署时各建一局。
//   4) niu_bot_events —— round_id + event_type 唯一，杜绝重复话术。
// ============================================

require('dotenv').config();
const { connect, hasColumn, hasTable, addColumn, addIndex } = require('./_helper');

async function run() {
  const conn = await connect();
  try {
    // ---------- 1. 机器人状态表（单例，id 固定为 1）----------
    if (!await hasTable(conn, 'niu_bot_state')) {
      await conn.query(`
        CREATE TABLE niu_bot_state (
          id                TINYINT UNSIGNED NOT NULL PRIMARY KEY COMMENT '固定为 1，单例',
          running           TINYINT(1)      NOT NULL DEFAULT 0 COMMENT '1=机器人运行中 0=已停止',
          auto_messages     TINYINT(1)      NOT NULL DEFAULT 1 COMMENT '1=自动发送阶段提示 0=只维护状态不发话术',
          room_key          VARCHAR(20)     NOT NULL DEFAULT 'junior' COMMENT '机器人当前所在场次',
          chat_channel      VARCHAR(20)     NOT NULL DEFAULT 'group' COMMENT '机器人消息写入的聊天频道',
          current_round_id  VARCHAR(64)     NULL COMMENT '当前局对局编号（game_rounds.round_id）',
          current_round_pk  BIGINT UNSIGNED NULL COMMENT '当前局主键（game_rounds.id）',
          current_phase     VARCHAR(20)     NULL COMMENT '当前阶段 WAITING/GRABBING/BETTING 等',
          phase_ends_at     DATETIME        NULL COMMENT '当前阶段截止时间（重启恢复用）',
          started_at        DATETIME        NULL COMMENT '本次启动时间',
          stopped_at        DATETIME        NULL COMMENT '最近一次停止时间',
          started_by        INT UNSIGNED    NULL COMMENT '启动的管理员 users.id',
          updated_by        INT UNSIGNED    NULL COMMENT '最近一次操作的管理员 users.id',
          updated_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          created_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_running (running),
          INDEX idx_room (room_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛游戏机器人状态（后端权威，与管理员浏览器无关）'
      `);
      console.log('  ✓ 新增表 niu_bot_state');
    } else {
      console.log('  · niu_bot_state 已存在，跳过');
    }

    // 单例行：没有就插入一行「已停止」的初始状态（绝不覆盖既有状态）
    await conn.query('INSERT IGNORE INTO niu_bot_state (id, running, auto_messages) VALUES (1, 0, 1)');
    console.log('  · niu_bot_state 单例行已就绪');

    // ---------- 2. game_rounds 阶段时间轴 ----------
    // 现状：game_rounds 只有 created_at / updated_at，没有 started_at / ended_at / phase，
    // 服务器重启后无法算出「当前阶段还剩多久」。这里纯增量补齐（全部可空，不影响既有行）。
    if (!await hasColumn(conn, 'game_rounds', 'started_at')) {
      await addColumn(conn, 'game_rounds', 'started_at',
        'DATETIME NULL DEFAULT NULL COMMENT \'本局开始时间\' AFTER updated_at');
    }
    if (!await hasColumn(conn, 'game_rounds', 'ended_at')) {
      await addColumn(conn, 'game_rounds', 'ended_at',
        'DATETIME NULL DEFAULT NULL COMMENT \'本局结束时间\' AFTER started_at');
    }
    if (!await hasColumn(conn, 'game_rounds', 'phase')) {
      await addColumn(conn, 'game_rounds', 'phase',
        'VARCHAR(20) NULL DEFAULT NULL COMMENT \'当前阶段 WAITING/GRABBING/BETTING 等\' AFTER status');
    }
    if (!await hasColumn(conn, 'game_rounds', 'phase_ends_at')) {
      await addColumn(conn, 'game_rounds', 'phase_ends_at',
        'DATETIME NULL DEFAULT NULL COMMENT \'当前阶段截止时间（机器人重启恢复用）\' AFTER ended_at');
    }

    // ---------- 3. 活动局唯一闸门 ----------
    // MySQL 不支持「部分唯一索引」，因此用生成列把「进行中的局」标识出来，
    // 再对 active_flag 建唯一键：进行中 = room_id（同一房间只允许一个），
    // 已结束 = NULL（MySQL 唯一索引忽略 NULL，因此历史局互不冲突）
    if (!await hasColumn(conn, 'game_rounds', 'active_flag')) {
      await addColumn(conn, 'game_rounds', 'active_flag',
        'INT UNSIGNED GENERATED ALWAYS AS (CASE WHEN packet_type = \'PLATFORM\' AND status NOT IN (\'FINISHED\',\'ENDED\',\'ABORTED\') THEN room_id ELSE NULL END) STORED COMMENT \'进行中局的唯一闸门（NULL 不参与唯一约束）\'');
    }
    await addIndex(conn, 'game_rounds', 'uq_game_rounds_active',
      'UNIQUE KEY uq_game_rounds_active (active_flag)');

    // ---------- 4. 机器人事件幂等表 ----------
    // round_id + event_type 唯一 → 「开始抢庄」永远只发一条，
    // 服务器重启 / 重复启动 / 重复请求都不会在群里刷出多条相同话术
    if (!await hasTable(conn, 'niu_bot_events')) {
      await conn.query(`
        CREATE TABLE niu_bot_events (
          id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
          round_id     VARCHAR(64)    NOT NULL COMMENT '对局编号 game_rounds.round_id（无局时用 bot:global）',
          event_type   VARCHAR(40)    NOT NULL COMMENT 'round_start/grab_start/grab_end/bet_start/deal/result/round_end/next_round',
          room_id      INT UNSIGNED   NULL,
          phase        VARCHAR(20)    NULL,
          created_at   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uq_bot_event (round_id, event_type),
          INDEX idx_round (round_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛机器人事件幂等表（防重复消息）'
      `);
      console.log('  ✓ 新增表 niu_bot_events');
    } else {
      console.log('  · niu_bot_events 已存在，跳过');
    }

    console.log('✅ 迁移 026 完成（机器人状态 + 阶段时间轴 + 活动局闸门 + 事件幂等）');
  } finally {
    await conn.end();
  }
}

module.exports = { run };

if (require.main === module) {
  run().catch(err => {
    console.error('❌ 迁移 026 失败:', err.message);
    process.exit(1);
  });
}