'use strict';
// ============================================
// 26牛牛 - 025 游戏核心回归「26牛牛游戏群」（复用现有游戏表，不新建第二套）
// ============================================
// 目标:
//   1) game_rooms  : 场次落到现有表（room_key 唯一），chat_channel='group' 表示游戏消息发在游戏群
//   2) game_rounds : status 枚举追加 26牛牛阶段（GRABBING/DEALING/RESULT/FINISHED/ABORTED），
//                    完整保留旧枚举值（旧红包对战历史照常可读）；追加 room_key/base_stake/
//                    player_count/chat_channel；round_id 升级为唯一（结算幂等闸门）
//   3) game_results: 补齐游戏积分结算字段 + UNIQUE(round_id,user_id)（防重复结算）
//   4) room_players: 直接作为「座位表」复用（追加 bet_level / grab_flag）
//   5) chat_messages: 追加 room_id / round_id / phase / game_round_pk，
//                    使「游戏系统消息」能关联到具体房间与具体一局
// 边界: 全部安全增量，无 DROP / 无 DELETE / 不改任何历史数据；可重复执行。
// ============================================

require('dotenv').config();

const { addColumn, addIndex, connect } = require('./_helper');

/** 追加 game_rounds.status 枚举值（保留现有全部取值与列属性） */
async function ensureRoundStatusEnum(conn) {
  const ADD = ['GRABBING', 'DEALING', 'RESULT', 'FINISHED', 'ABORTED'];
  const [rows] = await conn.query(
    `SELECT COLUMN_TYPE AS ty, IS_NULLABLE AS nl, COLUMN_DEFAULT AS df
     FROM information_schema.columns
     WHERE table_schema = ? AND table_name = 'game_rounds' AND column_name = 'status'`,
    [process.env.DB_NAME]
  );
  if (!rows.length) { console.log('  · game_rounds.status 不存在，跳过'); return false; }
  const cur = String(rows[0].ty || '');
  const missing = ADD.filter(v => cur.indexOf("'" + v + "'") === -1);
  if (!missing.length) { console.log('  · game_rounds.status 已含全部 26牛牛阶段，跳过'); return false; }
  const head = cur.match(/^enum\((.*)\)$/i);
  if (!head) { console.log('  · game_rounds.status 不是枚举，跳过: ' + cur); return false; }
  const next = head[1] + ',' + missing.map(v => "'" + v + "'").join(',');
  const nullable = String(rows[0].nl).toUpperCase() === 'YES' ? 'NULL' : 'NOT NULL';
  const dv = rows[0].df;
  const def = dv === null
    ? (nullable === 'NULL' ? '' : ' DEFAULT NULL')
    : " DEFAULT '" + String(dv).replace(/'/g, "''") + "'";
  await conn.query('ALTER TABLE game_rounds MODIFY status ENUM(' + next + ') ' + nullable + def);
  console.log('  ✓ game_rounds.status 追加阶段: ' + missing.join(',') + '（旧值全部保留）');
  return true;
}

/** game_rounds.round_id 升级为唯一索引（结算幂等闸门，不动数据） */
async function ensureRoundIdUnique(conn) {
  const [rows] = await conn.query(
    `SELECT index_name FROM information_schema.statistics
     WHERE table_schema = ? AND table_name = 'game_rounds' AND non_unique = 0 AND column_name = 'round_id'`,
    [process.env.DB_NAME]
  );
  if (rows.length) { console.log('  · game_rounds.round_id 已是唯一索引，跳过'); return false; }
  const [dup] = await conn.query('SELECT round_id, COUNT(*) c FROM game_rounds GROUP BY round_id HAVING c > 1 LIMIT 5');
  if (dup.length) {
    console.log('  ! game_rounds 存在重复 round_id（' + dup.length + ' 组），跳过唯一索引以免改数据');
    return false;
  }
  await conn.query('ALTER TABLE game_rounds ADD UNIQUE KEY uq_game_round_id (round_id)');
  console.log('  ✓ game_rounds 追加 UNIQUE(round_id)');
  return true;
}

async function ensureRoundColumns(conn) {
  await addColumn(conn, 'game_rounds', 'room_key',
    "VARCHAR(20) NULL COMMENT '26牛牛场次标识（红包对战为空）' AFTER room_id");
  await addColumn(conn, 'game_rounds', 'base_stake',
    "DECIMAL(20,2) NULL COMMENT '底分（游戏积分）' AFTER room_key");
  await addColumn(conn, 'game_rounds', 'player_count',
    "INT NOT NULL DEFAULT 0 COMMENT '参与人数（含庄家）' AFTER base_stake");
  await addColumn(conn, 'game_rounds', 'chat_channel',
    "VARCHAR(40) NULL COMMENT '游戏消息所在聊天频道（26牛牛为 group）' AFTER player_count");
}

async function ensureResultColumns(conn) {
  await addColumn(conn, 'game_results', 'seat_no',
    "INT NOT NULL DEFAULT 0 COMMENT '座位号' AFTER role");
  await addColumn(conn, 'game_results', 'grab_flag',
    "TINYINT(1) NOT NULL DEFAULT 0 COMMENT '本局是否抢庄' AFTER seat_no");
  await addColumn(conn, 'game_results', 'bet_level',
    "INT NOT NULL DEFAULT 1 COMMENT '倍数（游戏积分倍数）' AFTER grab_flag");
  await addColumn(conn, 'game_results', 'cards',
    "JSON NULL COMMENT '服务端发出的 5 张牌' AFTER bet_level");
  await addColumn(conn, 'game_results', 'hand_key',
    "VARCHAR(20) NULL COMMENT '牌型 key' AFTER cards");
  await addColumn(conn, 'game_results', 'expect_amount',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '应结（可能因积分不足封顶）' AFTER net_payout");
  await addColumn(conn, 'game_results', 'delta',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '游戏积分变动（正=获得）' AFTER expect_amount");
  await addColumn(conn, 'game_results', 'balance_before',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '结算前游戏积分' AFTER delta");
  await addColumn(conn, 'game_results', 'balance_after',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '结算后游戏积分' AFTER balance_before");
  await addColumn(conn, 'game_results', 'compare_result',
    "ENUM('BANKER','PLAYER','DRAW') NULL COMMENT '与庄家比牌结果' AFTER balance_after");
  await addColumn(conn, 'game_results', 'is_capped',
    "TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否因积分不足封顶结算' AFTER compare_result");
  await addIndex(conn, 'game_results', 'idx_result_user_time',
    'KEY idx_result_user_time (user_id, created_at)');
}

/** 同一局同一玩家只能有一条结算记录（第二道保险，配合 status 幂等闸门） */
async function ensureResultUnique(conn) {
  const [rows] = await conn.query(
    `SELECT index_name FROM information_schema.statistics
     WHERE table_schema = ? AND table_name = 'game_results' AND non_unique = 0 AND index_name = 'uq_result_round_user'`,
    [process.env.DB_NAME]
  );
  if (rows.length) { console.log('  · game_results 已有 UNIQUE(round_id,user_id)，跳过'); return false; }
  const [dup] = await conn.query(
    'SELECT round_id, user_id, COUNT(*) AS c FROM game_results GROUP BY round_id, user_id HAVING c > 1 LIMIT 5');
  if (dup.length) {
    console.log('  ! game_results 存在重复 (round_id,user_id)（' + dup.length + ' 组），跳过唯一索引以免改数据');
    return false;
  }
  await conn.query('ALTER TABLE game_results ADD UNIQUE KEY uq_result_round_user (round_id, user_id)');
  console.log('  ✓ game_results 追加 UNIQUE(round_id, user_id)');
  return true;
}

async function ensureRoomColumns(conn) {
  await addColumn(conn, 'game_rooms', 'room_key',
    "VARCHAR(20) NULL COMMENT '26牛牛场次标识' AFTER room_name");
  await addColumn(conn, 'game_rooms', 'base_stake',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '底分（游戏积分）' AFTER room_key");
  await addColumn(conn, 'game_rooms', 'seat_limit',
    "INT NOT NULL DEFAULT 6 COMMENT '座位上限' AFTER base_stake");
  await addColumn(conn, 'game_rooms', 'min_points',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '进入所需游戏积分' AFTER seat_limit");
  await addColumn(conn, 'game_rooms', 'chat_channel',
    "VARCHAR(40) NULL COMMENT '游戏消息频道（26牛牛为 group）' AFTER min_points");
  await addIndex(conn, 'game_rooms', 'uq_game_rooms_key',
    'UNIQUE KEY uq_game_rooms_key (room_key)');
}

/** room_players 直接作为座位表复用（局内字段，每局结束重置） */
async function ensureSeatColumns(conn) {
  await addColumn(conn, 'room_players', 'bet_level',
    "INT NOT NULL DEFAULT 1 COMMENT '本局倍数' AFTER role");
  await addColumn(conn, 'room_players', 'grab_flag',
    "TINYINT(1) NOT NULL DEFAULT 0 COMMENT '本局是否抢庄' AFTER bet_level");
  await addIndex(conn, 'room_players', 'uq_room_player',
    'UNIQUE KEY uq_room_player (room_id, user_id)');
}

/** 把 config/niuGame.js 的场次写入 game_rooms（已存在则不覆盖管理员改过的值） */
async function seedRooms(conn) {
  let NG = null;
  try { NG = require('../../config/niuGame'); } catch (_) { NG = null; }
  const list = (NG && Array.isArray(NG.ROOMS)) ? NG.ROOMS : [];
  if (!list.length) { console.log('  · config/niuGame.js 无场次，跳过'); return 0; }
  let n = 0;
  for (const r of list) {
    const key = String(r.key || '').trim();
    if (!key) continue;
    // eslint-disable-next-line no-await-in-loop
    const [rs] = await conn.query(
      `INSERT IGNORE INTO game_rooms
         (room_name, room_key, base_stake, seat_limit, min_points, max_players,
          min_players, chat_channel, packet_type, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'group', 'PLATFORM', 'WAITING')`,
      [String(r.name || key).slice(0, 100), key, Number(r.base_stake) || 0,
        Number(r.seat_limit) || NG.PLAYERS.DEFAULT_MAX, Number(r.min_points) || 0,
        Number(r.seat_limit) || NG.PLAYERS.DEFAULT_MAX, NG.PLAYERS.MIN]
    );
    if (rs.affectedRows) n += 1;
  }
  console.log(n ? '  ✓ 从 config/niuGame.js 同步 ' + n + ' 个场次到 game_rooms' : '  · 场次已存在，无需新增');
  return n;
}

/** chat_messages：游戏消息与房间 / 回合关联（「聊天群 = 游戏载体」的关键） */
async function ensureChatGameColumns(conn) {
  await addColumn(conn, 'chat_messages', 'room_id',
    "INT UNSIGNED NULL COMMENT '游戏房间（game_rooms.id）；普通聊天为空' AFTER channel");
  await addColumn(conn, 'chat_messages', 'round_id',
    "VARCHAR(50) NULL COMMENT '对局编号（game_rounds.round_id）；普通聊天为空' AFTER room_id");
  await addColumn(conn, 'chat_messages', 'phase',
    "VARCHAR(20) NULL COMMENT '发消息时所处游戏阶段' AFTER round_id");
  await addColumn(conn, 'chat_messages', 'game_round_pk',
    "INT UNSIGNED NULL COMMENT 'game_rounds.id（内部关联）' AFTER phase");
  await addIndex(conn, 'chat_messages', 'idx_chat_game_round',
    'KEY idx_chat_game_round (round_id, id)');
  await addIndex(conn, 'chat_messages', 'idx_chat_game_room',
    'KEY idx_chat_game_room (room_id, id)');
}

async function run() {
  const conn = await connect();
  try {
    await conn.beginTransaction();
    await ensureRoundStatusEnum(conn);
    await ensureRoundColumns(conn);
    await ensureRoundIdUnique(conn);
    await ensureResultColumns(conn);
    await ensureResultUnique(conn);
    await ensureRoomColumns(conn);
    await ensureSeatColumns(conn);
    await ensureChatGameColumns(conn);
    await seedRooms(conn);
    await conn.commit();
    console.log('=== 025 游戏核心回归聊天群（复用现有游戏表）迁移完成 ===');
  } catch (err) {
    await conn.rollback();
    console.error('025 迁移失败:', err.message);
    throw err;
  } finally {
    await conn.end().catch(() => {});
  }
}

if (require.main === module) {
  run().catch(() => process.exit(1));
}

module.exports = { run };
