'use strict';
require('dotenv').config();
const { connect } = require('./_helper');
async function main() {
  const conn = connect();
  console.log('=== 011 聊天禁言记录（安全增量）===');
  try {
    const [t] = await conn.query('SELECT TABLE_NAME FROM information_schema.tables WHERE table_schema=? AND table_name=?', [process.env.DB_NAME, 'moderation_actions']);
    if (!t.length) {
      await conn.query('CREATE TABLE IF NOT EXISTS moderation_actions (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT \'记录ID\',scope ENUM(\'GROUP\',\'USER\') NOT NULL COMMENT \'范围\',target_user_id INT UNSIGNED NULL COMMENT \'被禁言用户\',operator_id INT UNSIGNED NOT NULL COMMENT \'操作管理员\',action ENUM(\'MUTE\',\'UNMUTE\') NOT NULL COMMENT \'动作\',reason VARCHAR(255) NOT NULL COMMENT \'原因\',status ENUM(\'ACTIVE\',\'ENDED\') NOT NULL DEFAULT \'ACTIVE\' COMMENT \'状态\',created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT \'操作时间\',ended_at DATETIME NULL COMMENT \'解除时间\',ended_by INT UNSIGNED NULL COMMENT \'解除人\',INDEX idx_scope_status (scope,status),INDEX idx_target (target_user_id,status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT=\'聊天禁言记录\'');
      console.log('  ✓ 新建表 moderation_actions');
    } else { console.log('  · 表 moderation_actions 已存在，跳过'); }
    console.log('=== 011 完成 ===');
    process.exit(0);
  } catch (e) { console.error('迁移失败:', e.message); process.exit(1); }
}
main();
