// ============================================
// 26牛牛 - 迁移 006：在线状态 + 双人复核
// ============================================
// 新增:
//   - user_presence     在线状态（Socket 连接 / 聊天轮询心跳），支撑「在线人数」真实统计
//   - admin_approvals   后台高风险动作的双人复核请求（封禁 / 管理员权限 / 解除禁言）
// 运行方式: node database/migrations/006-presence-approval.js
// 安全原则:
//   - 只做「新增表」，不 DROP、不 DELETE、不改动任何现有数据
//   - 可重复执行（幂等）
// ============================================

require('dotenv').config();
const { hasTable, connect } = require('./_helper');

async function main() {
  const conn = await connect();
  try {
    console.log('== 006 在线状态 + 双人复核 ==');

    if (await hasTable(conn, 'user_presence')) {
      console.log('  · user_presence 已存在，跳过建表');
    } else {
      await conn.query(
        `CREATE TABLE user_presence (
          user_id    INT UNSIGNED NOT NULL PRIMARY KEY COMMENT '用户ID',
          last_seen  DATETIME NOT NULL COMMENT '最近活跃时间（Socket 连接或聊天轮询）',
          sockets    INT NOT NULL DEFAULT 0 COMMENT '当前服务端持有的 Socket 连接数',
          first_seen DATETIME NOT NULL COMMENT '首次被记录时间',
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY idx_presence_last_seen (last_seen)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛 在线状态（不记录 IP / 设备指纹）'`
      );
      console.log('  ✓ 新建表 user_presence');
    }

    if (await hasTable(conn, 'admin_approvals')) {
      console.log('  · admin_approvals 已存在，跳过建表');
    } else {
      await conn.query(
        `CREATE TABLE admin_approvals (
          id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '复核请求ID',
          action         VARCHAR(40) NOT NULL COMMENT '动作（user_status / user_role / user_unmute）',
          target_type    VARCHAR(20) NOT NULL DEFAULT 'user' COMMENT '目标类型',
          target_user_id INT UNSIGNED NULL COMMENT '目标用户ID',
          payload        JSON NULL COMMENT '动作参数（禁止存放密码 / 凭证等敏感信息）',
          reason         VARCHAR(255) NOT NULL COMMENT '申请原因（申请人填写）',
          status         ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
          requested_by   INT UNSIGNED NOT NULL COMMENT '申请人（管理员）',
          requested_at   DATETIME NOT NULL COMMENT '申请时间',
          reviewed_by    INT UNSIGNED NULL COMMENT '复核人（必须是另一名管理员）',
          reviewed_at    DATETIME NULL COMMENT '复核时间',
          review_note    VARCHAR(255) NULL COMMENT '复核备注 / 拒绝原因',
          apply_result   VARCHAR(255) NULL COMMENT '执行结果摘要（成功或失败原因，可审计）',
          created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          KEY idx_approval_status (status, id),
          KEY idx_approval_requester (requested_by, id),
          KEY idx_approval_target (target_user_id, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛 后台高风险动作双人复核'`
      );
      console.log('  ✓ 新建表 admin_approvals');
    }

    // 排序规则对齐（避免与既有表 JOIN 时报 collation 冲突）
    try {
      const [dbInfo] = await conn.query(
        `SELECT DEFAULT_CHARACTER_SET_NAME AS cs, DEFAULT_COLLATION_NAME AS col
         FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = DATABASE()`
      );
      for (const t of ['user_presence', 'admin_approvals']) {
        const [tbl] = await conn.query(
          `SELECT TABLE_COLLATION AS col FROM information_schema.tables
           WHERE table_schema = DATABASE() AND table_name = ?`, [t]
        );
        const want = dbInfo[0] && dbInfo[0].col;
        const now = tbl[0] && tbl[0].col;
        if (want && now && want !== now) {
          await conn.query(`ALTER TABLE ${t} CONVERT TO CHARACTER SET ${dbInfo[0].cs} COLLATE ${want}`);
          console.log(`  ✓ ${t} 排序规则对齐为 ${want}`);
        }
      }
    } catch (e) {
      console.log('  ! 排序规则检查失败（不影响功能）: ' + e.message);
    }

    console.log('\n006 完成（未删除任何数据）');
  } finally {
    await conn.end();
  }
}

main().catch(err => {
  console.error('迁移 006 失败:', err.message);
  process.exitCode = 1;
});
