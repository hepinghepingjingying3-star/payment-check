// ============================================
// 26牛牛 - 一次性运行全部增量迁移
// 运行方式: node database/migrations/run-all.js
// 说明: 全部迁移都是「安全增量」，不删除数据库 / 表 / 用户 / 数据
// ============================================

require('dotenv').config();
const { spawnSync } = require('child_process');
const path = require('path');

const FILES = [
  '001-platform.js', '002-otp.js', '003-chat.js', '004-moderation.js', '005-funds-referral.js',
  '006-presence-approval.js', '007-chat-redpacket.js',
  '008-account-security.js', '008-platform-settings.js', '009-guest-support.js',
  '010-cash-chips.js', '011-chat-moderation.js', '012-recharge-wizard.js', '016-withdrawals-final.js',
  '017-recharge-receiving-accounts.js', '018-avatars.js', '019-admin-console.js',
  '024-niu-game.js', '025-game-in-chat-group.js',
  // 026 机器人表（niu_bot_state / niu_bot_events）。必须排在 025 之后：
  // 它依赖 025 建出的 chat_messages.game_round_pk 等字段。
  '026-niu-bot.js',
  // 027 注册凭证一次性消费（registration_otp.consumed_at）。
  // auth.js 注册事务会读写 consumed_at，必须在此迁移之后运行。
  '027-otp-token-single-use.js'
];

for (const f of FILES) {
  const full = path.join(__dirname, f);
  console.log('\n>>> 运行 ' + f);
  const r = spawnSync(process.execPath, [full], { stdio: 'inherit' });
  if (r.status !== 0) {
    console.error('!! ' + f + ' 执行失败，已中止');
    process.exit(r.status || 1);
  }
}

console.log('\n全部迁移完成（未删除任何数据）');
