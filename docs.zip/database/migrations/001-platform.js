// ============================================
// 26牛牛 - 平台模块迁移（001）
// 新增（全部 IF NOT EXISTS，绝不 DROP / DELETE 任何数据）:
//   - announcements   公告表（文字/图片/置顶/排序/起止时间）
//   - notifications   通知中心（系统/活动/推广/客服/游戏）
//   - favorites       收藏（游戏/教学/公告）
//   - recent_visits   最近访问
// 运行方式: node database/migrations/001-platform.js
// ============================================

require('dotenv').config();
const { hasTable, addColumn, addIndex, connect } = require('./_helper');

const TABLES = [
  {
    name: 'announcements',
    sql: `CREATE TABLE IF NOT EXISTS announcements (
      id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '公告ID',
      type       ENUM('text','image','activity','system') NOT NULL DEFAULT 'text' COMMENT '公告类型',
      title      VARCHAR(120) NOT NULL COMMENT '标题',
      summary    VARCHAR(255) NULL COMMENT '摘要',
      content    TEXT NULL COMMENT '正文（文字公告）',
      image      VARCHAR(255) NULL COMMENT '图片地址（图片公告）',
      status     ENUM('active','hidden') NOT NULL DEFAULT 'active' COMMENT '状态',
      pinned     TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否置顶',
      sort       INT NOT NULL DEFAULT 0 COMMENT '排序权重（越大越靠前）',
      start_at   DATETIME NULL COMMENT '开始时间（空=立即）',
      end_at     DATETIME NULL COMMENT '结束时间（空=长期）',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      INDEX idx_status_time (status, start_at, end_at),
      INDEX idx_sort (sort, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='公告表'`
  },
  {
    name: 'notifications',
    sql: `CREATE TABLE IF NOT EXISTS notifications (
      id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '通知ID',
      user_id    INT UNSIGNED NOT NULL COMMENT '接收用户ID',
      category   ENUM('system','activity','referral','support','game') NOT NULL DEFAULT 'system' COMMENT '通知分类',
      title      VARCHAR(120) NOT NULL COMMENT '标题',
      content    TEXT NULL COMMENT '内容',
      link       VARCHAR(255) NULL COMMENT '跳转地址（站内相对路径）',
      is_read    TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否已读',
      read_at    DATETIME NULL COMMENT '已读时间',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      INDEX idx_user_read (user_id, is_read, id),
      INDEX idx_category (category),
      CONSTRAINT fk_noti_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='通知中心表'`
  },
  {
    name: 'favorites',
    sql: `CREATE TABLE IF NOT EXISTS favorites (
      id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '收藏ID',
      user_id     INT UNSIGNED NOT NULL COMMENT '用户ID',
      target_type ENUM('game','tutorial','announcement') NOT NULL COMMENT '收藏对象类型',
      target_id   VARCHAR(60) NOT NULL COMMENT '收藏对象ID',
      title       VARCHAR(120) NULL COMMENT '标题快照',
      created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
      UNIQUE KEY uk_user_target (user_id, target_type, target_id),
      INDEX idx_user_time (user_id, created_at),
      CONSTRAINT fk_fav_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收藏表'`
  },
  {
    name: 'recent_visits',
    sql: `CREATE TABLE IF NOT EXISTS recent_visits (
      id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
      user_id     INT UNSIGNED NOT NULL COMMENT '用户ID',
      target_type ENUM('game','tutorial','announcement') NOT NULL COMMENT '访问对象类型',
      target_id   VARCHAR(60) NOT NULL COMMENT '访问对象ID',
      title       VARCHAR(120) NULL COMMENT '标题快照',
      visited_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最近访问时间',
      UNIQUE KEY uk_user_target (user_id, target_type, target_id),
      INDEX idx_user_time (user_id, visited_at),
      CONSTRAINT fk_rv_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='最近访问表'`
  }
];

async function main() {
  const conn = connect();
  console.log('=== 001 平台模块迁移（安全增量，不删除任何数据）===');
  try {
    for (const t of TABLES) {
      await conn.query(t.sql);
      console.log('  ✓ 表就绪: ' + t.name);
    }
    // 旧 system_notices 兼容：补充缺失字段（不删除旧数据）
    if (await hasTable(conn, 'system_notices')) {
      await addColumn(conn, 'system_notices', 'pinned', 'TINYINT(1) NOT NULL DEFAULT 0');
      await addColumn(conn, 'system_notices', 'sort', 'INT NOT NULL DEFAULT 0');
      await addColumn(conn, 'system_notices', 'start_at', 'DATETIME NULL');
      await addColumn(conn, 'system_notices', 'end_at', 'DATETIME NULL');
    }
    // 用户贴图表：确保存在（V3 可能已建，幂等）
    await conn.query(`CREATE TABLE IF NOT EXISTS user_stickers (
      id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '贴图ID',
      user_id    INT UNSIGNED NOT NULL COMMENT '所属用户ID',
      name       VARCHAR(50) NOT NULL COMMENT '贴图名称',
      url        VARCHAR(255) NOT NULL COMMENT '贴图文件地址',
      size_bytes INT UNSIGNED NULL COMMENT '文件大小（字节）',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      INDEX idx_user (user_id),
      CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户自定义贴图表'`);
    await addColumn(conn, 'user_stickers', 'mime_type', "VARCHAR(60) NULL COMMENT '文件MIME类型'");
    await addIndex(conn, 'user_stickers', 'idx_user_time', 'INDEX idx_user_time (user_id, created_at)');
    console.log('  ✓ user_stickers 已就绪');
    console.log('=== 001 完成 ===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

main();