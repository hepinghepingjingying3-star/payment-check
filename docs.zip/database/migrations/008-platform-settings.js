// ============================================
// 26牛牛 - 008 平台优化迁移（安全增量，绝不删除数据）
// 新增:
//   - system_settings       系统配置中心（键值对；默认值写在 config/site.js，库里只存覆盖项）
//   - support_quick_replies 客服快捷回复（管理员维护，客服点击插入输入框，不自动发送）
//   - chat_messages.reply_to_id  聊天回复 / 引用
//   - users.token_version   退出其他设备（JWT 版本号，旧令牌立即失效）
// 运行方式: node database/migrations/008-platform-settings.js
// ============================================

require('dotenv').config();
const { hasTable, hasColumn, addColumn, addIndex, connect } = require('./_helper');

const TABLES = [
  {
    name: 'system_settings',
    sql: `CREATE TABLE IF NOT EXISTS system_settings (
      setting_key   VARCHAR(60)  NOT NULL COMMENT '配置键',
      setting_value TEXT         NULL COMMENT '配置值（JSON 字符串）',
      updated_by    INT UNSIGNED NULL COMMENT '最后修改的管理员ID',
      updated_at    DATETIME     NULL COMMENT '最后修改时间',
      created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      PRIMARY KEY (setting_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置中心（站点名称 / 充值区间 / 推广比例 / 维护模式等）'`
  },
  {
    name: 'support_quick_replies',
    sql: `CREATE TABLE IF NOT EXISTS support_quick_replies (
      id         INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '快捷回复ID',
      content    VARCHAR(300) NOT NULL COMMENT '回复内容（点击后插入输入框，不自动发送）',
      sort       INT          NOT NULL DEFAULT 0 COMMENT '排序（越小越前）',
      status     ENUM('active','hidden') NOT NULL DEFAULT 'active' COMMENT '状态',
      created_by INT UNSIGNED NULL COMMENT '创建管理员ID',
      created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      updated_at DATETIME     NULL COMMENT '更新时间',
      PRIMARY KEY (id),
      KEY idx_sort (status, sort)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服快捷回复短语'`
  }
];

async function main() {
  const conn = connect();
  console.log('=== 008 平台优化迁移（安全增量）===');
  try {
    for (const t of TABLES) {
      if (await hasTable(conn, t.name)) {
        console.log(`  · ${t.name} 已存在，跳过`);
      } else {
        await conn.query(t.sql);
        console.log(`  ✓ 新增表 ${t.name}`);
      }
    }

    // 聊天回复 / 引用
    await addColumn(conn, 'chat_messages', 'reply_to_id', "BIGINT UNSIGNED NULL COMMENT '引用的消息ID（NULL=非回复）'");
    await addIndex(conn, 'chat_messages', 'idx_reply_to', 'INDEX idx_reply_to (reply_to_id)');

    // 退出其他设备：JWT 版本号（旧令牌 tv 不匹配即失效；历史令牌 tv 视为 0）
    await addColumn(conn, 'users', 'token_version', "INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '令牌版本（+1 后旧令牌全部失效）'");

    console.log('008 完成（未删除任何数据）');
  } catch (err) {
    console.error('008 迁移失败:', err.message);
    process.exitCode = 1;
  } finally {
    await conn.end();
  }
}

main();