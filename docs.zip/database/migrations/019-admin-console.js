'use strict';
// ============================================
// 26牛牛 - 019 管理后台扩展：游戏入口 / 系统通知定向发送
// 目标：
//   1) games 表：管理平台已存在游戏的「启用 / 停用 / 名称 / 排序 / 入口图片」
//   2) notifications 定向字段：支持「全部用户 / 指定用户」的系统通知
// 边界：全部为安全增量，不删除任何表、列或数据；可重复执行。
// ============================================

require('dotenv').config();

const { hasTable, addColumn, addIndex, connect } = require('./_helper');

async function ensureGamesTable(conn) {
  if (await hasTable(conn, 'games')) {
    console.log('  · games 表已存在，跳过');
    return false;
  }
  await conn.query(`
    CREATE TABLE games (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT,
      game_key VARCHAR(60) NOT NULL COMMENT '稳定标识，前端入口按此读取',
      name VARCHAR(80) NOT NULL,
      description VARCHAR(255) NULL,
      entry_image VARCHAR(255) NULL COMMENT '站内 /assets/ 路径',
      sort_order INT NOT NULL DEFAULT 0,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_games_key (game_key),
      KEY idx_games_active_sort (is_active, sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
  console.log('  ✓ 新建表 games');
  return true;
}

/** notifications 定向发送：只增列，不改已有列语义 */
async function ensureNotificationColumns(conn) {
  await addColumn(conn, 'notifications', 'target_scope', "VARCHAR(20) NOT NULL DEFAULT 'user' AFTER category");
  await addColumn(conn, 'notifications', 'sender_id', 'INT UNSIGNED NULL AFTER target_scope');
  await addColumn(conn, 'notifications', 'audience_id', 'INT UNSIGNED NULL AFTER sender_id');
  await addColumn(conn, 'notifications', 'status', "VARCHAR(20) NOT NULL DEFAULT 'published' AFTER audience_id");
  await addIndex(conn, 'notifications', 'idx_notifications_target', 'KEY idx_notifications_target (target_scope, audience_id, status)');
}

/** 从 config/games.js 同步游戏入口（不覆盖管理员已改过的名称 / 状态） */
async function seedGames(conn) {
  let site = null;
  try { site = require('../../config/site'); } catch (_) { site = null; }
  let list = (site && (site.GAMES || (site.DEFAULTS && site.DEFAULTS.games))) || [];
  if (!Array.isArray(list) || !list.length) {
    try { list = require('../../config/games').GAMES || []; } catch (_) { list = []; }
  }
  if (!list.length) { console.log('  · 未找到游戏入口配置，跳过同步'); return 0; }
  let n = 0;
  for (const g of list) {
    if (!g || typeof g !== 'object') continue;
    const key = String(g.key || g.id || '').trim();
    if (!key) continue;
    // eslint-disable-next-line no-await-in-loop
    const [r] = await conn.query(
      'INSERT IGNORE INTO games (game_key, name, description, entry_image, sort_order, is_active) VALUES (?, ?, ?, ?, ?, 1)',
      [key.slice(0, 60), String(g.name || key).slice(0, 80),
        (g.description || g.intro) ? String(g.description || g.intro).slice(0, 255) : null,
        g.image ? String(g.image).slice(0, 255) : null, Number(g.order || g.sort) || 0]
    );
    if (r.affectedRows) n += 1;
  }
  console.log(n ? `  ✓ 从游戏配置同步 ${n} 个游戏入口` : '  · 游戏入口已同步，无需新增');
  return n;
}

async function run() {
  const conn = await connect();
  try {
    await conn.beginTransaction();
    await ensureGamesTable(conn);
    await ensureNotificationColumns(conn);
    await seedGames(conn);
    await conn.commit();
    console.log('=== 019 管理后台扩展完成 ===');
  } catch (err) {
    await conn.rollback();
    console.error('019 迁移失败:', err.message);
    throw err;
  } finally {
    await conn.end().catch(() => {});
  }
}

if (require.main === module) {
  run().catch(() => process.exit(1));
}

module.exports = { run };
