'use strict';
// ============================================
// 26牛牛 - 024 26牛牛娱乐场（非现金化游戏积分）
// ============================================
// 目标（全部安全增量，不删除任何表 / 列 / 数据，可重复执行）:
//   1) users.game_points          游戏积分（不可充值 / 不可提现 / 不可转账）
//   2) balance_transactions.currency_type 枚举追加 'GAME_POINTS'
//      （按当前枚举原值追加，保留可空性与默认值，历史数据不受影响）
//   3) niu_rounds / niu_round_players  真实对局记录（后端结算写入）
//   4) niu_user_stats                  对局统计 + 每日免费积分标记
//   5) system_settings.niu_game_enabled 管理后台可实时开关
// ============================================

require('dotenv').config();

const { hasTable, hasColumn, addColumn, addIndex, connect } = require('./_helper');

const ASSET = 'GAME_POINTS';

/** users.game_points */
async function ensureUserPoints(conn) {
  await addColumn(conn, 'users', 'game_points',
    "DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '游戏积分（不可充值/不可提现/不可转账）' AFTER cash_chips");
}

/** balance_transactions.currency_type：读取当前定义后仅追加枚举值 */
async function ensureLedgerCurrency(conn) {
  const [rows] = await conn.query(
    `SELECT COLUMN_TYPE AS ty, IS_NULLABLE AS nl, COLUMN_DEFAULT AS df
     FROM information_schema.columns
     WHERE table_schema = ? AND table_name = 'balance_transactions' AND column_name = 'currency_type'`,
    [process.env.DB_NAME]
  );
  if (!rows.length) { console.log('  · balance_transactions.currency_type 不存在，跳过'); return false; }
  const cur = String(rows[0].ty || '');
  if (cur.indexOf(ASSET) !== -1) { console.log('  · currency_type 已含 ' + ASSET + '，跳过'); return false; }
  const values = cur.replace(/^enum\(/i, '').replace(/\)$/, '');
  if (values.indexOf("'CASH_CHIPS'") === -1) { console.log('  · 当前不是预期枚举类型，跳过: ' + cur); return false; }
  const next = values.replace(/'CASH_CHIPS'$/, "'CASH_CHIPS','" + ASSET + "'");
  const nullable = String(rows[0].nl).toUpperCase() === 'YES' ? 'NULL' : 'NOT NULL';
  // 只有原本就有默认值时才保留 DEFAULT 子句（原本无默认值就不能写 DEFAULT NULL，否则 MySQL 报 Invalid default value）
  const dft = rows[0].df === null || rows[0].df === undefined
    ? ''
    : " DEFAULT '" + String(rows[0].df).replace(/'/g, "''") + "'";
  await conn.query(`ALTER TABLE balance_transactions MODIFY currency_type ENUM(${next}) ${nullable}${dft}`);
  console.log('  ✓ currency_type 枚举追加 ' + ASSET + '（历史数据不变）');
  return true;
}

/** 对局主表 */
async function ensureRoundsTable(conn) {
  if (await hasTable(conn, 'niu_rounds')) { console.log('  · niu_rounds 已存在，跳过'); return false; }
  await conn.query(`
    CREATE TABLE niu_rounds (
      id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
      round_no        VARCHAR(40) NOT NULL COMMENT '对局编号（服务端生成，唯一）',
      room_key        VARCHAR(20) NOT NULL COMMENT '场次 junior/middle/senior',
      base_stake      DECIMAL(20,2) NOT NULL COMMENT '底分（游戏积分）',
      banker_user_id  INT UNSIGNED NULL COMMENT '庄家',
      player_count    INT NOT NULL DEFAULT 0 COMMENT '参与人数（含庄家）',
      status          ENUM('WAITING','GRABBING','BETTING','DEALING','RESULT','SETTLEMENT','FINISHED','ABORTED')
                      NOT NULL DEFAULT 'WAITING' COMMENT '状态机（后端驱动）',
      started_at      TIMESTAMP NULL COMMENT '开局时间',
      ended_at        TIMESTAMP NULL COMMENT '结算时间',
      created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_niu_round_no (round_no),
      KEY idx_niu_round_room_time (room_key, ended_at),
      KEY idx_niu_round_status (status),
      KEY idx_niu_round_banker (banker_user_id),
      KEY idx_niu_round_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛娱乐场对局'
  `);
  console.log('  ✓ 新建表 niu_rounds');
  return true;
}

/** 对局玩家表（UNIQUE(round_id,user_id) 保证同一局不会重复结算） */
async function ensureRoundPlayersTable(conn) {
  if (await hasTable(conn, 'niu_round_players')) { console.log('  · niu_round_players 已存在，跳过'); return false; }
  await conn.query(`
    CREATE TABLE niu_round_players (
      id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      round_id        INT UNSIGNED NOT NULL COMMENT 'niu_rounds.id',
      user_id         INT UNSIGNED NOT NULL COMMENT 'users.id',
      role            ENUM('BANKER','PLAYER') NOT NULL COMMENT '庄家 / 闲家',
      seat_no         INT NOT NULL DEFAULT 0 COMMENT '座位号',
      grab_flag       TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否抢庄',
      bet_level       INT NOT NULL DEFAULT 1 COMMENT '倍数（游戏积分倍数）',
      cards           JSON NULL COMMENT '服务端发出的 5 张牌',
      hand_key        VARCHAR(20) NULL COMMENT '牌型 key',
      point_value     INT NOT NULL DEFAULT 0 COMMENT '点数（牛牛=10，无牛=0）',
      multiplier      INT NOT NULL DEFAULT 1 COMMENT '结算倍数',
      expect_amount   DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '应结（可能因余额封顶）',
      amount          DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '实际结（绝对值）',
      delta           DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '积分变动（正=获得）',
      balance_before  DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '结算前积分',
      balance_after   DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '结算后积分',
      result          ENUM('BANKER','PLAYER','DRAW') NULL COMMENT '与庄家比牌结果',
      is_capped       TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否因积分不足封顶结算',
      created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      UNIQUE KEY uq_niu_round_user (round_id, user_id),
      KEY idx_niu_rp_user_time (user_id, created_at),
      KEY idx_niu_rp_round (round_id),
      CONSTRAINT fk_niu_rp_round FOREIGN KEY (round_id) REFERENCES niu_rounds (id) ON DELETE RESTRICT,
      CONSTRAINT fk_niu_rp_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛娱乐场对局明细（每局每人一条，防重复结算）'
  `);
  console.log('  ✓ 新建表 niu_round_players');
  return true;
}

/** 对局统计 + 每日免费积分标记（每日只发一次的持久依据） */
async function ensureUserStatsTable(conn) {
  if (await hasTable(conn, 'niu_user_stats')) { console.log('  · niu_user_stats 已存在，跳过'); return false; }
  await conn.query(`
    CREATE TABLE niu_user_stats (
      user_id           INT UNSIGNED NOT NULL COMMENT 'users.id',
      total_rounds      INT NOT NULL DEFAULT 0 COMMENT '总对局数',
      win_rounds        INT NOT NULL DEFAULT 0 COMMENT '胜局数',
      banker_rounds     INT NOT NULL DEFAULT 0 COMMENT '上庄次数',
      grab_rounds       INT NOT NULL DEFAULT 0 COMMENT '抢庄次数',
      total_delta       DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '累计积分净变动',
      best_multiplier   INT NOT NULL DEFAULT 0 COMMENT '最大牌型倍数',
      daily_free_date   DATE NULL COMMENT '最近一次发放每日免费积分的日期',
      created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id),
      KEY idx_niu_stats_rounds (total_rounds),
      KEY idx_niu_stats_delta (total_delta),
      CONSTRAINT fk_niu_stats_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛娱乐场玩家统计'
  `);
  console.log('  ✓ 新建表 niu_user_stats');
  return true;
}

/** 游戏开关：写入默认值，管理员可后台实时关闭（已有值不覆盖） */
async function ensureSwitch(conn) {
  let NG = null;
  try { NG = require('../../config/niuGame'); } catch (_) { NG = null; }
  const key = (NG && NG.SWITCHES && NG.SWITCHES.DB_KEY) || 'niu_game_enabled';
  const [rows] = await conn.query('SELECT setting_key FROM system_settings WHERE setting_key = ?', [key]);
  if (rows.length) { console.log('  · 开关 ' + key + ' 已存在，保留现值'); return false; }
  const val = (NG && NG.SWITCHES && NG.SWITCHES.DEFAULT_ENABLED === false) ? '0' : '1';
  await conn.query('INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)', [key, val]);
  console.log('  ✓ 写入游戏开关 ' + key + '=' + val);
  return true;
}

async function run() {
  const conn = await connect();
  try {
    await conn.beginTransaction();
    await ensureUserPoints(conn);
    await ensureLedgerCurrency(conn);
    await ensureRoundsTable(conn);
    await ensureRoundPlayersTable(conn);
    await ensureUserStatsTable(conn);
    await ensureSwitch(conn);
    await conn.commit();
    console.log('=== 024 26牛牛娱乐场（游戏积分）迁移完成 ===');
  } catch (err) {
    await conn.rollback();
    console.error('024 迁移失败:', err.message);
    throw err;
  } finally {
    await conn.end().catch(() => {});
  }
}

if (require.main === module) {
  run().catch(() => process.exit(1));
}

module.exports = { run };
