// ============================================
// 26牛牛 - 迁移 008：账号安全中心
// ============================================
// 新增:
//   - users.token_version  INT UNSIGNED NOT NULL DEFAULT 0
//     「令牌版本号」：用户点击「退出其他设备」时 +1，
//     所有旧 JWT（tv 与当前不一致）立即失效；当前设备由服务端重新签发新令牌继续使用。
// 说明:
//   - 只新增列，绝不删除 / 修改既有数据；可重复执行（幂等）
//   - 默认 0，历史令牌没有 tv 字段时按 0 处理 → 旧用户不会被强制登出
//   - 不涉及任何真实资金 / 真实凭证
// 运行方式: node database/migrations/008-account-security.js
// ============================================

require('dotenv').config();
const { addColumn, connect } = require('./_helper');

async function main() {
  const conn = connect();
  console.log('=== 008 账号安全中心迁移（安全增量）===');
  try {
    await addColumn(conn, 'users', 'token_version',
      "INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '令牌版本号（退出其他设备时+1，使旧令牌失效）'");
    console.log('=== 008 完成 ===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

main();