'use strict';
// 提款模块兼容迁移：只新增字段/表，不删除或改写既有钱包数据。
require('dotenv').config();
const { addColumn, addIndex, hasTable, connect } = require('./_helper');

async function addTable(conn, name, sql) {
  if (await hasTable(conn, name)) return;
  await conn.query(sql);
  console.log('  ✓ 新建表 ' + name);
}
async function main() {
  const conn = connect();
  try {
    await addColumn(conn, 'users', 'bank_name', "VARCHAR(100) NULL COMMENT '本人收款银行名称'");
    await addColumn(conn, 'users', 'bank_account', "VARCHAR(120) NULL COMMENT '本人收款银行账号（仅本人/管理员接口可读）'");
    await addColumn(conn, 'withdraw_requests', 'withdrawal_id', "VARCHAR(40) NULL COMMENT '正式提款订单号'");
    await addColumn(conn, 'withdraw_requests', 'recipient_name', "VARCHAR(60) NULL COMMENT '收款人姓名快照'");
    await addColumn(conn, 'withdraw_requests', 'bank_name', "VARCHAR(100) NULL COMMENT '银行名称快照'");
    await addColumn(conn, 'withdraw_requests', 'bank_account', "VARCHAR(120) NULL COMMENT '银行账号快照（仅本人/管理员）'");
    await addColumn(conn, 'withdraw_requests', 'approved_at', "DATETIME NULL COMMENT '审核通过时间'");
    await addColumn(conn, 'withdraw_requests', 'rejected_at', "DATETIME NULL COMMENT '审核拒绝时间'");
    await addColumn(conn, 'withdraw_requests', 'idempotency_key', "VARCHAR(80) NULL COMMENT '提款请求幂等键'");
    await conn.query("UPDATE withdraw_requests SET withdrawal_id = order_id WHERE withdrawal_id IS NULL OR withdrawal_id = ''");
    await addIndex(conn, 'withdraw_requests', 'uq_withdrawal_id', 'UNIQUE INDEX uq_withdrawal_id (withdrawal_id)');
    await addIndex(conn, 'withdraw_requests', 'uq_withdraw_idempotency', 'UNIQUE INDEX uq_withdraw_idempotency (idempotency_key)');
    await addTable(conn, 'audit_logs', `CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      operator_id INT UNSIGNED NOT NULL,
      action VARCHAR(64) NOT NULL,
      target_id INT UNSIGNED NULL,
      reason VARCHAR(255) NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_audit_operator (operator_id),
      INDEX idx_audit_target (target_id),
      INDEX idx_audit_action (action)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='敏感业务审计日志'`);
    console.log('=== 提款模块兼容迁移完成 ===');
  } finally { await conn.end(); }
}
main().catch(e => { console.error('提款迁移失败:', e.message); process.exit(1); });
