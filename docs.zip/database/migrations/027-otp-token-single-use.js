// ============================================
// 26牛牛 - 迁移 027：注册凭证一次性消费（otp_token 防重放）
// 原则（与 025 / 026 一致）：
//   - 纯增量：只 ADD COLUMN，不 DROP、不 DELETE、不改写任何既有用户 / OTP 数据
//   - 可重复执行（幂等）
//
// 为什么需要：
//   registration_otp 行本身在「校验验证码」时就已经一次性失效（覆写 otp_hash），
//   但校验通过后签发给前端的注册凭证 otp_token 只是一枚含 phone 的短期 JWT：
//     1) 它不携带 registration_otp.id，无法确认「这枚凭证对应哪一条已验证记录」；
//     2) 它在有效期内可被无限次重放 —— 例如注册因邀请码错误失败后，攻击者（或用户）
//        可以拿同一枚 otp_token 反复提交注册，等于绕过了一次性验证码的限制；
//     3) 同一手机号重新申请验证码并验证后，旧凭证在 TTL 内仍然有效。
//   本迁移新增 consumed_at，注册成功时在同一事务里标记消费，
//   校验时若已消费则直接拒绝，从而让凭证真正「一次性」。
//   注意：users.phone 本身已有 UNIQUE 约束，重复注册最终仍会被数据库挡住；
//   本次修复解决的是「重放绕过校验」这一层，而不是重复建号。
// ============================================

require('dotenv').config();
const { connect, addColumn, addIndex } = require('./_helper');

async function run() {
  const conn = await connect();
  try {
    // 消费时间：NULL = 凭证未被使用；非 NULL = 已被某次注册成功消费
    await addColumn(conn, 'registration_otp', 'consumed_at',
      'DATETIME NULL COMMENT \'注册成功消费凭证的时间（非空=凭证已用，禁止重放）\'');

    // 注册时按 id + consumed_at 查证，索引加速
    await addIndex(conn, 'registration_otp', 'idx_consumed',
      'INDEX idx_consumed (id, consumed_at)');
  } finally {
    await conn.end();
  }
}

module.exports = { run };

if (require.main === module) {
  run()
    .then(() => {
      console.log('✓ 迁移 027 完成（注册凭证一次性消费；未删除任何数据）');
      return conn_close();
    })
    .catch(e => { console.error('✗ 迁移 027 失败:', e.message); process.exit(1); });
}

function conn_close() { return Promise.resolve(); }