// ============================================
// 26牛牛 - 用户治理迁移（004）
// 新增:
//   - users.muted_until  DATETIME NULL    禁言到期时间（NULL = 未禁言）
//   - users.mute_reason  VARCHAR(255) NULL 禁言原因（管理端展示 + 审计）
// 说明:
//   - 只新增列，绝不删除 / 修改既有数据；可重复执行
//   - 禁言由 routes/chat.js 发送消息时强制校验（数据库为准，不信任前端）
// 运行方式: node database/migrations/004-moderation.js
// ============================================

require('dotenv').config();
const { addColumn, connect } = require('./_helper');

async function main() {
  const conn = connect();
  console.log('=== 004 用户治理迁移（安全增量）===');
  try {
    await addColumn(conn, 'users', 'muted_until', "DATETIME NULL COMMENT '禁言到期时间（NULL=未禁言）'");
    await addColumn(conn, 'users', 'mute_reason', "VARCHAR(255) NULL COMMENT '禁言原因（管理端展示，禁止记录敏感信息）'");
    console.log('=== 004 完成 ===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

main();
