'use strict';
// 迁移 012：充值向导订单提交时间 + 收款配置由 system_settings 管理。
// 只做增量列变更，绝不删除或重建 recharge_orders。
require('dotenv').config();
const { addColumn, connect } = require('./_helper');

(async function () {
  const conn = await connect();
  try {
    await addColumn(conn, 'recharge_orders', 'submitted_at', "DATETIME NULL COMMENT '用户提交凭证时间'");
    console.log('012 完成：充值订单提交时间已就绪');
  } finally {
    await conn.end();
  }
})().catch(function (err) {
  console.error('012 迁移失败:', err.message);
  process.exitCode = 1;
});
