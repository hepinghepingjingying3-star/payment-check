'use strict';
// ============================================
// 迁移 018：官方头像库（avatar_categories / avatars / users.avatar_id）
// ============================================
// 安全增量：只建新表 / 新增列 / 新增索引，绝不 DROP、绝不删数据
// 运行：node database/migrations/018-avatars.js
require('dotenv').config();
const { addColumn, addIndex, hasTable, connect } = require('./_helper');

async function main() {
  const conn = connect();
  try {
    // ---------- 1. 头像分类 ----------
    if (!(await hasTable(conn, 'avatar_categories'))) {
      await conn.query(`CREATE TABLE avatar_categories (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL COMMENT '分类名称',
        sort_order INT NOT NULL DEFAULT 0 COMMENT '排序（越小越靠前）',
        is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 启用 / 0 停用',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_avatar_categories_sort (sort_order, id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
      console.log('  ✓ 新建 avatar_categories');
    } else {
      console.log('  · avatar_categories 已存在，跳过建表');
    }

    // ---------- 2. 头像表 ----------
    if (!(await hasTable(conn, 'avatars'))) {
      await conn.query(`CREATE TABLE avatars (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(80) NOT NULL COMMENT '头像名称',
        category_id INT UNSIGNED NULL COMMENT '所属分类',
        image_path VARCHAR(255) NOT NULL COMMENT '正式头像资源路径',
        sort_order INT NOT NULL DEFAULT 0 COMMENT '排序（越小越靠前）',
        is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 启用 / 0 停用（停用后普通用户不可再选）',
        allow_users TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 允许普通用户选择 / 0 仅管理员可见',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_avatars_category (category_id),
        INDEX idx_avatars_sort (sort_order, id),
        CONSTRAINT fk_avatars_category FOREIGN KEY (category_id)
          REFERENCES avatar_categories (id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
      console.log('  ✓ 新建 avatars');
    } else {
      console.log('  · avatars 已存在，跳过建表');
    }

    // ---------- 3. users.avatar_id ----------
    await addColumn(conn, 'users', 'avatar_id',
      "INT UNSIGNED NULL COMMENT '当前使用的官方头像ID'");
    await addIndex(conn, 'users', 'idx_users_avatar',
      'INDEX idx_users_avatar (avatar_id)');

    console.log('=== 头像库迁移完成 ===');
  } finally {
    try { await conn.end(); } catch (_) {}
  }
  process.exit(0);
}

main().catch((e) => { console.error('迁移失败:', e); process.exit(1); });