// ============================================
// 26牛牛 - 迁移工具（安全增量，绝不删除数据）
// ============================================
// 所有 migration 共用本文件，只做「新增 / 检查」，禁止 DROP / DELETE
// ============================================

/** 表是否存在 */
async function hasTable(conn, table) {
  const [rows] = await conn.query(
    `SELECT TABLE_NAME FROM information_schema.tables
     WHERE table_schema = ? AND table_name = ?`,
    [process.env.DB_NAME, table]
  );
  return rows.length > 0;
}

/** 列是否存在 */
async function hasColumn(conn, table, column) {
  const [rows] = await conn.query(
    `SELECT COLUMN_NAME FROM information_schema.columns
     WHERE table_schema = ? AND table_name = ? AND column_name = ?`,
    [process.env.DB_NAME, table, column]
  );
  return rows.length > 0;
}

/** 索引是否存在 */
async function hasIndex(conn, table, indexName) {
  const [rows] = await conn.query(
    `SELECT INDEX_NAME FROM information_schema.statistics
     WHERE table_schema = ? AND table_name = ? AND index_name = ?`,
    [process.env.DB_NAME, table, indexName]
  );
  return rows.length > 0;
}

/** 安全新增列（已存在则跳过） */
async function addColumn(conn, table, column, definition) {
  if (await hasColumn(conn, table, column)) {
    console.log(`  · ${table}.${column} 已存在，跳过`);
    return false;
  }
  await conn.query(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  console.log(`  ✓ 新增列 ${table}.${column}`);
  return true;
}

/** 安全新增索引（已存在则跳过） */
async function addIndex(conn, table, indexName, definition) {
  if (await hasIndex(conn, table, indexName)) {
    console.log(`  · ${table}.${indexName} 已存在，跳过`);
    return false;
  }
  await conn.query(`ALTER TABLE ${table} ADD ${definition}`);
  console.log(`  ✓ 新增索引 ${table}.${indexName}`);
  return true;
}

/** 建立数据库连接（迁移专用） */
function connect() {
  const mysql = require('mysql2');
  return mysql.createConnection({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    multipleStatements: true
  }).promise();
}

module.exports = { hasTable, hasColumn, hasIndex, addColumn, addIndex, connect };