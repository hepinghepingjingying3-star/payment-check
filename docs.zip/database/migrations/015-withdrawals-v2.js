// 提款模块兼容迁移：只新增字段/表，不删除现有钱包、用户或提款数据。
// 运行：node database/migrations/015-withdrawals-v2.js
require('dotenv').config();
const { addColumn, addIndex, hasTable, connect } = require('./_helper');

async function main() {
  const conn = connect();
  try {
    await addColumn(conn, 'users', 'bank_name', "VARCHAR(80) NULL COMMENT '本人收款银行名称'");
    await addColumn(conn, 'users', 'bank_account', "VARCHAR(120) NULL COMMENT '本人收款银行账号（仅本人与管理员可读）'");

    await addColumn(conn, 'withdraw_requests', 'bank_name', "VARCHAR(80) NULL COMMENT '收款银行名称快照'");
    await addColumn(conn, 'withdraw_requests', 'admin_remark', "VARCHAR(255) NULL COMMENT '管理员备注'");
    await addColumn(conn, 'withdraw_requests', 'approved_at', 'DATETIME NULL COMMENT '审核通过时间');
    await addColumn(conn, 'withdraw_requests', 'rejected_at', 'DATETIME NULL COMMENT '审核拒绝时间');
    await addColumn(conn, 'withdraw_requests', 'idempotency_key', "VARCHAR(80) NULL COMMENT '客户端幂等键'");
    await addIndex(conn, 'withdraw_requests', 'uq_withdraw_user_idempotency', 'UNIQUE INDEX uq_withdraw_user_idempotency (user_id, idempotency_key)');

    if (!(await hasTable(conn, 'audit_logs'))) {
      await conn.query(`CREATE TABLE audit_logs (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        operator_id INT UNSIGNED NULL,
        action VARCHAR(64) NOT NULL,
        target_id BIGINT UNSIGNED NULL,
        reason VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_audit_action (action, created_at),
        INDEX idx_audit_target (target_id, created_at),
        INDEX idx_audit_operator (operator_id, created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员操作审计'`);
      console.log('  ✓ 新建表 audit_logs');
    } else {
      console.log('  · 表 audit_logs 已存在，跳过');
    }
    console.log('=== 015 提款模块兼容迁移完成（未删除数据）===');
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exitCode = 1;
  } finally {
    await conn.end().catch(() => {});
  }
}
main();
