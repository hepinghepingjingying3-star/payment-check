// ============================================
// 26牛牛 - 迁移 007：聊天红包（群聊红包）
// ============================================
// 新增:
//   - chat_messages.message_type 扩展出 'redpacket'（保留 text/image/sticker/system/game）
//   - chat_red_packets          聊天红包主表（发送者 / 总额 / 个数 / 状态 / 有效期）
//   - chat_red_packet_claims    领取明细（同一红包同一用户只能领取一次）
// 运行方式: node database/migrations/007-chat-redpacket.js
// 安全原则:
//   - 只做「扩展枚举 / 新增表」，不 DROP、不 DELETE、不改动任何既有消息
//   - 资金一律使用平台内部测试资产（users.cash_chips），与真实支付无关
//   - 可重复执行（幂等）
// ============================================

require('dotenv').config();
const { hasTable, connect } = require('./_helper');

async function main() {
  const conn = await connect();
  try {
    console.log('== 007 聊天红包 ==');

    if (!(await hasTable(conn, 'chat_messages'))) {
      console.log('!! chat_messages 不存在，请先运行 database/migrate-v3.js');
      process.exitCode = 1;
      return;
    }

    // ---------- 1. 消息类型扩展（保留历史 5 种，新增 redpacket） ----------
    const [col] = await conn.query(
      `SELECT COLUMN_TYPE AS t FROM information_schema.columns
       WHERE table_schema = DATABASE() AND table_name = 'chat_messages' AND column_name = 'message_type'`
    );
    const current = col[0] ? String(col[0].t) : '';
    if (current.indexOf('redpacket') >= 0) {
      console.log('  · chat_messages.message_type 已包含 redpacket，跳过');
    } else {
      await conn.query(
        `ALTER TABLE chat_messages MODIFY COLUMN message_type
         ENUM('text','image','sticker','system','game','redpacket') NOT NULL DEFAULT 'text' COMMENT '消息类型'`
      );
      console.log('  ✓ chat_messages.message_type 扩展 redpacket（原类型全部保留）');
    }

    // ---------- 2. 聊天红包主表 ----------
    if (await hasTable(conn, 'chat_red_packets')) {
      console.log('  · chat_red_packets 已存在，跳过建表');
    } else {
      await conn.query(
        `CREATE TABLE chat_red_packets (
          id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '红包ID',
          packet_no      VARCHAR(32) NOT NULL COMMENT '红包编号（对用户展示）',
          channel        VARCHAR(40) NOT NULL COMMENT '频道（当前仅 group）',
          message_id     BIGINT UNSIGNED NULL COMMENT '对应的聊天消息ID',
          sender_id      INT UNSIGNED NOT NULL COMMENT '发送者用户ID',
          sender_name    VARCHAR(50) NULL COMMENT '发送时用户名快照',
          blessing       VARCHAR(80) NULL COMMENT '祝福语',
          currency_type  ENUM('GAME_BALANCE','CASH_CHIPS') NOT NULL DEFAULT 'CASH_CHIPS' COMMENT '资产类型（测试资产）',
          total_amount   DECIMAL(20,2) NOT NULL COMMENT '红包总额',
          total_count    INT NOT NULL COMMENT '红包总个数',
          claimed_count  INT NOT NULL DEFAULT 0 COMMENT '已领取个数',
          claimed_amount DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '已领取总额',
          status         ENUM('OPEN','EMPTY','EXPIRED') NOT NULL DEFAULT 'OPEN',
          expired_at     DATETIME NOT NULL COMMENT '过期时间（未领完自动退回）',
          closed_at      DATETIME NULL COMMENT '结束时间（领完 / 过期）',
          created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uk_chat_packet_no (packet_no),
          KEY idx_chat_packet_channel (channel, id),
          KEY idx_chat_packet_sender (sender_id, id),
          KEY idx_chat_packet_status (status, expired_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛 聊天红包（测试资产，非现金）'`
      );
      console.log('  ✓ 新建表 chat_red_packets');
    }

    // ---------- 3. 领取明细 ----------
    if (await hasTable(conn, 'chat_red_packet_claims')) {
      console.log('  · chat_red_packet_claims 已存在，跳过建表');
    } else {
      await conn.query(
        `CREATE TABLE chat_red_packet_claims (
          id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '领取ID',
          packet_id  INT UNSIGNED NOT NULL COMMENT '红包ID',
          user_id    INT UNSIGNED NOT NULL COMMENT '领取人',
          amount     DECIMAL(20,2) NOT NULL COMMENT '领取金额',
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE KEY uk_chat_claim_user (packet_id, user_id),
          KEY idx_chat_claim_user (user_id, id),
          CONSTRAINT fk_chat_rp_claim_packet FOREIGN KEY (packet_id)
            REFERENCES chat_red_packets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛 聊天红包领取明细'`
      );
      console.log('  ✓ 新建表 chat_red_packet_claims');
    }

    // ---------- 4. 排序规则对齐 ----------
    try {
      const [dbInfo] = await conn.query(
        `SELECT DEFAULT_CHARACTER_SET_NAME AS cs, DEFAULT_COLLATION_NAME AS col
         FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = DATABASE()`
      );
      for (const t of ['chat_red_packets', 'chat_red_packet_claims']) {
        const [tbl] = await conn.query(
          `SELECT TABLE_COLLATION AS col FROM information_schema.tables
           WHERE table_schema = DATABASE() AND table_name = ?`, [t]
        );
        const want = dbInfo[0] && dbInfo[0].col;
        const now = tbl[0] && tbl[0].col;
        if (want && now && want !== now) {
          await conn.query(`ALTER TABLE ${t} CONVERT TO CHARACTER SET ${dbInfo[0].cs} COLLATE ${want}`);
          console.log(`  ✓ ${t} 排序规则对齐为 ${want}`);
        }
      }
    } catch (e) {
      console.log('  ! 排序规则检查失败（不影响功能）: ' + e.message);
    }

    console.log('\n007 完成（未删除任何数据）');
  } finally {
    await conn.end();
  }
}

main().catch(err => {
  console.error('迁移 007 失败:', err.message);
  process.exitCode = 1;
});
