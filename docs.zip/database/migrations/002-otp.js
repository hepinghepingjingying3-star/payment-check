// ============================================
// 26牛牛 - OTP + 登录记录迁移（002）
// 新增（IF NOT EXISTS，绝不删除任何数据）:
//   - registration_otp   注册手机号验证码（只存哈希，明文仅临时保留供管理员查看）
//   - otp_audit_logs     管理员 OTP 查看 / 发送 / 操作审计（日志中绝不保存 OTP 明文）
//   - login_logs         登录记录（供「我的 → 账户安全 → 登录记录」）
// 运行方式: node database/migrations/002-otp.js
// ============================================

require('dotenv').config();
const { addColumn, addIndex, connect } = require('./_helper');

const TABLES = [
  {
    name: 'registration_otp',
    sql: `CREATE TABLE IF NOT EXISTS registration_otp (
      id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '验证码ID',
      phone         VARCHAR(20) NOT NULL COMMENT '手机号（标准化后）',
      otp_hash      CHAR(64) NOT NULL COMMENT 'OTP 的 HMAC-SHA256 哈希（校验用，不可逆）',
      otp_plain_tmp VARCHAR(12) NULL COMMENT '明文OTP：仅待发送期间临时保留，管理员标记已发送后立即清空',
      status        ENUM('pending','sent','verified','expired','locked') NOT NULL DEFAULT 'pending' COMMENT '状态',
      attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '已错误次数',
      max_attempts  TINYINT UNSIGNED NOT NULL DEFAULT 5 COMMENT '最大错误次数',
      expires_at    DATETIME NOT NULL COMMENT '过期时间',
      last_sent_at  DATETIME NULL COMMENT '最近生成/重发时间（用于 60 秒冷却）',
      verified_at   DATETIME NULL COMMENT '验证成功时间',
      sent_by       INT UNSIGNED NULL COMMENT '标记已发送的管理员ID',
      created_ip    VARCHAR(45) NULL COMMENT '申请来源IP（防刷统计）',
      created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      INDEX idx_phone_status (phone, status, id),
      INDEX idx_status_expire (status, expires_at),
      INDEX idx_created_ip (created_ip, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='注册手机号验证码表'`
  },
  {
    name: 'otp_audit_logs',
    sql: `CREATE TABLE IF NOT EXISTS otp_audit_logs (
      id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '审计ID',
      operator_id  INT UNSIGNED NULL COMMENT '操作者ID（管理员/客服，用户操作为NULL）',
      target_phone VARCHAR(20) NULL COMMENT '目标手机号',
      otp_id       BIGINT UNSIGNED NULL COMMENT '关联验证码ID',
      action       VARCHAR(30) NOT NULL COMMENT '操作类型: generate/view/resend/mark_sent/regenerate/verify_ok/verify_fail/expire/lock/cleanup',
      detail       VARCHAR(255) NULL COMMENT '备注（禁止写入 OTP 明文）',
      ip           VARCHAR(45) NULL COMMENT '操作来源IP',
      created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
      INDEX idx_operator (operator_id, created_at),
      INDEX idx_phone (target_phone, created_at),
      INDEX idx_action (action, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='OTP 审计日志表'`
  },
  {
    name: 'login_logs',
    sql: `CREATE TABLE IF NOT EXISTS login_logs (
      id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
      user_id    INT UNSIGNED NULL COMMENT '用户ID（用户名不存在时为NULL）',
      username   VARCHAR(50) NULL COMMENT '登录时填写的用户名',
      ip         VARCHAR(45) NULL COMMENT '来源IP',
      user_agent VARCHAR(255) NULL COMMENT '客户端标识',
      status     ENUM('success','fail') NOT NULL DEFAULT 'success' COMMENT '登录结果',
      reason     VARCHAR(60) NULL COMMENT '失败原因（不记录密码）',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
      INDEX idx_user_time (user_id, created_at),
      INDEX idx_status (status, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录记录表'`
  }
];

async function main() {
  const conn = connect();
  console.log('=== 002 OTP / 登录记录迁移（安全增量）===');
  try {
    for (const t of TABLES) {
      await conn.query(t.sql);
      console.log('  ✓ 表就绪: ' + t.name);
    }
    // 幂等补充列（兼容已手工建表的情况）
    await addColumn(conn, 'registration_otp', 'otp_plain_tmp', 'VARCHAR(12) NULL');
    await addColumn(conn, 'registration_otp', 'sent_by', 'INT UNSIGNED NULL');
    await addIndex(conn, 'registration_otp', 'idx_created_ip', 'INDEX idx_created_ip (created_ip, created_at)');
    console.log('=== 002 完成 ===');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

main();