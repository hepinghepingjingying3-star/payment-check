// ============================================
// 26牛牛 - 迁移 005：充值 / 提款订单扩展 + 推广奖励 Ledger
// ============================================
// 运行方式: node database/migrations/005-funds-referral.js
// 安全原则:
//   - 只做「新增列 / 扩展枚举 / 新增表 / 新增索引」
//   - 不 DROP、不 DELETE、不改动任何现有行的业务数据
//   - 可重复执行（幂等）
// ============================================

require('dotenv').config();
const { hasTable, hasColumn, hasIndex, addColumn, addIndex, connect } = require('./_helper');

async function main() {
  const conn = await connect();
  try {
    console.log('== 005 充值/提款订单扩展 + 推广奖励 ==');

    if (!(await hasTable(conn, 'wallet_orders'))) {
      console.log('!! wallet_orders 不存在，请先运行 database/migrate-v3.js');
      process.exitCode = 1;
      return;
    }

    // ---------- 1. 状态枚举扩展（保留历史值，不丢数据） ----------
    await conn.query(
      `ALTER TABLE wallet_orders MODIFY COLUMN status
       ENUM('PENDING','PROCESSING','COMPLETED','REJECTED','CANCELLED','PENDING_PAYMENT','PENDING_REVIEW','APPROVED')
       NOT NULL DEFAULT 'PENDING_PAYMENT' COMMENT '订单状态：充值 PENDING_PAYMENT→PENDING_REVIEW→APPROVED/REJECTED；提款 PENDING→PROCESSING→APPROVED/REJECTED'`
    );
    console.log('  ✓ wallet_orders.status 枚举已扩展');

    // ---------- 2. 新增列 ----------
    await addColumn(conn, 'wallet_orders', 'account_type',
      "VARCHAR(40) NULL COMMENT '提款收款方式类型（BANK/TNG/DUITNOW/OTHER，测试资料）'");
    await addColumn(conn, 'wallet_orders', 'account_reference',
      "VARCHAR(120) NULL COMMENT '提款收款账号/参考（测试资料）'");
    await addColumn(conn, 'wallet_orders', 'voucher_path',
      "VARCHAR(255) NULL COMMENT '充值凭证存储相对路径（非公开目录，仅管理员可查看）'");
    await addColumn(conn, 'wallet_orders', 'voucher_uploaded_at',
      "DATETIME NULL COMMENT '凭证提交时间'");
    await addColumn(conn, 'wallet_orders', 'payer_remark',
      "VARCHAR(255) NULL COMMENT '用户填写的转账备注（测试）'");
    await addColumn(conn, 'wallet_orders', 'before_balance',
      "DECIMAL(20,2) NULL COMMENT '审核通过前余额快照'");
    await addColumn(conn, 'wallet_orders', 'after_balance',
      "DECIMAL(20,2) NULL COMMENT '审核通过后余额快照'");
    await addColumn(conn, 'wallet_orders', 'review_reason',
      "VARCHAR(255) NULL COMMENT '审核说明（拒绝原因/备注，供用户端展示安全文案）'");

    // ---------- 3. 索引（订单号唯一 + 列表检索） ----------
    await addIndex(conn, 'wallet_orders', 'uk_wallet_order_no',
      "UNIQUE KEY uk_wallet_order_no (order_no)");
    await addIndex(conn, 'wallet_orders', 'idx_wallet_order_status',
      "INDEX idx_wallet_order_status (order_type, status, created_at)");
    await addIndex(conn, 'wallet_orders', 'idx_wallet_order_user',
      "INDEX idx_wallet_order_user (user_id, created_at)");

    // ---------- 4. 推广奖励 Ledger ----------
    if (await hasTable(conn, 'referral_rewards')) {
      console.log('  · referral_rewards 已存在，跳过建表');
    } else {
      await conn.query(
        `CREATE TABLE referral_rewards (
          id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '奖励ID',
          user_id        INT UNSIGNED NOT NULL COMMENT '获得奖励的用户',
          source_user_id INT UNSIGNED NULL COMMENT '产生奖励的来源用户',
          level          TINYINT NOT NULL COMMENT '0=自身游戏奖励 1=直属 2=二级',
          rate           DECIMAL(6,3) NOT NULL COMMENT '奖励比例（百分比，来自 config/referral.js）',
          base_amount    DECIMAL(20,2) NOT NULL COMMENT '奖励计算基数（测试资产金额）',
          reward_amount  DECIMAL(20,2) NOT NULL COMMENT '奖励金额（测试资产）',
          asset_type     VARCHAR(20) NOT NULL DEFAULT 'CASH_CHIPS' COMMENT '奖励资产类型（非现金化测试资产）',
          status         ENUM('PENDING','CREDITED','VOID') NOT NULL DEFAULT 'PENDING',
          source_type    VARCHAR(30) NOT NULL DEFAULT 'DEPOSIT' COMMENT '来源类型（DEPOSIT 等）',
          source_ref     VARCHAR(64) NULL COMMENT '来源单号（如充值订单号）',
          unique_key     VARCHAR(160) NOT NULL COMMENT '幂等键，防止重复奖励',
          remark         VARCHAR(255) NULL,
          operator_id    INT UNSIGNED NULL COMMENT '发放/结算管理员',
          created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          credited_at    DATETIME NULL COMMENT '入账时间',
          UNIQUE KEY uk_referral_reward (unique_key),
          KEY idx_reward_user (user_id, created_at),
          KEY idx_reward_status (status, created_at),
          KEY idx_reward_source (source_type, source_ref)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='26牛牛 推广奖励台账（非现金化测试资产）'`
      );
      console.log('  ✓ 新建表 referral_rewards');
    }

    // ---------- 5. 统一字符集/排序规则（避免与既有表 JOIN 时 collation 冲突） ----------
    try {
      const [dbInfo] = await conn.query(
        `SELECT DEFAULT_CHARACTER_SET_NAME AS cs, DEFAULT_COLLATION_NAME AS col
         FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = DATABASE()`
      );
      const [tbl] = await conn.query(
        `SELECT TABLE_COLLATION AS col FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = 'referral_rewards'`
      );
      const want = dbInfo[0] && dbInfo[0].col;
      const now = tbl[0] && tbl[0].col;
      if (want && now && want !== now) {
        await conn.query(
          `ALTER TABLE referral_rewards CONVERT TO CHARACTER SET ${dbInfo[0].cs} COLLATE ${want}`
        );
        console.log('  ✓ referral_rewards 排序规则对齐为 ' + want);
      } else {
        console.log('  · referral_rewards 排序规则已一致（' + now + '）');
      }
    } catch (e) {
      console.log('  ! 排序规则检查失败（不影响功能）: ' + e.message);
    }

    console.log('\n005 完成（未删除任何数据）');
  } finally {
    await conn.end();
  }
}

main().catch(err => {
  console.error('迁移 005 失败:', err.message);
  process.exitCode = 1;
});
