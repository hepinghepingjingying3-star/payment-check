'use strict';
// ============================================
// 迁移 017：后台收款账户管理 + 充值订单收款账户分配
// ============================================
// 说明:
//   - 只做「安全增量」：新增表 / 新增列 / 新增索引，绝不 DROP、绝不删除任何用户或订单数据
//   - 收款账户全部存数据库（不写死前端），充值订单创建时分配并快照到订单，订单创建后固定不变
//   - 历史订单（本阶段之前创建的）会在有可用账户时补齐快照，保证旧订单也能显示收款账户
//   - 不接入任何真实支付网关，只用于「用户线下转账 + 管理员人工审核」的信息展示
// 运行：node database/migrations/017-recharge-receiving-accounts.js
require('dotenv').config();
const { addColumn, addIndex, hasTable, connect } = require('./_helper');

const SNAPSHOT_COLUMNS = [
  ['receiving_account_id', "INT UNSIGNED NULL COMMENT '分配的收款账户ID（创建订单时固定）'"],
  ['receiving_account_type', "VARCHAR(20) NULL COMMENT '收款方式快照 BANK/EWALLET'"],
  ['receiving_account_name', "VARCHAR(100) NULL COMMENT '收款银行/电子钱包名称快照'"],
  ['receiving_account_holder', "VARCHAR(100) NULL COMMENT '收款户名快照'"],
  ['receiving_account_no', "VARCHAR(120) NULL COMMENT '收款账号/钱包号码快照'"],
  ['payment_reference', "VARCHAR(40) NULL COMMENT '付款参考编号'"],
  ['admin_remark', "VARCHAR(255) NULL COMMENT '管理员审核备注'"]
];

async function main() {
  const conn = connect();
  try {
    // ---------- 1. 收款账户表 ----------
    if (!(await hasTable(conn, 'recharge_receiving_accounts'))) {
      await conn.query(`CREATE TABLE recharge_receiving_accounts (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        account_type VARCHAR(20) NOT NULL DEFAULT 'BANK' COMMENT 'BANK 银行 / EWALLET 电子钱包',
        account_name VARCHAR(100) NOT NULL COMMENT '银行或电子钱包名称',
        holder_name VARCHAR(100) NOT NULL COMMENT '户名',
        account_no VARCHAR(120) NOT NULL COMMENT '账号 / 钱包号码',
        remark VARCHAR(255) NULL COMMENT '备注（仅管理员可见）',
        is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 启用 / 0 停用',
        sort_order INT NOT NULL DEFAULT 0 COMMENT '排序（越小越靠前）',
        created_by INT UNSIGNED NULL,
        updated_by INT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_receiving_active_sort (is_active, sort_order, id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
      console.log('  ✓ 新建 recharge_receiving_accounts');
    } else {
      console.log('  · recharge_receiving_accounts 已存在，跳过建表');
    }

    // ---------- 2. 充值订单收款账户快照列 ----------
    if (!(await hasTable(conn, 'recharge_orders'))) {
      console.log('  ! recharge_orders 不存在（充值模块未初始化），跳过列变更');
      return;
    }
    for (const [col, def] of SNAPSHOT_COLUMNS) {
      await addColumn(conn, 'recharge_orders', col, def);
    }
    await addIndex(conn, 'recharge_orders', 'idx_recharge_orders_account',
      "INDEX idx_recharge_orders_account (receiving_account_id)");
    await addIndex(conn, 'recharge_orders', 'uq_recharge_payment_reference',
      "UNIQUE INDEX uq_recharge_payment_reference (payment_reference)");

    // ---------- 3. 兼容迁移：把旧的系统设置收款资料转成第一条账户 ----------
    // 仅当账户表为空，且历史 system_settings 中确实配置过收款资料时才迁移（不伪造数据）
    const [acCount] = await conn.query('SELECT COUNT(*) AS c FROM recharge_receiving_accounts');
    if (Number(acCount[0] && acCount[0].c) === 0) {
      if (await hasTable(conn, 'system_settings')) {
        const [rows] = await conn.query(
          "SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('receiving_bank_name','receiving_account_number','receiving_account_holder')"
        );
        const map = {};
        rows.forEach(r => { map[r.setting_key] = String(r.setting_value == null ? '' : r.setting_value).replace(/^"|"$/g, ''); });
        const bankName = (map.receiving_bank_name || '').trim();
        const accountNo = (map.receiving_account_number || '').trim();
        const holder = (map.receiving_account_holder || '').trim();
        if (bankName && accountNo && holder) {
          await conn.query(
            "INSERT INTO recharge_receiving_accounts (account_type, account_name, holder_name, account_no, remark, is_active, sort_order) VALUES ('BANK', ?, ?, ?, ?, 1, 0)",
            [bankName.slice(0, 100), holder.slice(0, 100), accountNo.slice(0, 120), '由历史系统设置迁移']
          );
          console.log('  ✓ 已把历史系统设置中的收款资料迁移为第 1 个收款账户（请到后台核对/补充）');
        } else {
          console.log('  · 历史未配置收款资料，账户表保持为空（请到后台「收款账户」添加）');
        }
      }
    }

    // ---------- 4. 历史充值订单补齐收款账户快照 ----------
    const [need] = await conn.query(
      'SELECT COUNT(*) AS c FROM recharge_orders WHERE receiving_account_id IS NULL'
    );
    if (Number(need[0] && need[0].c) > 0) {
      const [first] = await conn.query(
        'SELECT id, account_type, account_name, holder_name, account_no FROM recharge_receiving_accounts WHERE is_active = 1 ORDER BY sort_order ASC, id ASC LIMIT 1'
      );
      if (first[0]) {
        const a = first[0];
        const [upd] = await conn.query(
          `UPDATE recharge_orders
             SET receiving_account_id = ?, receiving_account_type = ?, receiving_account_name = ?,
                 receiving_account_holder = ?, receiving_account_no = ?
           WHERE receiving_account_id IS NULL`,
          [a.id, a.account_type, a.account_name, a.holder_name, a.account_no]
        );
        console.log('  ✓ 历史充值订单已补齐收款账户快照：' + Number(upd.affectedRows) + ' 条（订单内容不会被改写）');
      } else {
        console.log('  · 当前没有启用中的收款账户，历史订单暂不补齐（后台启用账户后可重新执行本迁移）');
      }
    } else {
      console.log('  · 所有充值订单均已分配收款账户，跳过补齐');
    }

    console.log('=== 收款账户与充值分配迁移完成（未删除任何数据） ===');
  } catch (err) {
    console.error('017 迁移失败:', err.message);
    process.exitCode = 1;
  } finally {
    await conn.end().catch(() => {});
  }
}

main();
