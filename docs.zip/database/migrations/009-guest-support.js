/* 009-guest-support.js — 游客客服 + 管理员回复可见性
 * 幂等，可重复执行；只新增列/表，不删除、不修改任何现有数据。
 * 用法：node database/migrations/009-guest-support.js
 */
require('dotenv').config();
const mysql = require('mysql2/promise');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || process.env.DB_USERNAME || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || process.env.DB_DATABASE,
  });

  const hasCol = async (table, col) => {
    const [rows] = await conn.query(
      'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
      [table, col]
    );
    return rows[0].c > 0;
  };
  const hasTable = async (table) => {
    const [rows] = await conn.query(
      'SELECT COUNT(*) AS c FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?',
      [table]
    );
    return rows[0].c > 0;
  };

  try {
    if (!(await hasCol('chat_messages', 'guest_token'))) {
      await conn.query("ALTER TABLE chat_messages ADD COLUMN guest_token VARCHAR(64) NULL AFTER content");
      console.log('+ chat_messages.guest_token');
    } else {
      console.log('= chat_messages.guest_token 已存在');
    }

    if (!(await hasCol('chat_messages', 'sender_role'))) {
      await conn.query("ALTER TABLE chat_messages ADD COLUMN sender_role VARCHAR(20) NOT NULL DEFAULT 'user' AFTER guest_token");
      console.log('+ chat_messages.sender_role');
    } else {
      console.log('= chat_messages.sender_role 已存在');
    }

    // 不改写历史消息：旧消息继续按原有字段读取，新游客消息明确写入 guest / admin 角色。
    // 这样迁移只新增结构，不对现有用户数据执行批量 UPDATE。

    // 会话状态表：仅记录管理员显式 关闭/重开 的线程；未记录的线程视为 open。
    if (!(await hasTable('support_threads'))) {
      await conn.query(`CREATE TABLE support_threads (
        thread_key VARCHAR(80) NOT NULL PRIMARY KEY,
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        updated_by BIGINT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4`);
      console.log('+ support_threads');
    } else {
      console.log('= support_threads 已存在');
    }

    console.log('009-guest-support OK');
  } finally {
    await conn.end();
  }
})().catch((e) => {
  console.error('009-guest-support FAILED:', e.message);
  process.exit(1);
});
