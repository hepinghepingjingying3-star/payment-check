'use strict';
// 正式提款模块兼容迁移（只新增，不删除任何用户、钱包、充值或提款数据）。
// 运行：node database/migrations/016-withdrawals-final.js
require('dotenv').config();
const { addColumn, addIndex, hasTable, connect } = require('./_helper');

async function main() {
  const conn = connect();
  try {
    if (!(await hasTable(conn, 'withdraw_requests'))) {
      await conn.query(`CREATE TABLE withdraw_requests (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        order_id VARCHAR(40) NOT NULL UNIQUE,
        withdrawal_id VARCHAR(40) NULL,
        user_id INT UNSIGNED NOT NULL,
        amount DECIMAL(20,2) NOT NULL,
        currency VARCHAR(20) NOT NULL DEFAULT 'CASH_CHIPS',
        account_type VARCHAR(40) NOT NULL DEFAULT 'BANK',
        account_name VARCHAR(60) NULL,
        account_ref VARCHAR(120) NULL,
        recipient_name VARCHAR(60) NULL,
        bank_name VARCHAR(100) NULL,
        bank_account VARCHAR(120) NULL,
        status ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
        operator_id INT UNSIGNED NULL,
        admin_remark VARCHAR(255) NULL,
        approved_at DATETIME NULL,
        rejected_at DATETIME NULL,
        completed_at DATETIME NULL,
        idempotency_key VARCHAR(80) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_withdraw_user_time (user_id, created_at),
        INDEX idx_withdraw_status_time (status, created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
      console.log('  ✓ 新建 withdraw_requests');
    } else {
      await addColumn(conn, 'withdraw_requests', 'withdrawal_id', "VARCHAR(40) NULL COMMENT '正式唯一提款订单号'");
      await addColumn(conn, 'withdraw_requests', 'recipient_name', "VARCHAR(60) NULL COMMENT '收款人姓名快照'");
      await addColumn(conn, 'withdraw_requests', 'bank_name', "VARCHAR(100) NULL COMMENT '银行名称快照'");
      await addColumn(conn, 'withdraw_requests', 'bank_account', "VARCHAR(120) NULL COMMENT '银行账号快照（仅本人/管理员可读）'");
      await addColumn(conn, 'withdraw_requests', 'operator_id', 'INT UNSIGNED NULL');
      await addColumn(conn, 'withdraw_requests', 'admin_remark', 'VARCHAR(255) NULL');
      await addColumn(conn, 'withdraw_requests', 'approved_at', 'DATETIME NULL');
      await addColumn(conn, 'withdraw_requests', 'rejected_at', 'DATETIME NULL');
      await addColumn(conn, 'withdraw_requests', 'idempotency_key', "VARCHAR(80) NULL COMMENT '用户范围请求幂等键'");
      await conn.query("UPDATE withdraw_requests SET withdrawal_id=order_id WHERE withdrawal_id IS NULL OR withdrawal_id=''");
      await conn.query("UPDATE withdraw_requests SET recipient_name=account_name WHERE recipient_name IS NULL AND account_name IS NOT NULL");
      await conn.query("UPDATE withdraw_requests SET bank_account=account_ref WHERE bank_account IS NULL AND account_ref IS NOT NULL");
    }

    await addColumn(conn, 'users', 'bank_name', "VARCHAR(100) NULL COMMENT '本人收款银行名称'");
    await addColumn(conn, 'users', 'bank_account', "VARCHAR(120) NULL COMMENT '本人收款银行账号（仅本人/管理员可读）'");
    await addIndex(conn, 'withdraw_requests', 'uq_withdrawal_id', 'UNIQUE INDEX uq_withdrawal_id (withdrawal_id)');
    await addIndex(conn, 'withdraw_requests', 'uq_withdraw_user_idempotency', 'UNIQUE INDEX uq_withdraw_user_idempotency (user_id, idempotency_key)');

    if (!(await hasTable(conn, 'audit_logs'))) {
      await conn.query(`CREATE TABLE audit_logs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        operator_id INT UNSIGNED NOT NULL,
        action VARCHAR(64) NOT NULL,
        target_id INT UNSIGNED NULL,
        reason VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_audit_action_time (action, created_at),
        INDEX idx_audit_target_time (target_id, created_at),
        INDEX idx_audit_operator_time (operator_id, created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='敏感业务审计日志'`);
      console.log('  ✓ 新建 audit_logs');
    }
    console.log('=== 提款正式兼容迁移完成 ===');
  } finally {
    await conn.end();
  }
}
main().catch(err => { console.error('提款迁移失败:', err.message); process.exit(1); });
