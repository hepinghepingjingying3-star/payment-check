'use strict';
require('dotenv').config();
const bcryptjs = require('bcryptjs');
const mysql = require('mysql2/promise');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || '26niuniu'
  });

  const hashed = bcryptjs.hashSync('26niuniu_#TANHONDEE', 12);
  const [result] = await conn.query(
    'UPDATE users SET password_hash = ? WHERE username = ?',
    [hashed, '37491058']
  );

  console.log('Updated rows:', result.affectedRows);
  console.log('New hash:', hashed);

  await conn.end();
})().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});