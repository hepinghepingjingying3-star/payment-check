// ============================================
// 26牛牛 - 推广系统数据库迁移
// 添加 invite_code（推广码）与 invited_by（邀请人）字段
// 运行方式: node database/migrate-promote.js
// ============================================

require('dotenv').config();
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  multipleStatements: true
});

async function main() {
  console.log('执行推广系统迁移...');
  try {
    // 检查并添加 invite_code
    const [cols] = await connection.promise().query(
      `SELECT COLUMN_NAME FROM information_schema.columns WHERE table_schema = ? AND table_name = 'users' AND column_name = 'invite_code'`,
      [process.env.DB_NAME]
    );
    if (cols.length === 0) {
      await connection.promise().query(
        `ALTER TABLE users ADD COLUMN invite_code VARCHAR(20) NULL UNIQUE COMMENT '推广码' AFTER nickname`
      );
      console.log('已添加 invite_code');
    } else {
      console.log('invite_code 已存在，跳过');
    }

    const [cols2] = await connection.promise().query(
      `SELECT COLUMN_NAME FROM information_schema.columns WHERE table_schema = ? AND table_name = 'users' AND column_name = 'invited_by'`,
      [process.env.DB_NAME]
    );
    if (cols2.length === 0) {
      await connection.promise().query(
        `ALTER TABLE users ADD COLUMN invited_by INT UNSIGNED NULL COMMENT '邀请人用户ID' AFTER invite_code,
         ADD INDEX idx_invited_by (invited_by)`
      );
      console.log('已添加 invited_by');
    } else {
      console.log('invited_by 已存在，跳过');
    }

    // 为已有用户生成推广码（N + 100000 + id）
    const [users] = await connection.promise().query(
      `SELECT id FROM users WHERE invite_code IS NULL`
    );
    for (const u of users) {
      const code = 'N' + String(100000 + u.id);
      await connection.promise().query(
        `UPDATE users SET invite_code = ? WHERE id = ?`,
        [code, u.id]
      );
    }
    console.log('已为', users.length, '个用户生成推广码');
    console.log('迁移完成');
    process.exit(0);
  } catch (err) {
    console.error('迁移失败:', err.message);
    process.exit(1);
  }
}

main();