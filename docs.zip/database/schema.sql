-- ============================================
-- 26牛牛 - 数据库初始化脚本
-- 运行方式: node database/setup.js
-- 这个文件定义了数据库和所有数据表的结构
-- ============================================

-- 创建数据库（如果不存在）
-- 注意: 数据库名以数字开头，必须使用反引号 ` 包裹
CREATE DATABASE IF NOT EXISTS `26niuniu`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- 切换到 26niuniu 数据库
USE `26niuniu`;

-- ============================================
-- 用户表 users
-- 说明:
--   - password_hash 存储的是 bcrypt 哈希值，绝不存储明文密码
--   - role 角色: user=普通用户, admin=管理员, support=客服
--   - status 状态: active=正常, banned=封禁, deleted=已删除
--   - real_name 姓名（注册时必填，用于人工客服身份核验和实名认证）
--   - game_balance 游戏余额（DECIMAL，虚拟资产）
--   - cash_chips 现金筹码（DECIMAL，系统内虚拟资产）
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID（自增主键）',
  username              VARCHAR(50)  NOT NULL UNIQUE COMMENT '用户名（唯一）',
  nickname              VARCHAR(32) NULL COMMENT '公开昵称，不改变登录用户名',
  avatar_url            VARCHAR(255) NULL COMMENT '个人头像站内路径',
  email                 VARCHAR(100) UNIQUE COMMENT '邮箱（唯一，可空）',
  phone                 VARCHAR(20)  UNIQUE COMMENT '手机号（唯一，可空）',
  real_name             VARCHAR(50)  NOT NULL COMMENT '姓名（注册必填，用于人工客服身份核验和实名认证）',
  password_hash         VARCHAR(255) NOT NULL COMMENT '密码哈希值（bcrypt 加密，禁止明文）',
  role                  ENUM('user', 'admin', 'support') NOT NULL DEFAULT 'user' COMMENT '角色: user=普通用户, admin=管理员, support=客服',
  status                ENUM('active', 'banned', 'deleted') NOT NULL DEFAULT 'active' COMMENT '状态: active=正常, banned=封禁, deleted=已删除',
  game_balance          DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '游戏余额（虚拟资产）',
  cash_chips            DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '现金筹码（系统内虚拟资产）',
  created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（自动）',
  updated_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间（自动）'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ============================================
-- 管理员/客服操作日志表 admin_logs
-- 说明:
--   - 记录客服/管理员的关键操作（账号定位、密码重置等）
--   - 日志中绝对不能记录用户的原密码或新密码
-- ============================================
CREATE TABLE IF NOT EXISTS admin_logs (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '日志ID（自增主键）',
  admin_id      INT UNSIGNED NOT NULL COMMENT '操作的管理员/客服用户ID',
  target_user_id INT UNSIGNED NULL COMMENT '目标用户ID（被操作的用户）',
  action        VARCHAR(50) NOT NULL COMMENT '操作类型（如: account_lookup, password_reset）',
  detail        TEXT NULL COMMENT '操作详情（JSON格式，不包含密码）',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间（自动）',
  INDEX idx_admin_id (admin_id),
  INDEX idx_target_user_id (target_user_id),
  INDEX idx_action (action),
  CONSTRAINT fk_admin_logs_admin FOREIGN KEY (admin_id) REFERENCES users(id),
  CONSTRAINT fk_admin_logs_target FOREIGN KEY (target_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员/客服操作日志表';

-- ============================================
-- 余额交易记录表 balance_transactions
-- 说明:
--   - 记录每一次余额变化（游戏余额和现金筹码）
--   - 使用 DECIMAL 存储金额，禁止 FLOAT/DOUBLE
--   - 每次变化必须记录 balance_before、balance_after、amount、type、reason、operator_id
--   - currency_type: GAME_BALANCE=游戏余额, CASH_CHIPS=现金筹码
--   - type: ADMIN_GRANT=管理员发放, DEPOSIT=充值, WITHDRAW=提现, EXCHANGE=兑换, GAME_BET=下注, GAME_WIN=游戏赢, GAME_LOSE=游戏输
-- ============================================
CREATE TABLE IF NOT EXISTS balance_transactions (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '交易ID（自增主键）',
  user_id         INT UNSIGNED NOT NULL COMMENT '用户ID',
  currency_type   ENUM('GAME_BALANCE', 'CASH_CHIPS') NOT NULL COMMENT '货币类型: GAME_BALANCE=游戏余额, CASH_CHIPS=现金筹码',
  amount          DECIMAL(20,2) NOT NULL COMMENT '变化金额（正数=增加，负数=减少）',
  balance_before  DECIMAL(20,2) NOT NULL COMMENT '变化前余额',
  balance_after   DECIMAL(20,2) NOT NULL COMMENT '变化后余额',
  type            VARCHAR(30) NOT NULL COMMENT '交易类型（ADMIN_GRANT/DEPOSIT/WITHDRAW/EXCHANGE/GAME_BET/GAME_WIN/GAME_LOSE）',
  reason          VARCHAR(255) NULL COMMENT '原因/备注',
  operator_id     INT UNSIGNED NULL COMMENT '操作者ID（管理员发放时为管理员ID，系统操作为NULL）',
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '交易时间（自动）',
  INDEX idx_user_id (user_id),
  INDEX idx_currency_type (currency_type),
  INDEX idx_type (type),
  INDEX idx_created_at (created_at),
  CONSTRAINT fk_balance_tx_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_balance_tx_operator FOREIGN KEY (operator_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='余额交易记录表';
