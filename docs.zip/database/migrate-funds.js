'use strict';
// 阶段 12/13 资金审核流增量迁移：只新增列 / 补表，绝不 DROP / DELETE / 修改现有数据。
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { hasTable, addColumn, connect } = require('./migrations/_helper');

const REPORT = path.join(__dirname, '..', 'tests', 'funds-migration-report.json');

async function main() {
  const conn = connect();
  const added = [];
  try {
    if (!(await hasTable(conn, 'wallet_orders'))) {
      await conn.query(`CREATE TABLE IF NOT EXISTS wallet_orders (
        id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '订单ID',
        user_id       INT UNSIGNED NOT NULL COMMENT '用户ID',
        order_no      VARCHAR(32) NOT NULL UNIQUE COMMENT '订单号',
        order_type    ENUM('DEPOSIT','WITHDRAW') NOT NULL COMMENT '类型: 充值/提现',
        currency_type ENUM('GAME_BALANCE','CASH_CHIPS') NOT NULL DEFAULT 'CASH_CHIPS' COMMENT '货币类型',
        amount        DECIMAL(20,2) NOT NULL COMMENT '金额（RM 计价，测试环境）',
        method        VARCHAR(20) NOT NULL COMMENT '渠道标记（不接真实支付）',
        account       VARCHAR(120) NULL COMMENT '收款账号（测试信息）',
        status        ENUM('PENDING','PROCESSING','COMPLETED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING' COMMENT '状态',
        remark        VARCHAR(255) NULL COMMENT '用户备注',
        reviewed_by   INT UNSIGNED NULL COMMENT '审核管理员ID',
        reviewed_at   DATETIME NULL COMMENT '审核时间',
        reject_reason VARCHAR(255) NULL COMMENT '拒绝原因',
        admin_note    VARCHAR(255) NULL COMMENT '管理员备注',
        created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
        INDEX idx_user (user_id, created_at),
        INDEX idx_status (status, created_at),
        CONSTRAINT fk_wo_user FOREIGN KEY (user_id) REFERENCES users(id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='钱包充值/提现订单表'`);
      added.push('wallet_orders(table)');
      console.log('  ✓ 补建 wallet_orders 表');
    }
    for (const [col, def] of [
      ['reviewed_by', "INT UNSIGNED NULL COMMENT '审核管理员ID'"],
      ['reviewed_at', "DATETIME NULL COMMENT '审核时间'"],
      ['reject_reason', "VARCHAR(255) NULL COMMENT '拒绝原因'"],
      ['admin_note', "VARCHAR(255) NULL COMMENT '管理员备注'"]
    ]) {
      if (await addColumn(conn, 'wallet_orders', col, def)) added.push('wallet_orders.' + col);
    }
    if (await addColumn(conn, 'balance_transactions', 'related_request_id',
      "INT UNSIGNED NULL COMMENT '关联钱包订单ID'")) {
      added.push('balance_transactions.related_request_id');
    }
    const [cols] = await conn.query(
      'SELECT COLUMN_NAME AS c FROM information_schema.columns WHERE table_schema = ? AND table_name = ?',
      [process.env.DB_NAME, 'wallet_orders']
    );
    const names = cols.map(x => x.c || x.COLUMN_NAME);
    const need = ['order_no', 'order_type', 'currency_type', 'amount', 'method', 'account', 'status',
      'remark', 'reviewed_by', 'reviewed_at', 'reject_reason', 'admin_note'];
    const missing = need.filter(n => !names.includes(n));
    if (missing.length) throw new Error('wallet_orders 缺少列: ' + missing.join(','));
    fs.writeFileSync(REPORT, JSON.stringify({ passed: true, added, checkedAt: new Date().toISOString() }, null, 2));
    console.log('FUNDS_MIGRATION_PASS');
    process.exit(0);
  } catch (e) {
    fs.writeFileSync(REPORT, JSON.stringify({ passed: false, error: e.message, added, checkedAt: new Date().toISOString() }, null, 2));
    console.error('FUNDS_MIGRATION_FAIL: ' + e.message);
    process.exit(1);
  } finally {
    await conn.end().catch(() => {});
  }
}
main();
