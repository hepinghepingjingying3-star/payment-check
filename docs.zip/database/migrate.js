// ============================================
// 26牛牛 - 数据库兼容性迁移脚本
// 运行方式: node database/migrate.js
// ============================================

require('dotenv').config();
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  multipleStatements: true
});

console.log('🔧 正在执行数据库迁移...');

const migrations = [
  {
    name: '添加 real_name 字段到 users 表',
    type: 'column',
    tableName: 'users',
    columnName: 'real_name',
    sql: `ALTER TABLE users ADD COLUMN real_name VARCHAR(50) NOT NULL DEFAULT '' COMMENT '姓名' AFTER phone`
  },
  {
    name: '移除 account_recovery_code 字段（旧账号恢复辅助系统已停用）',
    type: 'remove-column',
    tableName: 'users',
    columnName: 'account_recovery_code',
    sql: `ALTER TABLE users DROP COLUMN account_recovery_code`
  },
  {
    name: '修改 role 字段支持 support 角色',
    type: 'modify',
    sql: `ALTER TABLE users MODIFY COLUMN role ENUM('user', 'admin', 'support') NOT NULL DEFAULT 'user' COMMENT '角色'`
  },
  {
    name: '创建 admin_logs 表',
    type: 'table',
    tableName: 'admin_logs',
    sql: `CREATE TABLE IF NOT EXISTS admin_logs (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      admin_id INT UNSIGNED NOT NULL,
      target_user_id INT UNSIGNED NULL,
      action VARCHAR(50) NOT NULL,
      detail TEXT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_admin_id (admin_id),
      CONSTRAINT fk_admin_logs_admin FOREIGN KEY (admin_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '添加 game_balance 字段到 users 表',
    type: 'column',
    tableName: 'users',
    columnName: 'game_balance',
    sql: `ALTER TABLE users ADD COLUMN game_balance DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '游戏余额' AFTER status`
  },
  {
    name: '添加 cash_chips 字段到 users 表',
    type: 'column',
    tableName: 'users',
    columnName: 'cash_chips',
    sql: `ALTER TABLE users ADD COLUMN cash_chips DECIMAL(20,2) NOT NULL DEFAULT 0.00 COMMENT '现金筹码' AFTER game_balance`
  },
  {
    name: '添加 round_id 字段和索引到 game_rooms 表',
    type: 'column',
    tableName: 'game_rooms',
    columnName: 'round_id',
    sql: `ALTER TABLE game_rooms ADD COLUMN round_id VARCHAR(50) NULL COMMENT '当前游戏局ID（对应 game_rounds.round_id）' AFTER packet_count, ADD INDEX idx_round_id (round_id)`
  },
  {
    name: '创建 balance_transactions 表',
    type: 'table',
    tableName: 'balance_transactions',
    sql: `CREATE TABLE IF NOT EXISTS balance_transactions (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id INT UNSIGNED NOT NULL,
      currency_type ENUM('GAME_BALANCE', 'CASH_CHIPS') NOT NULL,
      amount DECIMAL(20,2) NOT NULL,
      balance_before DECIMAL(20,2) NOT NULL,
      balance_after DECIMAL(20,2) NOT NULL,
      type VARCHAR(30) NOT NULL,
      reason VARCHAR(255) NULL,
      operator_id INT UNSIGNED NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_user_id (user_id),
      CONSTRAINT fk_balance_tx_user FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 game_rooms 表',
    type: 'table',
    tableName: 'game_rooms',
    sql: `CREATE TABLE IF NOT EXISTS game_rooms (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      room_name VARCHAR(100) NOT NULL,
      status ENUM('WAITING','BANKER_BIDDING','BETTING','RED_PACKET','CLAIMING','CALCULATING','SETTLEMENT','ENDED') NOT NULL DEFAULT 'WAITING',
      min_players INT NOT NULL DEFAULT 2,
      max_players INT NOT NULL DEFAULT 10,
      current_players INT NOT NULL DEFAULT 0,
      banker_id INT UNSIGNED NULL,
      banker_bid DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      banker_pool DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      packet_type ENUM('TNG_SIMULATED','PLATFORM') NOT NULL DEFAULT 'PLATFORM',
      packet_count INT NOT NULL DEFAULT 0,
      config JSON NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_status (status),
      INDEX idx_banker (banker_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 game_rounds 表',
    type: 'table',
    tableName: 'game_rounds',
    sql: `CREATE TABLE IF NOT EXISTS game_rounds (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      round_id VARCHAR(50) NOT NULL UNIQUE,
      room_id INT UNSIGNED NOT NULL,
      status ENUM('WAITING','BANKER_BIDDING','BETTING','RED_PACKET','CLAIMING','CALCULATING','SETTLEMENT','ENDED') NOT NULL DEFAULT 'WAITING',
      banker_id INT UNSIGNED NULL,
      banker_bid DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      banker_pool DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      packet_type ENUM('TNG_SIMULATED','PLATFORM') NOT NULL DEFAULT 'PLATFORM',
      result JSON NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_room (room_id),
      INDEX idx_status (status),
      INDEX idx_round_id (round_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 room_players 表',
    type: 'table',
    tableName: 'room_players',
    sql: `CREATE TABLE IF NOT EXISTS room_players (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      room_id INT UNSIGNED NOT NULL,
      round_id VARCHAR(50) NULL,
      user_id INT UNSIGNED NOT NULL,
      role ENUM('BANKER','PLAYER','SPECTATOR') NOT NULL DEFAULT 'SPECTATOR',
      status ENUM('ACTIVE','LEFT','KICKED') NOT NULL DEFAULT 'ACTIVE',
      joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      left_at TIMESTAMP NULL,
      INDEX idx_room (room_id),
      INDEX idx_user (user_id),
      INDEX idx_round (round_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 banker_bids 表',
    type: 'table',
    tableName: 'banker_bids',
    sql: `CREATE TABLE IF NOT EXISTS banker_bids (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      round_id VARCHAR(50) NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      amount DECIMAL(20,2) NOT NULL,
      status ENUM('PENDING','WON','LOST','CANCELLED') NOT NULL DEFAULT 'PENDING',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_round (round_id),
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 player_bets 表',
    type: 'table',
    tableName: 'player_bets',
    sql: `CREATE TABLE IF NOT EXISTS player_bets (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      round_id VARCHAR(50) NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      amount DECIMAL(20,2) NOT NULL,
      status ENUM('PENDING','WON','LOST','CANCELLED') NOT NULL DEFAULT 'PENDING',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_round (round_id),
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 red_packets 表',
    type: 'table',
    tableName: 'red_packets',
    sql: `CREATE TABLE IF NOT EXISTS red_packets (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      packet_id VARCHAR(50) NOT NULL UNIQUE,
      round_id VARCHAR(50) NOT NULL,
      type ENUM('TNG_SIMULATED','PLATFORM') NOT NULL,
      total_amount DECIMAL(20,2) NOT NULL,
      remaining_amount DECIMAL(20,2) NOT NULL,
      packet_count INT NOT NULL,
      status ENUM('ACTIVE','EXPIRED','CLAIMED','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      expired_at TIMESTAMP NULL,
      INDEX idx_round (round_id),
      INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 red_packet_claims 表',
    type: 'table',
    tableName: 'red_packet_claims',
    sql: `CREATE TABLE IF NOT EXISTS red_packet_claims (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      packet_id VARCHAR(50) NOT NULL,
      round_id VARCHAR(50) NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      amount DECIMAL(20,2) NOT NULL,
      claim_order INT NOT NULL,
      point_value INT NULL,
      card_type VARCHAR(20) NULL,
      multiplier DECIMAL(10,2) NULL,
      claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_packet (packet_id),
      INDEX idx_round (round_id),
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建 game_results 表',
    type: 'table',
    tableName: 'game_results',
    sql: `CREATE TABLE IF NOT EXISTS game_results (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      round_id VARCHAR(50) NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      role ENUM('BANKER','PLAYER') NOT NULL,
      packet_amount DECIMAL(20,2) NOT NULL,
      point_value INT NOT NULL,
      card_type VARCHAR(20) NOT NULL,
      multiplier DECIMAL(10,2) NOT NULL,
      is_winner TINYINT(1) NOT NULL DEFAULT 0,
      payout DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      fee DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      net_payout DECIMAL(20,2) NOT NULL DEFAULT 0.00,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_round (round_id),
      INDEX idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
  },
  {
    name: '创建虚拟现金筹码充值订单表 recharge_orders',
    type: 'table',
    tableName: 'recharge_orders',
    sql: `CREATE TABLE IF NOT EXISTS recharge_orders (
      id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '订单ID',
      order_id VARCHAR(40) NOT NULL UNIQUE COMMENT '唯一充值订单号',
      user_id INT UNSIGNED NOT NULL COMMENT '用户ID',
      amount DECIMAL(20,2) NOT NULL COMMENT '充值现金筹码数量',
      currency VARCHAR(20) NOT NULL DEFAULT 'POINTS' COMMENT '现金筹码币种',
      status ENUM('PENDING','COMPLETED','CANCELLED','EXPIRED') NOT NULL DEFAULT 'PENDING' COMMENT '订单状态',
      idempotency_key VARCHAR(64) NOT NULL UNIQUE COMMENT '幂等键',
      operator_id INT UNSIGNED NULL COMMENT '完成/取消订单的管理员ID',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      completed_at DATETIME NULL COMMENT '完成时间',
      INDEX idx_user (user_id, created_at),
      INDEX idx_status (status, created_at),
      CONSTRAINT fk_recharge_user FOREIGN KEY (user_id) REFERENCES users(id),
      CONSTRAINT fk_recharge_operator FOREIGN KEY (operator_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='虚拟现金筹码充值订单表'`
  },
];

function checkColumnExists(tableName, columnName) {
  return new Promise((resolve, reject) => {
    connection.query(
      `SELECT COUNT(*) AS count FROM information_schema.columns WHERE table_schema = ? AND table_name = ? AND column_name = ?`,
      [process.env.DB_NAME, tableName, columnName],
      (err, results) => err ? reject(err) : resolve(results[0].count > 0)
    );
  });
}

function checkTableExists(tableName) {
  return new Promise((resolve, reject) => {
    connection.query(
      `SELECT COUNT(*) AS count FROM information_schema.tables WHERE table_schema = ? AND table_name = ?`,
      [process.env.DB_NAME, tableName],
      (err, results) => err ? reject(err) : resolve(results[0].count > 0)
    );
  });
}

async function runMigrations() {
  for (const m of migrations) {
    try {
      if (m.type === 'column') {
        const exists = await checkColumnExists(m.tableName, m.columnName);
        if (exists) {
          console.log('⏭️  跳过: ' + m.name);
          continue;
        }
      }
      if (m.type === 'remove-column') {
        const exists = await checkColumnExists(m.tableName, m.columnName);
        if (!exists) {
          console.log('⏭️  跳过: ' + m.name);
          continue;
        }
      }
      if (m.type === 'table') {
        const exists = await checkTableExists(m.tableName);
        if (exists) {
          console.log('⏭️  跳过: ' + m.name);
          continue;
        }
      }
      await new Promise((resolve, reject) => {
        connection.query(m.sql, (err) => err ? reject(err) : resolve());
      });
      console.log('✅ ' + m.name);
    } catch (err) {
      console.error('❌ ' + m.name + ' 失败:', err.message);
      connection.end();
      process.exit(1);
    }
  }
  console.log('\n🎉 数据库迁移完成！');
  connection.end();
}

runMigrations();