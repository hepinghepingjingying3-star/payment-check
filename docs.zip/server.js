// 26牛牛 - 服务器入口文件
// 这个文件负责启动后端服务器

// 加载环境变量（读取 .env 文件中的配置）
require('dotenv').config();

// 引入 Express 框架（用于创建 Web 服务器）
const express = require('express');

// 引入 CORS 中间件（允许浏览器跨域访问）
const cors = require('cors');

// 引入数据库连接模块
const db = require('./config/db');

// 引入认证路由
const authRoutes = require('./routes/auth');

// 引入大厅路由
const lobbyRoutes = require('./routes/lobby');

// 引入钱包路由
const walletRoutes = require('./routes/wallet');

// 引入游戏路由（Phase 4C 红包对战）
const gameRoutes = require('./routes/game');

// 引入推广路由
const promoteRoutes = require('./routes/promote');

// 引入 Node.js http 模块（Socket.IO 需要）
const http = require('http');

// 创建 Express 应用实例
const app = express();

// 创建 HTTP 服务器并挂载 Express 应用
const server = http.createServer(app);

// 初始化 Socket.IO（Phase 4C 实时通信）
// 跨域白名单与 HTTP 接口共用同一份配置（config/cors.js）：
// 同源部署时 socketOrigin=false = 不放行任何跨域来源；否则只放行 CORS_ORIGINS 列表。
// 注意：HTTP 与 Socket 必须同一口径，否则网页被收紧而实时通道仍对全网开放。
const socketCors = require('./config/cors').load();
const { Server } = require('socket.io');
const io = new Server(server, {
  cors: {
    // false = 不回 CORS 头，等价于不放行跨域连接（同源部署）
    origin: socketCors.socketOrigin,
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// 初始化游戏 Socket 逻辑（JWT 认证 + 房间频道 + 用户私信通道 + 通知推送）
const gameSocket = require('./socket/gameSocket');
gameSocket.initGameSocket(io);

// 26牛牛娱乐场（非现金化娱乐积分）：状态机引擎 + 实时通道
const niuRoom = require('./utils/niuRoom');
const { initNiuSocket } = require('./socket/niuSocket');
initNiuSocket(io);
niuRoom.init(io);

// 将 io 挂载到 app，供路由内部使用（实时推送）
app.set('io', io);

// 在线状态模块注入 Socket.IO：登记/注销连接，并在封禁时主动断开该账号所有连接
const presence = require('./utils/presence');
presence.init(io);

// 通知实时推送：所有 pushNotification 入库后立即推送给在线用户（通知红点秒变）
require('./utils/content').setNotifyPush((userId, payload) => {
  gameSocket.emitToUser(io, userId, 'notify:new', payload);
});

// 聊天红包过期结算（未领完自动退回发送者）：启动后 15 秒跑一次，之后每 5 分钟一次
const chatRedPacket = require('./utils/chatRedPacket');
const RP_SWEEP_MS = 5 * 60 * 1000;
function sweepExpiredRedPackets() {
  chatRedPacket.expirePackets(50)
    .then(r => { if (r && r.closed) console.log('聊天红包过期结算: 处理 ' + r.closed + ' 个，退回 ' + r.refunded); })
    .catch(() => { /* 失败不影响服务，下个周期重试 */ });
}
const rpSweepTimer = setInterval(sweepExpiredRedPackets, RP_SWEEP_MS);
rpSweepTimer.unref();
setTimeout(sweepExpiredRedPackets, 15 * 1000).unref();

// 中间件配置
// 跨域：按 .env.example 的 CORS_ORIGINS 白名单执行（留空 = 同源部署，不放行跨域）。
// 详见 config/cors.js 的说明——这里从「任何来源都能调」收紧为「只放行白名单」。
app.use(cors(require('./config/cors').corsOptions()));
app.use(express.json());  // 解析 JSON 格式的请求体

// 健康检查：供部署 / 反向代理 / 监控使用（不返回任何敏感信息，也不受维护模式影响）
app.get('/api/health', (req, res) => {
  res.json({ success: true, data: { status: 'ok', time: new Date().toISOString(), uptime: Math.round(process.uptime()) } });
});

require('./middleware/admin-boundary')(app);

// 健康检查：/api/health（部署探针 + npm test 在线探测用）
// 必须早于维护模式中间件，保证维护期间监控仍能拿到状态
app.use('/api', require('./routes/health'));

// 维护模式（阶段 36）：数据库开关，管理员 / 客服不受影响
require('./middleware/maintenance')(app);

// 静态文件服务：将 public 文件夹中的文件（如 index.html）提供给浏览器
// 使用绝对路径，避免从不同工作目录启动时找不到文件导致“无法获取”
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));

// API 路由（认证、用户公开资料、客服查询）
app.use('/api', authRoutes);
app.use('/api', require('./routes/recovery'));
app.use('/api', require('./routes/profile'));

// 大厅路由（Phase 4A）
app.use('/api', lobbyRoutes);

// 钱包路由（Phase 4B）
app.use('/api', walletRoutes);

// 26牛牛娱乐场路由（必须先于旧红包对战路由挂载，避免 /game/:id 抢占）
app.use('/api', require('./routes/niu'));

// 游戏路由（Phase 4C 红包对战）
app.use('/api', gameRoutes);

// 推广路由
app.use('/api', promoteRoutes);

// 聊天路由（游戏群 + 在线客服）
const chatRoutes = require('./routes/chat');
app.use('/api', chatRoutes);

// ============================================
// V4 平台模块路由（每个模块单独文件，避免全部逻辑塞进 server.js）
// ============================================
const homeRoutes = require('./routes/home');                 // 大厅聚合
const announcementRoutes = require('./routes/announcements'); // 公告
const gameRoutes2 = require('./routes/games');                // 游戏（平台推荐）
const tutorialRoutes = require('./routes/tutorials');         // 玩法教学
const notificationRoutes = require('./routes/notifications'); // 通知中心
const favoriteRoutes = require('./routes/favorites');         // 收藏
const recentRoutes = require('./routes/recent');              // 最近访问
const searchRoutes = require('./routes/search');              // 全局搜索
const assetRoutes = require('./routes/assets');               // 图片资源清单
const otpRoutes = require('./routes/otp');                    // 注册手机号 OTP
const adminOtpRoutes = require('./routes/admin-otp');         // 管理员 OTP 管理
const adminRoutes = require('./routes/admin');               // 管理员后台（统计 / 用户查询）

app.use('/api', homeRoutes);
app.use('/api', announcementRoutes);
app.use('/api', gameRoutes2);
app.use('/api', tutorialRoutes);
app.use('/api', notificationRoutes);
app.use('/api', favoriteRoutes);
app.use('/api', recentRoutes);
app.use('/api', searchRoutes);
app.use('/api', assetRoutes);
app.use('/api', otpRoutes);
app.use('/api', adminOtpRoutes);

// 客服线程路由必须早于 adminRoutes 挂载；adminRoutes 的 /admin 守卫仅允许 admin。
// 这样 support 角色可以访问 /api/admin/support/threads，但仍无法访问其它管理员接口。
app.use('/api', require('./routes/admin-support'));
app.use('/api', adminRoutes);

// ============================================
// 虚拟现金筹码充值订单（内部系统，不接真实支付网关）
// ============================================
app.use('/api', require('./routes/recharge'));
app.use('/api', require('./routes/admin-recharge'));
app.use('/api', require('./routes/withdrawals'));
app.use('/api', require('./routes/transfers'));
app.use('/api', require('./routes/pay-password'));
app.use('/api', require('./routes/chat-moderation'));

// 官方头像库（用户端只能从后台发布的头像里选择；管理端由 /api/admin/* 保护）
app.use('/api', require('./routes/avatars'));
app.use('/api', require('./routes/admin-avatars'));

// 管理后台扩展：控制台运营统计 / 对局管理 / 游戏入口 / 系统通知 / 管理员 / 客服
// 权限完全复用现有 users.role + admin-boundary，不新建第二套权限系统
app.use('/api', require('./routes/admin-ops'));

// 管理后台：26牛牛娱乐场（状态 / 开关 / 对局 / 积分发放）
app.use('/api', require('./routes/admin-niu'));

// ============================================
// V6 平台优化模块（系统配置中心 / 维护模式 / 客服快捷回复）
// ============================================
const settingsRoutes = require('./routes/settings');
app.use('/api', settingsRoutes);
app.use('/api', require('./routes/admin-search'));

// 游客客服入口（注册/登录前也可咨询）：独立能力令牌隔离会话，
// 与已登录用户的客服频道共用同一消息数据模型，但不会互相读取。
app.use('/api/support/guest', require('./routes/support-guest'));

// ============================================
// 统一错误兜底：/api 404 与未捕获异常（绝不返回 SQL / 堆栈）
// 必须挂在所有路由之后
// ============================================
require('./middleware/errorHandler')(app);

// 进程级兜底：只记录日志，不让未处理的 Promise 拒绝静默吞掉错误
process.on('unhandledRejection', (reason) => {
  console.error('未处理的 Promise 拒绝:', reason && reason.message ? reason.message : reason);
});
process.on('uncaughtException', (err) => {
  console.error('未捕获异常:', err && err.message ? err.message : err);
});

// 测试数据库连接
db.query('SELECT 1', (err) => {
  if (err) {
    console.error('❌ MySQL 数据库连接失败:', err.message);
    console.error('   请检查 .env 文件中的数据库配置是否正确');
    console.error('   并确认 MySQL 服务已启动');
  } else {
    console.log('✅ MySQL 数据库连接成功');
  }
});

// 根路径路由：访问 http://localhost:3000/ 时返回提示信息
app.get('/', (req, res) => {
  res.send('26牛牛 服务器运行中！');
});

// 启动服务器（使用 HTTP 服务器同时支持 HTTP 和 WebSocket）
const PORT = process.env.PORT || 3000;

// 端口被占用时给出可执行的处理办法（否则只会抛一堆看不懂的堆栈）
const portOwner = require('./utils/portOwner');
server.on('error', async (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.error('❌ 端口 ' + PORT + ' 已被占用，26牛牛 未能启动（通常是上一次的服务还在跑）');
    const holders = await portOwner.findListeners(PORT).catch(() => []);
    if (holders.length) {
      holders.forEach(h => {
        console.error('   占用进程: ' + (h.name || '未知进程') + '  PID ' + h.pid +
          '    结束命令: ' + portOwner.killCommand(h.pid));
      });
    } else {
      console.error('   未能查出占用进程，请手动检查: netstat -ano | findstr :' + PORT);
    }
    console.error('   一键重启（结束旧进程 + 用当前代码启动）: npm run restart');
    console.error('   或临时换端口启动: set PORT=3001 && npm start');
    process.exit(1);
    return;
  }
  console.error('❌ 服务器启动失败:', err && err.message ? err.message : err);
  process.exit(1);
});

server.listen(PORT, () => {
  console.log(`🚀 26牛牛 服务器已启动`);
  console.log(`   浏览器访问地址: http://localhost:${PORT}`);
  console.log(`   Socket.IO 实时通信已启用`);
});
