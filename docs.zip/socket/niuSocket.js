'use strict';
// ============================================
// 26牛牛 - 26牛牛娱乐场实时通道
// ============================================
// 说明:
//   - Socket 只做「推送」与「订阅」，所有状态变化仍由服务端状态机驱动
//   - 握手鉴权已由 socket/gameSocket.js 的 io.use 完成，这里再按事件重新校验
//   - 玩家只能订阅配置内的场次 key（白名单），手牌永远只走定向通道
// ============================================

const NG = require('../config/niuGame');
const niu = require('../utils/niuRoom');

function validKey(v) {
  return !!NG.roomByKey(String(v || '').trim().toLowerCase());
}

function initNiuSocket(io) {
  io.on('connection', (socket) => {
    const uid = Number(socket.user && socket.user.id);
    if (!Number.isSafeInteger(uid) || uid <= 0) return;

    // 用户级定向通道：积分变动、个人结算明细
    socket.join('niu:u' + uid);
    let joined = null;

    socket.on('niu:subscribe', async (raw) => {
      const key = String(raw || '').trim().toLowerCase();
      if (!validKey(key)) return;
      try {
        if (!socket.connected) return;
        await socket.join(NG.CHAT.SOCKET_ROOM_PREFIX + key);
        joined = key;
        niu.attachSocket(key, uid, socket.id);
        const st = niu.stateFor(key, uid);
        if (st) socket.emit('niu:state_full', st);
      } catch (e) {
        socket.emit('niu:error', { message: '订阅失败，请重新进入场次' });
      }
    });

    socket.on('niu:unsubscribe', (raw) => {
      const key = String(raw || '').trim().toLowerCase();
      if (!validKey(key)) return;
      socket.leave(NG.CHAT.SOCKET_ROOM_PREFIX + key);
      niu.detachSocket(key, uid, socket.id);
      if (joined === key) joined = null;
    });

    socket.on('disconnecting', () => {
      if (joined) niu.detachSocket(joined, uid, socket.id);
    });
  });
}

module.exports = { initNiuSocket };
