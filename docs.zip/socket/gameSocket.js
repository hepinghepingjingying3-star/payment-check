// ============================================
// 26牛牛 - Socket.IO 实时通信（Phase 4C）
// 说明:
//   - Socket 仅用于实时推送（人数变化、阶段变化、红包事件等）
//   - 所有关键数据以 REST API / 数据库为最终可信来源
//   - 客户端必须通过 JWT 认证后才能连接
// ============================================

const { auth } = require('../middleware/auth');
const db = require('../config/db');
const presence = require('../utils/presence');
/** 聊天频道白名单：只允许加入真实存在的频道 */
const CHAT_CHANNELS = ['group', 'support'];

/** 在线用户 userId → Set<socketId>，用于通知等用户级定向推送 */
const userSockets = new Map();

// Reuse HTTP authentication: current database role/status and login-only JWTs.
async function authenticate(socket) {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  const req = { headers: { authorization: typeof token === 'string' ? 'Bearer ' + token : '' } };
  let accepted = false;
  await auth(req, { status() { return this; }, json() {} }, () => { accepted = true; });
  if (!accepted) throw new Error('认证失败，请重新登录');
  socket.user = req.user;
}

/**
 * 初始化 Socket.IO
 * @param {object} io - Socket.IO 服务器实例
 */
function initGameSocket(io) {
  // JWT 认证中间件（握手时验证）
  io.use((socket, next) => {
    authenticate(socket).then(() => next(), () => next(new Error('认证失败，请重新登录')));
  });

  io.on('connection', (socket) => {
    // 在线状态：登记连接（user_presence.sockets + 1，并刷新 last_seen）
    presence.registerSocket(socket);
    // 用户级定向推送登记：同一账号多端登录时每端都能收到通知
    const uid = Number(socket.user && socket.user.id);
    if (Number.isSafeInteger(uid) && uid > 0) {
      if (!userSockets.has(uid)) userSockets.set(uid, new Set());
      userSockets.get(uid).add(socket.id);
    }
    // Recheck account and membership before every subscription. Never trust a room ID alone.
    socket.on('room:join', async (roomId) => {
      const roomNum = Number(roomId);
      if (!Number.isSafeInteger(roomNum) || roomNum <= 0) return;
      try {
        await authenticate(socket);
        const [rows] = await db.promise().query(
          "SELECT user_id FROM room_players WHERE room_id = ? AND user_id = ? AND status = 'ACTIVE' LIMIT 1",
          [roomNum, socket.user.id]
        );
        if (!rows.length || !socket.connected) return;
        await socket.join(`room:${roomNum}`);
        io.to(`room:${roomNum}`).emit('room:player_online', {
          user_id: socket.user.id, username: socket.user.username
        });
      } catch (_) { socket.disconnect(true); }
    });

    socket.on('room:leave', (roomId) => {
      const roomNum = Number(roomId);
      if (!Number.isSafeInteger(roomNum) || roomNum <= 0 || !socket.rooms.has(`room:${roomNum}`)) return;
      socket.leave(`room:${roomNum}`);
      io.to(`room:${roomNum}`).emit('room:player_offline', {
        user_id: socket.user.id, username: socket.user.username
      });
    });

    // ============================================
    // 聊天频道实时推送：加入 / 离开（group / support）
    // - 每次加入都重新走一次 HTTP 同款鉴权（账号被禁用/封禁立即失效）
    // - 频道白名单校验，绝不允许客户端自选任意房间名
    // - 推送本体仍由 REST 路由内的 io.to('chat:<channel>') 发出
    // ============================================
    socket.on('chat:join', async (channel) => {
      const ch = String(channel || '');
      if (CHAT_CHANNELS.indexOf(ch) === -1) return;
      try {
        await authenticate(socket);
        if (!socket.connected) return;
        await socket.join('chat:' + ch);
        socket.emit('chat:joined', { channel: ch });
      } catch (_) { /* 鉴权失败不加入；15 秒兜底校验会断开失效连接 */ }
    });

    socket.on('chat:leave', (channel) => {
      const ch = String(channel || '');
      if (CHAT_CHANNELS.indexOf(ch) === -1) return;
      socket.leave('chat:' + ch);
    });

    // Bound idle subscriptions after account revocation; clear timer on disconnect.
    const timer = setInterval(() => {
      authenticate(socket).catch(() => socket.disconnect(true));
    }, 15000);
    timer.unref();
    socket.on('disconnect', () => {
      clearInterval(timer);
      // 在线状态：注销连接（user_presence.sockets - 1，并刷新 last_seen）
      presence.unregisterSocket(socket);
      // 用户级推送登记清理，防止 Map 无限增长
      if (Number.isSafeInteger(uid) && uid > 0) {
        const set = userSockets.get(uid);
        if (set) {
          set.delete(socket.id);
          if (!set.size) userSockets.delete(uid);
        }
      }
    });
  });

  console.log('✅ Socket.IO 游戏实时通信已初始化');
}

/**
 * 向指定房间广播游戏阶段变化
 * @param {object} io - Socket.IO 实例
 * @param {number} roomId - 房间ID
 * @param {string} phase - 新阶段
 * @param {object} extra - 附加数据
 */
function emitPhaseChange(io, roomId, phase, extra = {}) {
  io.to(`room:${roomId}`).emit('game:phase_change', { phase, ...extra });
}

/**
 * 向指定房间广播玩家人数变化
 */
function emitPlayerCount(io, roomId, count, maxPlayers) {
  io.to(`room:${roomId}`).emit('room:player_count', { count, max_players: maxPlayers });
}

/**
 * 向指定房间广播红包生成事件
 */
function emitRedPacketCreated(io, roomId, packetInfo) {
  io.to(`room:${roomId}`).emit('redpacket:created', packetInfo);
}

/**
 * 向指定房间广播抢红包结果
 */
function emitRedPacketClaimed(io, roomId, claimInfo) {
  io.to(`room:${roomId}`).emit('redpacket:claimed', claimInfo);
}

/**
 * 向指定房间广播结算结果
 */
function emitSettlement(io, roomId, settlementInfo) {
  io.to(`room:${roomId}`).emit('game:settlement', settlementInfo);
}

/**
 * 向指定房间广播竞标更新
 */
function emitBidUpdate(io, roomId, bidInfo) {
  io.to(`room:${roomId}`).emit('banker:bid_update', bidInfo);
}

/**
 * 向指定房间广播下注更新
 */
function emitBetUpdate(io, roomId, betInfo) {
  io.to(`room:${roomId}`).emit('bet:update', betInfo);
}

/**
 * 向单个用户的全部在线连接推送（通知红点、钱包订单状态变化等）
 * 用户不在线时静默忽略 —— 数据库仍是可信来源，客户端上线后会自行拉取
 */
function emitToUser(io, userId, event, payload) {
  const set = userSockets.get(Number(userId));
  if (!set || !set.size) return 0;
  let n = 0;
  set.forEach(sid => {
    const s = io.sockets.sockets.get(sid);
    if (s) { s.emit(event, payload); n++; }
  });
  return n;
}

/**
 * 向聊天频道推送（服务端内部使用；路由内也可直接 io.to('chat:x')）
 */
function emitToChannel(io, channel, event, payload) {
  if (CHAT_CHANNELS.indexOf(String(channel)) === -1) return;
  io.to('chat:' + channel).emit(event, payload);
}

/** 当前用户是否在线（用于决定是否需要额外提醒渠道） */
function isUserOnline(userId) {
  const set = userSockets.get(Number(userId));
  return !!(set && set.size);
}

module.exports = {
  initGameSocket,
  emitPhaseChange,
  emitPlayerCount,
  emitRedPacketCreated,
  emitRedPacketClaimed,
  emitSettlement,
  emitBidUpdate,
  emitBetUpdate,
  emitToUser,
  emitToChannel,
  isUserOnline
};