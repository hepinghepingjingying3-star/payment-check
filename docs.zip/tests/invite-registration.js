'use strict';
// Actual Express registration route, isolated database and OTP verification fixture.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createRequire } = require('node:module');
const assert = require('node:assert/strict');
const express = require('express');
const root = path.resolve(__dirname, '..');
const report = { mode: 'Real HTTP route; isolated DB and OTP fixture', checks: [], passed: false };
let server;
const relations = [];
let created, assignedInvite, committed = false;
// 注册凭证一次性消费的模拟：同一 otpId 只允许成功消费一次
const consumedOtpIds = new Set();
let consumeAttempted = 0, consumeRejected = 0;
const query = async (sql, p) => {
  if (sql.includes('FOR UPDATE')) {
    // 注意：registration_otp 的行锁也走 FOR UPDATE，必须先于下面的通用邀请人锁判断
    if (sql.includes('registration_otp')) {
      if (consumedOtpIds.has(Number(p[0]))) { consumeRejected += 1; return [[{ id: Number(p[0]), consumed_at: new Date() }]]; }
      return [[{ id: Number(p[0]), consumed_at: null }]];
    }
    return [[{ id: 1, status: 'active', invited_by: 9 }]];
  }
  if (sql.includes('UPDATE registration_otp SET consumed_at')) {
    consumeAttempted += 1;
    if (consumedOtpIds.has(Number(p[0]))) { consumeRejected += 1; return [{ affectedRows: 0 }]; }
    consumedOtpIds.add(Number(p[0]));
    return [{ affectedRows: 1 }];
  }
  if (sql.includes('FROM registration_otp WHERE id = ? AND phone = ?')) {
    // 现实中已消费的行仍然存在，只是 consumed_at 非空（不会被删除）
    const used = consumedOtpIds.has(Number(p[0]));
    return [[{ id: Number(p[0]), status: 'verified', consumed_at: used ? new Date() : null,
      expires_at: new Date(Date.now() + 600000) }]];
  }
  if (sql.includes('WHERE invite_code = ?')) {
    return [[...(p[0] === '3' ? [{ id: 1, status: 'active', username: 'first' }] : [])]];
  }
  if (sql.includes('INSERT INTO users')) { created = p; return [{ insertId: 20 }]; }
  if (sql.includes('UPDATE users SET invite_code')) { assignedInvite = p; return [{ affectedRows: 1 }]; }
  if (sql.includes('INTO referral_relations')) { relations.push(p); return [{ affectedRows: 1 }]; }
  throw Error('Unexpected SQL: ' + sql);
};
const conn = { query, beginTransaction: async () => {}, commit: async () => { committed = true; }, rollback: async () => {}, release() {} };
const db = { promise: () => ({ query, getConnection: async () => conn }) };
const filename = path.join(root, 'routes/auth.js');
const realRequire = createRequire(filename);
const mod = { exports: {} };
const dependencies = {
  '../config/db': db,
  '../utils/otp': {
    // 与真实实现保持一致：返回 { phone, otpId }
    // 每个负面用例用独立的凭证行：真实流程里注册成功后该行已被消费，
    // 复用同一 token 会先命中 OTP_TOKEN_USED，而轮不到后面的字段校验。
    verifyRegisterToken: token => ({
      'fixture-verified': { phone: '+60000000000', otpId: 1 },
      'fixture-pay-mismatch': { phone: '+60000000000', otpId: 2 },
      'fixture-short-pay': { phone: '+60000000000', otpId: 3 },
      'fixture-replay': { phone: '+60000000000', otpId: 1 }   // 与第 1 个相同：专门用于重放验证
    }[String(token || '')] || null),
    secondsLeft: () => 600
  },
  '../utils/content': { pushNotification: async () => {} }
};
vm.runInNewContext(fs.readFileSync(filename, 'utf8'), {
  module: mod, console, process: { env: {} },
  require: name => name in dependencies ? dependencies[name] : realRequire(name)
}, { filename });
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
async function main() {
  const app = express(); app.use(express.json()); app.use('/api', mod.exports);
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = 'http://127.0.0.1:' + server.address().port;
  const body = { username: 'new_player', phone: '+60000000000', email: 'fixture@example.test', real_name: '测试用户', password: 'Fixture123!', confirm_password: 'Fixture123!', pay_password: '123456', confirm_pay_password: '123456', otp_token: 'fixture-verified', invite_code: ' 3 ' };
  const res = await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const result = await res.json();
  report.registration = { status: res.status, message: result.message };
  check('UID inviter registers successfully', res.status === 201 && result.success);
  check('User and two referral levels committed', committed && created[7] === 1 && relations.length === 2 && relations[0][0] === 1 && relations[1][0] === 9);
  check('New random numeric invite is inserted inside transaction', /^[0-9]{8}$/.test(result.data.invite_code) && result.data.invite_code === created[6] && assignedInvite === undefined);
  check('Pay password stored only as bcrypt hash', typeof created[5] === 'string' && created[5].startsWith('$2') && created[5] !== '123456');
  check('Pay password never returned to the client', !JSON.stringify(result).includes('123456'));
  const badPay = await (await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...body, otp_token: 'fixture-pay-mismatch', confirm_pay_password: '654321' }) })).json();
  check('Mismatched pay password rejected', badPay.success === false && badPay.message === '两次支付密码不一致');
  const shortPay = await (await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...body, otp_token: 'fixture-short-pay', pay_password: '123', confirm_pay_password: '123' }) })).json();
  check('Non-6-digit pay password rejected', shortPay.success === false && shortPay.message === '支付密码必须为6位数字');
  const valid = await (await fetch(base + '/api/auth/invite/check?code=3')).json();
  check('UID live validation agrees', valid.data.valid === true);
  // ---------- 注册凭证一次性消费（防重放）----------
  // 同一个 otp_token 第二次使用必须失败：凭证与手机号 OTP 行已绑定并消费过。
  const replay = await (await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...body, otp_token: 'fixture-replay', username: 'replay_attempt' }) })).json();
  report.replayProbe = { replay, consumeRejected, consumeAttempted };
  check('Replayed OTP token cannot register a second account',
    replay.success === false && replay.code === 'OTP_TOKEN_USED',
    { message: replay.message, code: replay.code, consumeRejected, consumeAttempted });
  check('OTP row is consumed exactly once inside the registration transaction', consumedOtpIds.has(1) && consumeAttempted === 1,
    { consumeAttempted, consumeRejected, consumedRows: Array.from(consumedOtpIds) });
  const codes = require('../utils/inviteCode');
  check('Legacy codes rejected after conversion', !codes.isValidInviteCodeFormat('A8K29F'));
  check('UID range enforced', codes.isValidInviteCodeFormat('1') && codes.isValidInviteCodeFormat('4294967295') && !codes.isValidInviteCodeFormat('0') && !codes.isValidInviteCodeFormat('4294967296'));
  check('Invalid format rejected', !codes.isValidInviteCodeFormat('<script>'));
  const html = fs.readFileSync(path.join(root, 'public/register.html'), 'utf8');
  check('Registration no longer stores missing session', !html.includes('App.setSession(res.data.token, res.data.user)') && html.includes("window.location.replace('/login.html')"));
  for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) new vm.Script(match[1]);
  check('Register scripts parse', true);
  report.passed = true;
}
main().catch(e => { report.error = e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'invite-registration-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2)); process.exitCode = report.passed ? 0 : 1;
});
