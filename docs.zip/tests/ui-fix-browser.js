'use strict';
// 真实 Chrome + 生产 HTML/CSS/JS，配合隔离 API fixture，验证本次 UI 修复：
//   1) 输入框 / 下拉框不再出现浏览器默认白底（含自动填充兜底样式）
//   2) 注册页「获取验证码」按钮可见可点，注册按钮有明确的未完成提示
//   3) 「我的」页点击头像可更换头像（ActionSheet → 裁剪弹层）
//   4) 普通用户看不到后台入口，也拿不到后台内容（前端兜底门禁）
// 不写数据库、不改动生产文件；仅使用临时端口 + 临时 Chrome 用户目录。
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn } = require('node:child_process');
const express = require('express');

const root = path.resolve(__dirname, '..');
const report = { started: new Date().toISOString(), mode: 'Real Chrome; isolated API fixtures, NOT backend integration', checks: [], errors: [], requests: [] };
let server, chrome, ws;
const profile = fs.mkdtempSync(path.join(os.tmpdir(), '26-uifix-'));
const wait = ms => new Promise(r => setTimeout(r, ms));
function check(ok, name, detail) {
  report.checks.push({ name, pass: !!ok, detail });
  // 每步落盘：即使进程被终端中断，也能从报告看到进度与失败详情
  try { fs.writeFileSync(path.join(__dirname, 'ui-fix-browser-report.json'), JSON.stringify(report, null, 2)); } catch (_) {}
  if (!ok) throw new Error(name + ': ' + JSON.stringify(detail));
}
// '#1b1e23' → 深色判定：三通道均不超过阈值
function isDark(color, max = 80) {
  const m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(String(color || ''));
  if (!m) return false;
  return Math.max(+m[1], +m[2], +m[3]) <= max;
}
// 浅色文字判定：三通道最小值不低于阈值
function isLight(color, min = 180) {
  const m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(String(color || ''));
  if (!m) return false;
  return Math.min(+m[1], +m[2], +m[3]) >= min;
}

async function main() {
  const app = express();
  app.use(express.json());
  app.use((req, res, next) => { if (req.path.startsWith('/api/')) report.requests.push(req.path); next(); });
  // 后台页面的样式断言需要「管理员身份」才会渲染（页面本身有前端门禁）；
  // 普通用户场景通过 /api/__fixture/role?value=user 切换，用于验证看不到后台内容。
  let fixtureRole = 'admin';
  app.get('/api/__fixture/role', (req, res) => {
    fixtureRole = req.query.value === 'user' ? 'user' : 'admin';
    res.json({ success: true, data: { role: fixtureRole } });
  });
  app.get('/api/auth/me', (req, res) => res.json({
    success: true,
    data: {
      id: 1, username: 'tester', nickname: '测试员', avatar_url: null, email: 'tester@example.com',
      phone: '+60123456789', real_name: '测试', status: 'active', role: fixtureRole,
      created_at: new Date().toISOString()
    }
  }));
  app.get('/api/profile/real-name', (req, res) => res.json({ success: true, data: { status: 'unsubmitted', status_text: '未提交', real_name: null, remark: null } }));
  app.get('/api/auth/login-records', (req, res) => res.json({ success: true, data: { list: [] } }));
  app.get('/api/otp/status', (req, res) => res.json({ success: true, data: { cooldown: 0, pending: false } }));
  app.post('/api/otp/request', (req, res) => res.json({ success: true, data: { cooldown: 60 } }));
  app.get('/api/auth/invite/check', (req, res) => res.json({ success: true, data: { valid: true, invited_by_username: 'admin' } }));
  app.post('/api/profile/avatar', (req, res) => res.json({ success: true, data: { avatar_url: '/assets/avatars/users/fixture.jpg' } }));
  app.use('/api', (req, res) => res.json({ success: false, message: 'fixture 未实现' }));
  app.get('/favicon.ico', (req, res) => res.status(204).end());
  app.use(express.static(path.join(root, 'public')));
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const origin = 'http://127.0.0.1:' + server.address().port;
  chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank'], { stdio: 'ignore' });
  chrome.on('error', e => report.errors.push(e.message));
  let port;
  for (let i = 0; i < 100; i++) {
    try { port = fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0]; break; } catch (_) { await wait(100); }
  }
  if (!port) throw new Error('Chrome debug port not available');
  const targets = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json();
  const target = targets.find(t => t.type === 'page');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
  let id = 0;
  const pending = new Map();
  ws.onmessage = event => {
    const m = JSON.parse(event.data);
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.reject(new Error(m.error.message)); else p.resolve(m.result);
    }
    if (m.method === 'Runtime.exceptionThrown') report.errors.push(m.params.exceptionDetails);
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') report.errors.push(m.params);
    if (m.method === 'Network.loadingFailed' && !m.params.canceled) report.errors.push(m.params);
  };
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const n = ++id; pending.set(n, { resolve, reject }); ws.send(JSON.stringify({ id: n, method, params }));
  });
  const evaluate = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  const evaluateAsync = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  async function goto(url, readyExpr, tries = 80) {
    await send('Page.navigate', { url: origin + url });
    let ok = false;
    // 必须等 readyState=complete：否则可能在内联脚本与 app.css 生效前断言（加载竞态）
    for (let i = 0; i < tries; i++) {
      ok = await evaluate("document.readyState === 'complete' && (" + readyExpr + ")").catch(() => false);
      if (ok) break;
      await wait(100);
    }
    check(ok, 'Page ready: ' + url);
  }

  await send('Runtime.enable'); await send('Network.enable'); await send('Page.enable');
  await send('Network.setCacheDisabled', { cacheDisabled: true });
  await send('Page.addScriptToEvaluateOnNewDocument', { source: "localStorage.setItem('token','isolated-ui-fix-test');" });
  // ---------- 1. 注册页：获取验证码可达 + 未完成项提示 ----------
  await goto('/register.html', "!!document.getElementById('otpSendBtn')");
  const assets = await evaluate(`(() => {
    const link = document.querySelector('link[href="/app.css"]');
    const card = document.querySelector('.card');
    return {
      appType: typeof App,
      hasCssLink: !!link,
      cssLoaded: link ? link.sheet !== null : false,
      cardStyleLoaded: getComputedStyle(document.body).backgroundColor,
      cardBorder: card ? getComputedStyle(card).borderTopColor : null,
      assetLog: performance.getEntriesByType('resource').filter(r => /\\.css|\\.js/.test(r.name)).map(r => r.name.split('/').slice(-2).join('/') + ':' + (r.responseStatus || r.transferSize))
    };
  })()`);
  report.assets = assets;
  const reg = await evaluate(`(() => {
    const meta = document.getElementById('otpMeta');
    const send = document.getElementById('otpSendBtn');
    const btn = document.getElementById('regBtn');
    const hint = document.getElementById('readyHint');
    const username = document.getElementById('username');
    return {
      metaDisplay: getComputedStyle(meta).display,
      metaHeight: meta.getBoundingClientRect().height,
      sendDisplay: getComputedStyle(send).display,
      sendHeight: send.getBoundingClientRect().height,
      sendVisible: !!send.offsetParent,
      sendDisabled: send.disabled,
      regDisabled: btn.disabled,
      hintText: hint.textContent,
      hintRendered: hint.getBoundingClientRect().height,
      inputBg: getComputedStyle(username).backgroundColor,
      inputColor: getComputedStyle(username).color
    };
  })()`);
  check(reg.metaDisplay === 'flex' && reg.metaHeight > 0, '注册页 otpMeta 可见（修复前为 display:none）', reg);
  check(reg.sendVisible && reg.sendHeight > 0 && reg.sendDisplay !== 'none', '获取验证码按钮真实可见可点击', reg);
  check(reg.regDisabled === true, '未填完整时注册按钮保持禁用（防误提交）', reg);
  check(/还需完成/.test(reg.hintText) && reg.hintRendered > 0, '注册按钮下方给出未完成项提示', reg);
  check(isDark(reg.inputBg) && isLight(reg.inputColor), '注册页输入框为深色底 + 浅色文字', reg);

  // 点击「获取验证码」→ 验证码输入区展开（此前用户无法走通该流程）
  await evaluate(`(() => {
    document.getElementById('phone').value = '+60123456789';
    document.getElementById('otpSendBtn').click();
    return true;
  })()`);
  let otpRowShown = false;
  for (let i = 0; i < 40; i++) {
    otpRowShown = await evaluate("getComputedStyle(document.getElementById('otpRow')).display === 'flex'");
    if (otpRowShown) break;
    await wait(100);
  }
  const otpState = await evaluate(`(() => {
    const btn = document.getElementById('otpSendBtn');
    return { rowDisplay: getComputedStyle(document.getElementById('otpRow')).display, sendText: btn.textContent, sendDisabled: btn.disabled };
  })()`);
  check(otpRowShown && otpState.rowDisplay === 'flex', '点击获取验证码后 6 位验证码输入框展开', otpState);
  check(otpState.sendDisabled && /重试|秒/.test(otpState.sendText), '发送后进入 60 秒冷却倒计时并禁用按钮', otpState);
  check(report.requests.includes('/api/otp/request'), '真实发起了 /api/otp/request 请求');

  // 填满除 OTP 外的字段：提示应只剩验证码一项
  const partial = await evaluate(`(() => {
    const set = (id, v) => { const el = document.getElementById(id); el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); };
    set('username', 'tester01'); set('email', 'a@b.com'); set('realName', '张三');
    set('password', 'abcd1234'); set('password2', 'abcd1234'); set('invite', 'INVITE01');
    return { hint: document.getElementById('readyHint').textContent, disabled: document.getElementById('regBtn').disabled };
  })()`);
  check(partial.disabled === true && /验证码/.test(partial.hint) && !/用户名|邮箱|密码/.test(partial.hint), '仅剩验证码未完成时提示聚焦到验证码', partial);
  // ---------- 2. 我的页面：点击头像更换头像 ----------
  await goto('/me.html', "!!document.getElementById('identity') && document.getElementById('identity').hidden === false");
  const me = await evaluate(`(() => {
    const nick = document.getElementById('nicknameInput');
    const avatar = document.getElementById('userAvatar');
    const hint = document.querySelector('.me-avatar-hint');
    return {
      inputBg: getComputedStyle(nick).backgroundColor,
      inputColor: getComputedStyle(nick).color,
      avatarTag: avatar.tagName,
      avatarCursor: getComputedStyle(avatar).cursor,
      avatarBox: avatar.getBoundingClientRect().width,
      hintText: hint ? hint.textContent : '',
      sheetBefore: !!document.querySelector('.sheet-mask')
    };
  })()`);
  check(isDark(me.inputBg) && isLight(me.inputColor), '我的页面昵称输入框为深色底 + 浅色文字（修复白色输入框）', me);
  check(me.avatarTag === 'BUTTON' && me.avatarCursor === 'pointer' && me.avatarBox >= 60, '头像已改造为可点击按钮', me);
  check(/点击头像即可更换/.test(me.hintText) && me.sheetBefore === false, '头像旁给出可点击提示，且未预先弹出面板', me);

  await evaluate("document.getElementById('userAvatar').click();");
  await wait(300);
  const sheet = await evaluate(`(() => {
    const mask = document.querySelector('.sheet-mask');
    return mask ? { items: Array.prototype.map.call(mask.querySelectorAll('.sheet-item'), b => b.textContent.trim()), shown: mask.classList.contains('show') } : null;
  })()`);
  check(sheet && sheet.items.some(t => t.indexOf('从手机相册 / 文件中选择') >= 0), '点击头像弹出更换头像 ActionSheet', sheet);

  // 选择一张真实 PNG → 裁剪弹层出现且画布已绘制
  await evaluateAsync(`(async () => {
    const c = document.createElement('canvas');
    c.width = 40; c.height = 20;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#ff0000'; ctx.fillRect(0, 0, 40, 20);
    ctx.fillStyle = '#00ff00'; ctx.fillRect(20, 0, 20, 20);
    const blob = await new Promise(r => c.toBlob(r, 'image/png'));
    const dt = new DataTransfer();
    dt.items.add(new File([blob], 'pick.png', { type: 'image/png' }));
    const input = document.getElementById('avatarInput');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  })()`);
  let cropShown = false;
  for (let i = 0; i < 40; i++) {
    cropShown = await evaluate("document.getElementById('avatarCrop').hidden === false");
    if (cropShown) break;
    await wait(100);
  }
  const cropState = await evaluate(`(() => {
    const stage = document.getElementById('cropStage');
    const cv = document.getElementById('cropCanvas');
    const data = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
    let painted = 0;
    for (let i = 0; i < data.length; i += 4) { if (data[i] > 60 || data[i + 1] > 60 || data[i + 2] > 60) painted++; }
    return { hidden: document.getElementById('avatarCrop').hidden, stageW: stage.getBoundingClientRect().width, canvasW: cv.width, painted };
  })()`);
  check(cropShown && !cropState.hidden, '选择图片后弹出裁剪层', cropState);
  check(cropState.canvasW === 300 && cropState.stageW > 0 && cropState.stageW <= 340, '裁剪区在移动端宽度内自适应（<=340px）', cropState);
  check(cropState.painted > 0, '裁剪画布已绘制选中的图片内容', cropState);

  // 旋转 + 缩放不应抛异常；取消后弹层关闭且文件输入被清空
  const interactions = await evaluate(`(() => {
    document.getElementById('cropRotate').click();
    const zoom = document.getElementById('cropZoom');
    zoom.value = '2'; zoom.dispatchEvent(new Event('input', { bubbles: true }));
    const cv = document.getElementById('cropCanvas');
    const data = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
    let painted = 0;
    for (let i = 0; i < data.length; i += 4) { if (data[i] > 60 || data[i + 1] > 60 || data[i + 2] > 60) painted++; }
    document.getElementById('cropCancel').click();
    return { painted, closed: document.getElementById('avatarCrop').hidden, inputValue: document.getElementById('avatarInput').value };
  })()`);
  check(interactions.painted > 0, '旋转 / 缩放后画布仍有内容且无 JS 异常', interactions);
  check(interactions.closed && interactions.inputValue === '', '取消裁剪会关闭弹层并清空文件输入', interactions);
  // ---------- 3. 搜索页 ----------
  await goto('/search.html', "!!document.querySelector('.search-bar')");
  const search = await evaluate(`(() => {
    const bar = document.querySelector('.search-bar');
    const input = document.getElementById('q');
    return { display: getComputedStyle(bar).display, bg: getComputedStyle(bar).backgroundColor, inputColor: getComputedStyle(input).color, barH: bar.getBoundingClientRect().height, inputEditable: !input.readOnly };
  })()`);
  check(search.display === 'flex' && isDark(search.bg) && search.barH > 30 && search.inputEditable, '搜索页复用 .search-bar 深色搜索框且可输入', search);

  // ---------- 4. 后台 / OTP 管理：输入框与下拉框 ----------
  await goto('/admin.html', "!!document.getElementById('adjustUserId')");
  const admin = await evaluate(`(() => {
    const pick = id => document.getElementById(id);
    const cs = el => { const s = getComputedStyle(el); return { bg: s.backgroundColor, color: s.color, paddingRight: s.paddingRight }; };
    return { ledgerUser: cs(pick('ledgerUser')), adjustUserId: cs(pick('adjustUserId')), adjustAmount: cs(pick('adjustAmount')), adjustReason: cs(pick('adjustReason')), anContent: cs(pick('anContent')), adjustCurrency: cs(pick('adjustCurrency')), anType: cs(pick('anType')) };
  })()`);
  check(['ledgerUser', 'adjustUserId', 'adjustAmount', 'adjustReason', 'anContent'].every(k => isDark(admin[k].bg) && isLight(admin[k].color)), '后台文本框全部为深色底 + 浅色文字', admin);
  check(isDark(admin.adjustCurrency.bg) && isDark(admin.anType.bg) && admin.adjustCurrency.paddingRight === '38px' && admin.anType.paddingRight === '38px', '后台下拉框为深色底且带右侧箭头留白', admin);

  await goto('/admin-otp.html', "!!document.getElementById('otpStatus')");
  const otpStatus = await evaluate("(() => { const s = getComputedStyle(document.getElementById('otpStatus')); return { bg: s.backgroundColor, color: s.color, paddingRight: s.paddingRight }; })()");
  check(isDark(otpStatus.bg) && isLight(otpStatus.color) && otpStatus.paddingRight === '38px', 'OTP 管理下拉框为深色底 + 白色文字', otpStatus);

  // ---------- 5. 移动端宽度适配 ----------
  for (const width of [360, 375, 390, 412, 430]) {
    await send('Emulation.setDeviceMetricsOverride', { width, height: 850, deviceScaleFactor: 1, mobile: true });
    await goto('/me.html', "!!document.getElementById('identity') && document.getElementById('identity').hidden === false", 40);
    const layout = await evaluate("({ width: innerWidth, scroll: document.documentElement.scrollWidth, avatar: document.getElementById('userAvatar').getBoundingClientRect().toJSON() })");
    check(layout.scroll <= width && layout.avatar.width >= 60 && layout.avatar.right <= width + 1,
      '我的页面头像与布局适配 ' + width + 'px', layout);
  }
  await send('Emulation.setDeviceMetricsOverride', { width: 360, height: 850, deviceScaleFactor: 1, mobile: true });
  await goto('/me.html', "!!document.getElementById('identity') && document.getElementById('identity').hidden === false", 40);
  const narrow = await evaluate(`(() => {
    const stage = document.getElementById('cropStage');
    const box = document.querySelector('.crop-box');
    const mask = document.getElementById('avatarCrop');
    mask.hidden = false;
    const r = { stageW: stage.getBoundingClientRect().width, boxW: box.getBoundingClientRect().width, viewport: innerWidth };
    mask.hidden = true;
    return r;
  })()`);
  check(narrow.stageW > 0 && narrow.stageW <= 340 && narrow.boxW <= narrow.viewport, '裁剪弹层在 360px 视口内不溢出', narrow);

  // ---------- 6. 普通用户：看不到后台入口，也看不到后台内容 ----------
  await goto('/api/__fixture/role?value=user', "document.body.textContent.indexOf('\"role\":\"user\"') >= 0", 20);
  await goto('/admin.html', "document.getElementById('adminGate').innerHTML.indexOf('无权访问') >= 0", 40);
  const deniedAdmin = await evaluate(`(() => {
    const body = document.getElementById('adminBody');
    return {
      bodyHidden: body.hidden,
      bodyVisible: !!body.offsetParent,
      panelCount: document.querySelectorAll('#adminBody .admin-panel').length,
      gate: document.getElementById('adminGate').textContent
    };
  })()`);
  check(deniedAdmin.bodyHidden && !deniedAdmin.bodyVisible && deniedAdmin.gate.indexOf('无权访问') >= 0,
    '普通用户打开 /admin.html 只看到「无权访问」，后台面板全部隐藏', deniedAdmin);

  await goto('/admin-otp.html', "document.getElementById('otpGate').innerHTML.indexOf('无权访问') >= 0", 40);
  const deniedOtp = await evaluate(`(() => {
    const body = document.getElementById('otpBody');
    return { bodyHidden: body.hidden, bodyVisible: !!body.offsetParent, listVisible: !!document.getElementById('otpList').offsetParent };
  })()`);
  check(deniedOtp.bodyHidden && !deniedOtp.bodyVisible && !deniedOtp.listVisible,
    '普通用户打开 /admin-otp.html 看不到 OTP 控制台任何内容', deniedOtp);

  await goto('/me.html', "document.getElementById('identity').hidden === false", 40);
  const meLinks = await evaluate(`(() => ({
    adminVisible: !!document.getElementById('adminLink').offsetParent,
    otpVisible: !!document.getElementById('otpAdminLink').offsetParent
  }))()`);
  check(!meLinks.adminVisible && !meLinks.otpVisible, '普通用户的「我的」页不显示管理后台 / OTP 管理入口', meLinks);

  // 切回管理员身份，便于同一夹具继续复用
  await goto('/api/__fixture/role?value=admin', "document.body.textContent.indexOf('\"role\":\"admin\"') >= 0", 20);

  check(report.errors.length === 0, '无 JS 异常 / console 错误 / 资源加载失败', report.errors);
}
const timeout = setTimeout(() => finish(new Error('Browser test timeout')), 60000);
let finished = false;
function finish(error) {
  if (finished) return;
  finished = true;
  clearTimeout(timeout);
  if (error) { report.error = error.message; report.passed = false; }
  else report.passed = report.checks.every(c => c.pass);
  fs.writeFileSync(path.join(__dirname, 'ui-fix-browser-report.json'), JSON.stringify(report, null, 2));
  const failed = report.checks.filter(c => !c.pass);
  console.log(report.passed ? 'UI_FIX_BROWSER_PASS (' + report.checks.length + ' checks)' : 'UI_FIX_BROWSER_FAIL: ' + (report.error || '') + ' failed=' + failed.length);
  for (const f of failed) console.log('  FAIL ' + f.name);
  if (!report.passed) {
    console.log('ASSETS ' + JSON.stringify(report.assets || null));
    console.log('ERRORS ' + JSON.stringify((report.errors || []).slice(0, 3)));
  }
  try { if (ws) ws.close(); } catch (_) {}
  try { if (chrome) chrome.kill(); } catch (_) {}
  try { if (server) server.close(); } catch (_) {}
  process.exit(report.passed ? 0 : 1);
}
main().then(() => finish()).catch(e => finish(e));
