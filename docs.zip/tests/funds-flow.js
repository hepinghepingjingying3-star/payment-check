'use strict';
// 隔离数据库资金流测试：真实 HTTP + JWT；验证订单状态机、余额事务、防重复审核。
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createRequire } = require('node:module');
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const root = path.resolve(__dirname, '..');
const key = require('node:crypto').randomBytes(32).toString('hex');
const report = { mode: 'Isolated DB funds flow', checks: [], passed: false };
const users = {
  1: { id: 1, username: 'player1', role: 'user', status: 'active', cash_chips: 100, game_balance: 0 },
  2: { id: 2, username: 'admin1', role: 'admin', status: 'active', cash_chips: 0, game_balance: 0 }
};
const orders = {}; let nextOrderId = 1; const transactions = []; let nextTxId = 1;
const adminLogs = [];
function query(sql, p) {
  sql = String(sql).replace(/\s+/g, ' ').trim();
  p = p || [];
  // 可选：FF_TRACE=1 时输出全部 SQL（仅用于本地定位，默认关闭）
  if (process.env.FF_TRACE) {
    fs.appendFileSync(path.join(__dirname, 'funds-trace.txt'), sql.slice(0, 160) + ' :: ' + JSON.stringify(p) + '\n');
  }
  if (sql.startsWith('INSERT INTO wallet_orders')) {
    const id = nextOrderId++;
    orders[id] = {
      id, user_id: p[0], order_no: p[1],
      order_type: String(p[1]).charAt(0) === 'D' ? 'DEPOSIT' : 'WITHDRAW',
      currency_type: 'CASH_CHIPS', amount: Number(p[2]), method: p[3], account: p[4], remark: p[5],
      status: 'PENDING', reviewed_by: null, admin_note: null, reject_reason: null
    };
    return [{ insertId: id }];
  }
  if (sql.startsWith('SELECT o.*, u.username')) {
    return [Object.values(orders).map(o => ({ ...o, username: users[o.user_id].username, nickname: null, reviewer_username: o.reviewed_by && users[o.reviewed_by] ? users[o.reviewed_by].username : null }))];
  }
  if (sql.includes('SELECT order_type FROM wallet_orders')) {
    const o = orders[p[0]];
    return [o ? [{ order_type: o.order_type }] : []];
  }
  if (sql.includes('FROM wallet_orders WHERE id = ? FOR UPDATE')) {
    const o = orders[p[0]]; return [o ? [{ ...o }] : []];
  }
  if (sql.startsWith('UPDATE wallet_orders SET status')) {
    // 新逻辑：参数为 [status, operator, note, review_reason, before, after, id, prevStatus]
    const id = p[p.length - 2];
    const o = orders[id];
    if (o) {
      o.status = p[0];
      o.reviewed_by = p[1];
      o.admin_note = p[2] === null || p[2] === undefined ? null : p[2];
      o.reject_reason = p[3] === null || p[3] === undefined ? null : p[3];
      o.before_balance = p[4];
      o.after_balance = p[5];
    }
    return [{ affectedRows: o ? 1 : 0 }];
  }
  if (/SELECT (cash_chips|game_balance) AS bal FROM users WHERE id = \? FOR UPDATE/.test(sql)) {
    const u = users[p[0]];
    const field = sql.indexOf('game_balance') >= 0 ? 'game_balance' : 'cash_chips';
    return [[{ bal: u ? u[field] : 0 }]];
  }
  if (sql.startsWith('SELECT cash_chips FROM users WHERE id = ? FOR UPDATE')) {
    const u = users[p[0]];
    return [[{ cash_chips: u ? u.cash_chips : 0 }]];
  }
  if (sql.startsWith('UPDATE users SET cash_chips')) {
    if (users[p[1]]) users[p[1]].cash_chips = Number(p[0]);
    return [{ affectedRows: 1 }];
  }
  if (sql.startsWith('UPDATE users SET game_balance')) {
    if (users[p[1]]) users[p[1]].game_balance = Number(p[0]);
    return [{ affectedRows: 1 }];
  }
  if (sql.startsWith('INSERT INTO balance_transactions') && sql.includes("'ADJUST'")) {
    const id = nextTxId++;
    transactions.push({ id, user_id: p[0], amount: Number(p[2]), balance_before: p[3], balance_after: p[4], related_request_id: null, operator_id: p[6], action: 'ADJUST' });
    return [{ insertId: id }];
  }
  if (sql.startsWith('INSERT INTO balance_transactions')) {
    const id = nextTxId++;
    transactions.push({
      id, user_id: p[0], amount: Number(p[2]), balance_before: Number(p[3]), balance_after: Number(p[4]),
      related_request_id: p[8] === undefined ? null : p[8], operator_id: p[7], action: p[5]
    });
    return [{ insertId: id }];
  }
  if (sql.includes('FROM balance_transactions t')) {
    return [transactions.map(t => ({ ...t, username: users[t.user_id].username, nickname: null, operator_username: t.operator_id && users[t.operator_id] ? users[t.operator_id].username : null }))];
  }
  if (sql.startsWith('INSERT INTO admin_logs')) {
    adminLogs.push({ admin_id: p[0], target_user_id: p[1], action: p[2], detail: p[3] });
    return [{ insertId: adminLogs.length }];
  }
  if (sql.includes('FROM users WHERE id = ?')) {
    const u = users[p[0]];
    return [u ? [{ ...u }] : []];
  }
  if (sql.includes('FROM users')) return [Object.values(users)];
  throw new Error('Unexpected test SQL: ' + sql.slice(0, 60));
}
async function main() {
  const dbg = m => fs.appendFileSync(path.join(__dirname, 'funds-debug.txt'), m + '\n');
  dbg('main-start');
  const app = express(); app.use(express.json()); app.use('/api', wallet, admin);
  const server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  dbg('listening');
  async function api(url, uid, method = 'GET', body) {
    const headers = uid ? { Authorization: 'Bearer ' + jwt.sign({ id: uid, username: users[uid].username, role: users[uid].role }, key) } : {};
    if (body) headers['Content-Type'] = 'application/json';
    const r = await fetch('http://127.0.0.1:' + server.address().port + '/api' + url, { method, headers, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(5000) });
    return { status: r.status, body: await r.json() };
  }
  // 充值流程
  let r = await api('/wallet/deposit', 1, 'POST', { amount: 50, payment_method: 'TNG', account: '0123456789' });
  check('Deposit creates PENDING order', r.status === 201 && r.body.data.status === 'PENDING');
  const depId = r.body.data.id;
  check('Deposit does not credit balance yet', users[1].cash_chips === 100);
  check('Anonymous deposit denied', (await api('/wallet/deposit', null, 'POST', { amount: 50, payment_method: 'TNG' })).status === 401);
  check('Invalid method rejected', (await api('/wallet/deposit', 1, 'POST', { amount: 50, payment_method: 'USDT' })).status === 400);
  check('Player cannot review', (await api('/admin/wallet/orders/' + depId + '/review', 1, 'POST', { decision: 'approved' })).status === 403);
  check('Anonymous review denied', (await api('/admin/wallet/orders/' + depId + '/review', null, 'POST', { decision: 'approved' })).status === 401);
  r = await api('/admin/wallet/orders/' + depId + '/review', 2, 'POST', { decision: 'approved', note: 'test' });
  dbg('approve status=' + r.status + ' body=' + JSON.stringify(r.body).slice(0, 220));
  check('Admin approves deposit', r.status === 200 && r.body.data.status === 'COMPLETED');
  check('Balance credited exactly once', users[1].cash_chips === 150);
  const depTx = transactions.find(t => t.related_request_id === depId);
  check('Transaction logged with before/after', depTx && depTx.amount === 50 && depTx.balance_before === 100 && depTx.balance_after === 150);
  check('Repeat review rejected 409', (await api('/admin/wallet/orders/' + depId + '/review', 2, 'POST', { decision: 'approved' })).status === 409);
  check('Balance unchanged after repeat', users[1].cash_chips === 150);
  check('Only one transaction for order', transactions.filter(t => t.related_request_id === depId).length === 1);
  // 提现流程
  r = await api('/wallet/withdraw', 1, 'POST', { amount: 40, withdraw_method: 'BANK', account: 'ACC-1' });
  check('Withdraw creates PENDING order', r.status === 201 && r.body.data.status === 'PENDING');
  const wdId = r.body.data.id;
  check('Withdraw rejected without account', (await api('/wallet/withdraw', 1, 'POST', { amount: 40, withdraw_method: 'BANK' })).status === 400);
  check('Withdraw below minimum rejected', (await api('/wallet/withdraw', 1, 'POST', { amount: 5, withdraw_method: 'BANK', account: 'x' })).status === 400);
  check('Withdraw over-balance rejected 409', (await api('/wallet/withdraw', 1, 'POST', { amount: 20000, withdraw_method: 'BANK', account: 'x' })).status === 409);
  r = await api('/admin/wallet/orders/' + wdId + '/review', 2, 'POST', { decision: 'approved' });
  check('Admin approves withdraw', r.status === 200 && r.body.data.status === 'COMPLETED');
  check('Balance debited', users[1].cash_chips === 110);
  check('Withdraw transaction negative', transactions.some(t => t.related_request_id === wdId && t.amount === -40));
  check('Repeat withdraw review 409', (await api('/admin/wallet/orders/' + wdId + '/review', 2, 'POST', { decision: 'approved' })).status === 409);
  // 提现余额不足时提交 409
  r = await api('/wallet/withdraw', 1, 'POST', { amount: 200, withdraw_method: 'BANK', account: 'ACC-2' });
  check('Over-balance pending blocked at submit', r.status === 409);
  // 拒绝流程
  r = await api('/wallet/withdraw', 1, 'POST', { amount: 30, withdraw_method: 'BANK', account: 'ACC-3' });
  const wd2 = r.body.data.id;
  check('Reject requires reason', (await api('/admin/wallet/orders/' + wd2 + '/review', 2, 'POST', { decision: 'rejected' })).status === 422);
  r = await api('/admin/wallet/orders/' + wd2 + '/review', 2, 'POST', { decision: 'rejected', reject_reason: '测试拒绝' });
  check('Admin rejects withdraw', r.status === 200 && r.body.data.status === 'REJECTED');
  check('Reject does not touch balance', users[1].cash_chips === 110);
  check('No transaction on reject', !transactions.some(t => t.related_request_id === wd2));
  // 充值拒绝流程（此前缺失，导致「充值申请已拒绝」通知路径从未被验证）
  r = await api('/wallet/deposit', 1, 'POST', { amount: 60, payment_method: 'TNG', account: '0123456789' });
  const dep2 = r.body.data.id;
  check('Second deposit creates PENDING order', r.status === 201 && r.body.data.status === 'PENDING');
  r = await api('/admin/wallet/orders/' + dep2 + '/review', 2, 'POST', { decision: 'rejected', reject_reason: '测试拒绝充值' });
  check('Admin rejects deposit', r.status === 200 && r.body.data.status === 'REJECTED');
  check('Deposit reject does not touch balance', users[1].cash_chips === 110);
  check('No transaction on deposit reject', !transactions.some(t => t.related_request_id === dep2));
  check('Repeat deposit reject 409', (await api('/admin/wallet/orders/' + dep2 + '/review', 2, 'POST', { decision: 'rejected', reject_reason: '重复' })).status === 409);
  // 流水与权限
  r = await api('/admin/wallet/transactions?user_id=1', 2);
  check('Admin can read transactions', r.status === 200 && r.body.data.list.length === 2);
  check('Player cannot read all transactions', (await api('/admin/wallet/transactions', 1)).status === 403);
  // 余额调整
  check('Adjust self denied', (await api('/admin/users/2/adjust', 2, 'POST', { currency_type: 'CASH_CHIPS', amount: 10, reason: 'self' })).status === 422);
  check('Adjust requires reason', (await api('/admin/users/1/adjust', 2, 'POST', { currency_type: 'CASH_CHIPS', amount: 10 })).status === 422);
  check('Adjust negative beyond balance denied', (await api('/admin/users/1/adjust', 2, 'POST', { currency_type: 'CASH_CHIPS', amount: -500, reason: '测试扣减' })).status === 422);
  r = await api('/admin/users/1/adjust', 2, 'POST', { currency_type: 'GAME_BALANCE', amount: 25.5, reason: '测试调整' });
  check('Adjust ok', r.status === 200 && r.body.data.balance_after === 25.5);
  check('Adjust writes ADJUST transaction', transactions.some(t => t.action === 'ADJUST' && t.amount === 25.5));
  check('Admin log recorded', adminLogs.some(l => l.action === 'wallet_order_review'));
  check('Admin log has no password', !JSON.stringify(adminLogs).includes('password'));
  // 审核结果必须真实通知到用户（此前该断言缺失，导致 pushNotification 悄悄写进生产库也没人发现）
  // pushNotification(userId, category, title, body) → 标题在 args[2]
  const titles = notifications.map(n => String(n[2]));
  if (process.env.FF_TRACE) console.log('[notifications]', JSON.stringify(notifications));
  check('Review outcomes notify the user',
    titles.some(t => t.indexOf('充值审核已通过') >= 0) &&
    titles.some(t => t.indexOf('充值申请已拒绝') >= 0) &&
    titles.some(t => t.indexOf('提款审核已通过') >= 0) &&
    titles.some(t => t.indexOf('提款申请已拒绝') >= 0));
  check('Notification targets the order owner only',
    notifications.every(n => n[0] === 1 || n[0] === 2));
  check('Notification goes through the stub, never the real database',
    notifications.length === 4);
  server.closeAllConnections(); await new Promise(r2 => server.close(r2));
  report.passed = true;
}
const conn = { query: (s, p) => query(s, p), beginTransaction: async () => {}, commit: async () => {}, rollback: async () => {}, release() {} };
const db = { promise: () => ({ query: (s, p) => query(s, p), getConnection: async () => conn }) };
function load(file, overrides = {}) {
  const full = path.join(root, file), mod = { exports: {} }, realRequire = createRequire(full);
  vm.runInNewContext(fs.readFileSync(full, 'utf8'), {
    module: mod, exports: mod.exports, __dirname: path.dirname(full), console,
    process: { env: { JWT_SECRET: key } },
    require: name => name in overrides ? overrides[name] : realRequire(name)
  }, { filename: full });
  return mod.exports;
}
const auth = load('middleware/auth.js', { '../config/db': db });
const common = { '../config/db': db, '../middleware/auth': auth };
// utils/funds.js 现在承担审核事务与推广奖励结算：这里注入隔离 db 与假的奖励结算，
// 保证该测试完全不触碰真实数据库（真实奖励逻辑由 tests/deposit-withdraw-e2e.js 覆盖）。
// 注意：必须同时桩掉 ./content —— pushNotification 内部自取真实 db，
// 若不桩，本测试会用假 user_id 往生产 notifications 表写数据并触发外键失败。
const notifications = [];
const funds = load('utils/funds.js', {
  '../config/db': db,
  './adminAudit': { writeAdminLog: async o => { adminLogs.push({ admin_id: o.adminId, target_user_id: o.targetUserId, action: o.action, detail: o.detail }); return true; } },
  './referralRewards': { settleRewards: async () => [] },
  './content': { pushNotification: async (...args) => { notifications.push(args); return true; } }
});
const wallet = load('routes/wallet.js', common);
const admin = load('routes/admin.js', {
  ...common,
  '../utils/funds': funds,
  '../utils/content': { loadAnnouncements: async () => [] }
});
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
main().catch(e => { report.error = e.message; }).finally(() => {
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'funds-flow-report.json'), JSON.stringify(report, null, 2));
  // 本测试用 vm 加载真实路由模块，会连带创建定时器 / 连接池等长驻句柄，
  // 因此必须在报告写完后显式退出（否则 npm test 会一直等到超时）
  process.stdout.write(JSON.stringify(report, null, 2) + '\n', () => {
    process.exit(report.passed ? 0 : 1);
  });
});
