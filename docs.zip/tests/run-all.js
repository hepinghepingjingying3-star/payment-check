// ============================================
// 26牛牛 - 统一测试入口
// ============================================
// 运行: npm test
//   1) 离线测试（不需要服务器 / 不需要数据库）：全部必须通过，否则退出码 1
//   2) 在线测试（需要 npm start 已启动 + 真实数据库）：默认自动探测，
//      服务未启动时「跳过」而不是失败；TEST_REQUIRED=1 时缺失即视为失败
// 说明: 全部测试都不删除任何用户 / 订单 / 聊天 / 对局数据
// ============================================
'use strict';

const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');

/** 离线测试：纯逻辑 / 源码结构，永远可跑 */
const OFFLINE = [
  { file: 'tests/structure-check.js', name: '源码结构自检（防函数错位）' },
  { file: 'tests/niu-engine.js', name: '26牛牛引擎（洗牌 / 牌型 / 比牌 / 结算）' },
  { file: 'tests/invite-registration.js', name: '邀请码注册（含支付密码只存 hash）' }
];

/** 在线测试：需要服务在跑（默认 http://127.0.0.1:3000） */
const ONLINE = [
  { file: 'tests/funds-flow.js', name: '资金流状态机 + 余额事务 + 防重复审核' },
  { file: 'tests/uid-admin-verify.js', name: '管理员权限边界（普通用户 403）' },
  { file: 'tests/socket-auth.js', name: 'Socket.IO 握手鉴权' }
];

/** 数据库测试：需要真实 MySQL，自带临时服务器（不依赖已启动的服务） */
const WITH_DB = [
  { file: 'tests/niu-live.js', name: '26牛牛娱乐场（权限 / 状态机 / 结算闸门 / 真实数据）' }
];

function runOne(item) {
  const r = spawnSync(process.execPath, [path.join(ROOT, item.file)], {
    cwd: ROOT, encoding: 'utf8', timeout: 180000,
    env: Object.assign({}, process.env, { NO_PROXY: '1' })
  });
  if (r.error) {
    console.log('FAIL  ' + item.name.padEnd(38, ' ') + '  ' + r.error.message.slice(0, 90));
    return false;
  }
  const out = String(r.stdout || '') + String(r.stderr || '');
  const ok = r.status === 0;
  const last = out.split(/\r?\n/).filter(l => l.trim()).slice(-1)[0] || '';
  console.log((ok ? 'PASS  ' : 'FAIL  ') + item.name.padEnd(38, ' ') + '  ' + last.slice(0, 90));
  if (!ok) console.log(out.split(/\r?\n/).slice(0, 20).map(l => '      ' + l).join('\n'));
  return ok;
}

function serverAlive() {
  const base = process.env.TEST_BASE || 'http://127.0.0.1:' + (process.env.PORT || 3000);
  const script = "const http=require('http');const base=process.argv[1];" +
    "http.get(base+'/api/health',res=>process.exit(res.statusCode===200?0:2)).on('error',()=>process.exit(3));";
  const r = spawnSync(process.execPath, ['-e', script, base], { cwd: ROOT, timeout: 8000 });
  return r.status === 0;
}

/** 数据库连通性：自带服务器的测试只需要 MySQL 可连 */
function dbAlive() {
  const script = "require('dotenv').config();const db=require('./config/db');" +
    "db.query('SELECT 1',e=>{process.exit(e?1:0);});";
  const r = spawnSync(process.execPath, ['-e', script], { cwd: ROOT, timeout: 15000 });
  return r.status === 0;
}

let failed = 0;
console.log('\n== 离线测试 ==');
OFFLINE.forEach(i => { if (!runOne(i)) failed++; });

console.log('\n== 数据库测试（真实 MySQL，自带临时服务器）==');
if (dbAlive()) {
  WITH_DB.forEach(i => { if (!runOne(i)) failed++; });
} else {
  console.log('SKIP  未检测到可连接的 MySQL（请检查 .env 后重试）');
  WITH_DB.forEach(i => console.log('      - ' + i.name + '  (' + i.file + ')'));
  if (process.env.TEST_REQUIRED === '1') failed += WITH_DB.length;
}

console.log('\n== 在线测试（需要 npm start）==');
if (serverAlive()) {
  ONLINE.forEach(i => { if (!runOne(i)) failed++; });
} else {
  console.log('SKIP  未检测到运行中的服务（' + (process.env.TEST_BASE || 'http://127.0.0.1:3000') + '）');
  ONLINE.forEach(i => console.log('      - ' + i.name + '  (' + i.file + ')'));
  if (process.env.TEST_REQUIRED === '1') failed += ONLINE.length;
}

console.log(failed ? '\nTEST_FAIL (' + failed + ')' : '\nTEST_ALL_PASS');
process.exitCode = failed ? 1 : 0;
