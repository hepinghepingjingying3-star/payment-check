// ============================================
// 26牛牛 - 清理自动化测试遗留的临时账号（安全：只按测试前缀匹配）
// ============================================
// 运行: node tests/cleanup-temp-accounts.js [前缀...]   默认 zzperm_ zzfunds_
// 说明:
//   - 只删除用户名以指定前缀开头的账号（这些前缀只由自动化测试创建）
//   - 先按 information_schema 的外键关系清掉引用行，再删账号
//   - 绝不触碰真实用户（例如 dodo / 37491058 / bobo 等）
// ============================================
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const db = require('../config/db');

const prefixes = process.argv.slice(2).length ? process.argv.slice(2) : ['zzperm_', 'zzfunds_'];

(async () => {
  const conn = db.promise();
  const like = prefixes.map(p => "username LIKE '" + p.replace(/'/g, '') + "%'").join(' OR ');
  const [rows] = await conn.query('SELECT id, username FROM users WHERE ' + like + ' ORDER BY id');
  if (!rows.length) {
    console.log('没有需要清理的临时账号');
    await conn.end();
    return;
  }
  const ids = rows.map(r => Number(r.id));
  const list = ids.join(',');
  console.log('待清理临时账号：' + rows.map(r => r.id + ':' + r.username).join(', '));

  const [fks] = await conn.query(
    `SELECT table_name AS t, column_name AS c FROM information_schema.key_column_usage
     WHERE referenced_table_name = 'users' AND table_schema = DATABASE()`);
  let remaining = fks.slice();
  const removed = {};
  for (let pass = 0; pass < 4 && remaining.length; pass++) {
    const next = [];
    for (const fk of remaining) {
      try {
        const [r] = await conn.query('DELETE FROM `' + fk.t + '` WHERE `' + fk.c + '` IN (' + list + ')');
        if (r.affectedRows) removed[fk.t] = (removed[fk.t] || 0) + r.affectedRows;
      } catch (_) { next.push(fk); }
    }
    remaining = next;
  }
  // 历史业务表未必都带 users 外键；按真实存在的「表 + 用户列」逐项清理。
  // 必须覆盖所有角色列（例如 admin_logs 的 target_user_id），否则临时账号可能
  // 因外键或历史无外键记录无法删除。标识符来自固定白名单，不接受命令行输入。
  const legacyRefs = [
    ['chat_read_state', 'user_id'], ['user_presence', 'user_id'], ['user_stickers', 'user_id'],
    ['chat_messages', 'user_id'], ['chat_reports', 'reporter_id'],
    ['chat_red_packet_claims', 'user_id'], ['chat_red_packets', 'sender_id'],
    ['wallet_orders', 'user_id'], ['balance_transactions', 'user_id'],
    ['notifications', 'user_id'], ['login_logs', 'user_id'],
    ['admin_logs', 'admin_id'], ['admin_logs', 'target_user_id'],
    ['admin_approvals', 'requested_by'], ['admin_approvals', 'reviewed_by'], ['admin_approvals', 'target_user_id'],
    ['referral_rewards', 'user_id'], ['referral_rewards', 'source_user_id'],
    ['referral_relations', 'referrer_id'], ['referral_relations', 'referred_user_id'],
    ['real_name_reviews', 'user_id'], ['password_reset_tokens', 'user_id']
  ];
  for (const [tableName, columnName] of legacyRefs) {
    try {
      const [columns] = await conn.query(
        `SELECT 1 FROM information_schema.columns
         WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1`,
        [tableName, columnName]
      );
      if (!columns.length) continue;
      const [r] = await conn.query('DELETE FROM `' + tableName + '` WHERE `' + columnName + '` IN (' + list + ')');
      if (r.affectedRows) removed[tableName] = (removed[tableName] || 0) + r.affectedRows;
    } catch (_) {}
  }
  const [del] = await conn.query('DELETE FROM users WHERE id IN (' + list + ')');
  removed.users = del.affectedRows;
  console.log('清理结果：' + JSON.stringify(removed));
  console.log('（未触碰任何非测试前缀账号）');
  await conn.end();
})().catch(e => { console.error('清理失败:', e.message); process.exitCode = 1; });
