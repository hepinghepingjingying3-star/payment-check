'use strict';
// Read-only live verification. No data changes, no chat messages sent.
// Admin probe uses a short-lived token signed with the runtime secret (API-level check, NOT password login).
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const db = require('../config/db');
const jwt = require('jsonwebtoken');
const report = { started: new Date().toISOString(), db: {}, live: {}, passed: false };
async function main() {
  const [rows] = await db.promise().query(
    'SELECT id, username, role, status, invite_code FROM users WHERE id = 3 LIMIT 5'
  );
  report.db.accounts = rows;
  const [counts] = await db.promise().query(
    'SELECT COUNT(*) AS users_total, COALESCE(SUM(invite_code = CAST(id AS CHAR)), 0) AS invite_equals_uid FROM users'
  );
  report.db.invite_summary = counts[0];
  report.db.uid3_is_active_admin = rows.some(r => r.id === 3 && r.role === 'admin' && r.status === 'active');
  report.db.uid3_invite_equals_uid = rows.some(r => r.id === 3 && r.invite_code === '3');

  const port = Number(process.env.PORT || 3000);
  const base = 'http://127.0.0.1:' + port;
  const admin = rows.find(r => r.id === 3);
  let token = null;
  try {
    token = jwt.sign({ id: 3, username: (admin || {}).username || 'admin', role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '2m' });
  } catch (_) {}
  async function probe(name, url, useAuth) {
    try {
      const res = await fetch(base + url, {
        headers: useAuth && token ? { Authorization: 'Bearer ' + token } : {},
        signal: AbortSignal.timeout(4000)
      });
      let body = null;
      try { body = await res.json(); } catch (_) {}
      report.live[name] = {
        status: res.status,
        success: !!(body && body.success),
        can_use_official: body && body.data ? body.data.can_use_official === true : null,
        official_count: body && body.data && Array.isArray(body.data.official) ? body.data.official.length : null
      };
    } catch (e) {
      report.live[name] = { unreachable: e.code || e.message };
    }
  }
  await probe('stickers_anonymous', '/api/chat/stickers', false);
  await probe('stickers_admin_token', '/api/chat/stickers', true);
  await probe('home_anonymous', '/api/home', false);
  report.passed = report.db.uid3_is_active_admin && report.db.uid3_invite_equals_uid
    && report.live.stickers_anonymous && report.live.stickers_anonymous.status === 401
    && report.live.stickers_admin_token && report.live.stickers_admin_token.status === 200
    && report.live.stickers_admin_token.can_use_official === true
    && report.live.stickers_admin_token.official_count === 6
    && report.live.home_anonymous && report.live.home_anonymous.status === 401;
}
main().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  try { await db.end(); } catch (_) {}
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'admin-sticker-live-report.json'), JSON.stringify(report, null, 2));
  console.log(report.passed ? 'ADMIN_STICKER_LIVE_PASS' : 'ADMIN_STICKER_LIVE_FAIL');
  process.exitCode = report.passed ? 0 : 1;
});
