'use strict';
// Focused regression checks. No database connection, server, or business-data writes.
const assert = require('assert').strict;
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const report = { started: new Date().toISOString(), checks: [], completed: false };

async function check(name, action) {
  try {
    await action();
    report.checks.push({ name, pass: true });
  } catch (error) {
    report.checks.push({ name, pass: false, error: error.message });
  }
}

function response() {
  return {
    statusCode: 200,
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; }
  };
}

async function main() {
  const html = fs.readFileSync(path.join(root, 'public/lobby.html'), 'utf8');
  await check('Lobby inline scripts parse', () => {
    for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
      new vm.Script(match[1]);
    }
  });
  await check('My profile menu action navigates to an existing personal page', () => {
    const start = html.indexOf("$('settingsBtn').addEventListener");
    const end = html.indexOf('// 离开页面清理轮播 timer', start);
    assert.ok(start >= 0 && end > start, 'Settings handler not found');
    let click;
    let sheet;
    const location = { href: '' };
    vm.runInNewContext(html.slice(start, end), {
      $: id => {
        assert.equal(id, 'settingsBtn');
        return { addEventListener: (event, handler) => {
          assert.equal(event, 'click');
          click = handler;
        } };
      },
      App: { openSheet: value => { sheet = value; } },
      location
    });
    click();
    const item = sheet.items.find(entry => entry.label === '我的资料');
    assert.ok(item);
    item.onClick();
    assert.equal(location.href, '/me.html');
    assert.ok(fs.existsSync(path.join(root, 'public', location.href)));
    assert.ok(!html.includes('/home.html'));
  });

  // Load the actual route source with isolated dependencies, never the real DB/auth.
  const handlers = new Map();
  const router = {};
  for (const method of ['get', 'post']) {
    router[method] = (url, ...callbacks) => handlers.set(method + ' ' + url, callbacks.at(-1));
  }
  let queries = 0;
  const fixtureDb = { promise: () => ({ query: async (sql, params) => {
    assert.match(sql.trim(), /^SELECT\b/i, 'Unexpected database write');
    assert.equal(params[0], 7);
    queries++;
    if (sql.includes('FROM users')) return [[{ game_balance: '12.50', cash_chips: '3.25' }]];
    return [[]];
  } }) };
  const dependencies = {
    express: { Router: () => router },
    crypto: require('crypto'),
    '../config/db': fixtureDb,
    '../config/funds': require('../config/funds'),
    '../middleware/auth': { auth: () => {}, requireRole: () => () => {} },
    '../utils/request': require('../utils/request')
  };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'routes/wallet.js'), 'utf8'), {
    module: { exports: {} }, console,
    require: name => {
      assert.ok(Object.prototype.hasOwnProperty.call(dependencies, name), 'Unexpected dependency: ' + name);
      return dependencies[name];
    }
  }, { filename: 'wallet.js' });
  await check('Wallet summary reports independent assets and funding feature switches', async () => {
    const res = response();
    await handlers.get('get /wallet/summary')({ user: { id: 7 } }, res);
    assert.equal(res.statusCode, 200);
    assert.equal(res.body.success, true);
    const data = res.body.data;
    assert.equal(data.assets.game_balance, 12.5);
    assert.equal(data.assets.cash_chips, 3.25);
    assert.equal(data.assets.independent, true);
    // 充值 / 提款在 V5 已开放（测试资产，管理员审核后才变更余额）；兑换与转账仍未开放
    for (const name of ['deposit', 'withdraw']) {
      assert.equal(data.features[name].available, true, name);
      assert.match(data.features[name].note, /测试资产/);
    }
    for (const name of ['exchange', 'transfer']) {
      assert.equal(data.features[name].available, false, name);
      assert.match(data.features[name].note, /暂未开放/);
    }
    assert.equal(queries, 5);
  });
  await check('Deposit rejects invalid amount without database writes', async () => {
    const before = queries;
    const res = response();
    await handlers.get('post /wallet/deposit')({ user: { id: 7 }, body: { amount: 0, payment_method: 'BANK' } }, res);
    assert.equal(res.statusCode, 422);
    assert.equal(res.body.success, false);
    assert.equal(queries, before);
  });
  await check('Deposit enforces the same RM30 minimum as the new flow', async () => {
    const before = queries;
    const res = response();
    await handlers.get('post /wallet/deposit')({ user: { id: 7 }, body: { amount: 20, payment_method: 'BANK' } }, res);
    assert.equal(res.statusCode, 422);
    assert.match(res.body.message, /最低充值金额为 RM30/);
    assert.equal(queries, before);
  });
  report.completed = true;
}
main().catch(error => { report.error = error.message; }).finally(() => {
  report.passed = report.completed && !report.error && report.checks.every(item => item.pass);
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'navigation-wallet-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  process.exitCode = report.passed ? 0 : 1;
});
