'use strict';
// ============================================
// 26牛牛 - 充值 / 提款 / 推广奖励 端到端测试（真实 HTTP + 隔离 MySQL）
// ============================================
// 隔离策略:
//   - 新建独立测试库 nn_test_funds（结构与主库完全一致：CREATE TABLE ... LIKE）
//   - 只在测试库写入测试数据，绝不动主库、绝不删除任何真实用户
//   - 结束（无论成功失败）都会关闭测试服务器并删除测试库
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { fork } = require('node:child_process');
const mysql = require('mysql2/promise');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const ROOT = path.resolve(__dirname, '..');
const TEST_DB = 'nn_test_funds';
const KEY = crypto.randomBytes(32).toString('hex');
const jwt = require('jsonwebtoken');

const report = { mode: 'Isolated MySQL + real HTTP', checks: [], passed: false, started: new Date().toISOString() };
function check(name, pass, detail) {
  report.checks.push({ name, pass: Boolean(pass), ...(detail ? { detail: detail } : {}) });
}
function dbg(line) { report.diagnostics = (report.diagnostics || []).concat([String(line)]); }

// ---------- 生成一张真实的 64x64 PNG（用于凭证上传测试） ----------
function crc32(buf) {
  let c, crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    c = (crc ^ buf[i]) & 0xFF;
    for (let k = 0; k < 8; k++) c = c & 1 ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
function pngChunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}
function makePng(width, height, noisy) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const raw = Buffer.alloc((width * 3 + 1) * height);
  for (let y = 0; y < height; y++) {
    const off = y * (width * 3 + 1);
    raw[off] = 0;
    for (let x = 0; x < width; x++) {
      if (noisy) {
        // 伪随机内容：保证压缩后体积足够大（用于验证「文件过小」等边界）
        raw[off + 1 + x * 3] = (x * 7 + y * 13) % 251;
        raw[off + 2 + x * 3] = (x * 29 + y * 3) % 253;
        raw[off + 3 + x * 3] = (x * 11 + y * 37) % 249;
      } else {
        raw[off + 1 + x * 3] = 200; raw[off + 2 + x * 3] = 170; raw[off + 3 + x * 3] = 60;
      }
    }
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', zlib.deflateSync(raw)),
    pngChunk('IEND', Buffer.alloc(0))
  ]);
}

const conf = () => ({
  host: process.env.DB_HOST, port: process.env.DB_PORT,
  user: process.env.DB_USER, password: process.env.DB_PASSWORD,
  multipleStatements: true
});


// ---------- 隔离库准备 ----------
let root, child, base, serverPort = 0;
let users = {};

async function prepareDatabase() {
  root = await mysql.createConnection(conf());
  await root.query('DROP DATABASE IF EXISTS ' + TEST_DB);
  await root.query('CREATE DATABASE ' + TEST_DB + ' CHARACTER SET utf8mb4');
  const [tables] = await root.query(
    'SELECT table_name AS t FROM information_schema.tables WHERE table_schema = ?', [process.env.DB_NAME]
  );
  for (const { t } of tables) {
    await root.query('CREATE TABLE ' + TEST_DB + '.`' + t + '` LIKE `' + process.env.DB_NAME + '`.`' + t + '`');
  }
  check('隔离测试库建立（表结构复制完成）', tables.length > 10, { tables: tables.length });

  const tdb = await mysql.createConnection(Object.assign(conf(), { database: TEST_DB }));
  const ins = 'INSERT INTO users (username, email, phone, real_name, password_hash, invite_code, invited_by, role, status, game_balance, cash_chips) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
  const hash = '$2a$12$e2eteste2eteste2eteste2eteste2eteste2eteste2eteste2etest';
  const rows = [
    ['e2e_upline', 'upline@e2e.test', '+60111000001', 'Upline', hash, '22222222', null, 'user', 'active', 0, 0],
    ['e2e_grant', 'grant@e2e.test', '+60111000002', 'Grant', hash, '33333333', null, 'user', 'active', 0, 0],
    ['e2e_player', 'player@e2e.test', '+60111000003', 'Player', hash, '11111111', null, 'user', 'active', 5, 1000],
    ['e2e_admin', 'admin@e2e.test', '+60111000004', 'Admin', hash, '44444444', null, 'admin', 'active', 0, 0],
    ['e2e_support', 'support@e2e.test', '+60111000005', 'Support', hash, '55555555', null, 'support', 'active', 0, 0]
  ];
  for (const r of rows) await tdb.query(ins, r);
  await tdb.query('UPDATE users SET invited_by = (SELECT id FROM (SELECT id FROM users WHERE username = ?) x) WHERE username = ?',
    ['e2e_upline', 'e2e_player']);
  await tdb.query('UPDATE users SET invited_by = (SELECT id FROM (SELECT id FROM users WHERE username = ?) x) WHERE username = ?',
    ['e2e_grant', 'e2e_upline']);
  // 邀请关系表（注册时后端会在同一事务写入；这里按同样规则补齐直属/二级）
  await tdb.query("INSERT INTO referral_relations (referrer_id, referred_user_id, level) SELECT p.invited_by, p.id, 1 FROM users p WHERE p.username = 'e2e_player'");
  await tdb.query("INSERT INTO referral_relations (referrer_id, referred_user_id, level) SELECT p.invited_by, p.id, 1 FROM users p WHERE p.username = 'e2e_upline'");
  await tdb.query("INSERT INTO referral_relations (referrer_id, referred_user_id, level) SELECT g.id, p.id, 2 FROM users p JOIN users d ON d.id = p.invited_by JOIN users g ON g.id = d.invited_by WHERE p.username = 'e2e_player'");
  const [list] = await tdb.query('SELECT id, username, role, invite_code FROM users WHERE username LIKE ?', ['e2e_%']);
  list.forEach(u => { users[u.username] = u; });
  check('测试账号写入隔离库（5 个）', list.length === 5, { count: list.length });
  await tdb.end();
}

let serverLog = '';
async function startServer() {
  const bootstrap = "const http=require('http');const listen=http.Server.prototype.listen;" +
    "http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args);};require('./server');";
  child = fork('-e', [bootstrap], {
    cwd: ROOT, silent: true,
    env: Object.assign({}, process.env, { PORT: '0', DB_NAME: TEST_DB, JWT_SECRET: KEY, COOKIE_SECURE: '0' })
  });
  // 只保留最近的服务端日志，用于失败定位（不含口令 / OTP 明文）
  const keep = d => { serverLog = (serverLog + d.toString()).slice(-4000); };
  child.stdout.on('data', keep);
  child.stderr.on('data', keep);
  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('服务器启动超时')), 20000);
    child.once('message', m => { clearTimeout(timer); resolve(m.port); });
    child.once('exit', code => { clearTimeout(timer); reject(new Error('服务器提前退出: ' + code)); });
  });
  serverPort = port;
  base = 'http://127.0.0.1:' + port;
  check('测试服务器已启动（隔离库）', port > 0, { port });
}

function token(username) {
  return jwt.sign({ id: users[username].id, username: username, purpose: 'login' }, KEY, { expiresIn: '1h', algorithm: 'HS256' });
}

async function api(method, url, who, body) {
  const headers = {};
  if (who) headers.Authorization = 'Bearer ' + token(who);
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const res = await fetch(base + url, { method: method, headers: headers, body: payload, signal: AbortSignal.timeout(15000) });
  const type = res.headers.get('content-type') || '';
  if (type.indexOf('json') >= 0) return { status: res.status, body: await res.json(), headers: res.headers };
  const buf = Buffer.from(await res.arrayBuffer());
  return { status: res.status, buffer: buf, headers: res.headers };
}

async function sql(query, params) {
  const c = await mysql.createConnection(Object.assign(conf(), { database: TEST_DB }));
  try { const rows = await c.query(query, params || []); return rows[0]; }
  finally { await c.end(); }
}


// ============================================
// 管理员审核 / 权限 / 幂等 / 提款
// ============================================
async function runAdminFlow(orderId) {
  let r = await api('GET', '/api/admin/deposits', 'e2e_player');
  check('普通用户访问管理员充值列表 403', r.status === 403);
  r = await api('GET', '/api/admin/deposits', 'e2e_support');
  check('客服角色访问管理员充值列表 403（不越权）', r.status === 403);
  r = await api('GET', '/api/admin/deposits', null);
  check('匿名访问管理员充值列表 401', r.status === 401);
  r = await api('GET', '/api/admin/otp', 'e2e_support');
  check('客服角色可访问 OTP 管理接口', r.status === 200 && r.body.success === true, { status: r.status });

  r = await api('GET', '/api/admin/deposits?status=PENDING_REVIEW&q=e2e_player', 'e2e_admin');
  check('管理员可按状态+关键字筛选充值订单',
    r.status === 200 && r.body.data.list.some(o => o.id === orderId), { total: r.body.data.total });
  const adminOrder = r.body.data.list.filter(o => o.id === orderId)[0] || {};
  check('订单归属用户名为 e2e_player', adminOrder.user && adminOrder.user.username === 'e2e_player');
  check('列表响应不含密码 / OTP 字段', !/password_hash|otp/i.test(JSON.stringify(r.body.data.list)));
  r = await api('GET', '/api/admin/deposits/' + orderId, 'e2e_admin');
  check('管理员订单详情含凭证链接与流水',
    r.status === 200 && String(r.body.data.order.voucher_url).indexOf('/voucher') > 0 &&
    Array.isArray(r.body.data.order.transactions));
  r = await api('GET', '/api/admin/deposits/' + orderId + '/voucher', 'e2e_admin');
  check('管理员可查看凭证图片', r.status === 200 && /image\/png/.test(r.headers.get('content-type') || ''));
  r = await api('GET', '/api/admin/deposits/' + orderId + '/voucher', 'e2e_player');
  check('普通用户访问管理员凭证接口 403', r.status === 403);

  // 批准（事务 + 余额 + 流水 + 审计）
  r = await api('POST', '/api/admin/deposits/' + orderId + '/review', 'e2e_admin', { decision: 'approve' });
  check('管理员批准充值', r.status === 200 && r.body.data.status === 'APPROVED', { detail: JSON.stringify(r.body).slice(0, 200) });
  check('批准后余额精确增加 RM100',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '1100.00');
  const tx = await sql(
    'SELECT type, amount, balance_before, balance_after, operator_id FROM balance_transactions WHERE related_request_id = ?',
    [orderId]
  );
  check('写入余额流水（含 before/after/操作人）',
    tx.length === 1 && tx[0].type === 'DEPOSIT' && String(tx[0].amount) === '100.00' &&
    String(tx[0].balance_before) === '1000.00' && String(tx[0].balance_after) === '1100.00' &&
    Number(tx[0].operator_id) === users['e2e_admin'].id);
  const ord = await sql('SELECT status, before_balance, after_balance, reviewed_by, reviewed_at FROM wallet_orders WHERE id = ?', [orderId]);
  check('订单快照记录前后余额与操作人',
    ord[0].status === 'APPROVED' && String(ord[0].before_balance) === '1000.00' &&
    String(ord[0].after_balance) === '1100.00' && Number(ord[0].reviewed_by) === users['e2e_admin'].id &&
    Boolean(ord[0].reviewed_at));
  const audit = await sql("SELECT detail FROM admin_logs WHERE action = 'wallet_order_review' AND detail LIKE ?", ['order=' + orderId + ' %']);
  check('Audit Log 记录充值审核', audit.length >= 1 && /decision=approved/.test(audit[0].detail));
  check('Audit Log 不含密码 / OTP 明文', !/password|otp/i.test(JSON.stringify(audit)));
  r = await api('POST', '/api/admin/deposits/' + orderId + '/review', 'e2e_admin', { decision: 'approve' });
  check('重复批准返回 409（幂等）', r.status === 409, { status: r.status, code: r.body.code });
  check('重复批准不重复入账',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '1100.00');
  check('同一订单只有一条充值流水',
    (await sql('SELECT COUNT(*) AS c FROM balance_transactions WHERE related_request_id = ?', [orderId]))[0].c === 1);
  r = await api('POST', '/api/admin/wallet/orders/' + orderId + '/review', 'e2e_admin', { decision: 'approved' });
  check('旧资金审核接口同样拒绝重复批准 409', r.status === 409);
}


// ============================================
// 推广奖励 Ledger（后端计算 + 幂等）
// ============================================
async function runRewardFlow(orderId) {
  const rewards = await sql('SELECT user_id, level, rate, base_amount, reward_amount, status FROM referral_rewards ORDER BY level');
  check('充值通过后生成两档推广奖励（直属 + 二级）', rewards.length === 2, { count: rewards.length });
  const direct = rewards.filter(x => Number(x.level) === 1)[0];
  const second = rewards.filter(x => Number(x.level) === 2)[0];
  check('直属奖励 0.5% × RM100 = RM0.50 且已入账',
    direct && String(direct.rate) === '0.500' && String(direct.reward_amount) === '0.50' && direct.status === 'CREDITED');
  check('二级奖励 0.3% × RM100 = RM0.30 且已入账',
    second && String(second.rate) === '0.300' && String(second.reward_amount) === '0.30' && second.status === 'CREDITED');
  check('奖励归属正确（直属 → e2e_upline，二级 → e2e_grant）',
    Number(direct.user_id) === users['e2e_upline'].id && Number(second.user_id) === users['e2e_grant'].id);
  check('奖励入账到上级测试资产',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_upline'].id]))[0].cash_chips) === '0.50' &&
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_grant'].id]))[0].cash_chips) === '0.30');
  check('奖励流水类型为 REFERRAL_REWARD',
    (await sql("SELECT COUNT(*) AS c FROM balance_transactions WHERE type = 'REFERRAL_REWARD'"))[0].c === 2);

  let r = await api('POST', '/api/admin/referrals/rewards/settle', 'e2e_admin', { order_id: orderId });
  check('补结算幂等：重复结算不再发奖', r.status === 200 && r.body.data.created === 0, { created: r.body.data.created });
  check('奖励总数仍为 2 条', (await sql('SELECT COUNT(*) AS c FROM referral_rewards'))[0].c === 2);
  r = await api('POST', '/api/admin/referrals/rewards/settle', 'e2e_player', { order_id: orderId });
  check('普通用户不能触发补结算（403）', r.status === 403);

  r = await api('GET', '/api/promote/rewards', 'e2e_upline');
  check('上级可在推广页看到自己的奖励台账',
    r.status === 200 && r.body.data.list.length === 1 && r.body.data.list[0].reward_amount === 0.5 &&
    r.body.data.summary.credited === 0.5);
  r = await api('GET', '/api/promote/rewards', 'e2e_player');
  check('普通用户看不到他人的奖励', r.status === 200 && r.body.data.list.length === 0);
  r = await api('GET', '/api/admin/referrals?q=22222222', 'e2e_admin');
  const refRow = (r.body.data.list || [])[0] || {};
  check('管理员推广管理可搜索邀请码并显示直属/二级与奖励',
    r.status === 200 && refRow.direct === 1 && refRow.second === 0 && refRow.reward_total === 0.5,
    { detail: JSON.stringify(refRow).slice(0, 200) });
  r = await api('GET', '/api/admin/referrals/rewards?level=2', 'e2e_admin');
  check('管理员可按层级筛选奖励台账', r.status === 200 && r.body.data.list.length === 1 && r.body.data.list[0].level === 2);
  check('推广后台不返回密码字段', !/password_hash/i.test(JSON.stringify(r.body.data)));
}



// ============================================
// 提款流程（提交不扣款 / 批准才扣 / 不产生负余额）
// ============================================
async function runWithdrawFlow() {
  let r = await api('GET', '/api/withdraw/config', 'e2e_player');
  check('提款配置返回资产类型与收款方式',
    r.status === 200 && r.body.data.asset_types.length === 2 && r.body.data.account_types.length >= 3);
  check('提款提示为测试环境（非现金化测试资产）',
    r.body.data.test_mode === true && /测试/.test(r.body.data.test_mode_notice.title));

  r = await api('GET', '/api/withdraw/balance?asset_type=CASH_CHIPS', 'e2e_player');
  check('可用测试资产余额来自后端', r.status === 200 && r.body.data.available === 1100 && r.body.data.asset_type === 'CASH_CHIPS');

  r = await api('POST', '/api/withdrawals/orders', 'e2e_player', { asset_type: 'CASH_CHIPS', amount: 0, account_type: 'BANK', account_reference: 'TEST-ACC-1' });
  check('提款金额 0 被拒绝', r.status === 422);
  r = await api('POST', '/api/withdrawals/orders', 'e2e_player', { asset_type: 'CASH_CHIPS', amount: -50, account_type: 'BANK', account_reference: 'TEST-ACC-1' });
  check('负数提款被拒绝', r.status === 422);
  r = await api('POST', '/api/withdrawals/orders', 'e2e_player', { asset_type: 'CASH_CHIPS', amount: 5000, account_type: 'BANK', account_reference: 'TEST-ACC-1' });
  check('超过可用余额的提款被拒绝（409）', r.status === 409 && r.body.code === 'INSUFFICIENT_BALANCE');
  r = await api('POST', '/api/withdrawals/orders', 'e2e_player', { asset_type: 'CASH_CHIPS', amount: 100, account_type: 'WECHAT', account_reference: 'TEST-ACC-1' });
  check('非法收款方式被拒绝', r.status === 422);
  r = await api('POST', '/api/withdrawals/orders', 'e2e_player', { asset_type: 'CASH_CHIPS', amount: 100, account_type: 'BANK', account_reference: 'x' });
  check('收款账号过短被拒绝', r.status === 422);

  r = await api('POST', '/api/withdrawals/orders', 'e2e_player',
    { asset_type: 'CASH_CHIPS', amount: 200, account_type: 'BANK', account_reference: 'TEST-ACC-8899', remark: 'e2e' });
  check('提款申请创建成功（PENDING）', r.status === 200 && r.body.data.order.status === 'PENDING', { detail: JSON.stringify(r.body).slice(0, 160) });
  const wdId = r.body.data.order.id;
  check('提款订单号以 W 开头且唯一', /^W[0-9A-F]{12,}$/.test(r.body.data.order.order_no));
  check('提交提款不扣余额',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '1100.00');

  r = await api('GET', '/api/admin/withdrawals?status=PENDING&q=e2e_player', 'e2e_admin');
  check('管理员可筛选提款订单', r.status === 200 && r.body.data.list.some(o => o.id === wdId));
  r = await api('POST', '/api/admin/withdrawals/' + wdId + '/review', 'e2e_admin', { decision: 'approve' });
  check('管理员批准提款', r.status === 200 && r.body.data.status === 'APPROVED');
  check('批准后余额精确扣减 RM200',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '900.00');
  const wtx = await sql("SELECT amount, balance_before, balance_after FROM balance_transactions WHERE related_request_id = ? AND type = 'WITHDRAW'", [wdId]);
  check('提款流水为负数且记录前后余额',
    wtx.length === 1 && String(wtx[0].amount) === '-200.00' &&
    String(wtx[0].balance_before) === '1100.00' && String(wtx[0].balance_after) === '900.00');
  r = await api('POST', '/api/admin/withdrawals/' + wdId + '/review', 'e2e_admin', { decision: 'approve' });
  check('重复批准提款 409（不重复扣款）', r.status === 409);
  check('余额未被重复扣减',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '900.00');

  // 余额不足时批准 → 409 且不产生负余额
  r = await api('POST', '/api/withdrawals/orders', 'e2e_player',
    { asset_type: 'CASH_CHIPS', amount: 800, account_type: 'BANK', account_reference: 'TEST-ACC-0001' });
  const wd2 = r.body.data.order.id;
  await sql('UPDATE users SET cash_chips = 100.00 WHERE id = ?', [users['e2e_player'].id]);
  r = await api('POST', '/api/admin/withdrawals/' + wd2 + '/review', 'e2e_admin', { decision: 'approve' });
  check('余额不足时批准被拒绝（409）', r.status === 409 && r.body.code === 'INSUFFICIENT_BALANCE');
  check('余额不足不会产生负余额',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '100.00');
  r = await api('POST', '/api/admin/withdrawals/' + wd2 + '/review', 'e2e_admin', { decision: 'reject', reason: '测试拒绝' });
  check('管理员拒绝提款成功', r.status === 200 && r.body.data.status === 'REJECTED');
  check('拒绝不改动余额',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '100.00');
  r = await api('POST', '/api/admin/withdrawals/' + wd2 + '/review', 'e2e_admin', { decision: 'reject' });
  check('拒绝必须填写原因（422）', r.status === 422);

  // 用户取消
  r = await api('POST', '/api/deposits/orders', 'e2e_player', { amount: '30', payment_method: 'BANK' });
  const cancelId = r.body.data.order.id;
  r = await api('POST', '/api/deposits/orders/' + cancelId + '/cancel', 'e2e_player');
  check('用户可取消未审核充值订单', r.status === 200 && r.body.data.status === 'CANCELLED');
  let fd = new FormData();
  fd.append('voucher', new Blob([makePng(64, 64, true)], { type: 'image/png' }), 'v.png');
  r = await api('POST', '/api/deposits/orders/' + cancelId + '/voucher', 'e2e_player', fd);
  check('已取消订单不能再提交凭证（409）', r.status === 409, { status: r.status, code: r.body.code });
  r = await api('POST', '/api/deposits/orders/' + cancelId + '/cancel', 'e2e_player');
  check('重复取消 409', r.status === 409);
  r = await api('POST', '/api/deposits/orders/' + cancelId + '/cancel', 'e2e_upline');
  check('他人不能取消自己的订单（404）', r.status === 404);
}

// ============================================
// 入口
// ============================================
async function main() {
  await prepareDatabase();
  await startServer();
  // 主流程内需要 orderId 传递给后续流程 → 用共享变量
  const created = await createDepositAndVoucher();
  await runAdminFlow(created);
  await runRewardFlow(created);
  await runWithdrawFlow();
  await runWalletRecords();
  report.completed = true;
}

async function createDepositAndVoucher() {
  let r = await api('GET', '/api/deposit/config', null);
  check('匿名读取充值配置 → 401', r.status === 401, { status: r.status });
  r = await api('GET', '/api/deposit/config', 'e2e_player');
  check('充值配置：最低 RM30、最高 RM50,000', r.status === 200 && r.body.data.min === 30 && r.body.data.max === 50000);
  check('付款方式只有「银行转账」', r.body.data.payment_methods.length === 1 && r.body.data.payment_methods[0].code === 'BANK');
  check('测试环境提示为「测试充值」', r.body.data.test_mode_notice.title === '测试充值');
  check('测试收款资料明确标注不可真实转账',
    r.body.data.test_receiving.account_no === 'TEST-ACCOUNT' && /不可用于真实转账/.test(r.body.data.test_receiving.notice),
    { notice: r.body.data.test_receiving.notice });
  check('USDT 入口指向在线客服', r.body.data.usdt_entry.link === '/support-chat.html');

  const badAmounts = [20, 50001, 0, -5, 'abc', '30.999', '1e9', 'Infinity', 'NaN', '', null];
  let badOk = true, badDetail = '';
  for (const a of badAmounts) {
    const res = await api('POST', '/api/deposits/orders', 'e2e_player', { amount: a, payment_method: 'BANK' });
    if (res.status !== 422) { badOk = false; badDetail = String(a) + ' → ' + res.status; break; }
  }
  check('非法充值金额全部 422（0/负数/NaN/Infinity/科学计数法/超限/低于下限）', badOk, { detail: badDetail });
  r = await api('POST', '/api/deposits/orders', 'e2e_player', { amount: 100, payment_method: 'USDT' });
  check('不支持的付款方式 422', r.status === 422 && r.body.code === 'INVALID_METHOD');
  r = await api('POST', '/api/deposits/orders', null, { amount: 100, payment_method: 'BANK' });
  check('匿名创建充值订单 401', r.status === 401);

  r = await api('POST', '/api/deposits/orders', 'e2e_player', { amount: '100', payment_method: 'BANK' });
  check('创建充值订单成功', r.status === 200 && r.body.success === true, { detail: JSON.stringify(r.body).slice(0, 160) });
  const order = r.body.data.order;
  const orderId = order.id;
  check('订单状态为 PENDING_PAYMENT（待付款）', order.status === 'PENDING_PAYMENT' && order.status_text === '待付款');
  check('订单号服务端生成且唯一', /^D[0-9A-F]{12,}$/.test(order.order_no), { order_no: order.order_no });
  check('订单金额为 RM100.00（现金筹码测试资产）', order.amount === 100 && order.asset_type === 'CASH_CHIPS');
  check('创建订单不改动余额',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '1000.00');
  const r2 = await api('POST', '/api/deposits/orders', 'e2e_player', { amount: '30', payment_method: 'BANK' });
  check('第二笔订单号与第一笔不同', r2.body.data.order.order_no !== order.order_no);
  check('最低金额 RM30 可正常下单', r2.body.data.order.status === 'PENDING_PAYMENT');

  r = await api('GET', '/api/deposits/orders/' + orderId, 'e2e_player');
  check('订单详情含测试收款信息与充值声明',
    r.status === 200 && r.body.data.test_receiving.bank_name === '测试银行' &&
    Array.isArray(r.body.data.declaration.items) && r.body.data.declaration.items.indexOf('订单号') >= 0);
  r = await api('GET', '/api/deposits/orders/' + orderId, 'e2e_upline');
  check('他人订单详情 → 404（越权保护）', r.status === 404);

  let fd = new FormData();
  fd.append('voucher', new Blob([Buffer.alloc(3000, 0x41)], { type: 'image/png' }), 'fake.png');
  r = await api('POST', '/api/deposits/orders/' + orderId + '/voucher', 'e2e_player', fd);
  check('伪造扩展名的文本文件被拒绝', r.status === 422 && r.body.code === 'FILE_TYPE_INVALID', { detail: r.body.code });
  fd = new FormData();
  fd.append('voucher', new Blob([makePng(32, 32, true)], { type: 'image/png' }), 'small.png');
  r = await api('POST', '/api/deposits/orders/' + orderId + '/voucher', 'e2e_player', fd);
  check('尺寸过小图片被拒绝', r.status === 422 && r.body.code === 'IMAGE_TOO_SMALL', { detail: r.body.code });
  fd = new FormData();
  fd.append('voucher', new Blob([makePng(64, 64, true)], { type: 'image/jpeg' }), 'voucher.jpg');
  r = await api('POST', '/api/deposits/orders/' + orderId + '/voucher', 'e2e_player', fd);
  check('真实 PNG 上传成功（以文件内容识别类型）',
    r.status === 200 && r.body.data.order.status === 'PENDING_REVIEW', { detail: JSON.stringify(r.body).slice(0, 200) });
  check('提交凭证后提示等待管理员审核', /等待管理员审核/.test(r.body.data.message || ''));
  check('提交凭证不增加余额（不会自动充值成功）',
    String((await sql('SELECT cash_chips FROM users WHERE id = ?', [users['e2e_player'].id]))[0].cash_chips) === '1000.00');
  const vp = (await sql('SELECT voucher_path, voucher_uploaded_at FROM wallet_orders WHERE id = ?', [orderId]))[0];
  check('凭证保存在非公开目录且文件名由服务器生成',
    /^vouchers\//.test(vp.voucher_path || '') && Boolean(vp.voucher_uploaded_at), { path: vp.voucher_path });
  check('凭证未落在 public 静态目录', !fs.existsSync(path.join(ROOT, 'public', vp.voucher_path || 'nope')));
  r = await api('GET', '/api/deposits/orders/' + orderId + '/voucher', 'e2e_player');
  check('本人可查看自己的凭证（image/png）', r.status === 200 && /image\/png/.test(r.headers.get('content-type') || ''));
  r = await api('GET', '/api/deposits/orders/' + orderId + '/voucher', 'e2e_upline');
  check('他人无法查看凭证 404', r.status === 404);
  return orderId;
}

// ---------- 钱包交易记录 ----------
async function runWalletRecords() {
  let r = await api('GET', '/api/wallet/records?filter=all&limit=50', 'e2e_player');
  const list = (r.body.data && r.body.data.list) || [];
  check('钱包交易记录包含充值入账',
    r.status === 200 && list.some(x => x.type_text === '充值' || x.type === 'DEPOSIT'));
  r = await api('GET', '/api/wallet/summary', 'e2e_upline');
  check('推广奖励进入余额流水（上级钱包可见）',
    r.status === 200 && r.body.data.recent_transactions.some(x => x.type === 'REFERRAL_REWARD'),
    { detail: JSON.stringify(r.body.data.recent_transactions).slice(0, 200) });
}


// ---------- 收尾 ----------
const watchdog = setTimeout(() => { report.error = '端到端测试超过 120 秒'; finish(); }, 120000);
let finished = false;
async function finish() {
  if (finished) return;
  finished = true;
  clearTimeout(watchdog);
  if (child) { try { child.kill(); } catch (e) {} }
  try { if (root) await root.query('DROP DATABASE IF EXISTS ' + TEST_DB); } catch (e) { report.cleanup = e.message; }
  try { if (root) await root.end(); } catch (e) {}
  report.finished = new Date().toISOString();
  report.passed = report.completed === true && !report.error && report.checks.every(c => c.pass);
  if (!report.passed) report.server_log_tail = serverLog.slice(-2500);
  const file = path.join(__dirname, 'deposit-withdraw-e2e-report.json');
  fs.writeFileSync(file, JSON.stringify(report, null, 2));
  const failed = report.checks.filter(c => !c.pass);
  console.log('DEPOSIT_WITHDRAW_E2E ' + (report.passed ? 'PASS' : 'FAIL') +
    ' (' + (report.checks.length - failed.length) + '/' + report.checks.length + ')');
  if (report.error) console.log('  error: ' + report.error);
  failed.forEach(c => console.log('  FAIL: ' + c.name + (c.detail ? ' :: ' + c.detail : '')));
  process.exitCode = report.passed ? 0 : 1;
}

main()
  .then(() => finish())
  .catch(err => { report.error = err.message + ' | ' + String(err.stack || '').split('\n')[1]; finish(); });

