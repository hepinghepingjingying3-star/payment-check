'use strict';
// ============================================
// 26牛牛 - 真实管理员账号只读验收（默认对 3000 端口开发服务）
// 用途: 用线上/开发环境里真实存在的管理员账号走一遍完整链路，确认
//       1) 真实登录下发 HttpOnly 页面票据 Cookie（SameSite=Lax）
//       2) 管理员打开 /admin.html、/admin-otp.html → 200 且 no-store
//       3) 管理员可调用 /api/admin/dashboard、/api/admin/users（含禁言/角色字段）
//       4) 门禁：普通用户票据 / 匿名 / 伪造签名 → 302 回 /me.html?admin=denied，绝不下发后台 HTML
//       5) 退出登录清除票据
//       6) 真实 Chrome：我的页入口 → 后台 → 统计卡进用户列表 → 点用户名开管理面板
//          （管理员自身只有「取消管理员权限」；普通用户含 设为管理员 / 禁言 / 封禁）
//          → OTP 管理页正常
// 数据安全: 全程只读 —— 只做登录 / 退出与 GET 查询，不创建账号、不改任何账号、
//           不领取 OTP 明文。登录本身会在 login_logs 留下一条真实登录记录（与人工登录一致）。
// 凭证: 口令不写进仓库，必须通过环境变量传入：
//         set NN_ADMIN_PASSWORD=<口令>            （可选 NN_ADMIN_USERNAME / NN_BASE）
// 运行: node tests\admin-real-account.js
// 报告: tests/admin-real-account-report.json
// ============================================
require('dotenv').config();
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const jwt = require('jsonwebtoken');

const BASE = String(process.env.NN_BASE || 'http://127.0.0.1:3000').replace(/\/+$/, '');
const ADMIN_USER = String(process.env.NN_ADMIN_USERNAME || '37491058');
const ADMIN_PASS = String(process.env.NN_ADMIN_PASSWORD || '');
const NORMAL_USER_ID = Number(process.env.NN_NORMAL_USER_ID || 11); // dodo:普通用户,验证门禁按数据库角色判断
const CHROME = process.env.NN_CHROME || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const reportPath = path.join(__dirname, 'admin-real-account-report.json');

const results = [];
function check(ok, name, detail) {
  results.push({ name, pass: !!ok, detail: detail === undefined ? null : detail });
  console.log((ok ? '  ok   ' : '  FAIL ') + name + (detail === undefined ? '' : ' :: ' + JSON.stringify(detail)));
}
const wait = ms => new Promise(r => setTimeout(r, ms));

if (!ADMIN_PASS) {
  console.log('缺少环境变量 NN_ADMIN_PASSWORD（真实管理员口令），未执行任何请求。');
  console.log('用法: set NN_ADMIN_PASSWORD=<口令> && node tests\\admin-real-account.js');
  process.exit(2);
}

(async () => {
  // ---------- 1. 服务存活 + 真实管理员登录 ----------
  const home = await fetch(BASE + '/me.html');
  check(home.status === 200, '3000 端口服务存活 (/me.html 200)', { status: home.status });

  const loginRes = await fetch(BASE + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: ADMIN_USER, password: ADMIN_PASS })
  });
  const loginJson = await loginRes.json().catch(() => ({}));
  const loginData = loginJson.data || {};
  check(loginRes.status === 200 && loginJson.success === true, '真实管理员 37491058 登录成功',
    { status: loginRes.status, message: loginJson.message });
  check(!!loginData.token && loginData.user && loginData.user.role === 'admin',
    '登录返回 JWT 且角色为 admin',
    { id: loginData.user && loginData.user.id, username: loginData.user && loginData.user.username, role: loginData.user && loginData.user.role });
  const token = loginData.token;

  const setCookieList = typeof loginRes.headers.getSetCookie === 'function' ? loginRes.headers.getSetCookie() : [];
  const rawCookie = setCookieList.find(c => c.indexOf('nn_page=') === 0) || '';
  const pageCookie = rawCookie.split(';')[0];
  check(!!pageCookie, '下发页面票据 Cookie nn_page', { cookie: pageCookie ? pageCookie.slice(0, 22) + '…' : 'missing' });
  check(/HttpOnly/i.test(rawCookie), '票据为 HttpOnly（页面 JS 读不到）');
  check(/SameSite=Lax/i.test(rawCookie), '票据为 SameSite=Lax');

  const H_ADMIN = { Authorization: 'Bearer ' + token };
  const H_COOKIE = { Cookie: pageCookie };

  // ---------- 2. 管理页面：真实管理员可进 ----------
  const a1 = await fetch(BASE + '/admin.html', { headers: H_COOKIE, redirect: 'manual' });
  const b1 = await a1.text();
  check(a1.status === 200, '管理员打开 /admin.html → 200（未被拦回）', { status: a1.status });
  check(b1.indexOf('id="adminBody"') >= 0 && b1.indexOf('id="userList"') >= 0 && b1.indexOf('id="statGrid"') >= 0,
    '后台 HTML 含后台主体 / 统计区 / 用户列表容器');
  check(/no-store/i.test(a1.headers.get('cache-control') || ''), '管理页禁止缓存 (no-store)', { cache: a1.headers.get('cache-control') });

  const a2 = await fetch(BASE + '/admin-otp.html', { headers: H_COOKIE, redirect: 'manual' });
  const b2 = await a2.text();
  check(a2.status === 200, '管理员打开 /admin-otp.html → 200', { status: a2.status });
  check(/id="otpBody"[^>]*hidden/.test(b2), 'OTP 页内容区默认隐藏（校验通过后才显示）');
  check(/no-store/i.test(a2.headers.get('cache-control') || ''), 'OTP 页禁止缓存 (no-store)', { cache: a2.headers.get('cache-control') });

  // ---------- 3. 管理 API：真实管理员可用 ----------
  const dash = await fetch(BASE + '/api/admin/dashboard', { headers: H_ADMIN });
  const dashJson = await dash.json().catch(() => ({}));
  const dashData = dashJson.data || {};
  check(dash.status === 200 && !!dashData.users, 'GET /api/admin/dashboard → 200',
    { status: dash.status, users: dashData.users });
  check(dashData.users && dashData.users.total >= 1 && typeof dashData.users.today === 'number',
    '概览统计包含总用户数与今日注册', dashData.users);

  const usersRes = await fetch(BASE + '/api/admin/users?limit=5', { headers: H_ADMIN });
  const usersJson = await usersRes.json().catch(() => ({}));
  const list = (usersJson.data && (usersJson.data.users || usersJson.data.list)) || [];
  check(usersRes.status === 200 && list.length > 0, 'GET /api/admin/users → 200 且有数据',
    { status: usersRes.status, count: list.length });
  check(list.length > 0 && Object.prototype.hasOwnProperty.call(list[0], 'muted') &&
    Object.prototype.hasOwnProperty.call(list[0], 'muted_until') && Object.prototype.hasOwnProperty.call(list[0], 'role'),
    '用户列表带禁言 / 角色字段', list.length ? Object.keys(list[0]) : []);

  // ---------- 4. 门禁：普通用户 / 匿名 / 伪造签名 ----------
  const normalCookie = 'nn_page=' + jwt.sign({ id: NORMAL_USER_ID }, process.env.JWT_SECRET, { expiresIn: '5m', algorithm: 'HS256' });
  const n1 = await fetch(BASE + '/admin.html', { headers: { Cookie: normalCookie }, redirect: 'manual' });
  check(n1.status === 302 && n1.headers.get('location') === '/me.html?admin=denied',
    '普通用户票据访问 /admin.html → 302 /me.html?admin=denied',
    { status: n1.status, location: n1.headers.get('location') });

  const n2 = await fetch(BASE + '/admin-otp.html', { headers: { Cookie: normalCookie }, redirect: 'manual' });
  const n2body = n2.status === 302 ? '' : await n2.text();
  check(n2.status === 302 && n2body.indexOf('id="otpList"') < 0,
    '普通用户票据访问 /admin-otp.html → 302 且不下发后台 HTML', { status: n2.status });

  const a3 = await fetch(BASE + '/admin.html', { redirect: 'manual' });
  check(a3.status === 302, '匿名访问 /admin.html → 302', { status: a3.status });

  const forged = 'nn_page=' + jwt.sign({ id: 10 }, 'wrong-secret', { expiresIn: '5m', algorithm: 'HS256' });
  const a4 = await fetch(BASE + '/admin.html', { headers: { Cookie: forged }, redirect: 'manual' });
  check(a4.status === 302, '伪造签名票据访问 /admin.html → 302', { status: a4.status });

  // ---------- 5. 退出登录清除票据 ----------
  const out = await fetch(BASE + '/api/auth/logout', { method: 'POST', headers: Object.assign({}, H_ADMIN, H_COOKIE) });
  const outCookie = (typeof out.headers.getSetCookie === 'function' ? out.headers.getSetCookie() : [])
    .find(c => c.indexOf('nn_page=') === 0) || '';
  check(out.status === 200, 'POST /api/auth/logout → 200', { status: out.status });
  check(/Expires=Thu, 01 Jan 1970|Max-Age=0/i.test(outCookie), '退出登录清除 nn_page',
    { set_cookie: outCookie.replace(/nn_page=[^;]*/, 'nn_page=<cleared>') });
  const a5 = await fetch(BASE + '/admin.html', { headers: { Cookie: 'nn_page=' }, redirect: 'manual' });
  check(a5.status === 302, '票据清除后访问 /admin.html → 302', { status: a5.status });

  await runBrowserPhase(token);
  report();
})().catch(err => {
  console.log('REAL_ADMIN_ACCEPT ERROR ' + err.message);
  report();
  process.exit(1);
});

function report() {
  const passed = results.filter(r => r.pass).length;
  fs.writeFileSync(reportPath, JSON.stringify({
    finished: new Date().toISOString(),
    base: BASE, admin_username: ADMIN_USER,
    mode: 'read-only acceptance (login + logout + GET only; no account changes)',
    total: results.length, passed, failed: results.filter(r => !r.pass), results
  }, null, 2));
  console.log('ADMIN_REAL_ACCOUNT ' + (passed === results.length ? 'PASS' : 'FAIL') + ' (' + passed + '/' + results.length + ')');
  process.exit(passed === results.length ? 0 : 1);
}

// ---------- 6. 真实 Chrome：真实管理员账号的只读界面走查 ----------
async function runBrowserPhase(adminToken) {
  console.log('\n[浏览器阶段] 真实 Chrome + 3000 端口真实管理员账号（只读）');
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), '26-realadmin-'));
  const pageErrors = [];
  let ws = null;
  try {
    const chrome = spawn(CHROME, [
      '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
      '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank'
    ], { stdio: 'ignore' });
    chrome.on('error', e => pageErrors.push('chrome: ' + e.message));
    let debugPort = null;
    for (let i = 0; i < 120; i++) {
      try { debugPort = fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0]; break; } catch (_) { await wait(100); }
    }
    check(!!debugPort, 'Chrome DevTools 调试端口可用', { port: debugPort || null });
    if (!debugPort) return;
    const targets = await (await fetch('http://127.0.0.1:' + debugPort + '/json/list')).json();
    const target = targets.find(t => t.type === 'page');
    ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
    let seq = 0;
    const pending = new Map();
    ws.onmessage = event => {
      const m = JSON.parse(event.data);
      if (m.id && pending.has(m.id)) {
        const p = pending.get(m.id); pending.delete(m.id);
        if (m.error) p.reject(new Error(m.error.message)); else p.resolve(m.result);
      }
      if (m.method === 'Runtime.exceptionThrown') pageErrors.push('exception: ' + String(m.params.exceptionDetails.text || ''));
      if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') pageErrors.push('console.error: ' + JSON.stringify(m.params.args));
    };
    const send = (method, params = {}) => new Promise((resolve, reject) => {
      const n = ++seq; pending.set(n, { resolve, reject }); ws.send(JSON.stringify({ id: n, method, params }));
    });
    const evaluate = async expression => {
      const r = await send('Runtime.evaluate', { expression, returnByValue: true });
      if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
      return r.result.value;
    };
    const evaluateAsync = async expression => {
      const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
      if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
      return r.result.value;
    };
    async function waitExpr(expr, tries = 60) {
      for (let i = 0; i < tries; i++) {
        if (await evaluate('(' + expr + ')').catch(() => false)) return true;
        await wait(120);
      }
      return false;
    }
    async function goto(url, readyExpr, tries = 60) {
      await send('Page.navigate', { url: BASE + url });
      let ok = false;
      for (let i = 0; i < tries; i++) {
        ok = await evaluate("document.readyState === 'complete' && (" + readyExpr + ")").catch(() => false);
        if (ok) break;
        await wait(120);
      }
      check(ok, '页面就绪: ' + url);
      return ok;
    }
    const sheetLabels = () => evaluate('Array.from(document.querySelectorAll(".sheet-item")).map(n => n.textContent.trim())');
    async function openSheetFor(username) {
      await send('Runtime.evaluate', { expression: 'document.getElementById("userQuery").value = ' + JSON.stringify(username) });
      // 先清空列表，确保随后出现的第一行一定来自本次查询结果
      await evaluate('(() => { document.getElementById("userList").innerHTML = ""; return true; })()');
      await evaluate('document.getElementById("searchUsers").click(); true');
      const found = await waitExpr('document.querySelectorAll("#userList .user-name[data-user]").length > 0 && document.getElementById("userList").textContent.indexOf(' + JSON.stringify(username) + ') >= 0');
      check(found, '用户查询命中「' + username + '」');
      await evaluate('(() => { const nodes = Array.from(document.querySelectorAll("#userList .user-name[data-user]"));' +
        'if (!nodes.length) return false; nodes[0].click(); return true; })()');
      check(await waitExpr('document.querySelectorAll(".sheet-item").length > 0'), '点击用户名弹出管理面板：' + username);
      return sheetLabels();
    }
    async function closeSheet() {
      await evaluate('(() => { const m = document.querySelector(".sheet-mask"); if (m) m.click(); return true; })()');
      check(await waitExpr('!document.querySelector(".sheet-mask")'), '关闭管理面板');
    }
    await send('Runtime.enable'); await send('Page.enable'); await send('Network.setCacheDisabled', { cacheDisabled: true });
    await send('Page.addScriptToEvaluateOnNewDocument', {
      source: "try { localStorage.setItem('token', " + JSON.stringify(adminToken) + "); window.prompt = function(){ return '只读走查'; }; } catch (e) {}"
    });
    await runBrowserSteps({ evaluate, evaluateAsync, waitExpr, goto, sheetLabels, openSheetFor, closeSheet });
  } finally {
    try { if (ws) ws.close(); } catch (_) {}
    await wait(300);
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (_) {}
  }
  check(pageErrors.length === 0, '界面走查全程无 JS 异常 / console.error', pageErrors.slice(0, 3));
}

// ---------- 7. 走查步骤（真实管理员账号，全部只读） ----------
async function runBrowserSteps(B) {
  // 浏览器内以真实账号登录（Cookie 由浏览器自己保存，与人工操作一致）
  await B.goto('/me.html', "document.getElementById('identity').hidden === false");
  const browserLogin = await B.evaluateAsync('(async () => {' +
    'const res = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" },' +
    ' body: JSON.stringify({ username: ' + JSON.stringify(ADMIN_USER) + ', password: ' + JSON.stringify(ADMIN_PASS) + ' }), credentials: "same-origin" });' +
    'const body = await res.json().catch(() => ({})); return { status: res.status, role: body && body.data && body.data.user ? body.data.user.role : null }; })()');
  check(browserLogin.status === 200 && browserLogin.role === 'admin',
    '浏览器内真实管理员登录成功（票据 Cookie 由浏览器保存）', browserLogin);

  await B.goto('/me.html', "document.getElementById('identity').hidden === false");
  const links = await B.evaluate('(() => ({' +
    'adminVisible: !!document.getElementById("adminLink").offsetParent,' +
    'otpVisible: !!document.getElementById("otpAdminLink").offsetParent,' +
    'adminHref: document.getElementById("adminLink").getAttribute("href"),' +
    'otpHref: document.getElementById("otpAdminLink").getAttribute("href") }))()');
  check(links.adminVisible && links.otpVisible && links.adminHref === '/admin.html' && links.otpHref === '/admin-otp.html',
    '「我的」页显示 管理后台 / OTP 管理 入口', links);

  // 真实点击入口链接进入后台
  await B.evaluate('(() => { document.getElementById("adminLink").click(); return true; })()');
  check(await B.waitExpr('location.pathname === "/admin.html" && document.getElementById("adminBody") && document.getElementById("adminBody").hidden === false'),
    '点击「管理后台」入口后成功进入 /admin.html（未被拦回）',
    { path: await B.evaluate('location.pathname + location.search') });

  const tiles = await B.evaluate('(() => { const nodes = Array.from(document.querySelectorAll("#statGrid [data-go]"));' +
    'return { count: nodes.length, labels: nodes.map(n => n.querySelector(".stat-label").textContent),' +
    'cursor: nodes.length ? getComputedStyle(nodes[0]).cursor : "",' +
    'text: nodes.length ? nodes[0].textContent.replace(/\\s+/g, " ").trim() : "" }; })()');
  check(tiles.count >= 2 && tiles.labels.indexOf('用户总数') >= 0 && tiles.labels.indexOf('今日注册') >= 0 && tiles.cursor === 'pointer',
    '概览「用户总数 / 今日注册」注册人数统计卡可点击（cursor:pointer）', tiles);

  check(await B.evaluate('(() => { document.querySelector("#statGrid [data-go]").click(); return true; })()'), '点击注册人数统计卡');
  check(await B.waitExpr('document.getElementById("panel-users").hidden === false'), '点击注册人数后进入用户列表 Tab');
  check(await B.waitExpr('document.querySelectorAll("#userList .user-name[data-user]").length > 0'), '用户列表渲染出可点击的用户名');
  const rows = await B.evaluate('(() => { const names = Array.from(document.querySelectorAll("#userList .user-name[data-user]"));' +
    'return { count: names.length, first: names[0].textContent.trim(), cursor: getComputedStyle(names[0]).cursor,' +
    'tags: Array.from(document.querySelectorAll("#userList .admin-tag")).map(n => n.textContent.trim()).slice(0, 6) }; })()');
  check(rows.count > 0 && rows.cursor === 'pointer', '用户名是可点击按钮（cursor:pointer）', rows);

  // 管理员自身：只应出现「取消管理员权限」，不出现禁言 / 封禁入口
  const adminSheet = await B.openSheetFor(ADMIN_USER);
  const hasRoleDown = adminSheet.some(t => t.indexOf('取消管理员权限') >= 0);
  const hasMute = adminSheet.some(t => t.indexOf('禁言') >= 0);
  const hasBan = adminSheet.some(t => t.indexOf('封禁') >= 0);
  check(hasRoleDown && !hasMute && !hasBan,
    '管理员账号面板只有「取消管理员权限」（禁言 / 封禁入口不出现）', adminSheet);
  await B.closeSheet();

  // 普通用户：应出现 设为管理员 / 禁言 / 封禁
  const userSheet = await B.openSheetFor('dodo');
  const uRole = userSheet.some(t => t.indexOf('设为管理员') >= 0);
  const uMute = userSheet.some(t => t.indexOf('禁言') >= 0);
  const uBan = userSheet.some(t => t.indexOf('封禁账号') >= 0);
  check(uRole && uMute && uBan, '普通用户面板提供 设为管理员 / 禁言 / 封禁', userSheet);
  await B.closeSheet();

  // OTP 管理页（只读：不点「领取一次」）
  await B.goto('/admin-otp.html', 'document.getElementById("otpBody") && document.getElementById("otpBody").hidden === false');
  check(await B.waitExpr('!document.querySelector("#otpList .sk-box")'), 'OTP 列表加载完成（未出现加载骨架）');
  const otp = await B.evaluate('(() => ({ path: location.pathname, denied: document.body.textContent.indexOf("无权访问") >= 0,' +
    'hasReload: !!document.getElementById("reloadOtp"), statusOptions: document.querySelectorAll("#otpStatus option").length,' +
    'listText: document.getElementById("otpList").textContent.replace(/\\s+/g, " ").trim().slice(0, 80) }))()');
  check(otp.path === '/admin-otp.html' && !otp.denied && otp.hasReload && otp.statusOptions >= 5,
    '管理员可正常打开 OTP 管理页（未领取任何验证码）', otp);
}
