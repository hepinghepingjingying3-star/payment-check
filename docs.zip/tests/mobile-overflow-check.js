'use strict';
// ============================================
// 26牛牛 - 移动端四屏宽实测（阶段 46 / 49）
// ============================================
// 做法:
//   - 真实 MySQL + 真实 server.js（临时端口）+ 真实 Chrome（CDP）
//   - 用临时管理员账号在浏览器里真实登录一次（写入 localStorage + 页面票据 Cookie）
//   - 逐页 × 四屏宽（360 / 375 / 390 / 412）检查：
//       1) 没有横向溢出（scrollWidth <= innerWidth）
//       2) 没有超出屏幕的输入框
//       3) 输入框 / 下拉框不是白底（深灰背景 + 浅色文字）
//       4) 底部导航不越出视口
//       5) 页面没有 JS 异常
//   - 临时账号在结束时删除；不改动任何真实用户、配置与资金数据
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const root = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(root, '.env') });

const PORT = 3104;
const BASE = 'http://127.0.0.1:' + PORT;
const WIDTHS = [360, 375, 390, 412, 430];
// 桌面端（任务要求 1366 / 1440 / 1920 基本适配，重点检查后台）
const DESKTOP_WIDTHS = [1366, 1440, 1920];
const DESKTOP_PAGES = ['/admin.html', '/admin-otp.html', '/lobby.html', '/niu.html', '/wallet.html', '/promote.html'];
const PAGES = [
  '/login.html', '/register.html', '/lobby.html', '/wallet.html',
  '/recharge.html', '/recharge-detail.html?id=1', '/withdraw.html',
  '/promote.html', '/group-chat.html', '/support-chat.html',
  '/notifications.html', '/messages.html', '/me.html',
  '/settings.html', '/security.html', '/tutorial.html', '/niu.html', '/avatar.html',
  '/admin.html', '/admin-otp.html'
];
const PASSWORD = 'TempPass!123';
const prefix = 'zzmob_' + Date.now().toString(36) + '_';
const report = { started: new Date().toISOString(), mode: 'Real server, real MySQL, real Chrome', checks: [], errors: [], pages: [], passed: false };
let conn = null;
let serverProcess = null;
let chrome = null;
let ws = null;
let tempUserId = null;
const profileDir = fs.mkdtempSync(path.join(os.tmpdir(), '26-mobile-'));
const wait = ms => new Promise(r => setTimeout(r, ms));

/**
 * 删除本脚本创建的临时账号及所有由 users 外键直接引用的临时记录。
 *
 * 不能只删 admin_logs/login_logs：真实库还会因浏览页面写入
 * chat_read_state、user_presence、notifications 等用户关联记录。这里从
 * information_schema 读取当前数据库的真实外键，逐个删掉引用该临时 UID 的
 * 子记录，再删除用户；不触碰任何非临时用户的数据，也不关闭外键检查。
 */
async function deleteTempUserAndDependencies(connection, userId) {
  const [refs] = await connection.query(
    `SELECT k.TABLE_NAME AS table_name, k.COLUMN_NAME AS column_name
       FROM information_schema.KEY_COLUMN_USAGE k
      WHERE k.TABLE_SCHEMA = DATABASE()
        AND k.REFERENCED_TABLE_NAME = 'users'
        AND k.REFERENCED_COLUMN_NAME = 'id'
      ORDER BY k.TABLE_NAME, k.ORDINAL_POSITION`
  );

  // 有些子表又被其它子表引用（例如红包领取 → 红包主表 → users），
  // 所以按多轮尝试处理：暂时受外键阻挡的项留到下一轮，直到所有可删项完成。
  let remaining = refs.slice();
  for (let pass = 0; pass < 6 && remaining.length; pass++) {
    const next = [];
    for (const ref of remaining) {
      try {
        // 标识符来自 information_schema，不使用客户端输入；仍转义反引号以保持安全。
        const table = String(ref.table_name).replace(/`/g, '``');
        const column = String(ref.column_name).replace(/`/g, '``');
        await connection.query('DELETE FROM `' + table + '` WHERE `' + column + '` = ?', [userId]);
      } catch (_) {
        next.push(ref);
      }
    }
    remaining = next;
  }

  // 某些历史表没有外键，但仍按用户 ID 保存数据；按实际存在的列分别删除，
  // 避免一个缺失列使同表中其它临时记录也无法清理。
  const legacyRefs = [
    ['chat_read_state', 'user_id'], ['user_presence', 'user_id'], ['user_stickers', 'user_id'],
    ['chat_messages', 'user_id'], ['chat_reports', 'reporter_id'],
    ['chat_red_packet_claims', 'user_id'], ['chat_red_packets', 'sender_id'],
    ['wallet_orders', 'user_id'], ['balance_transactions', 'user_id'],
    ['notifications', 'user_id'], ['login_logs', 'user_id'],
    ['admin_logs', 'admin_id'], ['admin_logs', 'target_user_id'],
    ['admin_approvals', 'requested_by'], ['admin_approvals', 'reviewed_by'], ['admin_approvals', 'target_user_id'],
    ['referral_rewards', 'user_id'], ['referral_rewards', 'source_user_id'],
    ['referral_relations', 'referrer_id'], ['referral_relations', 'referred_user_id'],
    ['real_name_reviews', 'user_id'], ['password_reset_tokens', 'user_id']
  ];
  for (const [tableName, columnName] of legacyRefs) {
    const [columns] = await connection.query(
      `SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1`,
      [tableName, columnName]
    );
    if (columns.length) {
      await connection.query('DELETE FROM `' + tableName + '` WHERE `' + columnName + '` = ?', [userId]);
    }
  }
  await connection.query('DELETE FROM users WHERE id = ?', [userId]);
}

function check(name, ok, detail) {
  report.checks.push({ name, pass: !!ok, detail: detail === undefined ? null : detail });
  try { fs.writeFileSync(path.join(__dirname, 'mobile-overflow-report.json'), JSON.stringify(report, null, 2)); } catch (_) {}
  if (!ok) throw new Error(name + ': ' + JSON.stringify(detail));
}

async function startServer() {
  serverProcess = spawn(process.execPath, ['server.js'], {
    cwd: root, env: Object.assign({}, process.env, { PORT: String(PORT) }),
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  serverProcess.stdout.on('data', d => { output += d.toString(); });
  serverProcess.stderr.on('data', d => { output += d.toString(); });
  for (let i = 0; i < 40; i++) {
    await wait(250);
    try { const r = await fetch(BASE + '/'); if (r.ok) return; } catch (_) { /* 尚未就绪 */ }
    if (serverProcess.exitCode !== null) throw new Error('server stopped: ' + output.slice(-300));
  }
  throw new Error('server did not start: ' + output.slice(-300));
}

/** 临时管理员账号（四屏宽检查需要能打开后台页） */
async function createTempAdmin() {
  const username = prefix + 'admin';
  const hash = await bcrypt.hash(PASSWORD, 10);
  const [r] = await conn.query(
    `INSERT INTO users (username, nickname, email, phone, real_name, password_hash,
       invite_code, role, status, token_version)
     VALUES (?, ?, NULL, NULL, ?, ?, ?, 'admin', 'active', 0)`,
    [username, username, '移动端验收', hash,
      crypto.randomBytes(4).toString('hex').toUpperCase()]
  );
  tempUserId = r.insertId;
  return username;
}

// ---------- Chrome / CDP ----------
async function launchChrome() {
  const candidates = [
    'C:/Program Files/Google/Chrome/Application/chrome.exe',
    'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe'
  ];
  const exe = candidates.filter(p => fs.existsSync(p))[0];
  if (!exe) throw new Error('Chrome not found');
  chrome = spawn(exe, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-port=0', '--user-data-dir=' + profileDir, 'about:blank'], { stdio: 'ignore' });
  chrome.on('error', e => report.errors.push(e.message));
  let port = null;
  for (let i = 0; i < 100 && !port; i++) {
    try { port = fs.readFileSync(path.join(profileDir, 'DevToolsActivePort'), 'utf8').split('\n')[0]; } catch (_) { await wait(100); }
  }
  if (!port) throw new Error('Chrome debug port not available');
  const targets = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json();
  const target = targets.filter(t => t.type === 'page')[0];
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
  let id = 0;
  const pending = new Map();
  const pageErrors = [];
  ws.onmessage = event => {
    const m = JSON.parse(event.data);
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.reject(new Error(m.error.message)); else p.resolve(m.result);
    }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = m.params.exceptionDetails || {};
      pageErrors.push(d.text || (d.exception && d.exception.description) || 'exception');
    }
  };
  const send = (method, params) => new Promise((resolve, reject) => {
    const n = ++id; pending.set(n, { resolve, reject }); ws.send(JSON.stringify({ id: n, method, params: params || {} }));
  });
  await send('Page.enable');
  await send('Runtime.enable');
  return {
    errors: pageErrors,
    resetErrors() { pageErrors.length = 0; },
    async evaluate(expression) {
      const r = await send('Runtime.evaluate', { expression, returnByValue: true });
      return r.result ? r.result.value : undefined;
    },
    async goto(url) { await send('Page.navigate', { url }); await wait(280); },
    async setWidth(width) {
      await send('Emulation.setDeviceMetricsOverride', { width, height: 800, deviceScaleFactor: 2, mobile: true });
    }
  };
}

// 页面内测量：横向溢出 / 输入框越界 / 输入框白底 / 底部导航越界
const MEASURE = `(function(){
  var de = document.documentElement;
  var vw = window.innerWidth;
  var sw = Math.max(de.scrollWidth, document.body ? document.body.scrollWidth : 0);
  var bad = [];
  var nodes = document.querySelectorAll('input:not([type=checkbox]):not([type=radio]):not([type=hidden]), textarea, select');
  for (var i = 0; i < nodes.length; i++) {
    var el = nodes[i];
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    if (r.right > vw + 1) bad.push('wide:' + (el.id || el.tagName));
    var bg = getComputedStyle(el).backgroundColor || '';
    if (bg.indexOf('rgb') === 0) {
      var parts = bg.replace('rgba(', '').replace('rgb(', '').replace(')', '').split(',');
      var alpha = parts.length > 3 ? parseFloat(parts[3]) : 1;
      var min = Math.min(parseInt(parts[0], 10), parseInt(parts[1], 10), parseInt(parts[2], 10));
      if (alpha > 0.5 && min > 170) bad.push('light:' + (el.id || el.tagName) + ':' + bg);
    }
  }
  var nav = document.querySelector('.bottom-nav');
  var navBottom = nav ? Math.round(nav.getBoundingClientRect().bottom) : null;
  var vh = window.innerHeight;
  if (navBottom !== null && navBottom > vh + 1) bad.push('nav-overflow:' + navBottom + '>' + vh);
  return { width: vw, scrollWidth: sw, overflow: sw - vw, bad: bad.slice(0, 6), path: location.pathname };
})()`;

async function main() {
  conn = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
  const username = await createTempAdmin();
  await startServer();
  const B = await launchChrome();
  await B.setWidth(390);

  // ---------- 真实浏览器登录（写入 localStorage + 页面票据 Cookie） ----------
  await B.goto(BASE + '/login.html');
  await B.evaluate('(function(){document.getElementById("username").value=' + JSON.stringify(username) +
    ';document.getElementById("password").value=' + JSON.stringify(PASSWORD) + ';return true})()');
  await B.evaluate('(function(){document.getElementById("loginForm").dispatchEvent(new Event("submit",{cancelable:true,bubbles:true}));return true})()');
  let landed = null;
  for (let i = 0; i < 40; i++) {
    await wait(250);
    const p = await B.evaluate('location.pathname');
    if (p && p !== '/login.html') { landed = p; break; }
  }
  check('real browser login reaches lobby', landed === '/lobby.html', landed);

  // ---------- 逐页 × 多屏宽（手机端 360/375/390/412/430）----------
  const jsErrors = [];
  async function sweep(pages, widths, tag) {
    for (const page of pages) {
      const worst = { overflow: 0, at: null, bad: [] };
      for (const width of widths) {
        await B.setWidth(width);
        B.resetErrors();
        await B.goto(BASE + page);
        await wait(300);
        let m;
        try { m = await B.evaluate(MEASURE); } catch (e) { jsErrors.push(page + '@' + width + ': measure failed'); continue; }
        if (!m) { jsErrors.push(page + '@' + width + ': no measurement'); continue; }
        if (m.overflow > worst.overflow) { worst.overflow = m.overflow; worst.at = width; }
        if (m.bad.length) worst.bad = worst.bad.concat(m.bad.map(b => width + 'px ' + b));
        if (B.errors.length) jsErrors.push(page + '@' + width + ': ' + String(B.errors[0]).slice(0, 110));
      }
      report.pages.push({ scope: tag, page, worst_overflow: worst.overflow, at: worst.at, bad: worst.bad.slice(0, 4) });
      check('no horizontal overflow (<=1px) [' + tag + ']: ' + page, worst.overflow <= 1, worst.overflow + 'px @ ' + worst.at + 'px');
      check('inputs dark & inside viewport [' + tag + ']: ' + page, worst.bad.length === 0, worst.bad.slice(0, 4));
    }
  }
  await sweep(PAGES, WIDTHS, 'mobile');
  await sweep(DESKTOP_PAGES, DESKTOP_WIDTHS, 'desktop');
  report.js_errors = jsErrors;
  check('no uncaught JS exception across pages', jsErrors.length === 0, jsErrors.slice(0, 3));
  console.log(JSON.stringify({ passed: true, pages: report.pages.length, checks: report.checks.length }, null, 2));
}
main().catch(err => {
  report.error = err.message;
  console.error('MOBILE_OVERFLOW_ERROR: ' + err.message);
  process.exitCode = 1;
}).finally(async () => {
  try { if (ws) ws.close(); } catch (_) {}
  try { if (chrome) chrome.kill(); } catch (_) {}
  try {
    if (serverProcess && serverProcess.exitCode === null) {
      serverProcess.kill();
      await new Promise(r => serverProcess.once('exit', r));
    }
  } catch (_) {}
  try {
    if (conn) {
      if (tempUserId) {
        await deleteTempUserAndDependencies(conn, tempUserId);
      }
      const [left] = await conn.query('SELECT COUNT(*) AS c FROM users WHERE username LIKE ?', [prefix + '%']);
      report.temp_users_left = Number(left[0].c);
      await conn.end();
    }
  } catch (e) { report.cleanup_error = e.message; }
  try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch (_) {}
  report.passed = report.checks.length > 0 && report.checks.every(c => c.pass) && !report.error && !report.cleanup_error;
  report.finished = new Date().toISOString();
  try { fs.writeFileSync(path.join(__dirname, 'mobile-overflow-report.json'), JSON.stringify(report, null, 2)); } catch (_) {}
  console.log(report.passed ? 'MOBILE_OVERFLOW_PASS (' + report.checks.length + ' checks)'
    : 'MOBILE_OVERFLOW_FAIL: ' + (report.error || 'checks failed'));
});


