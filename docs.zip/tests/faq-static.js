'use strict';
// Static regression only: no browser, server, credentials or database access.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'public/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'public/tutorial.html'), 'utf8');
const report = { checkedAt: new Date().toISOString(), mode: 'Static assertions; NOT browser computed styles', checks: [] };
function check(name, run) {
  try { run(); report.checks.push({ name, pass: true }); }
  catch (e) { report.checks.push({ name, pass: false, error: e.message }); }
}
function rule(selector) {
  const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const matches = [...css.matchAll(new RegExp('(?:^|\\n)' + escaped + '\\s*\\{([^}]+)\\}', 'g'))];
  assert.ok(matches.length, 'Missing rule: ' + selector);
  return matches.at(-1)[1];
}
check('Tutorial renders native details and summary', () => {
  assert.ok(html.includes('<details class="faq-item">'));
  assert.ok(html.includes('<summary class="faq-q">'));
  assert.ok(html.includes('<div class="faq-a">'));
});
check('Native open attribute explicitly reveals answer', () => {
  assert.match(rule('.faq-item[open] > .faq-a'), /display:\s*block\s*;/);
});
check('Arrow has valid empty content and border shape', () => {
  const value = rule('.faq-q::after');
  assert.match(value, /content:\s*""\s*;/);
  assert.match(value, /border-right:/);
  assert.match(value, /border-bottom:/);
  assert.match(value, /rotate\(45deg\)/);
  assert.match(rule('.faq-item[open] > .faq-q::after'), /rotate\(225deg\)/);
});
check('FAQ keyboard focus remains visible', () => {
  assert.match(rule('.faq-q:focus-visible'), /outline:\s*2px solid var\(--gold\)/);
});
check('Styles contain no damaged control characters', () => {
  assert.ok(!/[\u0080-\u009f\ufffd]/.test(css));
});
check('Tutorial and browser regression scripts parse', () => {
  for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) new vm.Script(match[1]);
  new vm.Script(fs.readFileSync(path.join(root, '_test_tutorial_browser.js'), 'utf8'));
});
report.expectedStyles = { openAnswerDisplay: 'block', closedArrowRotation: '45deg', openArrowRotation: '225deg' };
report.passed = report.checks.every(c => c.pass);
fs.writeFileSync(path.join(__dirname, 'faq-static-report.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.passed ? 0 : 1;
