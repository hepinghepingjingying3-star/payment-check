'use strict';
// ============================================
// 26牛牛 - 充值 / 提款 / 推广 真实浏览器走查
// ============================================
// 环境: 真实服务器（临时端口）+ 真实 MySQL + 真实 Chrome（headless）
// 覆盖:
//   1) 充值页：快捷金额 / 自定义金额校验 / 付款方式卡片 / 测试环境提示 / USDT 客服入口 / 立即充值
//   2) 充值详情页：订单号、测试收款资料、充值声明、备注提示、下一步
//   3) 上传凭证页：文件选择 → 预览 → 提交 → 提示等待审核（余额不变）
//   4) 管理员：充值管理 / 提款管理 / 推广管理 面板与批准流程
//   5) 提款页：可用余额、资产类型、余额不足校验、提交申请
//   6) 移动端：输入框为深色（非纯白）、底部导航不遮挡聊天输入框
// 数据隔离:
//   - 只创建 zzfunds_ 前缀临时账号，结束后删除自己创建的订单/流水/奖励/审计/账号
//   - 使用临时端口 fork server.js，不触碰默认 3000 端口开发服务
// 报告: tests/funds-browser-report.json
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const zlib = require('node:zlib');
const { spawn, fork } = require('node:child_process');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const crypto0 = require('node:crypto');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const root = path.resolve(__dirname, '..');
const reportPath = path.join(__dirname, 'funds-browser-report.json');
const report = { started: new Date().toISOString(), mode: 'Real server + real MySQL + real Chrome; zzfunds_* temp data removed', checks: [], errors: [], cleanup: null };
let server, chrome, ws, db;
const tempIds = [];
let adminId = null, uplineId = null, playerId = null;
const profile = fs.mkdtempSync(path.join(os.tmpdir(), '26-funds-'));
const stamp = Date.now().toString(36);
const adminName = 'zzfunds_a_' + stamp;
const uplineName = 'zzfunds_u_' + stamp;
const playerName = 'zzfunds_p_' + stamp;
const adminPass = 'Zz-Funds-Admin-1!';
const userPass = 'Zz-Funds-User-1!';
const wait = ms => new Promise(r => setTimeout(r, ms));

function save() { try { fs.writeFileSync(reportPath, JSON.stringify(report, null, 2)); } catch (_) {} }
function check(ok, name, detail) {
  report.checks.push({ name, pass: !!ok, ...(detail === undefined ? {} : { detail }) });
  save();
  if (!ok) throw new Error(name + ': ' + JSON.stringify(detail));
}

// ---------- 一张真实 PNG（用于凭证上传） ----------
function crc32(buf) {
  let c, crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    c = (crc ^ buf[i]) & 0xFF;
    for (let k = 0; k < 8; k++) c = c & 1 ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
function pngChunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}
function makePng(w, h) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    const off = y * (w * 3 + 1); raw[off] = 0;
    for (let x = 0; x < w; x++) {
      raw[off + 1 + x * 3] = (x * 7 + y * 13) % 251;
      raw[off + 2 + x * 3] = (x * 29 + y * 3) % 253;
      raw[off + 3 + x * 3] = (x * 11 + y * 37) % 249;
    }
  }
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    pngChunk('IHDR', ihdr), pngChunk('IDAT', zlib.deflateSync(raw)), pngChunk('IEND', Buffer.alloc(0))]);
}
const voucherFile = path.join(profile, 'voucher.png');

// ---------- 数据库 ----------
async function connectDb() {
  db = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT), user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
}
async function createTempUser(username, role) {
  const hash = bcrypt.hashSync(userPass, 10);
  const code = String(10000000 + (crypto0.randomInt ? crypto0.randomInt(0, 20000000) : Math.floor(Math.random() * 20000000)));
  const [result] = await db.query(
    `INSERT INTO users (username, nickname, real_name, password_hash, invite_code, role, status, cash_chips)
     VALUES (?, ?, ?, ?, ?, ?, 'active', 1000.00)`,
    [username, username, '临时资金验收账号', hash, code, role]
  );
  tempIds.push(result.insertId);
  return result.insertId;
}

/**
 * 深度删除临时账号：
 * 先按 information_schema 的外键关系清掉所有引用 users 的子表行（只限本次临时ID），
 * 最后删除 users 行，避免 FK 约束导致残留测试账号。
 */
async function deleteUsersDeep(ids) {
  const detail = {};
  if (!ids.length) return detail;
  const list = ids.join(',');
  const [fks] = await db.query(
    `SELECT table_name AS t, column_name AS c FROM information_schema.key_column_usage
     WHERE referenced_table_name = 'users' AND table_schema = DATABASE()`);
  let remaining = fks.slice();
  for (let pass = 0; pass < 4 && remaining.length; pass++) {
    const next = [];
    for (const fk of remaining) {
      try {
        const [r] = await db.query('DELETE FROM `' + fk.t + '` WHERE `' + fk.c + '` IN (' + list + ')');
        if (r.affectedRows) detail[fk.t] = (detail[fk.t] || 0) + r.affectedRows;
      } catch (_) { next.push(fk); }
    }
    remaining = next;
  }
  const [ids2] = await db.query('SELECT id FROM users WHERE id IN (' + list + ')');
  if (ids2.length) {
    const [u] = await db.query('DELETE FROM users WHERE id IN (' + list + ')');
    detail.users = u.affectedRows;
  }
  return detail;
}
async function setRelation(childId, parentId, level) {
  await db.query('UPDATE users SET invited_by = ? WHERE id = ?', [parentId, childId]);
  await db.query('INSERT INTO referral_relations (referrer_id, referred_user_id, level) VALUES (?, ?, ?)', [parentId, childId, level]);
}
async function balanceOf(id) {
  const [rows] = await db.query('SELECT cash_chips FROM users WHERE id = ?', [id]);
  return rows[0] ? Number(rows[0].cash_chips) : null;
}
async function orderRow(id) {
  const [rows] = await db.query('SELECT id, order_no, user_id, order_type, amount, status, voucher_path, before_balance, after_balance FROM wallet_orders WHERE id = ?', [id]);
  return rows[0] || null;
}
async function waitDb(describe, fn, timeout = 9000) {
  const deadline = Date.now() + timeout;
  let last = null;
  while (Date.now() < deadline) {
    last = await fn();
    if (last) return last;
    await wait(150);
  }
  throw new Error('DB 条件未满足: ' + describe + ' (last=' + JSON.stringify(last) + ')');
}

// ---------- 服务器与 HTTP ----------
async function startServer() {
  const bootstrap = "const http=require('http');const listen=http.Server.prototype.listen;" +
    "http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args);};require('./server');";
  server = fork('-e', [bootstrap], { cwd: root, env: Object.assign({}, process.env, { PORT: '0' }), silent: true });
  server.stdout.resume(); server.stderr.resume();
  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('服务器启动超时')), 20000);
    server.once('message', m => { clearTimeout(timer); resolve(m.port); });
    server.once('exit', code => { clearTimeout(timer); reject(new Error('服务器提前退出: ' + code)); });
  });
  return 'http://127.0.0.1:' + port;
}
async function login(base, username, password) {
  const response = await fetch(base + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }), signal: AbortSignal.timeout(10000)
  });
  const body = await response.json().catch(() => ({}));
  const setCookie = response.headers.get('set-cookie') || '';
  return { status: response.status, token: body && body.data ? body.data.token : null, cookie: setCookie.split(';')[0] };
}
async function api(base, pathname, opts) {
  opts = opts || {};
  const headers = {};
  if (opts.token) headers.Authorization = 'Bearer ' + opts.token;
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(base + pathname, {
    method: opts.method || 'GET', headers,
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body), signal: AbortSignal.timeout(10000)
  });
  return { status: response.status, json: await response.json().catch(() => null) };
}


// ---------- Chrome (CDP) ----------
async function launchChrome() {
  chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-port=0', '--user-data-dir=' + profile,
    '--window-size=390,844', 'about:blank'
  ], { stdio: 'ignore' });
  chrome.on('error', e => report.errors.push('chrome: ' + e.message));
  let debugPort = null;
  for (let i = 0; i < 150 && !debugPort; i++) {
    try { debugPort = fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0]; } catch (_) { await wait(100); }
  }
  check(!!debugPort, 'Chrome DevTools 调试端口可用', { port: debugPort || null });
  const targets = await (await fetch('http://127.0.0.1:' + debugPort + '/json/list')).json();
  const target = targets.filter(t => t.type === 'page')[0];
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
}

function cdpSession() {
  let id = 0;
  const pending = new Map();
  ws.onmessage = event => {
    const m = JSON.parse(event.data);
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.reject(new Error(m.error.message)); else p.resolve(m.result);
    }
    if (m.method === 'Runtime.exceptionThrown') report.errors.push(m.params.exceptionDetails.text || 'exception');
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') report.errors.push('console.error');
  };
  const send = (method, params) => new Promise((resolve, reject) => {
    const n = ++id; pending.set(n, { resolve, reject }); ws.send(JSON.stringify({ id: n, method, params: params || {} }));
  });
  const evaluate = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails).slice(0, 300));
    return r.result.value;
  };
  return { send, evaluate };
}


async function setLocalSession(B, base, session, withCookie) {
  // 必须先进入同源页面，否则 about:blank 无法写 localStorage
  await B.send('Page.navigate', { url: base + '/login.html' });
  await wait(400);
  await B.send('Network.enable').catch(() => {});
  if (withCookie) {
    await B.send('Network.setCookie', {
      name: 'nn_page', value: session.token, domain: new URL(base).hostname, path: '/', httpOnly: true, sameSite: 'Lax'
    });
  }
  await B.evaluate("localStorage.setItem('token', " + JSON.stringify(session.token) + "); localStorage.setItem('user', '{}');");
}

// ============ 浏览器走查：充值 → 详情 → 凭证 ============
async function runPlayerDepositFlow(base, B, playerSession) {
  const waitFor = async (expr, tries) => {
    for (let i = 0; i < (tries || 80); i++) {
      if (await B.evaluate('(' + expr + ')').catch(() => false)) return true;
      await wait(150);
    }
    return false;
  };
  const goto = async (url, ready) => {
    await B.send('Page.navigate', { url: base + url });
    check(await waitFor("document.readyState === 'complete' && (" + ready + ")"), '页面就绪: ' + url);
  };
  await setLocalSession(B, base, playerSession, false);

  await goto('/deposit.html', "document.getElementById('formArea') && !document.getElementById('formArea').hidden");
  check((await B.evaluate("document.querySelectorAll('#quickGrid .amount-chip').length")) === 9,
    '充值页渲染 9 个快捷金额');
  check(await B.evaluate("document.querySelector('#methodBox .method-card.active') !== null"),
    '付款方式「银行转账」默认选中');
  const banner = await B.evaluate("document.getElementById('testTitle').textContent + '|' + document.getElementById('testText').textContent");
  check(banner.indexOf('测试充值') === 0 && banner.indexOf('不涉及真实资金') > 0,
    '充值页显示测试环境提示（不涉及真实资金）', { banner });
  check((await B.evaluate("document.getElementById('usdtText').textContent")).indexOf('USDT') > 0 &&
    (await B.evaluate("document.getElementById('usdtCard').getAttribute('href')")) === '/support-chat.html',
    'USDT 入口指向在线客服');
  const inputBg = await B.evaluate("getComputedStyle(document.getElementById('amount')).backgroundColor");
  check(!/rgb\(255, 255, 255\)/.test(inputBg), '金额输入框为深色（非纯白）', { background: inputBg });

  await B.evaluate("document.getElementById('amount').value='20'; document.getElementById('amount').dispatchEvent(new Event('input'))");
  check((await B.evaluate("document.getElementById('amountHint').textContent")).indexOf('最低充值金额为 RM30') >= 0,
    '低于 RM30 前端提示「最低充值金额为 RM30」');
  await B.evaluate("document.getElementById('amount').value='60000'; document.getElementById('amount').dispatchEvent(new Event('input'))");
  check((await B.evaluate("document.getElementById('amountHint').textContent")).indexOf('单笔最高充值金额为 RM50,000') >= 0,
    '超过 RM50,000 前端提示「单笔最高充值金额为 RM50,000」');
  await B.evaluate("document.querySelector('#quickGrid .amount-chip[data-amt=\"100\"]').click()");
  check((await B.evaluate("document.getElementById('amount').value")) === '100' &&
    (await B.evaluate("document.getElementById('amountHint').textContent")).indexOf('RM100.00') > 0,
    '点击快捷金额 RM100 → 输入框与校验提示同步');

  await B.evaluate("document.getElementById('submitBtn').click()");
  check(await waitFor("location.pathname === '/deposit-detail.html'", 120), '点击「立即充值」进入充值详情页');

  check(await waitFor("document.getElementById('amount') && document.getElementById('amount').textContent === 'RM100.00'"),
    '详情页顶部显示充值金额 RM100.00');
  const detailText = await B.evaluate("document.getElementById('detail').innerText");
  check(detailText.indexOf('订单号') > 0 && detailText.indexOf('待付款') > 0,
    '详情页显示订单号与订单状态', { sample: detailText.slice(0, 100) });
  check((await B.evaluate("document.getElementById('rcvBank').textContent")) === '测试银行' &&
    (await B.evaluate("document.getElementById('rcvNo').textContent")) === 'TEST-ACCOUNT' &&
    (await B.evaluate("document.getElementById('rcvNotice').textContent")).indexOf('不可用于真实转账') > 0,
    '详情页显示测试收款资料并明确不可真实转账');
  check((await B.evaluate("document.getElementById('declareTitle').textContent")).indexOf('请确认付款资料与订单信息一致') > 0,
    '详情页显示充值声明');
  check((await B.evaluate("document.getElementById('remarkHints').textContent")).indexOf('OKOK') >= 0,
    '详情页显示备注提示（OKOK / DONE / NOTED）');

  const orderId = Number((await B.evaluate('new URLSearchParams(location.search).get("id")')) || 0);
  check(orderId > 0, '详情页地址带唯一订单ID', { orderId: orderId });
  const created = await waitDb('订单落库为 PENDING_PAYMENT', async () => {
    const row = await orderRow(orderId);
    return row && row.status === 'PENDING_PAYMENT' ? row : null;
  });
  check(Number(created.amount) === 100, '订单在数据库为 PENDING_PAYMENT 且金额 RM100', { order_no: created.order_no });

  await B.evaluate("document.getElementById('nextBtn').click()");
  check(await waitFor("location.pathname === '/deposit-voucher.html'", 120), '点击「下一步」进入上传凭证页');
  check(await waitFor("document.getElementById('reqList').children.length >= 4"), '凭证页显示凭证要求清单');
  check((await B.evaluate("document.getElementById('bank').textContent")) === '测试银行', '凭证页显示收款银行');

  const doc = await B.send('DOM.getDocument', { depth: -1 });
  const node = await B.send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#fileInput' });
  await B.send('DOM.setFileInputFiles', { files: [voucherFile], nodeId: node.nodeId });
  check(await waitFor("!document.getElementById('previewBox').hidden"), '选择凭证后显示图片预览');
  check(await B.evaluate("!document.getElementById('submitBtn').disabled"), '选择凭证后「提交充值申请」可点击');
  await B.evaluate("document.getElementById('submitBtn').click()");
  check(await waitFor("location.pathname === '/deposit-detail.html'", 140), '提交凭证后回到充值详情页');
  const uploaded = await waitDb('状态变为 PENDING_REVIEW', async () => {
    const row = await orderRow(orderId);
    return row && row.status === 'PENDING_REVIEW' ? row : null;
  });
  check(!!uploaded.voucher_path, '凭证已绑定订单（服务端生成文件名）', { path: uploaded.voucher_path });
  check((await balanceOf(playerId)) === 1000, '提交凭证后余额不变（绝不自动充值成功）');
  check(await waitFor("document.getElementById('status') && document.getElementById('status').innerText.indexOf('待审核') >= 0", 100),
    '详情页显示订单状态「待审核」');
  return orderId;
}


// ============ 管理员：充值/提款/推广面板 ============
async function runAdminFlow(base, B, adminSession, orderId) {
  const waitFor = async (expr, tries) => {
    for (let i = 0; i < (tries || 100); i++) {
      if (await B.evaluate('(' + expr + ')').catch(() => false)) return true;
      await wait(150);
    }
    return false;
  };
  await B.send('Network.enable');
  await B.send('Network.clearBrowserCookies');
  await setLocalSession(B, base, adminSession, true);
  await B.send('Page.navigate', { url: base + '/admin.html' });
  check(await waitFor("document.getElementById('adminBody') && !document.getElementById('adminBody').hidden"),
    '管理员可打开 /admin.html（页面票据有效）');
  const tabs = await B.evaluate("Array.prototype.map.call(document.querySelectorAll('.admin-tab'), function(t){return t.textContent}).join(',')");
  check(/充值管理/.test(tabs) && /提款管理/.test(tabs) && /推广管理/.test(tabs),
    '后台含「充值管理 / 提款管理 / 推广管理」标签', { tabs: tabs });

  await B.evaluate("document.querySelector('.admin-tab[data-tab=\"deposits\"]').click()");
  check(await waitFor("document.querySelector('#depList .card-title') !== null && document.getElementById('depList').innerText.indexOf('待审核') >= 0"),
    '充值管理列出待审核订单');
  check((await B.evaluate("document.getElementById('depList').innerText")).indexOf('测试资产') >= 0 ||
    (await B.evaluate("document.getElementById('depList').innerText")).indexOf('RM100.00') >= 0,
    '充值管理显示订单金额');
  check(await B.evaluate("document.querySelector('#depList [data-voucher]') !== null"),
    '充值管理提供「查看凭证」入口');
  const voucherUrl = await B.evaluate("'/api/admin/deposits/' + document.querySelector('#depList [data-voucher]').dataset.voucher + '/voucher'");
  const voucherRes = await fetch(base + voucherUrl, { headers: { Authorization: 'Bearer ' + adminSession.token } });
  const voucherBuf = Buffer.from(await voucherRes.arrayBuffer());
  const isJpeg = voucherBuf[0] === 0xFF && voucherBuf[1] === 0xD8 && voucherBuf[2] === 0xFF;
  const isPng = voucherBuf[0] === 0x89 && voucherBuf[1] === 0x50 && voucherBuf[2] === 0x4E;
  check(voucherRes.status === 200 && (isJpeg || isPng),
    '管理员可读取凭证图片（非公开目录，内容为真实图片）',
    { status: voucherRes.status, bytes: voucherBuf.length, kind: isJpeg ? 'jpeg' : (isPng ? 'png' : 'unknown') });
  check((await B.evaluate("document.getElementById('depList').innerText")).indexOf('待审核') >= 0,
    '批准前订单状态为「待审核」');

  // 批准（确认弹窗）
  await B.evaluate("document.querySelector('#depList [data-approve]').click()");
  check(await waitFor("document.querySelector('.dialog-mask [data-yes]') !== null"), '批准前弹出二次确认对话框');
  await B.evaluate("document.querySelector('.dialog-mask [data-yes]').click()");
  const approved = await waitDb('订单状态变为 APPROVED', async () => {
    const row = await orderRow(orderId);
    return row && row.status === 'APPROVED' ? row : null;
  });
  check(Number(approved.after_balance) - Number(approved.before_balance) === 100,
    '批准后订单记录前后余额（+RM100）',
    { before: approved.before_balance, after: approved.after_balance });
  check((await balanceOf(playerId)) === 1100, '批准后用户测试资产余额 +RM100');
  check(Math.abs((await balanceOf(uplineId)) - 1000.5) < 0.001,
    '上级获得 0.5% 推广奖励 RM0.50（后端计算入账）', { upline_balance: await balanceOf(uplineId) });
  check(await waitFor("document.getElementById('depList').innerText.indexOf('已通过') >= 0"),
    '批准后后台列表显示「已通过」');
  check((await B.evaluate("document.querySelectorAll('#depList [data-approve]').length")) === 0,
    '已通过订单不再显示批准按钮（防重复批准）');

  // 推广管理
  await B.evaluate("document.querySelector('.admin-tab[data-tab=\"referrals\"]').click()");
  check(await waitFor("document.getElementById('refList').innerText.indexOf('zzfunds_u_') >= 0"), '推广管理列出推广用户');
  check(await waitFor("document.getElementById('refRewards').innerText.indexOf('已入账') >= 0"), '推广奖励台账显示已入账奖励');
  check((await B.evaluate("document.getElementById('refSummary').textContent")).indexOf('0.5%') > 0,
    '推广管理显示集中配置的奖励比例');
  check((await B.evaluate("document.getElementById('refList').innerText")).indexOf('password') < 0,
    '推广管理不显示任何密码字段');
  return approved;
}


// ============ 提款：提交 + 管理员批准 ============
async function runWithdrawFlow(base, B, playerSession, adminSession) {
  const waitFor = async (expr, tries) => {
    for (let i = 0; i < (tries || 100); i++) {
      if (await B.evaluate('(' + expr + ')').catch(() => false)) return true;
      await wait(150);
    }
    return false;
  };
  await B.send('Network.clearBrowserCookies');
  await setLocalSession(B, base, playerSession, false);
  await B.send('Page.navigate', { url: base + '/withdraw.html' });
  check(await waitFor("document.getElementById('form') && !document.getElementById('form').hidden"), '提款页就绪');
  check((await B.evaluate("document.getElementById('available').textContent")) === 'RM1100.00',
    '提款页显示后端返回的可用测试资产余额');
  check((await B.evaluate("document.querySelectorAll('#assetBox .method-card').length")) === 2,
    '提款页提供资产类型选择');
  check((await B.evaluate("document.getElementById('testText').textContent")).indexOf('测试') >= 0,
    '提款页显示测试环境提示（非现金化测试资产）');

  await B.evaluate("document.getElementById('amount').value='5000'; document.getElementById('amount').dispatchEvent(new Event('input'))");
  check((await B.evaluate("document.getElementById('amountHint').textContent")).indexOf('可用测试资产不足') >= 0,
    '余额不足时前端提示且不提交');
  await B.evaluate("document.getElementById('amount').value='200'; document.getElementById('amount').dispatchEvent(new Event('input'))");
  await B.evaluate("document.getElementById('accountRef').value='TEST-ACC-BROWSER'");
  await B.evaluate("document.getElementById('submitBtn').click()");
  check(await waitFor("document.getElementById('orderList').innerText.indexOf('待审核') >= 0"), '提款申请出现在我的列表（待审核）');
  check((await balanceOf(playerId)) === 1100, '提交提款申请不改动余额');
  const wd = await waitDb('提款订单落库', async () => {
    const [rows] = await db.query("SELECT id, amount, status, account_reference FROM wallet_orders WHERE user_id = ? AND order_type = 'WITHDRAW' ORDER BY id DESC LIMIT 1", [playerId]);
    return rows[0] ? rows[0] : null;
  });
  check(wd.status === 'PENDING' && Number(wd.amount) === 200, '提款订单为 PENDING 且金额 RM200', { id: wd.id });

  await B.send('Network.setCookie', {
    name: 'nn_page', value: adminSession.token, domain: new URL(base).hostname, path: '/', httpOnly: true, sameSite: 'Lax'
  });
  await B.evaluate("localStorage.setItem('token', " + JSON.stringify(adminSession.token) + ");");
  await B.send('Page.navigate', { url: base + '/admin.html' });
  check(await waitFor("document.getElementById('adminBody') && !document.getElementById('adminBody').hidden"), '管理员再次进入后台');
  await B.evaluate("document.querySelector('.admin-tab[data-tab=\"withdrawals\"]').click()");
  check(await waitFor("document.getElementById('wdList').innerText.indexOf('待审核') >= 0"), '提款管理列出待审核申请');
  check((await B.evaluate("document.getElementById('wdList').innerText")).indexOf('TEST-ACC-BROWSER') >= 0,
    '提款管理显示测试收款资料');
  await B.evaluate("document.querySelector('#wdList [data-approve]').click()");
  check(await waitFor("document.querySelector('.dialog-mask [data-yes]') !== null"), '批准提款前二次确认');
  await B.evaluate("document.querySelector('.dialog-mask [data-yes]').click()");
  const approvedWd = await waitDb('提款订单变为 APPROVED', async () => {
    const row = await orderRow(wd.id);
    return row && row.status === 'APPROVED' ? row : null;
  });
  check((await balanceOf(playerId)) === 900, '批准提款后余额精确扣减 RM200', { balance: await balanceOf(playerId) });
  check(Number(approvedWd.before_balance) - Number(approvedWd.after_balance) === 200, '提款订单记录扣减前后余额');
  check((await B.evaluate("document.querySelectorAll('#wdList [data-approve]').length")) === 0,
    '已通过提款不再显示批准按钮（防重复扣款）');
}


// ============ 移动端与钱包检查 ============
async function runMobileCheck(base, B, playerSession) {
  const waitFor = async (expr, tries) => {
    for (let i = 0; i < (tries || 100); i++) {
      if (await B.evaluate('(' + expr + ')').catch(() => false)) return true;
      await wait(150);
    }
    return false;
  };
  await B.send('Network.clearBrowserCookies');
  await setLocalSession(B, base, playerSession, false);

  await B.send('Page.navigate', { url: base + '/wallet.html' });
  check(await waitFor("document.getElementById('content') && getComputedStyle(document.getElementById('content')).display !== 'none'"),
    '钱包页内容加载完成（#content 可见）');
  const walletText = await B.evaluate("document.getElementById('content').innerText");
  check(walletText.indexOf('游戏余额') >= 0 && walletText.indexOf('现金筹码') >= 0, '钱包页区分游戏余额与现金筹码');
  check(walletText.indexOf('充值') >= 0 && walletText.indexOf('提款') >= 0 && walletText.indexOf('交易记录') >= 0,
    '钱包页提供充值 / 提款 / 交易记录入口');
  check(!(await B.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 1")),
    '钱包页无横向溢出（移动端 390px）');
  check(await waitFor("document.getElementById('txList').innerText.indexOf('充') >= 0 || document.getElementById('txList').innerText.indexOf('提') >= 0"),
    '钱包交易记录显示充值/提款记录');

  await B.send('Page.navigate', { url: base + '/promote.html' });
  check(await waitFor("document.getElementById('content') && getComputedStyle(document.getElementById('content')).display !== 'none'"),
    '推广页内容加载完成（#content 可见）');
  check((await B.evaluate("document.body.innerText")).indexOf('推广奖励台账') > 0, '推广页显示奖励台账区块');
  check(await waitFor("document.getElementById('rewardList').innerText.indexOf('暂无') >= 0 || document.getElementById('rewardList').innerText.indexOf('+') >= 0"),
    '推广页奖励台账可加载（无记录时显示空状态）');

  await B.send('Page.navigate', { url: base + '/group-chat.html' });
  check(await waitFor("document.querySelector('.chat-input') !== null && document.querySelector('.bottom-nav') !== null", 150),
    '游戏群聊天页就绪（含底部导航）');
  const geometry = await B.evaluate(
    "(function(){var input=document.querySelector('.input-bar')||document.querySelector('.chat-input');" +
    "var nav=document.querySelector('.bottom-nav')||document.querySelector('.tabbar')||document.querySelector('nav');" +
    "if(!input||!nav)return null;var a=input.getBoundingClientRect();var b=nav.getBoundingClientRect();" +
    "return {input_bottom:Math.round(a.bottom),nav_top:Math.round(b.top),nav_height:Math.round(b.height)};})()"
  );
  check(geometry && geometry.input_bottom <= geometry.nav_top + 1,
    '底部导航不遮挡聊天输入框（输入框底边在导航上方）', geometry || {});
}


// ============ HTTP 侧：权限、幂等、审计 ============
async function runHttpChecks(base, adminSession, playerSession, orderId) {
  let r = await api(base, '/api/admin/deposits/' + orderId, { token: playerSession.token });
  check(r.status === 403, '普通用户读取管理员充值详情 → 403', { status: r.status });
  r = await api(base, '/api/admin/deposits/' + orderId + '/review', { method: 'POST', token: playerSession.token, body: { decision: 'approve' } });
  check(r.status === 403, '普通用户不能批准充值 → 403');
  r = await api(base, '/api/admin/deposits/' + orderId + '/review', { method: 'POST', token: adminSession.token, body: { decision: 'approve' } });
  check(r.status === 409, '管理员重复批准 → 409（幂等）', { status: r.status, code: r.json && r.json.code });
  check((await balanceOf(playerId)) === 900, '重复批准不会重复入账（当前余额 RM900）');
  const [txRows] = await db.query('SELECT COUNT(*) AS c FROM balance_transactions WHERE related_request_id = ?', [orderId]);
  check(Number(txRows[0].c) === 1, '同一充值订单只有一条流水', { count: Number(txRows[0].c) });
  const [logs] = await db.query("SELECT action, detail FROM admin_logs WHERE admin_id = ? AND action = 'wallet_order_review'", [adminId]);
  check(logs.length >= 2 && logs.some(l => /decision=approved/.test(l.detail)) &&
    logs.some(l => l.detail.indexOf('type=WITHDRAW') > 0),
    'Audit Log 记录充值审核与提款审核', { count: logs.length });
  check(!/password|otp/i.test(JSON.stringify(logs)), 'Audit Log 不含密码 / OTP 明文');
  const depositOrder = await orderRow(orderId);
  const [rewards] = await db.query(
    'SELECT user_id, level, rate, reward_amount, status FROM referral_rewards WHERE source_ref = ?', [depositOrder.order_no]
  );
  check(rewards.length === 1 && Number(rewards[0].level) === 1 && Number(rewards[0].reward_amount) === 0.5 &&
    rewards[0].status === 'CREDITED', '推广奖励 Ledger 有来源、有比例、已入账');
  r = await api(base, '/api/admin/referrals/rewards/settle', { method: 'POST', token: adminSession.token, body: { order_id: orderId } });
  check(r.status === 200 && r.json.data.created === 0, '补结算幂等：重复结算不再发奖');
}

// ============ 清理（只删除本次创建的数据） ============
async function cleanup() {
  const detail = { users: 0, orders: 0, transactions: 0, rewards: 0, logs: 0, relations: 0 };
  try {
    if (db && tempIds.length) {
      const list = tempIds.join(',');
      // 先取出本次临时订单的凭证文件，删除订单后一并清理（避免遗留孤儿凭证）
      const [vpRows] = await db.query(
        "SELECT voucher_path FROM wallet_orders WHERE user_id IN (" + list + ") AND voucher_path IS NOT NULL AND voucher_path <> ''"
      );
      const [o] = await db.query('DELETE FROM wallet_orders WHERE user_id IN (' + list + ')');
      detail.orders = o.affectedRows;
      let vouchersRemoved = 0;
      for (const row of vpRows) {
        const abs = require('../utils/voucherStore').resolveVoucher(row.voucher_path);
        try { if (abs && fs.existsSync(abs)) { fs.unlinkSync(abs); vouchersRemoved++; } } catch (_) {}
      }
      detail.voucher_files = vouchersRemoved;
      const [t] = await db.query('DELETE FROM balance_transactions WHERE user_id IN (' + list + ')');
      detail.transactions = t.affectedRows;
      const [rw] = await db.query('DELETE FROM referral_rewards WHERE user_id IN (' + list + ') OR source_user_id IN (' + list + ')');
      detail.rewards = rw.affectedRows;
      const [lg] = await db.query('DELETE FROM admin_logs WHERE admin_id IN (' + list + ') OR target_user_id IN (' + list + ')');
      detail.logs = lg.affectedRows;
      const [rel] = await db.query('DELETE FROM referral_relations WHERE referrer_id IN (' + list + ') OR referred_user_id IN (' + list + ')');
      detail.relations = rel.affectedRows;
      // 其它引用 users 的子表（如 chat_read_state）按外键关系清理，最后删账号
      const deep = await deleteUsersDeep(tempIds);
      detail.users = deep.users || 0;
      detail.dependents = deep;
    }
  } catch (e) { report.cleanup_error = e.message; }
  report.cleanup = detail;
  try { if (ws) ws.close(); } catch (_) {}
  try { if (chrome) chrome.kill(); } catch (_) {}
  try { if (server) server.kill(); } catch (_) {}
  try { if (db) await db.end(); } catch (_) {}
}

/** 清理历史中断运行残留的 zzfunds_* 临时账号（只清测试前缀，不动任何真实用户） */
async function purgeLeftoverTempUsers() {
  const [rows] = await db.query("SELECT id FROM users WHERE username LIKE 'zzfunds%'");
  if (!rows.length) return 0;
  const ids = rows.map(r => Number(r.id));
  const list = ids.join(',');
  await db.query('DELETE FROM wallet_orders WHERE user_id IN (' + list + ')');
  await db.query('DELETE FROM balance_transactions WHERE user_id IN (' + list + ')');
  await db.query('DELETE FROM referral_rewards WHERE user_id IN (' + list + ') OR source_user_id IN (' + list + ')');
  await db.query('DELETE FROM admin_logs WHERE admin_id IN (' + list + ') OR target_user_id IN (' + list + ')');
  await db.query('DELETE FROM referral_relations WHERE referrer_id IN (' + list + ') OR referred_user_id IN (' + list + ')');
  const deep = await deleteUsersDeep(ids);
  return deep.users || 0;
}

async function main() {
  fs.writeFileSync(voucherFile, makePng(96, 96));
  await connectDb();
  const purged = await purgeLeftoverTempUsers();
  if (purged) report.purged_leftover_users = purged;
  adminId = await createTempUser(adminName, 'admin');
  uplineId = await createTempUser(uplineName, 'user');
  playerId = await createTempUser(playerName, 'user');
  await setRelation(playerId, uplineId, 1);
  check(tempIds.length === 3, '创建 3 个临时验收账号（zzfunds_*，结束即删除）');

  const base = await startServer();
  const adminSession = await login(base, adminName, userPass);
  const playerSession = await login(base, playerName, userPass);
  check(adminSession.status === 200 && playerSession.status === 200, '临时管理员与用户均可真实登录', { admin: adminSession.status, player: playerSession.status });

  await launchChrome();
  const B = cdpSession();
  await B.send('Runtime.enable');
  await B.send('Page.enable');
  await B.send('DOM.enable');
  const orderId = await runPlayerDepositFlow(base, B, playerSession);
  await runAdminFlow(base, B, adminSession, orderId);
  await runWithdrawFlow(base, B, playerSession, adminSession);
  await runMobileCheck(base, B, playerSession);
  await runHttpChecks(base, adminSession, playerSession, orderId);
  check(report.errors.length === 0, '浏览器控制台无 JS 异常', { errors: report.errors.slice(0, 3) });
}

const watchdog = setTimeout(() => finish('浏览器走查超过 240 秒'), 240000);
let finished = false;
async function finish(error) {
  if (finished) return;
  finished = true;
  clearTimeout(watchdog);
  await cleanup();
  if (error) report.error = error;
  report.finished = new Date().toISOString();
  report.passed = !error && report.checks.length > 0 && report.checks.every(c => c.pass);
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  const failed = report.checks.filter(c => !c.pass);
  console.log('FUNDS_BROWSER ' + (report.passed ? 'PASS' : 'FAIL') +
    ' (' + (report.checks.length - failed.length) + '/' + report.checks.length + ')');
  if (error) console.log('  error: ' + error);
  failed.forEach(c => console.log('  FAIL: ' + c.name + (c.detail ? ' :: ' + JSON.stringify(c.detail) : '')));
  process.exitCode = report.passed ? 0 : 1;
}

main().then(() => finish()).catch(err => finish(err.message + ' | ' + String(err.stack || '').split('\n')[1]));

