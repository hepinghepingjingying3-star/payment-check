'use strict';
// ============================================
// 26牛牛 - 治理与聊天红包 真实环境验收（V6）
// ============================================
// 覆盖:
//   1) 在线状态：user_presence 心跳 / 在线人数（真实，不是账号总数）
//   2) 禁言联动：聊天 / 红包 / 建房下注 / 提款 逐个拦截，充值与读取不受影响
//   3) 双人复核：封禁 / 管理员权限 / 解除禁言必须另一名管理员通过才生效，
//      不能复核自己的请求，拒绝路径不改数据
//   4) 封禁主动断开 Socket：account:revoked 推送 + 连接关闭 + presence.sockets 归零
//   5) 聊天红包：真实事务扣款 / 随机分配 / 不超发 / 不能抢自己的 / 不能重复领取 /
//      过期自动退回发送者 / 撤回被拒绝 / 参数边界
// 说明:
//   - 真实 MySQL + 真实 HTTP + 真实 Socket.IO，临时端口 0 fork server.js
//   - 只使用 zzmt_ 前缀临时账号，结束时按外键关系删除，不触碰真实账号
// 运行: node tests/moderation-redpacket-live.js
// 报告: tests/moderation-redpacket-live-report.json（每步落盘）
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const { fork } = require('node:child_process');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const root = path.resolve(__dirname, '..');
const reportPath = path.join(__dirname, 'moderation-redpacket-live-report.json');
const report = {
  started: new Date().toISOString(),
  mode: 'Real server (temp port) + Real MySQL + real Socket.IO; temporary zzmt_* accounts removed afterwards',
  checks: [], errors: [], cleanup: null, finished: null
};
let server = null;
let db = null;
const wait = ms => new Promise(r => setTimeout(r, ms));
const stamp = Date.now().toString(36);
const PREFIX = 'zzmt_';
const USERNAMES = {
  admin1: PREFIX + 'a1_' + stamp,
  admin2: PREFIX + 'a2_' + stamp,
  u1: PREFIX + 'u1_' + stamp,
  u2: PREFIX + 'u2_' + stamp,
  u3: PREFIX + 'u3_' + stamp
};
const PASSWORD = 'Zz-Mt-Test-1!';
const ids = {};
const tokens = {};

function save() {
  try { fs.writeFileSync(reportPath, JSON.stringify(report, null, 2)); } catch (_) {}
}
function check(ok, name, detail) {
  report.checks.push({ name: name, pass: !!ok, ...(detail === undefined ? {} : { detail: detail }) });
  save();
  if (!ok) throw new Error(name + ' :: ' + JSON.stringify(detail));
}

// ---------- 数据库 ----------
async function connectDb() {
  db = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT), user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
}
async function createTempUser(username, role) {
  const hash = bcrypt.hashSync(PASSWORD, 11);
  const [result] = await db.query(
    `INSERT INTO users (username, nickname, real_name, password_hash, role, status)
     VALUES (?, ?, ?, ?, ?, 'active')`,
    [username, username, '临时验收账号', hash, role]
  );
  return Number(result.insertId);
}
async function userRow(id) {
  const [rows] = await db.query(
    'SELECT id, username, role, status, muted_until, mute_reason, cash_chips FROM users WHERE id = ?', [id]
  );
  return rows[0] || null;
}
async function packetRow(id) {
  const [rows] = await db.query('SELECT * FROM chat_red_packets WHERE id = ?', [id]);
  return rows[0] || null;
}
async function countOf(sql, params) {
  const [rows] = await db.query(sql, params || []);
  return Number(rows[0] && rows[0].c) || 0;
}
async function waitDb(describe, fn, timeout = 6000) {
  const deadline = Date.now() + timeout;
  let last = null;
  while (Date.now() < deadline) {
    last = await fn();
    if (last) return last;
    await wait(150);
  }
  throw new Error('DB 条件未满足: ' + describe + ' (last=' + JSON.stringify(last) + ')');
}

// ---------- 服务器 ----------
async function startServer() {
  const bootstrap = `const http=require('http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args);};require('./server');`;
  server = fork('-e', [bootstrap], { cwd: root, env: { ...process.env, PORT: '0' }, silent: true });
  server.stdout.resume();
  server.stderr.resume();
  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('服务器启动超时')), 20000);
    server.once('message', m => { clearTimeout(timer); resolve(m.port); });
    server.once('exit', code => { clearTimeout(timer); reject(new Error('服务器提前退出: ' + code)); });
  });
  return 'http://127.0.0.1:' + port;
}

// ---------- HTTP ----------
async function login(base, username) {
  const response = await fetch(base + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: username, password: PASSWORD }), signal: AbortSignal.timeout(8000)
  });
  const body = await response.json().catch(() => ({}));
  return { status: response.status, token: body && body.data ? body.data.token : null };
}
async function api(base, pathname, opt) {
  opt = opt || {};
  const headers = {};
  if (opt.token) headers.Authorization = 'Bearer ' + opt.token;
  if (opt.body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(base + pathname, {
    method: opt.method || 'GET', headers: headers,
    body: opt.body === undefined ? undefined : JSON.stringify(opt.body),
    signal: AbortSignal.timeout(10000)
  });
  const json = await response.json().catch(() => null);
  return { status: response.status, json: json };
}

// ---------- Socket 客户端（原生 WebSocket，无额外依赖） ----------
function socketConnect(base, token) {
  return new Promise((resolve, reject) => {
    const url = base.replace('http://', 'ws://') + '/socket.io/?EIO=4&transport=websocket';
    const ws = new WebSocket(url);
    const events = [];
    const timer = setTimeout(() => reject(new Error('Socket 连接超时')), 10000);
    ws.addEventListener('error', () => { clearTimeout(timer); reject(new Error('Socket 连接错误')); });
    ws.addEventListener('message', ev => {
      const packet = String(ev.data);
      events.push(packet);
      if (packet.startsWith('0')) ws.send('40' + JSON.stringify({ token: token }));
      else if (packet === '2') ws.send('3');
      else if (packet.startsWith('40')) { clearTimeout(timer); resolve({ ws: ws, events: events }); }
      else if (packet.startsWith('44')) { clearTimeout(timer); reject(new Error('Socket 认证被拒绝')); }
    });
  });
}
async function waitFor(fn, timeout) {
  const deadline = Date.now() + (timeout || 5000);
  while (Date.now() < deadline) {
    if (fn()) return true;
    await wait(100);
  }
  return false;
}

// ---------- 阶段 1：在线状态（真实心跳，不是账号总数） ----------
async function phasePresence(base) {
  check((await api(base, '/api/admin/online')).status === 401, '匿名访问 /api/admin/online → 401');
  check((await api(base, '/api/admin/approvals', { token: tokens.u1 })).status === 403, '普通用户访问 /api/admin/approvals → 403');
  check((await api(base, '/api/admin/online', { token: tokens.u1 })).status === 403, '普通用户访问 /api/admin/online → 403');

  const msg = await api(base, '/api/chat/messages?channel=group&limit=5', { token: tokens.u1 });
  check(msg.status === 200, '聊天轮询正常（同时作为在线心跳）', { status: msg.status });

  const presenceRow = await waitDb('user_presence 出现该账号', async () => {
    const [rows] = await db.query('SELECT user_id, last_seen, sockets FROM user_presence WHERE user_id = ?', [ids.u1]);
    return rows[0] || null;
  });
  check(!!presenceRow && !!presenceRow.last_seen, 'user_presence 写入真实心跳', { row: presenceRow });

  const dash = await api(base, '/api/admin/dashboard', { token: tokens.a1 });
  check(dash.status === 200 && dash.json && dash.json.success, '后台概览可读取',
    { status: dash.status, body: dash.json });
  const online = dash.json.data.online || {};
  check(online.available === true && typeof online.count === 'number',
    '在线人数来自真实心跳（available=true 且为数字）', online);
  check(online.count >= 1, '在线人数 >= 1（含刚心跳的账号）', { count: online.count });
  check(Array.isArray(dash.json.data.unsupported) && !dash.json.data.unsupported.some(u => u.key === 'online_users'),
    '概览不再把「在线用户」列为不支持', dash.json.data.unsupported);
  check(!!dash.json.data.moderation && typeof dash.json.data.moderation.expiring_remind_minutes === 'number',
    '概览返回禁言到期提醒窗口', dash.json.data.moderation);
  check(!!dash.json.data.approvals && typeof dash.json.data.approvals.enabled === 'boolean',
    '概览返回双人复核开关与动作列表', dash.json.data.approvals);

  const onlineList = await api(base, '/api/admin/online', { token: tokens.a1 });
  check(onlineList.status === 200 && onlineList.json.data.supported === true, '在线用户列表可用（supported=true）');
  check(onlineList.json.data.list.some(u => Number(u.id) === ids.u1),
    '在线列表包含刚心跳的账号', { ids: onlineList.json.data.list.map(u => u.id) });

  const channels = await api(base, '/api/chat/channels', { token: tokens.u1 });
  check(channels.status === 200 && channels.json.data.online.available === true, '会话列表返回真实在线人数');
  const group = (channels.json.data.list || []).find(c => c.channel === 'group');
  check(!!group && typeof group.member_online === 'number',
    '游戏群 member_online 是真实数字（不再是 null）', { member_online: group && group.member_online });
  const rpCfg = channels.json.data.red_packet || {};
  check(rpCfg.enabled === true && Array.isArray(rpCfg.channels) && rpCfg.channels.indexOf('group') >= 0,
    '会话列表返回红包配置（游戏群开放）', rpCfg);
  check(rpCfg.channels.indexOf('support') === -1, '客服频道不开放红包');
  check(channels.json.data.my_mute && channels.json.data.my_mute.muted === false, '未禁言账号 my_mute.muted=false');
  check(Array.isArray(channels.json.data.my_mute.rules) && channels.json.data.my_mute.rules.length >= 5,
    '会话列表返回禁言联动范围（供前端展示）', channels.json.data.my_mute.rules);
}

// ---------- 阶段 2：双人复核（封禁 / 权限 / 解禁） ----------
async function phaseDualApproval(base) {
  const target = ids.u2;
  check((await userRow(target)).status === 'active', '封禁前目标账号为 active');

  const req1 = await api(base, '/api/admin/users/' + target + '/status', {
    token: tokens.a1, method: 'POST', body: { status: 'banned', reason: '自动化验收：封禁需双人复核' }
  });
  check(req1.status === 202 && req1.json.success && req1.json.data.pending_approval === true,
    '封禁提交后返回 202（待复核，不立即生效）', { status: req1.status, body: req1.json });
  const approvalId = Number(req1.json.data.approval.id);
  check(Number.isInteger(approvalId) && approvalId > 0, '返回复核请求ID', { approvalId: approvalId });
  check((await userRow(target)).status === 'active', '未复核前账号状态保持 active（绝不提前生效）');

  const selfReview = await api(base, '/api/admin/approvals/' + approvalId + '/decide', {
    token: tokens.a1, method: 'POST', body: { decision: 'approve' }
  });
  check(selfReview.status === 403 && selfReview.json.code === 'SELF_REVIEW_FORBIDDEN',
    '申请人不能复核自己提交的请求（403）', { status: selfReview.status, body: selfReview.json });

  const queue = await api(base, '/api/admin/approvals?status=PENDING', { token: tokens.a2 });
  const item = (queue.json.data.list || []).find(a => Number(a.id) === approvalId);
  check(!!item && item.can_review === true, '另一名管理员看到待复核请求且 can_review=true', { item: item });
  check(!!item && item.action === 'user_status' && item.payload && item.payload.status === 'banned',
    '复核请求携带动作参数（status=banned）', { payload: item && item.payload });

  const approve = await api(base, '/api/admin/approvals/' + approvalId + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(approve.status === 200 && approve.json.data.decision === 'APPROVED', '另一名管理员复核通过 → 执行', approve.json);
  check((await userRow(target)).status === 'banned', '复核通过后封禁真正生效（数据库核对）');
  check(await countOf("SELECT COUNT(*) AS c FROM admin_logs WHERE action = 'admin_approval_approve' AND target_user_id = ?", [target]) >= 1,
    '审计写入 admin_approval_approve');
  check(await countOf("SELECT COUNT(*) AS c FROM admin_logs WHERE action = 'user_status' AND target_user_id = ? AND detail LIKE '%approved_by=%'", [target]) >= 1,
    '审计同时记录 requested_by / approved_by（双人可追溯）');

  const replay = await api(base, '/api/admin/approvals/' + approvalId + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(replay.status === 409 && replay.json.code === 'ALREADY_DECIDED', '同一复核请求不能重复通过（409）', replay.json);

  const unbanReq = await api(base, '/api/admin/users/' + target + '/status', {
    token: tokens.a1, method: 'POST', body: { status: 'active', reason: '自动化验收：解封需双人复核' }
  });
  check(unbanReq.status === 202, '解封同样进入待复核', { status: unbanReq.status });
  const unbanApprove = await api(base, '/api/admin/approvals/' + unbanReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(unbanApprove.status === 200 && (await userRow(target)).status === 'active', '解封复核通过并生效');

  const rejectReq = await api(base, '/api/admin/users/' + target + '/status', {
    token: tokens.a1, method: 'POST', body: { status: 'banned', reason: '自动化验收：拒绝路径' }
  });
  const rejectNoNote = await api(base, '/api/admin/approvals/' + rejectReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'reject' }
  });
  check(rejectNoNote.status === 422, '拒绝必须填写原因（422）', rejectNoNote.json);
  const rejected = await api(base, '/api/admin/approvals/' + rejectReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'reject', note: '自动化验收：不予封禁' }
  });
  check(rejected.status === 200 && rejected.json.data.decision === 'REJECTED', '复核拒绝成功', rejected.json);
  check((await userRow(target)).status === 'active', '拒绝后数据未被修改（仍 active）');
  check(await countOf("SELECT COUNT(*) AS c FROM admin_logs WHERE action = 'admin_approval_reject'") >= 1,
    '审计写入 admin_approval_reject');

  const roleReq = await api(base, '/api/admin/users/' + target + '/role', {
    token: tokens.a1, method: 'POST', body: { role: 'admin', reason: '自动化验收：权限变更需复核' }
  });
  check(roleReq.status === 202 && (await userRow(target)).role === 'user', '管理员权限变更进入待复核且未提前生效');
  const roleApprove = await api(base, '/api/admin/approvals/' + roleReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(roleApprove.status === 200 && (await userRow(target)).role === 'admin', '复核通过后角色变更为 admin');

  const roleBack = await api(base, '/api/admin/users/' + target + '/role', {
    token: tokens.a1, method: 'POST', body: { role: 'user', reason: '自动化验收：恢复普通用户' }
  });
  const roleBackApprove = await api(base, '/api/admin/approvals/' + roleBack.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(roleBackApprove.status === 200 && (await userRow(target)).role === 'user', '角色已恢复为普通用户');
}

// ---------- 阶段 3：禁言联动范围 ----------
async function phaseMuteScope(base) {
  const target = ids.u1;
  const mute = await api(base, '/api/admin/users/' + target + '/mute', {
    token: tokens.a1, method: 'POST', body: { minutes: 5, reason: '自动化验收：禁言联动' }
  });
  check(mute.status === 200 && mute.json.success, '禁言直接执行（轻度治理，无需复核）', mute.json);
  check(!!mute.json.data.scope_note && mute.json.data.scope_note.indexOf('发送聊天消息') >= 0,
    '禁言接口返回联动范围说明', mute.json.data.scope_note);
  check(!!(await userRow(target)).muted_until, '数据库禁言时间已写入');

  const chat = await api(base, '/api/chat/messages', {
    token: tokens.u1, method: 'POST', body: { channel: 'group', message_type: 'text', content: 'zzmt muted chat' }
  });
  check(chat.status === 403 && chat.json.code === 'USER_MUTED', '被禁言 → 发聊天消息 403 USER_MUTED', chat.json);

  const rp = await api(base, '/api/chat/redpackets', {
    token: tokens.u1, method: 'POST', body: { channel: 'group', amount: 5, count: 2, blessing: '禁言测试' }
  });
  check(rp.status === 403 && rp.json.code === 'USER_MUTED', '被禁言 → 发红包 403 USER_MUTED', rp.json);

  const wd = await api(base, '/api/withdrawals/orders', {
    token: tokens.u1, method: 'POST',
    body: { asset_type: 'CASH_CHIPS', amount: 1, account_type: 'BANK', account_reference: 'ZZMT-TEST-1', remark: 'zzmt' }
  });
  check(wd.status === 403 && wd.json.code === 'USER_MUTED', '被禁言 → 提交提款 403 USER_MUTED', wd.json);

  const game = await api(base, '/api/game/rooms', {
    token: tokens.u1, method: 'POST', body: { room_name: 'zzmt', min_players: 2, max_players: 4 }
  });
  check(game.status === 403 && game.json.code === 'USER_MUTED',
    '被禁言 → 建房/游戏写接口 403 USER_MUTED（先于 503 判定）', game.json);

  const dep = await api(base, '/api/deposits/orders', {
    token: tokens.u1, method: 'POST', body: { payment_method: 'BANK', amount: 50 }
  });
  check(dep.status !== 403, '被禁言 → 充值不受限（资金流入，配置默认不拦）', { status: dep.status, body: dep.json });

  const ch = await api(base, '/api/chat/channels', { token: tokens.u1 });
  check(ch.json.data.my_mute.muted === true && /禁言/.test(ch.json.data.my_mute.notice || ''),
    '会话列表返回我的禁言状态与提示文案', ch.json.data.my_mute);

  const expiring = await api(base, '/api/admin/mute-expiring', { token: tokens.a1 });
  check(expiring.status === 200 && expiring.json.data.list.some(u => Number(u.id) === target),
    '禁言到期提醒名单包含该账号（5 分钟 < 24 小时窗口）', expiring.json.data.list);

  const filterList = await api(base, '/api/admin/users?mute=expiring', { token: tokens.a1 });
  check(filterList.status === 200 &&
    (filterList.json.data.list || []).some(u => Number(u.id) === target && u.mute_expiring === true),
    '后台用户列表支持「即将解禁」筛选并返回 mute_expiring', { total: filterList.json.data.total });

  const unmuteReq = await api(base, '/api/admin/users/' + target + '/unmute', {
    token: tokens.a1, method: 'POST', body: { reason: '自动化验收：解除禁言' }
  });
  check(unmuteReq.status === 202 && unmuteReq.json.data.pending_approval === true,
    '解除禁言进入双人复核', { status: unmuteReq.status });
  check((await userRow(target)).muted_until !== null, '未复核前仍处于禁言状态');
  const unmuteApprove = await api(base, '/api/admin/approvals/' + unmuteReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(unmuteApprove.status === 200 && (await userRow(target)).muted_until === null, '复核通过后解除禁言生效');

  const sent = await api(base, '/api/chat/messages', {
    token: tokens.u1, method: 'POST', body: { channel: 'group', message_type: 'text', content: 'zzmt unmuted ok' }
  });
  check(sent.status === 201, '解除禁言后可正常发消息（真实入库）', { status: sent.status });
}

// ---------- 阶段 4：封禁主动断开 Socket ----------
async function phaseSocketKick(base) {
  const target = ids.u3;
  const sock = await socketConnect(base, tokens.u3);
  check(!!sock && sock.ws.readyState === 1, '临时账号可通过 JWT 建立 Socket.IO 连接', { readyState: sock.ws.readyState });

  const withSocket = await waitDb('presence.sockets >= 1', async () => {
    const [rows] = await db.query('SELECT sockets FROM user_presence WHERE user_id = ?', [target]);
    return rows[0] && Number(rows[0].sockets) >= 1 ? rows[0] : null;
  });
  check(Number(withSocket.sockets) >= 1, '在线状态表记录 Socket 连接数 >= 1', { sockets: Number(withSocket.sockets) });

  const banReq = await api(base, '/api/admin/users/' + target + '/status', {
    token: tokens.a1, method: 'POST', body: { status: 'banned', reason: '自动化验收：封禁需断开连接' }
  });
  check(banReq.status === 202, '封禁申请已提交（待复核）', { status: banReq.status });
  const approve = await api(base, '/api/admin/approvals/' + banReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check(approve.status === 200, '封禁复核通过', approve.json);
  check(!!approve.json.data.result && typeof approve.json.data.result.sockets_closed === 'number',
    '执行结果返回被断开的连接数', approve.json.data.result);

  const revoked = await waitFor(() => sock.events.some(e => e.indexOf('account:revoked') >= 0), 6000);
  check(revoked, '被封禁账号收到 account:revoked 主动通知', { events: sock.events.slice(-5) });
  const closed = await waitFor(() => sock.ws.readyState >= 2, 6000);
  check(closed, '被封禁账号的 Socket 连接被服务端主动断开', { readyState: sock.ws.readyState });

  const zeroed = await waitDb('presence.sockets 归零', async () => {
    const [rows] = await db.query('SELECT sockets FROM user_presence WHERE user_id = ?', [target]);
    return rows[0] && Number(rows[0].sockets) === 0 ? rows[0] : null;
  });
  check(Number(zeroed.sockets) === 0, '断开后在线状态表连接数归零');

  const blocked = await api(base, '/api/chat/messages?channel=group', { token: tokens.u3 });
  check(blocked.status === 403, '被封禁账号的既有 JWT 立即失效（403）', { status: blocked.status });

  const unbanReq = await api(base, '/api/admin/users/' + target + '/status', {
    token: tokens.a1, method: 'POST', body: { status: 'active', reason: '自动化验收：恢复临时账号' }
  });
  await api(base, '/api/admin/approvals/' + unbanReq.json.data.approval.id + '/decide', {
    token: tokens.a2, method: 'POST', body: { decision: 'approve' }
  });
  check((await userRow(target)).status === 'active', '临时账号已恢复 active');
}

// ---------- 阶段 5：聊天红包（真实事务，测试资产） ----------
async function phaseRedPacket(base) {
  const sender = ids.u1;
  const claimer = ids.u2;

  // 测试资产由管理员调整接口发放（会写流水与审计）
  for (const pair of [[sender, 100], [claimer, 20]]) {
    const adj = await api(base, '/api/admin/users/' + pair[0] + '/adjust', {
      token: tokens.a1, method: 'POST',
      body: { currency_type: 'CASH_CHIPS', amount: pair[1], reason: '自动化验收：红包测试资产' }
    });
    check(adj.status === 200, '管理员发放测试资产（用户 ' + pair[0] + '）', adj.json);
  }
  const senderBefore = Number((await userRow(sender)).cash_chips);
  const claimerBefore = Number((await userRow(claimer)).cash_chips);
  check(senderBefore >= 100 && claimerBefore >= 20, '测试资产到账（数据库核对）', { senderBefore, claimerBefore });

  // 参数边界
  const bounds = [
    [{ amount: 0.5, count: 1 }, 422, '金额低于下限 → 422'],
    [{ amount: 99999, count: 1 }, 422, '金额高于上限 → 422'],
    [{ amount: 10, count: 0 }, 422, '个数为 0 → 422'],
    [{ amount: 1, count: 200 }, 422, '个数超上限 → 422']
  ];
  for (const b of bounds) {
    const res = await api(base, '/api/chat/redpackets', {
      token: tokens.u1, method: 'POST',
      body: { channel: 'group', amount: b[0].amount, count: b[0].count }
    });
    check(res.status === b[1], b[2], { status: res.status, body: res.json });
  }
  check((await api(base, '/api/chat/redpackets', {
    token: tokens.u1, method: 'POST', body: { channel: 'support', amount: 10, count: 2 }
  })).status === 400, '客服频道发红包 → 400');
  check((await api(base, '/api/chat/redpackets', {
    method: 'POST', body: { channel: 'group', amount: 10, count: 2 }
  })).status === 401, '未登录发红包 → 401');

  // 极限分配：1.00 RM 分成 100 份（每份恰好 0.01，合计数不变）
  const edge = await api(base, '/api/chat/redpackets', {
    token: tokens.u1, method: 'POST', body: { channel: 'group', amount: 1, count: 100, blessing: '极限拆分' }
  });
  check(edge.status === 201 && Number(edge.json.data.packet.total_amount) === 1 &&
    Number(edge.json.data.packet.total_count) === 100,
    '1.00 RM 分成 100 份可正常发出（每份 0.01）', edge.json && edge.json.data && edge.json.data.packet);

  // 懒清扫验证：把刚发的极限红包置为过期并读取详情，未领取部分应原路退回
  await db.query('UPDATE chat_red_packets SET expired_at = DATE_SUB(NOW(), INTERVAL 1 MINUTE) WHERE id = ?',
    [Number(edge.json.data.packet.id)]);
  await api(base, '/api/chat/redpackets/' + Number(edge.json.data.packet.id), { token: tokens.u1 });
  const senderBeforeMain = Number((await userRow(sender)).cash_chips);
  check(senderBeforeMain === senderBefore, '极限红包过期后发送者余额回到发放前（懒清扫退款）',
    { senderBefore: senderBefore, senderBeforeMain: senderBeforeMain });

  // 正常发红包
  const created = await api(base, '/api/chat/redpackets', {
    token: tokens.u1, method: 'POST', body: { channel: 'group', amount: 10, count: 3, blessing: '自动化验收红包' }
  });
  check(created.status === 201 && created.json.success, '发红包成功（201）', created.json && created.json.message);
  const packet = created.json.data.packet;
  const packetId = Number(packet.id);
  check(Number(packet.total_amount) === 10 && Number(packet.total_count) === 3 && packet.status === 'OPEN',
    '红包字段正确（10 元 / 3 个 / OPEN）', packet);
  check(packet.can_claim === false && /不能抢自己/.test(packet.can_claim_text || ''),
    '发送者本人不能抢自己的红包（服务端视图）', packet.can_claim_text);
  const senderAfter = Number((await userRow(sender)).cash_chips);
  check(Math.round((senderBeforeMain - senderAfter) * 100) === 1000, '发送者余额精确扣减 10.00',
    { senderBeforeMain, senderAfter });
  check(created.json.data.message && created.json.data.message.message_type === 'redpacket',
    '红包同时写入聊天流（message_type=redpacket）', created.json.data.message);

  const [msgRows] = await db.query(
    "SELECT id, meta FROM chat_messages WHERE user_id = ? AND message_type = 'redpacket' ORDER BY id DESC LIMIT 1", [sender]
  );
  const metaObj = msgRows[0] && typeof msgRows[0].meta === 'string'
    ? JSON.parse(msgRows[0].meta) : (msgRows[0] ? msgRows[0].meta : null);
  check(!!msgRows[0] && !!metaObj && Number(metaObj.packet_id) === packetId,
    '红包消息 meta 正确指向该红包', { meta: msgRows[0] && msgRows[0].meta });
  check(await countOf("SELECT COUNT(*) AS c FROM balance_transactions WHERE type = 'RED_PACKET_SEND' AND user_id = ? AND reason LIKE ?",
    [sender, '%' + packet.packet_no + '%']) >= 1, '余额流水写入 RED_PACKET_SEND');

  const self = await api(base, '/api/chat/redpackets/' + packetId + '/claim', { token: tokens.u1, method: 'POST' });
  check(self.status === 403 && self.json.code === 'CANNOT_CLAIM_OWN', '发送者抢自己的红包 → 403', self.json);

  const detailBefore = await api(base, '/api/chat/redpackets/' + packetId, { token: tokens.u2 });
  check(detailBefore.status === 200 && detailBefore.json.data.packet.can_claim === true, '其他用户可领取（can_claim=true）');
  check(Number(detailBefore.json.data.packet.claims_total) === 0, '领取记录初始为 0');

  const claim1 = await api(base, '/api/chat/redpackets/' + packetId + '/claim', { token: tokens.u2, method: 'POST' });
  check(claim1.status === 200 && Number(claim1.json.data.amount) > 0, '领取成功且金额 > 0', claim1.json.data);
  const amount1 = Number(claim1.json.data.amount);
  check(amount1 >= 0.01 && amount1 <= 10, '领取金额在总额范围内', { amount1 });
  const claimerAfter = Number((await userRow(claimer)).cash_chips);
  check(Math.round((claimerAfter - claimerBefore) * 100) === Math.round(amount1 * 100),
    '领取金额精确入账', { claimerBefore, claimerAfter, amount1 });
  check(await countOf("SELECT COUNT(*) AS c FROM balance_transactions WHERE type = 'RED_PACKET_CLAIM' AND user_id = ?", [claimer]) >= 1,
    '余额流水写入 RED_PACKET_CLAIM');

  const claim2 = await api(base, '/api/chat/redpackets/' + packetId + '/claim', { token: tokens.u2, method: 'POST' });
  check(claim2.status === 409 && claim2.json.code === 'ALREADY_CLAIMED', '重复领取 → 409', claim2.json);
  check(Math.round((Number((await userRow(claimer)).cash_chips) - claimerAfter) * 100) === 0, '重复领取未产生任何入账');

  const detailAfter = await api(base, '/api/chat/redpackets/' + packetId, { token: tokens.u2 });
  check(detailAfter.json.data.packet.my_claim &&
    Number(detailAfter.json.data.packet.my_claim.amount) === amount1, '详情返回我的领取记录');
  check(detailAfter.json.data.packet.can_claim === false, '已领取后不能再次领取');
  check(detailAfter.json.data.packet.claims.length === 1 &&
    detailAfter.json.data.packet.claims[0].is_mine === true, '领取记录列表正确', detailAfter.json.data.packet.claims);

  const recall = await api(base, '/api/chat/recall/' + msgRows[0].id, { token: tokens.u1, method: 'POST' });
  check(recall.status === 403 && recall.json.code === 'RED_PACKET_NO_RECALL', '红包消息不能撤回（403）', recall.json);

  return { packetId: packetId, amount1: amount1, packetNo: packet.packet_no, sender: sender, third: ids.u3 };
}

// ---------- 阶段 6：红包过期自动退回（未领部分不丢失） ----------
async function phaseRedPacketExpiry(base, ctx) {
  const thirdBefore = Number((await userRow(ctx.third)).cash_chips);
  // 把过期时间改到过去，模拟到期
  await db.query('UPDATE chat_red_packets SET expired_at = DATE_SUB(NOW(), INTERVAL 1 MINUTE) WHERE id = ?', [ctx.packetId]);

  const senderBeforeRefund = Number((await userRow(ctx.sender)).cash_chips);
  const expire = await api(base, '/api/chat/redpackets/' + ctx.packetId + '/claim', { token: tokens.u3, method: 'POST' });
  check(expire.status === 409 && expire.json.code === 'PACKET_EXPIRED', '过期后领取 → 409 PACKET_EXPIRED', expire.json);

  const afterRow = await packetRow(ctx.packetId);
  check(afterRow.status === 'EXPIRED', '红包状态变为 EXPIRED', { status: afterRow.status });

  const expectedRefund = Math.round((10 - ctx.amount1) * 100);
  const actualRefund = Math.round((Number((await userRow(ctx.sender)).cash_chips) - senderBeforeRefund) * 100);
  check(actualRefund === expectedRefund, '未领取部分原路退回发送者（分位精确）',
    { actualRefund: actualRefund, expectedRefund: expectedRefund });
  check(await countOf("SELECT COUNT(*) AS c FROM balance_transactions WHERE type = 'RED_PACKET_REFUND' AND user_id = ? AND reason LIKE ?",
    [ctx.sender, '%' + ctx.packetNo + '%']) >= 1, '余额流水写入 RED_PACKET_REFUND');
  check(Math.round(Number(afterRow.claimed_amount) * 100) === Math.round(ctx.amount1 * 100),
    '已领金额与实际领取一致（未超发）', afterRow);
  check(await countOf('SELECT COUNT(*) AS c FROM chat_red_packet_claims WHERE packet_id = ?', [ctx.packetId]) === 1,
    '该红包只有 1 条领取记录（未重复发钱）');
  check(Math.round(Number((await userRow(ctx.third)).cash_chips) * 100) === Math.round(thirdBefore * 100),
    '过期领取失败的账号没有获得任何金额');

  // 过期后再看详情：状态与剩余金额正确
  const detail = await api(base, '/api/chat/redpackets/' + ctx.packetId, { token: tokens.u2 });
  check(detail.status === 200 && detail.json.data.packet.status === 'EXPIRED' &&
    detail.json.data.packet.can_claim === false, '过期红包详情不可领取', detail.json.data.packet);
  check(Number(detail.json.data.packet.remaining_amount) === Number((10 - ctx.amount1).toFixed(2)),
    '详情剩余金额与实际一致', { remaining: detail.json.data.packet.remaining_amount });
}

// ---------- 清理临时账号（只删 zzmt_ 前缀，按外键关系清理） ----------
async function cleanup() {
  const [rows] = await db.query("SELECT id FROM users WHERE username LIKE '" + PREFIX + "%'");
  if (!rows.length) { report.cleanup = { removed: 0 }; return; }
  const list = rows.map(r => Number(r.id)).join(',');
  const removed = {};
  const [fks] = await db.query(
    `SELECT table_name AS t, column_name AS c FROM information_schema.key_column_usage
     WHERE referenced_table_name = 'users' AND table_schema = DATABASE()`);
  let remaining = fks.slice();
  for (let pass = 0; pass < 4 && remaining.length; pass++) {
    const next = [];
    for (const fk of remaining) {
      try {
        const [r] = await db.query('DELETE FROM `' + fk.t + '` WHERE `' + fk.c + '` IN (' + list + ')');
        if (r.affectedRows) removed[fk.t] = (removed[fk.t] || 0) + r.affectedRows;
      } catch (_) { next.push(fk); }
    }
    remaining = next;
  }
  const extra = [
    ['wallet_orders', 'user_id'], ['balance_transactions', 'user_id'], ['referral_rewards', 'user_id'],
    ['referral_relations', 'referrer_id'], ['admin_logs', 'admin_id'], ['user_presence', 'user_id'],
    ['admin_approvals', 'requested_by'], ['admin_approvals', 'target_user_id'],
    ['chat_red_packets', 'sender_id'], ['chat_read_state', 'user_id'], ['user_stickers', 'user_id'],
    // 聊天消息（含红包消息）没有外键约束，必须显式删除，否则群里会留下「指向已删红包」的空卡片
    ['chat_messages', 'user_id']
  ];
  for (const e of extra) {
    try {
      const [r] = await db.query('DELETE FROM `' + e[0] + '` WHERE `' + e[1] + '` IN (' + list + ')');
      if (r.affectedRows) removed[e[0]] = (removed[e[0]] || 0) + r.affectedRows;
    } catch (_) { /* 表或列不存在时忽略 */ }
  }
  const [del] = await db.query('DELETE FROM users WHERE id IN (' + list + ')');
  removed.users = del.affectedRows;
  // 残留核对：临时账号 / 聊天消息 / 红包主表必须归零
  removed.residue = {
    users: await countOf("SELECT COUNT(*) AS c FROM users WHERE username LIKE '" + PREFIX + "%'"),
    chat_messages: await countOf('SELECT COUNT(*) AS c FROM chat_messages WHERE user_id IN (' + list + ')'),
    chat_red_packets: await countOf('SELECT COUNT(*) AS c FROM chat_red_packets WHERE sender_id IN (' + list + ')')
  };
  report.cleanup = removed;
}

// ---------- 主流程 ----------
(async () => {
  await connectDb();
  ids.a1 = await createTempUser(USERNAMES.admin1, 'admin');
  ids.a2 = await createTempUser(USERNAMES.admin2, 'admin');
  ids.u1 = await createTempUser(USERNAMES.u1, 'user');
  ids.u2 = await createTempUser(USERNAMES.u2, 'user');
  ids.u3 = await createTempUser(USERNAMES.u3, 'user');
  report.accounts = Object.assign({}, USERNAMES);

  const base = await startServer();
  report.base = base;
  const KEY_MAP = { admin1: 'a1', admin2: 'a2', u1: 'u1', u2: 'u2', u3: 'u3' };
  for (const key of Object.keys(USERNAMES)) {
    const res = await login(base, USERNAMES[key]);
    check(res.status === 200 && !!res.token, '临时账号登录成功: ' + key, { status: res.status });
    tokens[KEY_MAP[key]] = res.token;
  }

  await phasePresence(base);
  await phaseDualApproval(base);
  await phaseMuteScope(base);
  await phaseSocketKick(base);
  const ctx = await phaseRedPacket(base);
  await phaseRedPacketExpiry(base, ctx);
  report.passed = true;
})().catch(err => {
  report.errors.push(err.message);
  console.error('验收失败:', err.message);
}).finally(async () => {
  try { await cleanup(); } catch (e) { report.cleanup = { error: e.message }; }
  await wait(300);
  if (server) { try { server.kill(); } catch (_) { /* 忽略 */ } }
  if (db) { try { await db.end(); } catch (_) { /* 忽略 */ } }
  report.finished = new Date().toISOString();
  save();
  const failed = report.checks.filter(c => !c.pass).length;
  console.log('检查项: ' + report.checks.length + '，失败: ' + failed +
    (report.errors.length ? '，错误: ' + report.errors.join(' | ') : ''));
  const okAll = report.passed && !failed && !report.errors.length;
  console.log(okAll ? 'MODERATION_REDPACKET_LIVE_PASS' : 'MODERATION_REDPACKET_LIVE_FAIL');
  process.exitCode = okAll ? 0 : 1;
});
