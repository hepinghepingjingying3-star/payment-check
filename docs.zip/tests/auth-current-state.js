'use strict';
// Real HTTP/JWT middleware with isolated account state; no real account changes.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const jwt = require('jsonwebtoken');
const express = require('express');
const secret = require('node:crypto').randomBytes(32).toString('hex');
const report = { checks: [], passed: false, mode: 'HTTP, real JWT, isolated database' };
let account = { id: 7, username: 'test', role: 'admin', status: 'active' }, fault = false, reads = 0, server;
const db = { promise: () => ({ query: async () => {
  reads++;
  if (fault) throw Error('private SQL diagnostic');
  return [account ? [account] : []];
} }) };
const mod = { exports: {} };
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../middleware/auth.js'), 'utf8'), {
  module: mod, process: { env: { JWT_SECRET: secret } },
  require: n => { if (n === 'jsonwebtoken') return jwt; if (n === '../config/db') return db; throw Error(n); }
});
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
(async () => {
  const app = express();
  const boundary = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../middleware/admin-boundary.js'), 'utf8'), {
    module: boundary, require: n => { if (n === './auth') return mod.exports; throw Error(n); }
  });
  boundary.exports(app);
  app.get('/api/admin/probe', (req, res) => res.json(req.user));
  // Mount actual OTP router outside the global boundary to verify its own guard.
  const otpModule = { exports: {} };
  const otpDependencies = {
    express, '../config/db': db, '../middleware/auth': mod.exports,
    '../config/otp': { OTP_CONFIG: {}, OTP_STATUS_TEXT: {} },
    '../utils/otp': {}, '../utils/request': require('../utils/request'),
    './otp': { audit: async () => {}, expireStale: async () => {} }
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../routes/admin-otp.js'), 'utf8'), {
    module: otpModule, console,
    require: n => { if (n in otpDependencies) return otpDependencies[n]; throw Error(n); }
  });
  app.use('/isolated', otpModule.exports);
  server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const sign = payload => jwt.sign(payload, secret, { expiresIn: 60 });
  const token = sign({ id: 7, role: 'admin' });
  async function call(t) {
    const res = await fetch('http://127.0.0.1:' + server.address().port + '/api/admin/probe', {
      headers: t ? { Authorization: 'Bearer ' + t } : {}, signal: AbortSignal.timeout(5000)
    });
    return { status: res.status, body: await res.json() };
  }
  async function otpCall(t) {
    return fetch('http://127.0.0.1:' + server.address().port + '/isolated/admin/otp/invalid/reveal', {
      method: 'POST', headers: t ? { Authorization: 'Bearer ' + t } : {}, signal: AbortSignal.timeout(5000)
    });
  }
  check('OTP router anonymous denied independently', (await otpCall()).status === 401);
  check('OTP router admin reaches input validation', (await otpCall(token)).status === 400);
  account.role = 'user';
  check('OTP router player denied independently', (await otpCall(token)).status === 403);
  account.role = 'support';
  check('OTP router support denied independently', (await otpCall(token)).status === 403);
  account.role = 'admin';
  check('Anonymous denied', (await call()).status === 401);
  check('Active admin allowed', (await call(token)).status === 200);
  account.role = 'user';
  check('Old admin token denied after demotion', (await call(token)).status === 403);
  account.role = 'support';
  check('Support denied admin-only access', (await call(token)).status === 403);
  account.role = 'admin'; account.status = 'banned';
  check('Old login token denied after ban', (await call(token)).status === 403);
  account.status = 'active';
  const before = reads;
  for (const purpose of ['register_otp', 'reset_password']) {
    check(purpose + ' cannot authenticate', (await call(sign({ id: 7, purpose }))).status === 401);
  }
  check('Non-login tokens never query accounts', reads === before);
  check('Invalid ID denied', (await call(sign({ id: '7' }))).status === 401);
  check('Invalid signature denied', (await call(jwt.sign({ id: 7 }, 'isolated-wrong-key'))).status === 401);
  account = null;
  check('Missing account denied', (await call(token)).status === 401);
  fault = true;
  const failed = await call(token);
  check('Database outage fails closed without SQL leak', failed.status === 500 && !JSON.stringify(failed.body).includes('SQL'));
  report.passed = true;
})().catch(e => { report.error = e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'auth-current-state-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report)); process.exitCode = report.passed ? 0 : 1;
});
