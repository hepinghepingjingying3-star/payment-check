'use strict';
// Actual password handler, HTTP and bcrypt; isolated user state. No production writes.
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const assert = require('node:assert/strict'), express = require('express'), bcrypt = require('bcryptjs');
const root = path.resolve(__dirname, '..');
const report = { scope: 'HTTP / isolated user / real bcrypt', checks: [], passed: false };
let server, hash, conflict = false, broken = false;
const db = { promise: () => ({ query: async (sql, args) => {
  if (sql.startsWith('SELECT id, password_hash')) return [[{ id: 1, password_hash: hash }]];
  if (sql.startsWith('UPDATE users SET password_hash')) {
    if (broken) throw Error('isolated storage failure');
    assert.match(sql, /AND password_hash = \? AND status = 'active'/);
    if (conflict || args[2] !== hash) return [{ affectedRows: 0 }];
    hash = args[0]; return [{ affectedRows: 1 }];
  }
  throw Error('Unexpected SQL');
} }) };
const source = fs.readFileSync(path.join(root, 'routes/auth.js'), 'utf8');
const start = source.indexOf("router.post('/auth/change-password'");
const end = source.indexOf('// 导出路由', start);
const router = express.Router();
vm.runInNewContext(source.slice(start, end), { router, db, bcrypt, Buffer, console,
  auth(req, res, next) { if (!req.headers.authorization) return res.status(401).json({ success: false }); req.user = { id: 1 }; next(); }
});
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
async function main() {
  hash = await bcrypt.hash('Old-password-123', 4);
  const app = express(); app.use(express.json()); app.use('/api', router);
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const valid = { old_password: 'Old-password-123', new_password: 'New-password-456', confirm_password: 'New-password-456' };
  async function call(body, loggedIn = true) {
    const r = await fetch('http://127.0.0.1:' + server.address().port + '/api/auth/change-password', {
      method: 'POST', headers: { 'Content-Type': 'application/json', ...(loggedIn ? { Authorization: 'isolated-test' } : {}) },
      body: JSON.stringify(body), signal: AbortSignal.timeout(5000)
    });
    return { status: r.status, body: await r.json(), cache: r.headers.get('cache-control') };
  }
  check('Anonymous denied', (await call(valid, false)).status === 401);
  check('Missing input rejected', (await call({})).status === 422);
  check('Mismatch rejected', (await call({ ...valid, confirm_password: 'different' })).status === 422);
  check('Same password rejected', (await call({ ...valid, new_password: valid.old_password, confirm_password: valid.old_password })).status === 422);
  const long = '密'.repeat(25);
  check('bcrypt byte limit enforced', (await call({ ...valid, new_password: long, confirm_password: long })).status === 422);
  check('Wrong old password denied', (await call({ ...valid, old_password: 'Incorrect-password' })).status === 401);
  conflict = true;
  check('Concurrent change rejected', (await call(valid)).status === 409);
  conflict = false; broken = true;
  check('Database failure not success', (await call(valid)).status === 500);
  broken = false;
  const result = await call(valid);
  check('Password update succeeds', result.status === 200 && result.body.success);
  check('New password works, old password fails', await bcrypt.compare(valid.new_password, hash) && !await bcrypt.compare(valid.old_password, hash));
  check('Response no-store without credentials', result.cache === 'no-store' && !JSON.stringify(result.body).includes(hash) && !JSON.stringify(result.body).includes(valid.new_password));
  report.passed = true;
}
main().catch(e => { report.error = e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'change-password-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2)); process.exitCode = report.passed ? 0 : 1;
});
