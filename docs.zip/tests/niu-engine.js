'use strict';
// ============================================
// 26牛牛娱乐场 - 纯逻辑测试（无需数据库 / 无需服务器）
// 运行: node tests/niu-engine.js
// 覆盖: 牌堆 / 洗牌 / 发牌 / 牌型 / 点数 / 比牌 / 结算 / 配置 / 前端与路由静态约束
// ============================================
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const E = require(path.join(root, 'utils/niuEngine'));
const NG = require(path.join(root, 'config/niuGame'));

const report = { name: 'niu-engine', checks: [], passed: false };
function check(name, fn) {
  fn();
  report.checks.push({ name: name, pass: true });
}
function card(rank, suit) {
  const suitCode = ['S', 'H', 'C', 'D'][suit];
  return {
    id: suitCode + E.RANK_LABEL[rank], rank: rank, suit: suit, suit_code: suitCode,
    suit_label: E.SUITS[suit].label, rank_label: E.RANK_LABEL[rank], point: E.pointValue(rank)
  };
}
function hand(codes) {
  // codes 形如 ['SA','H10','C2','D3','S4']，也允许数字写法 ['S1','S13']
  return codes.map(c => {
    const suit = ['S', 'H', 'C', 'D'].indexOf(c.charAt(0));
    const token = c.slice(1);
    const numeric = Number(token);
    const rank = (Number.isInteger(numeric) && E.RANK_LABEL[numeric])
      ? numeric
      : Number(Object.keys(E.RANK_LABEL).find(r => E.RANK_LABEL[r] === token));
    return card(rank, suit);
  });
}

async function main() {
  // ---------- 牌堆 ----------
  check('一副牌 52 张且不重复', () => {
    const deck = E.buildDeck();
    assert.equal(deck.length, 52);
    assert.equal(new Set(deck.map(c => c.id)).size, 52);
  });
  check('点数换算：A=1，10/J/Q/K=10', () => {
    assert.deepEqual([1, 9, 10, 11, 12, 13].map(E.pointValue), [1, 9, 10, 10, 10, 10]);
  });

  // ---------- 洗牌 / 发牌 ----------
  check('洗牌是纯函数且含全部 52 张', () => {
    const deck = E.buildDeck();
    const shuffled = E.shuffle(deck, n => 0);   // 确定性随机，可复现
    assert.equal(shuffled.length, 52);
    assert.deepEqual(deck.map(c => c.id), E.buildDeck().map(c => c.id));   // 原数组未被修改
    assert.notDeepEqual(shuffled.map(c => c.id), deck.map(c => c.id));
  });
  check('发牌每人 5 张且互不重复', () => {
    const d = E.deal(E.buildDeck(), [11, 22, 33]);
    const ids = Object.keys(d.hands);
    assert.deepEqual(ids.sort(), ['11', '22', '33']);
    const all = [];
    ids.forEach(k => { assert.equal(d.hands[k].length, 5); all.push(...d.hands[k].map(c => c.id)); });
    assert.equal(new Set(all).size, 15);
  });
  check('人数超出牌堆容量时报错', () => {
    assert.throws(() => E.deal(E.buildDeck(), new Array(11).fill(0).map((_, i) => i + 1)), /DEAL_CAPACITY/);
  });

  // ---------- 牌型 / 点数 ----------
  check('无牛判定', () => {
    const h = E.identifyHand(hand(['S1', 'H2', 'C3', 'D4', 'S1']));
    assert.equal(h.key, 'NO_NIU');
    assert.equal(h.multiplier, 1);
  });
  check('牛七判定（1+4+5=10，余 3+10=13 → 3 点）', () => {
    const h = E.identifyHand(hand(['S1', 'H4', 'C5', 'D3', 'SK']));
    assert.equal(h.key, 'NIU_3');
    assert.equal(h.point_value, 3);
    assert.equal(h.multiplier, 1);
  });
  check('牛牛判定并取得 3 倍', () => {
    const h = E.identifyHand(hand(['S1', 'H4', 'C5', 'D10', 'SK']));
    assert.equal(h.key, 'NIU_NIU');
    assert.equal(h.point_value, 10);
    assert.equal(h.multiplier, 3);
  });
  check('五小牛判定（全部 ≤4 且总点数 ≤10，10 倍）', () => {
    const h = E.identifyHand(hand(['S1', 'H2', 'C3', 'D1', 'S2']));
    assert.equal(h.key, 'WU_XIAO');
    assert.equal(h.multiplier, 10);
  });
  check('炸弹牛判定（四张同点，8 倍）', () => {
    const h = E.identifyHand(hand(['S7', 'H7', 'C7', 'D7', 'S2']));
    assert.equal(h.key, 'ZHA_DAN');
    assert.equal(h.multiplier, 8);
  });
  check('五花牛判定（全部 J/Q/K，5 倍）', () => {
    const h = E.identifyHand(hand(['SJ', 'HQ', 'CK', 'DJ', 'SK']));
    assert.equal(h.key, 'WU_HUA');
    assert.equal(h.multiplier, 5);
  });
  check('同花牛判定（同花且成牛，4 倍）', () => {
    const h = E.identifyHand(hand(['S1', 'S4', 'S5', 'S10', 'SK']));
    assert.equal(h.key, 'TONG_HUA');
    assert.equal(h.multiplier, 4);
  });
  check('牛八高于牛七（比牌顺序确定）', () => {
    const a = E.identifyHand(hand(['S9', 'H9', 'C2', 'D4', 'SK']));   // 9+9+2=20 余 4+10=14 → 牛四
    const b = E.identifyHand(hand(['S1', 'H7', 'C2', 'D3', 'S5']));   // 1+7+2=10 余 3+5=8 → 牛八
    assert.equal(a.key, 'NIU_4');
    assert.equal(b.key, 'NIU_8');
    assert.ok(E.compareHands(b, a) > 0);
  });
  check('非法手牌抛错，伪造牌面被 validateCards 拦截', () => {
    assert.throws(() => E.identifyHand([card(1, 0)]), /HAND_NEED_5_CARDS/);
    assert.equal(E.validateCards(hand(['S1', 'H2', 'C3', 'D4', 'S5'])), true);
    const dup = hand(['S1', 'H2', 'C3', 'D4', 'S5']);
    dup[4] = dup[0];
    assert.equal(E.validateCards(dup), false);
    assert.equal(E.validateCards([{ id: 'XY', rank: 99, suit: 9 }]), false);
  });


  // ---------- 结算 ----------
  const bankerWin = E.identifyHand(hand(['S1', 'H4', 'C5', 'D10', 'SK']));   // 牛牛 3 倍
  const playerLose = E.identifyHand(hand(['S1', 'H2', 'C3', 'D4', 'SK']));   // 无牛（任意三张都不成 10 的倍数）
  const playerWin = E.identifyHand(hand(['S1', 'H7', 'C2', 'D3', 'S5']));    // 牛八 2 倍

  check('底分 × 倍数：闲家输，按庄家牌型倍数结算', () => {
    const rows = E.settle(10,
      { user_id: 1, hand: bankerWin, points: 1000 },
      [{ user_id: 2, hand: playerLose, bet_level: 2, points: 1000 }]);
    const banker = rows.find(r => r.role === 'BANKER');
    const p = rows.find(r => r.role === 'PLAYER');
    assert.equal(p.delta, -60);          // 10 × 2 × 3（庄家牛牛 3 倍）
    assert.equal(banker.delta, 60);
    assert.equal(rows.reduce((s, r) => s + r.delta, 0), 0);
  });
  check('闲家赢：庄家积分不足时封顶，且总量守恒', () => {
    const rows = E.settle(100,
      { user_id: 1, hand: playerLose, points: 50 },
      [{ user_id: 2, hand: playerWin, bet_level: 5, points: 1000 }]);
    const banker = rows.find(r => r.role === 'BANKER');
    const p = rows.find(r => r.role === 'PLAYER');
    assert.equal(p.expect_amount, 100 * 5 * 2);   // 应结 1000
    assert.equal(p.delta, 50);                    // 庄家只有 50，封顶
    assert.equal(p.is_capped, true);
    assert.equal(banker.delta, -50);
    assert.equal(rows.reduce((s, r) => s + r.delta, 0), 0);
  });
  check('平局：牌型与牌面完全相同时不产生任何积分变动', () => {
    // 同一副牌不会发出两张相同的牌，这里用同一手牌验证 settle() 的 DRAW 分支
    const x = E.identifyHand(hand(['S1', 'H2', 'C3', 'D4', 'S5']));
    const rows = E.settle(10,
      { user_id: 1, hand: x, points: 500 },
      [{ user_id: 2, hand: x, bet_level: 3, points: 500 }]);
    assert.equal(rows.find(r => r.role === 'PLAYER').delta, 0);
    assert.equal(rows.find(r => r.role === 'BANKER').delta, 0);
    assert.equal(rows.find(r => r.role === 'PLAYER').is_draw, true);
  });
  check('同点数不同花色：按花色确定胜负，绝不出现假平局', () => {
    const spadeHigh = E.identifyHand(hand(['S1', 'H2', 'C3', 'D4', 'S5']));   // 最大牌 黑桃5
    const heartHigh = E.identifyHand(hand(['H1', 'C2', 'D3', 'S4', 'H5']));   // 最大牌 红心5
    assert.ok(E.compareHands(spadeHigh, heartHigh) > 0);
    assert.ok(E.compareHands(heartHigh, spadeHigh) < 0);
  });
  check('错误倍数回退到默认值，非法底分抛错', () => {
    const rows = E.settle(10,
      { user_id: 1, hand: bankerWin, points: 100 },
      [{ user_id: 2, hand: playerLose, bet_level: 999, points: 100 }]);
    assert.equal(rows.find(r => r.role === 'PLAYER').bet_level, NG.BET_DEFAULT_LEVEL);
    assert.throws(() => E.settle(0, { user_id: 1, hand: bankerWin, points: 1 }, []), /INVALID_BASE_STAKE/);
  });
  check('多闲家结果确定（与传入顺序无关，始终按 user_id 排序）', () => {
    const a = E.settle(10, { user_id: 1, hand: bankerWin, points: 1000 },
      [{ user_id: 3, hand: playerLose, bet_level: 1, points: 1000 }, { user_id: 2, hand: playerLose, bet_level: 1, points: 1000 }]);
    const b = E.settle(10, { user_id: 1, hand: bankerWin, points: 1000 },
      [{ user_id: 2, hand: playerLose, bet_level: 1, points: 1000 }, { user_id: 3, hand: playerLose, bet_level: 1, points: 1000 }]);
    assert.deepEqual(a.map(r => r.user_id), b.map(r => r.user_id));
    assert.deepEqual(a.map(r => r.delta), b.map(r => r.delta));
  });

  // ---------- 配置 ----------
  check('倍数只接受配置白名单', () => {
    assert.equal(NG.isValidBetLevel(1), true);
    assert.equal(NG.isValidBetLevel(5), true);
    assert.equal(NG.isValidBetLevel(4), false);
    assert.equal(NG.isValidBetLevel('2'), true);
    assert.equal(NG.isValidBetLevel(-1), false);
  });
  check('状态机与阶段时长完整（后端唯一驱动）', () => {
    ['WAITING', 'GRABBING', 'BETTING', 'DEALING', 'RESULT', 'SETTLEMENT', 'FINISHED']
      .forEach(function (k) {
        assert.ok(NG.PHASE[k], '缺少阶段 ' + k);
        assert.ok(NG.PHASE_TEXT[NG.PHASE[k]], '缺少阶段文案 ' + k);
        assert.ok(NG.TIMERS[k] > 0, '缺少阶段时长 ' + k);
      });
  });
  check('场次配置含门槛与底分（进入条件只看游戏积分）', () => {
    assert.ok(NG.ROOMS.length >= 3);
    NG.ROOMS.forEach(function (r) {
      assert.ok(r.key && r.name && r.base_stake > 0);
      assert.ok(r.seat_limit >= NG.PLAYERS.MIN);
    });
    assert.equal(NG.POINTS.ASSET, 'GAME_POINTS');
    assert.ok(NG.POINTS.DAILY_FREE.AMOUNT > 0);
  });
  check('公开配置不含内部字段（无密钥 / 无数据库信息）', () => {
    const json = JSON.stringify(NG.publicConfig());
    assert.equal(json.indexOf('password'), -1);
    assert.equal(json.indexOf('secret'), -1);
    assert.equal(json.indexOf('DB_'), -1);
    assert.ok(json.indexOf('不可兑换现金') !== -1);
  });
  check('牌型倍数与 config 单一来源一致', () => {
    assert.equal(E.identifyHand(hand(['S1', 'H4', 'C5', 'D10', 'SK'])).multiplier, NG.HAND_TYPES.NIU_NIU.multiplier);
    assert.equal(E.identifyHand(hand(['S1', 'H2', 'C3', 'D1', 'S2'])).multiplier, NG.HAND_TYPES.WU_XIAO.multiplier);
  });

  // ---------- 静态约束（保证「后端可信 + 非现金化」不被回归破坏） ----------
  const read = f => fs.readFileSync(path.join(root, f), 'utf8');

  check('迁移文件只做安全增量（无 DROP / DELETE / TRUNCATE）', () => {
    const sql = read('database/migrations/024-niu-game.js');
    assert.equal(/\bDROP\b/i.test(sql), false);
    assert.equal(/\bTRUNCATE\b/i.test(sql), false);
    assert.equal(/DELETE\s+FROM/i.test(sql), false);
    assert.ok(sql.indexOf("GAME_POINTS") !== -1);
    assert.ok(sql.indexOf('UNIQUE KEY uq_niu_round_user') !== -1);   // 防重复结算
  });
  check('游戏路由要求登录，且不返回他人手牌字段', () => {
    const api = read('routes/niu.js');
    assert.ok(api.indexOf("require('../middleware/auth')") !== -1);
    ['/config', '/rooms', '/state', '/join', '/leave', '/grab', '/bet', '/stats', '/records',
      '/leaderboard', '/daily-free'].forEach(function (p) {
        assert.ok(api.indexOf("PREFIX + '" + p) !== -1, '缺少接口 ' + p);
      });
    assert.ok(api.indexOf('rateLimit') !== -1 || api.indexOf('limiter') !== -1);
  });
  check('管理后台接口叠加 auth + requireRole(admin)，未硬编码用户名', () => {
    const adm = read('routes/admin-niu.js');
    assert.ok(adm.indexOf('requireRole') !== -1);
    assert.ok(adm.indexOf('writeAdminLog') !== -1);
    assert.equal(/username\s*===\s*['"]/.test(adm), false);
  });
  check('结算使用事务 + 行锁 + 统一流水，且积分变动走 ledger', () => {
    const room = read('utils/niuRoom.js');
    assert.ok(room.indexOf('beginTransaction') !== -1);
    assert.ok(room.indexOf('FOR UPDATE') !== -1);
    assert.ok(room.indexOf('ledger.applyBalance') !== -1);
    assert.equal(/UPDATE users SET game_points/i.test(room), false);   // 禁止裸改积分
    assert.ok(room.indexOf("status = 'SETTLEMENT'") !== -1);           // 幂等闸门
  });
  check('游戏开关由系统设置中心控制（真实开关）', () => {
    assert.equal(NG.SWITCHES.DB_KEY, 'niu_game_enabled');
    const site = read('config/site.js');
    assert.ok(site.indexOf('niu_game_enabled') !== -1);
  });
  check('游戏页面存在且不包含随机假数据', () => {
    const page = read('public/niu.html');
    const js = read('public/js/niu-page.js');
    assert.ok(page.indexOf('/js/niu-page.js') !== -1);
    assert.ok(page.indexOf('/api/game/niu') !== -1 || js.indexOf('/api/game/niu') !== -1);
    assert.equal(/Math\.random\(/.test(js), false);   // 前端不得生成任何结果/积分
  });
  check('大厅唯一入口是「26牛牛游戏群」，不存在独立游戏页', () => {
    const games = require(path.join(root, 'config/games'));
    const g = games.GAMES.find(x => x.id === '26niuniu');
    assert.ok(g, '缺少 26牛牛 入口配置');
    // 游戏核心在聊天群里：入口必须是 chat 类型，且指向真实群聊页面
    assert.equal(g.entry.type, 'chat');
    assert.equal(g.entry.url, '/group-chat.html');
    // 不允许再有指向独立游戏页的入口
    const all = JSON.stringify(games.GAMES);
    assert.equal(all.indexOf('/niu.html'), -1, '大厅仍残留独立游戏页入口');
  });
  check('游戏系统消息发在 group 聊天频道（不是独立频道）', () => {
    assert.equal(NG.CHAT.GROUP_CHANNEL, 'group');
    assert.equal(NG.CHAT.MESSAGE_TYPE, 'game');
    const chat = read('routes/chat.js');
    assert.ok(chat.indexOf("'group'") !== -1 || chat.indexOf('"group"') !== -1);
  });
  check('游戏阶段话术定义在聊天群里（开局/抢庄/发牌/结算/结束）', () => {
    const L = NG.CHAT.LINES;
    ['NEW_ROUND', 'GRAB_START', 'GRAB_END', 'BET_START', 'DEAL_DONE', 'REVEAL_HEAD', 'SETTLE_HEAD', 'ROUND_END']
      .forEach(k => assert.ok(typeof L[k] === 'string' && L[k].length > 0, '缺少话术: ' + k));
    assert.ok(L.NEW_ROUND.indexOf('26牛牛') >= 0);
  });
  check('聊天页加载游戏操作卡片模块（游戏在聊天界面里操作）', () => {
    const page = read('public/group-chat.html');
    assert.ok(page.indexOf('/js/chat-game-card.js') !== -1);
    const card = read('public/js/chat-game-card.js');
    assert.ok(card.indexOf('/api/game/niu') !== -1);
    // 卡片只提交阶段允许的动作，绝不提交结果 / 积分
    assert.equal(/amount|result|delta|points\s*:/.test(card), false, '卡片不得提交结算字段');
  });
  check('管理后台包含 26牛牛 面板与脚本', () => {
    const html = read('public/admin.html');
    const panel = read('public/js/admin-niu-panel.js');
    assert.ok(html.indexOf('data-tab="niu"') !== -1);
    assert.ok(html.indexOf('id="panel-niu"') !== -1);
    assert.ok(html.indexOf('/js/admin-niu-panel.js') !== -1);
    assert.ok(panel.indexOf('/api/admin/niu/status') !== -1);
  });
  check('设置页音效开关与游戏页读取同一存储键', () => {
    const st = read('public/js/settings-page.js');
    const ng = read('public/js/niu-page.js');
    assert.ok(st.indexOf('nn_niu_sound') !== -1);
    assert.ok(ng.indexOf('nn_niu_sound') !== -1);
  });

  report.passed = true;
}

main().catch(function (e) {
  report.error = e && e.message ? e.message : String(e);
}).finally(function () {
  report.checked = report.checks.length;
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'niu-engine-report.json'), JSON.stringify(report, null, 2));
  console.log((report.passed ? 'NIU_ENGINE PASS' : 'NIU_ENGINE FAIL') +
    ' (' + report.checked + '/' + report.checks.length + ')' + (report.error ? ' :: ' + report.error : ''));
  process.exitCode = report.passed ? 0 : 1;
});

