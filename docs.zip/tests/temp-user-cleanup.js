'use strict';
// 安全删除「已由测试脚本明确创建」的临时用户及其关联数据。
// 调用方必须传入自身创建的数值 ID；本工具不会按用户名匹配或查询真实用户。

async function deleteUsersDeep(conn, ids) {
  const userIds = Array.from(new Set((ids || []).map(Number).filter(Number.isSafeInteger).filter(id => id > 0)));
  if (!userIds.length) return {};
  const list = userIds.join(',');
  const removed = {};
  const [fks] = await conn.query(
    `SELECT table_name AS table_name, column_name AS column_name
       FROM information_schema.key_column_usage
      WHERE referenced_table_name = 'users' AND referenced_column_name = 'id'
        AND table_schema = DATABASE()`
  );
  let remaining = fks.slice();
  for (let pass = 0; pass < 6 && remaining.length; pass++) {
    const next = [];
    for (const fk of remaining) {
      try {
        const table = String(fk.table_name).replace(/`/g, '``');
        const column = String(fk.column_name).replace(/`/g, '``');
        const [r] = await conn.query('DELETE FROM `' + table + '` WHERE `' + column + '` IN (' + list + ')');
        if (r.affectedRows) removed[table] = (removed[table] || 0) + r.affectedRows;
      } catch (_) { next.push(fk); }
    }
    remaining = next;
  }
  const legacyRefs = [
    ['chat_read_state', 'user_id'], ['user_presence', 'user_id'], ['user_stickers', 'user_id'],
    ['chat_messages', 'user_id'], ['chat_reports', 'reporter_id'],
    ['chat_red_packet_claims', 'user_id'], ['chat_red_packets', 'sender_id'],
    ['wallet_orders', 'user_id'], ['balance_transactions', 'user_id'],
    ['notifications', 'user_id'], ['login_logs', 'user_id'],
    ['admin_logs', 'admin_id'], ['admin_logs', 'target_user_id'],
    ['admin_approvals', 'requested_by'], ['admin_approvals', 'reviewed_by'], ['admin_approvals', 'target_user_id'],
    ['referral_rewards', 'user_id'], ['referral_rewards', 'source_user_id'],
    ['referral_relations', 'referrer_id'], ['referral_relations', 'referred_user_id'],
    ['real_name_reviews', 'user_id'], ['password_reset_tokens', 'user_id']
  ];
  for (const [tableName, columnName] of legacyRefs) {
    const [columns] = await conn.query(
      `SELECT 1 FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ? LIMIT 1`,
      [tableName, columnName]
    );
    if (!columns.length) continue;
    try {
      const [r] = await conn.query('DELETE FROM `' + tableName + '` WHERE `' + columnName + '` IN (' + list + ')');
      if (r.affectedRows) removed[tableName] = (removed[tableName] || 0) + r.affectedRows;
    } catch (_) {}
  }
  const [del] = await conn.query('DELETE FROM users WHERE id IN (' + list + ')');
  removed.users = del.affectedRows;
  return removed;
}

module.exports = { deleteUsersDeep };