'use strict';
// ============================================
// 26牛牛 - 系统设置 / 维护模式 / 快捷回复 真实验证（临时账号，结束即清理）
// ============================================
// 说明:
//   - 真实 HTTP + 真实 MySQL：启动 server.js（临时端口），用临时 admin / support / user 账号调用
//   - 只写入 system_settings 中本次测试用到的键，并在结束时恢复原值（绝不长期改动站点配置）
//   - 临时账号与临时快捷回复在 finally 中删除；不触碰任何真实用户
//   - 绝不修改 JWT Secret / 数据库密码 / 真实资金数据
// ============================================
require('dotenv').config();
const crypto = require('crypto');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { spawn } = require('child_process');

const PORT = 3103;
const BASE = 'http://127.0.0.1:' + PORT;
const prefix = 'zzset_' + Date.now().toString(36) + '_';
const TOUCHED_KEYS = ['maintenance_mode', 'maintenance_notice'];
const results = [];
let conn = null;
let serverProcess = null;
const ids = [];
let qrId = null;
let originalSettings = {};
let maintenanceOn = false;

function check(name, condition, detail) {
  const ok = !!condition;
  results.push({ name, ok, detail: detail === undefined ? null : String(detail) });
  if (!ok) throw new Error(name + (detail !== undefined ? ': ' + detail : ''));
}

async function call(path, options) {
  const r = await fetch(BASE + path, options || {});
  const body = await r.json().catch(() => ({}));
  return { status: r.status, body, headers: r.headers };
}

function token(user) {
  return jwt.sign(
    { id: user.id, username: user.username, role: user.role, purpose: 'login', tv: Number(user.token_version || 0) },
    process.env.JWT_SECRET, { expiresIn: '5m' }
  );
}

async function startServer() {
  serverProcess = spawn(process.execPath, ['server.js'], {
    cwd: require('path').join(__dirname, '..'),
    env: Object.assign({}, process.env, { PORT: String(PORT) }),
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  serverProcess.stdout.on('data', d => { output += d.toString(); });
  serverProcess.stderr.on('data', d => { output += d.toString(); });
  for (let i = 0; i < 40; i++) {
    await new Promise(resolve => setTimeout(resolve, 250));
    try { const r = await fetch(BASE + '/'); if (r.ok) return; } catch (_) { /* 尚未就绪 */ }
    if (serverProcess.exitCode !== null) throw new Error('verification server stopped: ' + output.slice(-300));
  }
  throw new Error('verification server did not start: ' + output.slice(-300));
}

async function createUser(role) {
  const username = prefix + role;
  const hash = await bcrypt.hash('TempPass!123', 10);
  const [r] = await conn.query(
    `INSERT INTO users (username, nickname, email, phone, real_name, password_hash,
       invite_code, role, status, token_version)
     VALUES (?, ?, NULL, NULL, ?, ?, ?, ?, 'active', 0)`,
    [username, username, '临时设置测试', hash,
      crypto.randomBytes(4).toString('hex').toUpperCase(), role]
  );
  ids.push(r.insertId);
  return { id: r.insertId, username, role, token_version: 0 };
}

(async () => {
  conn = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
  const [rows] = await conn.query(
    'SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (?)', [TOUCHED_KEYS]
  );
  rows.forEach(r => { originalSettings[r.setting_key] = r.setting_value; });

  await startServer();

  const admin = await createUser('admin');
  const support = await createUser('support');
  const user = await createUser('user');
  const adminToken = token(admin), supportToken = token(support), userToken = token(user);

  // ---------- 1. 权限边界（阶段 37 / 42） ----------
  let r = await call('/api/admin/settings');
  check('anonymous cannot read admin settings', r.status === 401, r.status);
  r = await call('/api/admin/settings', { headers: { Authorization: 'Bearer ' + userToken } });
  check('ordinary user cannot read admin settings', r.status === 403, r.status);
  r = await call('/api/admin/settings', {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + userToken },
    body: JSON.stringify({ values: { site_name: 'x' } })
  });
  check('ordinary user cannot write settings', r.status === 403, r.status);
  r = await call('/api/admin/settings', {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + supportToken },
    body: JSON.stringify({ values: { site_name: 'x' } })
  });
  check('support cannot write core settings', r.status === 403, r.status);

  // ---------- 2. 管理员读取配置定义 ----------
  r = await call('/api/admin/settings', { headers: { Authorization: 'Bearer ' + adminToken } });
  check('admin reads settings with definitions',
    r.status === 200 && r.body.success === true && Array.isArray(r.body.data.definitions) && r.body.data.definitions.length >= 10, r.status);
  check('settings payload exposes no credentials',
    !/password|secret|jwt|api[_-]?key/i.test(JSON.stringify(r.body)), '');

  // ---------- 3. 区间校验 ----------
  r = await call('/api/admin/settings', {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken },
    body: JSON.stringify({ values: { deposit_min: 50000, deposit_max: 30 } })
  });
  check('deposit min > max is rejected', r.status === 422, r.status);

  // ---------- 4. 正常保存 + 审计 ----------
  const notice = '维护测试文案' + Date.now().toString(36);
  r = await call('/api/admin/settings', {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken },
    body: JSON.stringify({ values: { maintenance_notice: notice }, reason: '自动验收测试' })
  });
  check('admin saves setting and receives changed keys',
    r.status === 200 && r.body.success === true && (r.body.data.changed || []).indexOf('maintenance_notice') >= 0, r.status);
  const [stored] = await conn.query("SELECT setting_value FROM system_settings WHERE setting_key = 'maintenance_notice'");
  check('setting persisted in MySQL', stored.length === 1 && String(stored[0].setting_value).indexOf(notice.slice(0, 6)) >= 0, stored.length);
  const [audit] = await conn.query(
    "SELECT id FROM admin_logs WHERE action = 'settings_update' AND admin_id = ? ORDER BY id DESC LIMIT 1", [admin.id]
  );
  check('settings change written to audit log', audit.length === 1, audit.length);

  // ---------- 5. 维护模式（阶段 36） ----------
  r = await call('/api/admin/settings', {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken },
    body: JSON.stringify({ values: { maintenance_mode: true } })
  });
  check('admin enables maintenance mode',
    r.status === 200 && (r.body.data.changed || []).indexOf('maintenance_mode') >= 0, r.status);
  maintenanceOn = true;

  r = await call('/api/auth/me', { headers: { Authorization: 'Bearer ' + userToken } });
  check('ordinary user API blocked during maintenance', r.status === 503 && r.body.code === 'MAINTENANCE', r.status);
  const page = await fetch(BASE + '/lobby.html', { redirect: 'manual' });
  check('ordinary user page redirected to maintenance page',
    page.status === 302 && page.headers.get('location') === '/maintenance.html', page.status);
  r = await call('/api/admin/settings', { headers: { Authorization: 'Bearer ' + adminToken } });
  check('admin still works during maintenance', r.status === 200, r.status);
  r = await call('/api/settings');
  check('public settings reports maintenance on', r.status === 200 && r.body.data.maintenance.on === true, r.status);

  r = await call('/api/admin/settings', {
    method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken },
    body: JSON.stringify({ values: { maintenance_mode: false } })
  });
  check('maintenance mode restored off', r.status === 200, r.status);
  maintenanceOn = false;
  r = await call('/api/auth/me', { headers: { Authorization: 'Bearer ' + userToken } });
  check('ordinary user works again after maintenance off', r.status === 200, r.status);


  // ---------- 6. 客服快捷回复（阶段 34） ----------
  const content = '自动验收快捷回复' + Date.now().toString(36);
  r = await call('/api/admin/support/quick-replies', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken },
    body: JSON.stringify({ content: content, sort: 99 })
  });
  check('admin adds quick reply', r.status === 200 && r.body.data && r.body.data.id > 0, r.status);
  qrId = r.body.data.id;

  r = await call('/api/support/quick-replies', { headers: { Authorization: 'Bearer ' + supportToken } });
  check('support reads quick replies for insertion',
    r.status === 200 && (r.body.data.list || []).some(x => x.content === content), r.status);

  r = await call('/api/admin/support/quick-replies', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + supportToken },
    body: JSON.stringify({ content: 'support 不应能新增快捷回复' })
  });
  check('support cannot manage quick replies', r.status === 403, r.status);

  r = await call('/api/admin/support/quick-replies/' + qrId, { method: 'DELETE', headers: { Authorization: 'Bearer ' + adminToken } });
  check('admin hides quick reply', r.status === 200, r.status);
  const [qrRow] = await conn.query('SELECT status FROM support_quick_replies WHERE id = ?', [qrId]);
  check('quick reply is soft deleted (row kept for audit)', qrRow.length === 1 && qrRow[0].status === 'hidden', qrRow.length);

  console.log(JSON.stringify({ passed: true, checks: results }, null, 2));
})().catch(err => {
  console.error(JSON.stringify({ passed: false, error: err.message, checks: results }, null, 2));
  process.exitCode = 1;
}).finally(async () => {
  if (conn) {
    try {
      // 恢复本次测试触碰过的系统配置键（曾存在则还原，未存在则删除覆盖行）
      for (const k of TOUCHED_KEYS) {
        if (Object.prototype.hasOwnProperty.call(originalSettings, k)) {
          await conn.query('UPDATE system_settings SET setting_value = ? WHERE setting_key = ?', [originalSettings[k], k]);
        } else {
          await conn.query('DELETE FROM system_settings WHERE setting_key = ?', [k]);
        }
      }
      if (qrId) await conn.query('DELETE FROM support_quick_replies WHERE id = ?', [qrId]);
      if (ids.length) {
        const { deleteUsersDeep } = require('./temp-user-cleanup');
        await deleteUsersDeep(conn, ids);
      }
    } catch (e) {
      console.error('temporary settings-test cleanup failed:', e.message);
      process.exitCode = 1;
    }
    await conn.end();
  }
  if (serverProcess && serverProcess.exitCode === null) {
    serverProcess.kill();
    await new Promise(resolve => serverProcess.once('exit', resolve));
  }
  if (maintenanceOn) console.error('WARNING: maintenance mode may still be enabled');
});
