'use strict';
// Real Socket.IO transport and current DB authentication; read-only account query.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const db = require('../config/db');
const { initGameSocket } = require('../socket/gameSocket');
const report = { mode: 'Real Socket.IO transport, real DB, read-only; test-signed JWT, not password login', checks: [], passed: false };
let io;
function check(name, pass) { assert.ok(pass, name); report.checks.push({ name, pass: true }); }
function connect(port, token) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket('ws://127.0.0.1:' + port + '/socket.io/?EIO=4&transport=websocket');
    const timer = setTimeout(() => { ws.close(); reject(Error('Socket timeout')); }, 6000);
    ws.addEventListener('error', () => { clearTimeout(timer); reject(Error('Socket transport error')); });
    ws.addEventListener('message', event => {
      const packet = String(event.data);
      if (packet.startsWith('0')) ws.send('40' + JSON.stringify({ token }));
      else if (packet === '2') ws.send('3');
      else if (packet.startsWith('40') || packet.startsWith('44')) {
        clearTimeout(timer);
        const accepted = packet.startsWith('40');
        ws.close(); resolve(accepted);
      }
    });
  });
}
(async () => {
  const [rows] = await db.promise().query("SELECT id FROM users WHERE status = 'active' ORDER BY id LIMIT 1");
  assert.ok(rows.length, 'No active account for read-only test');
  const server = http.createServer(); io = new Server(server); initGameSocket(io);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const sign = payload => jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '30s' });
  check('Active login JWT connects', await connect(port, sign({ id: rows[0].id })));
  check('Invalid JWT rejected', !await connect(port, 'not-a-token'));
  check('Missing JWT rejected', !await connect(port, undefined));
  check('OTP purpose rejected', !await connect(port, sign({ id: rows[0].id, purpose: 'register_otp' })));
  check('Reset purpose rejected', !await connect(port, sign({ id: rows[0].id, purpose: 'reset_password' })));
  report.passed = true;
})().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  if (io) await new Promise(resolve => io.close(resolve));
  await db.promise().end();
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'socket-auth-report.json'), JSON.stringify(report, null, 2));
  console.log(report.passed ? 'SOCKET_AUTH_PASS' : 'SOCKET_AUTH_FAIL');
  process.exitCode = report.passed ? 0 : 1;
});
