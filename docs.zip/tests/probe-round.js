'use strict';
require('dotenv').config();
const db = require('../config/db');
const NG = require('../config/niuGame');
const bot = require('../utils/niuBot');
const room = require('../utils/niuRoom');
const out = [];
function log(s) { out.push(String(s)); require('fs').writeFileSync(__dirname + '/probe-round.txt', out.join('\n'), 'utf8'); }

(async () => {
  await room.init(null);
  const st0 = await bot.status();
  log('bot before=' + JSON.stringify(st0));
  await bot.start(1, { room_key: 'junior' });
  log('bot after start=' + JSON.stringify(await bot.status()));

  const [urows] = await db.promise().query(
    "SELECT id FROM users WHERE role <> 'admin' ORDER BY id ASC LIMIT 2");
  const ids = urows.map(r => Number(r.id));
  log('players=' + JSON.stringify(ids));

  for (const uid of ids) {
    await db.promise().query('UPDATE users SET game_points = 50000 WHERE id = ?', [uid]);
    const p = await room.loadProfile(uid);
    await room.join('junior', uid, 'socket-probe-' + uid);
    log('join ' + uid + ' => ' + JSON.stringify(p && p.nickname));
  }

  const seen = [];
  const deadline = Date.now() + 50000;
  let roundNo = null;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 500));
    const s = room.stateFor('junior', ids[0]) || {};
    if (s.phase === 'GRABBING') {
      room.setGrab('junior', ids[0], 1).catch(() => {});
      room.setGrab('junior', ids[1], 0).catch(() => {});
    } else if (s.phase === 'BETTING') {
      room.setBet('junior', ids[0], 2).catch(() => {});
      room.setBet('junior', ids[1], 2).catch(() => {});
    }
    if (s.round_no && s.round_no !== roundNo) {
      roundNo = s.round_no;
      log('round=' + roundNo + ' phase=' + s.phase);
    }
    if (roundNo && (await db.promise().query(
      'SELECT COUNT(*) c FROM game_results WHERE round_id = ?', [roundNo]))[0][0].c > 0) { log('settled'); break; }
  }

  const [msgs] = await db.promise().query(
    "SELECT id, phase, round_id, room_id, LEFT(content,34) c, JSON_UNQUOTE(JSON_EXTRACT(meta,'$.kind')) k FROM chat_messages WHERE message_type='game' AND round_id = ? ORDER BY id ASC",
    [roundNo]);
  log('MSGS for round ' + roundNo + ' = ' + msgs.length);
  msgs.forEach(m => log('  #' + m.id + ' [' + m.phase + '] room=' + m.room_id + ' kind=' + m.k + ' | ' + m.c));

  const [ev] = await db.promise().query(
    'SELECT event_type, phase FROM niu_bot_events WHERE round_id = ? ORDER BY id ASC', [roundNo]);
  log('EVENTS=' + JSON.stringify(ev));

  for (const uid of ids) await room.leave('junior', uid, 'socket-probe-' + uid).catch(() => {});
  await bot.stop(1);
  process.exit(0);
})().catch(e => { log('ERR ' + e.stack); process.exit(1); });
