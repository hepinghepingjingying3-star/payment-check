'use strict';
// Recovery endpoints are disabled: manual customer-service verification only.
// Verifies verify/reset-password return 410 RECOVERY_DISABLED, help returns manual steps,
// responses are no-store, and rate limiting still applies.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('node:crypto');
const report = { scope: 'HTTP / isolated / disabled self-service recovery', checks: [], passed: false };
const root = path.resolve(__dirname, '..');
let server;
const tokens = new Map();
async function query(sql, p) {
  if (sql.includes('SELECT id, password_hash FROM users')) return [[]];
  if (sql.includes('INSERT INTO password_reset_tokens')) { tokens.set(p[0], { user_id: p[1] }); return [{ affectedRows: 1 }]; }
  throw Error('Unexpected SQL: self-service recovery must not touch the database');
}
const conn = { query, beginTransaction: async () => {}, commit: async () => {}, rollback: async () => {}, release() {} };
const db = { promise: () => ({ query, getConnection: async () => conn }) };
function check(name, condition) { assert.ok(condition, name); report.checks.push({ name, pass: true }); }
async function main() {
  const module = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'routes/recovery.js'), 'utf8'), {
    module, Buffer, setInterval, Date, require: name => ({ express, bcryptjs: bcrypt, 'node:crypto': crypto, '../config/db': db })[name]
  });
  const app = express(); app.use(express.json()); app.use('/api', module.exports);
  server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = 'http://127.0.0.1:' + server.address().port + '/api/auth/recovery/';
  async function post(endpoint, body) {
    const res = await fetch(base + endpoint, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}), signal: AbortSignal.timeout(5000)
    });
    return { status: res.status, body: await res.json(), cache: res.headers.get('cache-control') };
  }
  async function get(endpoint) {
    const res = await fetch(base + endpoint, { signal: AbortSignal.timeout(5000) });
    return { status: res.status, body: await res.json(), cache: res.headers.get('cache-control') };
  }
  const v = await post('verify', { any_input: 'x' });
  check('Verify disabled with 410', v.status === 410 && v.body.code === 'RECOVERY_DISABLED');
  check('Verify message points to manual support', /人工身份核验|在线客服/.test(v.body.message));
  const r = await post('reset-password', { reset_token: 'x', new_password: 'a', confirm_password: 'a' });
  check('Reset-password disabled with 410', r.status === 410 && r.body.code === 'RECOVERY_DISABLED');
  check('Disabled responses cannot be cached', v.cache === 'no-store' && r.cache === 'no-store');
  const h = await get('help');
  check('Help returns manual verification steps', h.status === 200 && h.body.success && h.body.data.method === 'manual' && Array.isArray(h.body.data.steps) && h.body.data.steps.length > 0);
  check('Help exposes support contact', typeof h.body.data.contact === 'string' && h.body.data.contact.length > 0);
  check('No reset tokens were created', tokens.size === 0);
  for (let i = 0; i < 12; i++) await post('verify', {});
  const limited = await post('verify', {});
  check('Repeated requests rate limited', limited.status === 429);
  report.passed = true;
}
main().catch(e => { report.error = e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'recovery-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2)); process.exitCode = report.passed ? 0 : 1;
});
