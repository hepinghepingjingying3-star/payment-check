'use strict';
// Reuse existing Chrome harness without modifying it. Production page, fixture API.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const root = path.resolve(__dirname, '..');
let source = fs.readFileSync(path.join(root, '_test_tutorial_browser.js'), 'utf8').replace(/\r\n/g, '\n');
source = source.replace('const app = express();', `const app = express();
  app.get('/api/chat/channels', (req, res) => res.json({ success: true, data: { list: [{
    channel: 'group', name: '26牛牛游戏群', pinned: true, unread: 0,
    avatar: require('./routes/assets').getManifest(true).avatars_url
  }] } }));`);
const start = source.indexOf('  const seed =');
const end = source.indexOf('\n}\nconst timeout', start);
if (start < 0 || end < 0) throw new Error('Harness boundaries not found');
source = source.slice(0, start) + `
  await send('Page.addScriptToEvaluateOnNewDocument', { source: "localStorage.setItem('token','isolated-avatar-test');" });
  await send('Page.navigate', { url: origin + '/messages.html' });
  let image;
  for (let i = 0; i < 80; i++) {
    image = await evaluate("(() => { const el = document.querySelector('a[href=\\\"/group-chat.html\\\"] img.conv-avatar'); return el ? { src: el.getAttribute('src'), naturalWidth: el.naturalWidth, width: el.getBoundingClientRect().width } : null; })()");
    if (image && image.naturalWidth > 0) break;
    await wait(100);
  }
  check(image && image.src === '/assets/avatars/official.jpg' && image.naturalWidth > 0 && image.width > 0, 'Chat group avatar renders exact official asset', image);
  check(report.errors.length === 0, 'No browser errors', report.errors);
` + source.slice(end);
source = source.replace('_tutorial_browser_report.json', 'tests/avatar-browser-report.json');
const filename = path.join(root, '_avatar_browser_runtime.js');
const runtime = new Module(filename, module);
runtime.filename = filename;
runtime.paths = Module._nodeModulePaths(root);
runtime._compile(source, filename);
