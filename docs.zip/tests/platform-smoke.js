'use strict';
// Start the actual server on an ephemeral port. No database writes or OTP creation.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { fork } = require('child_process');
const root = path.resolve(__dirname, '..');
const output = path.join(__dirname, 'platform-smoke-report.json');
const report = { started: new Date().toISOString(), checks: [], completed: false };
let child;
function check(name, pass, detail) {
  report.checks.push({ name, pass: Boolean(pass), ...(detail ? { detail } : {}) });
}
async function main() {
  const publicDir = path.join(root, 'public');
  const pages = fs.readdirSync(publicDir).filter(f => f.endsWith('.html'));
  for (const file of pages) {
    const html = fs.readFileSync(path.join(publicDir, file), 'utf8');
    let index = 0;
    for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
      const src = match[1].match(/src=["']([^"']+)["']/i);
      if (src) {
        if (src[1].startsWith('/') && !src[1].startsWith('//')) {
          check(file + ': script exists ' + src[1], fs.existsSync(path.join(publicDir, src[1])));
        }
      } else {
        try { new vm.Script(match[2], { filename: file }); check(file + ': inline script ' + (++index), true); }
        catch (e) { check(file + ': inline script', false, e.message); }
      }
    }
  }
  for (const file of fs.readdirSync(path.join(publicDir, 'js')).filter(f => f.endsWith('.js'))) {
    try { new vm.Script(fs.readFileSync(path.join(publicDir, 'js', file), 'utf8')); check('JS syntax: ' + file, true); }
    catch (e) { check('JS syntax: ' + file, false, e.message); }
  }
  // Intercept listen only to obtain the ephemeral port; load unmodified server.js.
  const bootstrap = `const http=require('http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args);};require('./server');`;
  child = fork('-e', [bootstrap], { cwd: root, env: { ...process.env, PORT: '0' }, silent: true });
  // Drain output without logging configuration, credentials or message contents.
  child.stdout.resume(); child.stderr.resume();
  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Server start timed out')), 12000);
    child.once('message', m => { clearTimeout(timer); resolve(m.port); });
    child.once('exit', code => { clearTimeout(timer); reject(new Error('Server exited before listen: ' + code)); });
  });
  const base = 'http://127.0.0.1:' + port;
  for (const url of ['/recovery.html', '/js/admin-otp.js', '/js/admin-page.js', '/js/app-common.js', '/app.css']) {
    const response = await fetch(base + url, { signal: AbortSignal.timeout(5000) });
    const text = await response.text();
    check('Actual server GET ' + url, response.status === 200 && text.length > 0, { status: response.status });
  }
  // 管理页面不再是公开静态壳：匿名访问必须 302 回 /me.html?admin=denied，且不会下发后台 HTML
  for (const url of ['/admin-otp.html', '/admin.html']) {
    const response = await fetch(base + url, { redirect: 'manual', signal: AbortSignal.timeout(5000) });
    const location = response.headers.get('location') || '';
    check('Protected page redirect for ' + url, response.status === 302 && location === '/me.html?admin=denied',
      { status: response.status, location });
    const followed = await fetch(base + url, { signal: AbortSignal.timeout(5000) });
    const text = await followed.text();
    check('No admin shell served for ' + url,
      followed.url.endsWith('/me.html?admin=denied') && text.indexOf('id="adminBody"') === -1 && text.indexOf('id="otpBody"') === -1,
      { final_url: followed.url, length: text.length });
  }
  for (const url of ['/api/admin/otp', '/api/admin/otp/logs', '/api/admin/dashboard', '/api/admin/users']) {
    const response = await fetch(base + url, { signal: AbortSignal.timeout(5000) });
    const body = await response.json();
    check('Unauthenticated denied: ' + url, response.status === 401 && body.success === false);
  }
  for (const endpoint of ['verify', 'reset-password']) {
    const response = await fetch(base + '/api/auth/recovery/' + endpoint, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}', signal: AbortSignal.timeout(5000)
    });
    const body = await response.json();
    check('Actual recovery route validates empty input: ' + endpoint, response.status === 422 && body.success === false);
    check('Actual recovery response no-store: ' + endpoint, response.headers.get('cache-control') === 'no-store');
  }
  report.completed = true;
}
const watchdog = setTimeout(() => {
  report.error = 'Smoke test exceeded 40 seconds';
  finish();
}, 40000);
let finished = false;
function finish() {
  if (finished) return;
  finished = true;
  clearTimeout(watchdog);
  if (child) child.kill();
  report.finished = new Date().toISOString();
  report.passed = report.completed && !report.error && report.checks.every(c => c.pass);
  fs.writeFileSync(output, JSON.stringify(report, null, 2));
  console.log(report.passed ? 'PLATFORM_SMOKE_PASS' : 'PLATFORM_SMOKE_FAIL');
  process.exitCode = report.passed ? 0 : 1;
}
main().catch(e => { report.error = e.message; }).finally(finish);
