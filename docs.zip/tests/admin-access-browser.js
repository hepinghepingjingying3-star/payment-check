'use strict';
// ============================================
// 26牛牛 - 管理后台权限与账号治理端到端验收
// 环境: 真实服务器（临时端口）+ 真实 MySQL + 真实 Chrome
// 覆盖:
//   1) 匿名 / 普通用户访问 /admin.html、/admin-otp.html 一律 302 回 /me.html?admin=denied，绝不下发后台 HTML
//   2) 匿名 /api/admin/** → 401；普通用户 → 403
//   3) 登录下发 HttpOnly 页面票据（Cookie）；退出登录清除票据后同一 Cookie 立即失效
//   4) 管理员：概览「用户总数 / 今日注册」卡片可点击 → 用户列表 → 点用户名打开管理面板
//      → 设为管理员 / 取消管理员 / 禁言 / 解除禁言 / 封禁 / 解除封禁（数据库 + 审计日志逐项核对）
//   5) 禁言以数据库为准：被禁言用户发送聊天消息 403，解除后可发送
// 数据隔离:
//   - 只创建 zzperm_ 前缀的临时账号（1 个管理员 + 1 个普通用户），结束后删除自己创建的账号、审计与聊天记录
//   - 用临时端口 fork server.js，不触碰默认 3000 端口的开发服务
// 报告: tests/admin-access-browser-report.json（每步落盘，中断也不丢结果）
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn, fork } = require('node:child_process');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const root = path.resolve(__dirname, '..');
const reportPath = path.join(__dirname, 'admin-access-browser-report.json');
const report = {
  started: new Date().toISOString(),
  mode: 'Real server (temp port) + Real MySQL + Real Chrome; temporary zzperm_* accounts are removed afterwards',
  checks: [], errors: [], requests: [], cleanup: null
};
let server, chrome, ws, db;
let tempAdminId = null;
let reviewerId = null;
let tempUserId = null;
const tempIds = [];
const profile = fs.mkdtempSync(path.join(os.tmpdir(), '26-adminperm-'));
const stamp = Date.now().toString(36);
const adminUsername = 'zzperm_a_' + stamp;
const userUsername = 'zzperm_u_' + stamp;
const reviewerUsername = 'zzperm_r_' + stamp;
const adminPassword = 'Zz-Perm-Admin-1!';
const userPassword = 'Zz-Perm-User-1!';
const reviewerPassword = 'Zz-Perm-Review-1!';
let reviewerToken = null;
const wait = ms => new Promise(r => setTimeout(r, ms));

function save() {
  try { fs.writeFileSync(reportPath, JSON.stringify(report, null, 2)); } catch (_) {}
}
function check(ok, name, detail) {
  report.checks.push({ name, pass: !!ok, ...(detail === undefined ? {} : { detail }) });
  save();
  if (!ok) throw new Error(name + ': ' + JSON.stringify(detail));
}

// ---------- 数据库：临时账号 ----------
async function connectDb() {
  db = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT), user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
}
async function createTempUser(username, role, password) {
  const hash = bcrypt.hashSync(password, 11);
  const [result] = await db.query(
    `INSERT INTO users (username, nickname, real_name, password_hash, role, status)
     VALUES (?, ?, ?, ?, ?, 'active')`,
    [username, username, '临时验收账号', hash, role]
  );
  tempIds.push(result.insertId);
  return result.insertId;
}
async function userRow(id) {
  const [rows] = await db.query(
    'SELECT id, username, role, status, muted_until, mute_reason FROM users WHERE id = ?', [id]
  );
  return rows[0] || null;
}
async function waitDb(describe, fn, timeout = 8000) {
  const deadline = Date.now() + timeout;
  let last = null;
  while (Date.now() < deadline) {
    last = await fn();
    if (last) return last;
    await wait(150);
  }
  throw new Error('DB 条件未满足: ' + describe + ' (last=' + JSON.stringify(last) + ')');
}

// ---------- 双人复核辅助（V6：封禁 / 管理员权限 / 解除禁言需另一名管理员复核） ----------
/** 由第二管理员通过本次申请人挂起的全部待复核请求 */
async function approvePendingAsReviewer(base, expectMin) {
  let approved = 0;
  const list = await api(base, '/api/admin/approvals?status=PENDING&limit=50', { token: reviewerToken });
  const pending = ((list.json && list.json.data && list.json.data.list) || [])
    .filter(a => a.requested_by && a.requested_by.id === tempAdminId && a.can_review === true);
  for (const a of pending) {
    const res = await api(base, '/api/admin/approvals/' + Number(a.id) + '/decide',
      { method: 'POST', token: reviewerToken, body: { decision: 'approve', note: '自动化验收：复核通过' } });
    if (res.status === 200) approved++;
  }
  if (typeof expectMin === 'number' && approved < expectMin) {
    throw new Error('双人复核未完成：approved=' + approved + '（期望 >= ' + expectMin + '）');
  }
  return approved;
}

/** 敏感治理动作：200 直接生效；202（待复核）则由第二管理员复核后生效 */
async function sensitiveCall(base, token, pathname, body) {
  const res = await api(base, pathname, { method: 'POST', token: token, body: body });
  if (res.status !== 202) return res;
  await approvePendingAsReviewer(base, 1);
  return { status: 200, viaApproval: true, pending: res.json };
}

// ---------- 服务器（临时端口，使用未修改的 server.js） ----------
async function startServer() {
  const bootstrap = `const http=require('http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args);};require('./server');`;
  server = fork('-e', [bootstrap], { cwd: root, env: { ...process.env, PORT: '0' }, silent: true });
  server.stdout.resume(); server.stderr.resume();
  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('服务器启动超时')), 15000);
    server.once('message', m => { clearTimeout(timer); resolve(m.port); });
    server.once('exit', code => { clearTimeout(timer); reject(new Error('服务器提前退出: ' + code)); });
  });
  return 'http://127.0.0.1:' + port;
}

// ---------- HTTP 工具 ----------
function cookieOf(response) {
  const raw = typeof response.headers.getSetCookie === 'function'
    ? response.headers.getSetCookie()
    : [response.headers.get('set-cookie')].filter(Boolean);
  return raw.filter(Boolean).map(c => c.split(';')[0]).join('; ');
}
async function login(base, username, password) {
  const response = await fetch(base + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }), signal: AbortSignal.timeout(8000)
  });
  const body = await response.json().catch(() => ({}));
  return {
    status: response.status,
    token: body && body.data ? body.data.token : null,
    role: body && body.data && body.data.user ? body.data.user.role : null,
    cookie: cookieOf(response),
    setCookieRaw: response.headers.get('set-cookie') || ''
  };
}
async function api(base, pathname, { method = 'GET', token, body } = {}) {
  const headers = {};
  if (token) headers.Authorization = 'Bearer ' + token;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(base + pathname, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(8000)
  });
  const json = await response.json().catch(() => null);
  return { status: response.status, json };
}


// ---------- 阶段一：HTTP 边界与账号治理 ----------
async function runHttpPhase(base) {
  // 1. 未登录：管理页面 302 挡回，管理 API 401
  for (const url of ['/admin.html', '/admin-otp.html']) {
    const res = await fetch(base + url, { redirect: 'manual', signal: AbortSignal.timeout(8000) });
    const location = res.headers.get('location');
    check(res.status === 302 && location === '/me.html?admin=denied',
      '匿名访问 ' + url + ' 被 302 挡回 /me.html?admin=denied', { status: res.status, location });
    const followed = await fetch(base + url, { signal: AbortSignal.timeout(8000) });
    const html = await followed.text();
    check(followed.url.endsWith('/me.html?admin=denied') && !html.includes('id="adminBody"') && !html.includes('id="otpBody"'),
      '匿名请求 ' + url + ' 拿不到后台 HTML', { final_url: followed.url, length: html.length });
  }
  const anonApi = await api(base, '/api/admin/dashboard');
  check(anonApi.status === 401, '匿名访问 /api/admin/dashboard → 401', { status: anonApi.status });

  // 2. 普通用户：页面 302、API 403
  const userLogin = await login(base, userUsername, userPassword);
  check(userLogin.status === 200 && !!userLogin.token && userLogin.role === 'user',
    '临时普通用户可正常登录', { status: userLogin.status, role: userLogin.role });
  check(/nn_page=/.test(userLogin.cookie) && /HttpOnly/i.test(userLogin.setCookieRaw) && /SameSite=Lax/i.test(userLogin.setCookieRaw),
    '登录下发 HttpOnly + SameSite=Lax 的页面票据 Cookie',
    { set_cookie: userLogin.setCookieRaw.replace(/nn_page=[^;]+/, 'nn_page=<redacted>') });
  for (const url of ['/admin.html', '/admin-otp.html']) {
    const res = await fetch(base + url, { headers: { cookie: userLogin.cookie }, redirect: 'manual', signal: AbortSignal.timeout(8000) });
    check(res.status === 302 && res.headers.get('location') === '/me.html?admin=denied',
      '普通用户（已登录 + 有效票据）访问 ' + url + ' 仍被 302 挡回', { status: res.status, location: res.headers.get('location') });
  }
  for (const pathname of ['/api/admin/dashboard', '/api/admin/users', '/api/admin/otp']) {
    const res = await api(base, pathname, { token: userLogin.token });
    check(res.status === 403, '普通用户访问 ' + pathname + ' → 403', { status: res.status, message: res.json && res.json.message });
  }

  // 3. 退出登录：票据立即清除
  const logoutRes = await fetch(base + '/api/auth/logout', {
    method: 'POST', headers: { Authorization: 'Bearer ' + userLogin.token }, signal: AbortSignal.timeout(8000)
  });
  const logoutCookie = logoutRes.headers.get('set-cookie') || '';
  check(logoutRes.status === 200 && /nn_page=;/.test(logoutCookie) && /Expires=Thu, 01 Jan 1970|Max-Age=0/i.test(logoutCookie),
    '退出登录清除页面票据 Cookie', { status: logoutRes.status, set_cookie: logoutCookie.replace(/nn_page=[^;]*/, 'nn_page=<cleared>') });
  const afterLogout = await fetch(base + '/admin.html', {
    headers: { cookie: 'nn_page=' + 'z'.repeat(60) }, redirect: 'manual', signal: AbortSignal.timeout(8000)
  });
  check(afterLogout.status === 302, '无效票据访问 /admin.html 立即被挡回', { status: afterLogout.status });

  return userLogin;
}


// ---------- 阶段二：管理员完整权限（角色 / 禁言 / 封禁） ----------
async function runAdminPhase(base, userLogin) {
  const adminLogin = await login(base, adminUsername, adminPassword);
  check(adminLogin.status === 200 && adminLogin.role === 'admin', '临时管理员可正常登录', { status: adminLogin.status, role: adminLogin.role });
  // V6 双人复核：需要第二名活跃管理员才能完成复核
  const reviewerLogin = await login(base, reviewerUsername, reviewerPassword);
  check(reviewerLogin.status === 200 && reviewerLogin.role === 'admin',
    '第二管理员（复核人）可正常登录', { status: reviewerLogin.status });
  reviewerToken = reviewerLogin.token;
  for (const pair of [['/admin.html', 'id="adminBody"'], ['/admin-otp.html', 'id="otpBody"']]) {
    const res = await fetch(base + pair[0], { headers: { cookie: adminLogin.cookie }, redirect: 'manual', signal: AbortSignal.timeout(8000) });
    const html = await res.text();
    check(res.status === 200 && html.includes(pair[1]) && (res.headers.get('cache-control') || '').includes('no-store'),
      '管理员访问 ' + pair[0] + ' → 200 且禁止缓存', { status: res.status, cache: res.headers.get('cache-control') });
  }

  // 角色（V6：管理员权限变更需另一名管理员复核后生效）
  const roleUp = await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/role',
    { role: 'admin', reason: '自动化验收：授予管理员' });
  check(roleUp.status === 200 && (await userRow(tempUserId)).role === 'admin',
    '授予管理员权限（提交 → 第二管理员复核）生效（数据库核对）', roleUp.pending || (roleUp.json && roleUp.json.data));
  const roleDown = await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/role',
    { role: 'user', reason: '自动化验收：取消管理员' });
  check(roleDown.status === 200 && (await userRow(tempUserId)).role === 'user',
    '取消管理员权限（提交 → 复核）生效（数据库核对）', roleDown.pending || (roleDown.json && roleDown.json.data));

  // 禁言 → 发送被拦截 → 解除禁言 → 发送成功
  const mute = await api(base, '/api/admin/users/' + tempUserId + '/mute',
    { method: 'POST', token: adminLogin.token, body: { minutes: 60, reason: '自动化验收：禁言' } });
  const mutedRow = await waitDb('禁言到期时间写入', async () => {
    const row = await userRow(tempUserId);
    return row && row.muted_until && new Date(row.muted_until).getTime() > Date.now() ? row : null;
  });
  check(mute.status === 200 && mutedRow.mute_reason === '自动化验收：禁言', '禁言 60 分钟生效（数据库核对）', { muted_until: mutedRow.muted_until });
  const blocked = await api(base, '/api/chat/messages',
    { method: 'POST', token: userLogin.token, body: { channel: 'group', message_type: 'text', content: 'zzperm mute check' } });
  check(blocked.status === 403 && /禁言/.test((blocked.json && blocked.json.message) || ''),
    '被禁言用户发送聊天消息 → 403 且提示禁言', blocked.json);

  const unmute = await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/unmute',
    { reason: '自动化验收：解除禁言' });
  check(unmute.status === 200 && !(await userRow(tempUserId)).muted_until,
    '解除禁言（提交 → 第二管理员复核）生效（数据库核对）', unmute.pending || (unmute.json && unmute.json.data));
  const sent = await api(base, '/api/chat/messages',
    { method: 'POST', token: userLogin.token, body: { channel: 'group', message_type: 'text', content: 'zzperm unmute check' } });
  check(sent.status === 201 && !!(sent.json && sent.json.success), '解除禁言后可正常发消息（真实入库）', { status: sent.status });

  // 封禁 → 无法登录 → 解封 → 可登录（均需第二管理员复核）
  const ban = await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/status',
    { status: 'banned', reason: '自动化验收：封禁' });
  check(ban.status === 200 && (await userRow(tempUserId)).status === 'banned',
    '封禁（提交 → 复核）生效（数据库核对）', ban.pending || (ban.json && ban.json.data));
  const bannedLogin = await login(base, userUsername, userPassword);
  check(bannedLogin.status === 403, '被封禁账号无法登录 → 403', { status: bannedLogin.status });
  const unban = await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/status',
    { status: 'active', reason: '自动化验收：解封' });
  check(unban.status === 200 && (await userRow(tempUserId)).status === 'active',
    '解封（提交 → 复核）生效（数据库核对）', unban.pending || (unban.json && unban.json.data));
  const relogin = await login(base, userUsername, userPassword);
  check(relogin.status === 200, '解封后可正常登录', { status: relogin.status });

  return adminLogin;
}

// ---------- 阶段三：安全护栏 + 审计 ----------
async function runGuardPhase(base, adminLogin) {
  const selfRole = await api(base, '/api/admin/users/' + tempAdminId + '/role',
    { method: 'POST', token: adminLogin.token, body: { role: 'user', reason: '自动化验收：不能改自己' } });
  check(selfRole.status === 403, '管理员不能修改自己的角色 → 403', selfRole.json);
  const selfBan = await api(base, '/api/admin/users/' + tempAdminId + '/status',
    { method: 'POST', token: adminLogin.token, body: { status: 'banned', reason: '自动化验收：不能封自己' } });
  check(selfBan.status === 403, '管理员不能封禁自己 → 403', selfBan.json);
  const badRole = await api(base, '/api/admin/users/' + tempUserId + '/role',
    { method: 'POST', token: adminLogin.token, body: { role: 'root', reason: '自动化验收：非法角色' } });
  check(badRole.status === 422, '非法角色被拒绝 → 422', badRole.json);
  const shortReason = await api(base, '/api/admin/users/' + tempUserId + '/mute',
    { method: 'POST', token: adminLogin.token, body: { minutes: 60, reason: 'x' } });
  check(shortReason.status === 422, '禁言必须填写原因 → 422', shortReason.json);
  const badMinutes = await api(base, '/api/admin/users/' + tempUserId + '/mute',
    { method: 'POST', token: adminLogin.token, body: { minutes: 999999, reason: '时长越界' } });
  check(badMinutes.status === 422, '禁言时长越界被拒绝 → 422', badMinutes.json);

  // 管理员账号不能被禁言 / 不能被封禁（先临时提权目标账号，提权同样需要复核）
  await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/role',
    { role: 'admin', reason: '自动化验收：临时提权' });
  check((await userRow(tempUserId)).role === 'admin', '临时提权（提交 → 复核）生效', { role: (await userRow(tempUserId)).role });
  const muteAdmin = await api(base, '/api/admin/users/' + tempUserId + '/mute',
    { method: 'POST', token: adminLogin.token, body: { minutes: 60, reason: '自动化验收：管理员不可禁言' } });
  check(muteAdmin.status === 403, '管理员账号不能被禁言 → 403', muteAdmin.json);
  const banAdmin = await api(base, '/api/admin/users/' + tempUserId + '/status',
    { method: 'POST', token: adminLogin.token, body: { status: 'banned', reason: '自动化验收：管理员不可封禁' } });
  check(banAdmin.status === 403, '管理员账号不能被封禁 → 403', banAdmin.json);
  const restore = await sensitiveCall(base, adminLogin.token, '/api/admin/users/' + tempUserId + '/role',
    { role: 'user', reason: '自动化验收：恢复普通用户' });
  check(restore.status === 200 && (await userRow(tempUserId)).role === 'user',
    '临时提权可正常回收（提交 → 复核）', restore.pending || (restore.json && restore.json.data));

  // 审计日志（角色 / 禁言 / 解除禁言 / 封禁 全部留痕，且不含任何凭证）
  // V6：双人复核下「申请」写申请人、执行写复核人，因此两侧都要统计
  const audit = await api(base, '/api/admin/audit-logs?limit=100', { token: adminLogin.token });
  const mine = ((audit.json && audit.json.data && audit.json.data.list) || [])
    .filter(l => l.admin && (l.admin.id === tempAdminId || l.admin.id === reviewerId));
  const actions = mine.map(l => l.action);
  check(['user_role', 'user_mute', 'user_unmute', 'user_status'].every(a => actions.indexOf(a) >= 0),
    '审计日志完整记录 角色 / 禁言 / 解除禁言 / 封禁', actions);
  check(['admin_approval_request', 'admin_approval_approve'].every(a => actions.indexOf(a) >= 0),
    '审计日志记录双人复核的申请与通过（可追溯双人）', actions);
  const leaked = mine.filter(l => /password|otp_|token|jwt|secret/i.test(String(l.detail || '')));
  check(leaked.length === 0, '审计日志不包含密码 / OTP / 凭证', leaked.map(l => l.action));
}

// ---------- 阶段四：真实浏览器 UI 流程 ----------
async function runBrowserPhase(base, adminToken) {
  chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank'
  ], { stdio: 'ignore' });
  chrome.on('error', e => report.errors.push(e.message));
  let debugPort;
  for (let i = 0; i < 120; i++) {
    try { debugPort = fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0]; break; } catch (_) { await wait(100); }
  }
  check(!!debugPort, 'Chrome DevTools 调试端口可用', { port: debugPort || null });
  const targets = await (await fetch('http://127.0.0.1:' + debugPort + '/json/list')).json();
  const target = targets.find(t => t.type === 'page');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
  let id = 0;
  const pending = new Map();
  ws.onmessage = event => {
    const m = JSON.parse(event.data);
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.reject(new Error(m.error.message)); else p.resolve(m.result);
    }
    if (m.method === 'Runtime.exceptionThrown') report.errors.push(m.params.exceptionDetails);
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') report.errors.push(m.params);
    if (m.method === 'Network.loadingFailed' && !m.params.canceled) report.errors.push(m.params);
  };
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const n = ++id; pending.set(n, { resolve, reject }); ws.send(JSON.stringify({ id: n, method, params }));
  });
  const evaluate = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  const evaluateAsync = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  async function waitExpr(expr, tries = 60) {
    for (let i = 0; i < tries; i++) {
      if (await evaluate('(' + expr + ')').catch(() => false)) return true;
      await wait(120);
    }
    return false;
  }
  async function goto(url, readyExpr, tries = 60) {
    await send('Page.navigate', { url: base + url });
    let ok = false;
    for (let i = 0; i < tries; i++) {
      ok = await evaluate("document.readyState === 'complete' && (" + readyExpr + ")").catch(() => false);
      if (ok) break;
      await wait(120);
    }
    check(ok, '页面就绪: ' + url);
  }
  const userSelector = '#userList .user-name[data-user="' + tempUserId + '"]';
  const userSelectorJson = JSON.stringify(userSelector);
  const clickUser = '(() => { const el = document.querySelector(' + userSelectorJson + '); if (!el) return false; el.click(); return true; })()';
  async function clickSheetItem(text) {
    const clicked = await evaluate('(() => {' +
      'const el = Array.from(document.querySelectorAll(".sheet-item")).find(n => n.textContent.indexOf(' + JSON.stringify(text) + ') >= 0);' +
      'if (!el) return false; el.click(); return true; })()');
    check(clicked, '点击操作项「' + text + '」');
    await wait(300);
  }
  async function openUserSheet() {
    check(await evaluate(clickUser), '点击用户名打开管理面板');
    check(await waitExpr('document.querySelectorAll(".sheet-item").length > 0'), '用户管理面板已弹出');
    return evaluate('Array.from(document.querySelectorAll(".sheet-item")).map(n => n.textContent.trim())');
  }

  await send('Runtime.enable'); await send('Network.enable'); await send('Page.enable');
  await send('Network.setCacheDisabled', { cacheDisabled: true });
  // 预置管理员 token（App 的 API 认证用）；原因输入用自动化 prompt 替代人工输入。
  // 页面票据 Cookie 由浏览器自己的登录请求下发，与真实用户完全一致。
  await send('Page.addScriptToEvaluateOnNewDocument', {
    source: "localStorage.setItem('token', " + JSON.stringify(adminToken) + "); window.prompt = function(){ return '自动化验收原因'; };"
  });
  await goto('/me.html', "document.getElementById('identity').hidden === false");
  const browserLogin = await evaluateAsync('(async () => {' +
    'const res = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" },' +
    ' body: JSON.stringify({ username: ' + JSON.stringify(adminUsername) + ', password: ' + JSON.stringify(adminPassword) + ' }), credentials: "same-origin" });' +
    'const body = await res.json().catch(() => ({})); return { status: res.status, ok: !!body.success }; })()');
  check(browserLogin.status === 200 && browserLogin.ok, '浏览器内管理员登录成功（票据 Cookie 由浏览器保存）', browserLogin);

  await goto('/me.html', "document.getElementById('identity').hidden === false");
  const links = await evaluate('(() => ({' +
    'adminVisible: !!document.getElementById("adminLink").offsetParent,' +
    'otpVisible: !!document.getElementById("otpAdminLink").offsetParent,' +
    'adminHref: document.getElementById("adminLink").getAttribute("href") }))()');
  check(links.adminVisible && links.otpVisible && links.adminHref === '/admin.html',
    '管理员在「我的」页看到 管理后台 / OTP 管理 入口', links);

  return { evaluate, evaluateAsync, waitExpr, goto, clickSheetItem, openUserSheet };
}


// ---------- 阶段五：通过后台 UI 完成 授予权限 / 禁言 / 封禁 ----------
/** 双人复核通过后，后台页面里的用户缓存仍是旧的；点一次「查询」重新拉取列表 */
async function refreshUserList(B) {
  await B.evaluate("(() => { const b = document.getElementById('searchUsers'); if (b) { b.click(); } return true; })()");
  await wait(800);
}

async function runUiFlow(base, B) {
  const userSelectorJson = JSON.stringify('#userList .user-name[data-user="' + tempUserId + '"]');
  await B.goto('/admin.html', "document.getElementById('adminBody').hidden === false");

  // 概览统计卡（注册人数）→ 用户列表
  check(await B.waitExpr('!!document.querySelector("#statGrid [data-go]")'), '概览统计卡加载完成（含可点击的注册人数）');
  const tiles = await B.evaluate('(() => { const nodes = Array.from(document.querySelectorAll("#statGrid [data-go]"));' +
    'return { count: nodes.length, labels: nodes.map(n => n.querySelector(".stat-label").textContent), cursor: nodes.length ? getComputedStyle(nodes[0]).cursor : "" }; })()');
  check(tiles.count >= 2 && tiles.labels.indexOf('用户总数') >= 0 && tiles.labels.indexOf('今日注册') >= 0 && tiles.cursor === 'pointer',
    '「用户总数 / 今日注册」统计卡可点击（data-go + cursor:pointer）', tiles);
  check(await B.evaluate('(() => { document.querySelector("#statGrid [data-go]").click(); return true; })()'), '点击注册人数统计卡');
  check(await B.waitExpr("document.getElementById('panel-users').hidden === false"), '点击统计卡后进入用户列表 Tab');
  check(await B.waitExpr('!!document.querySelector(' + userSelectorJson + ')'), '用户列表显示新注册用户（用户名按钮）');
  const card = await B.evaluate('(() => { const btn = document.querySelector(' + userSelectorJson + ');' +
    'const box = btn.closest(".card");' +
    'return { username: btn.textContent.trim(), title: box.querySelector(".card-title").textContent.trim(),' +
    ' tags: Array.from(box.querySelectorAll(".admin-tag")).map(t => t.textContent.trim()) }; })()');
  check(card.username === userUsername && /普通用户/.test(card.title) && /正常/.test(card.title),
    '用户名按钮可点击，卡片显示角色 / 状态标签', card);

  // UI：禁言 1 小时（普通用户可直接禁言）
  let labels = await B.openUserSheet();
  check(labels.some(l => l.indexOf('设为管理员') >= 0) && labels.some(l => l.indexOf('禁言') >= 0) && labels.some(l => l.indexOf('封禁') >= 0),
    '点击用户名弹出的管理面板含 设为管理员 / 禁言 / 封禁', labels);
  await B.clickSheetItem('禁言该账号');
  check(await B.waitExpr('Array.from(document.querySelectorAll(".sheet-item")).some(n => n.textContent.indexOf("禁言 1 小时") >= 0)'),
    '禁言时长面板出现（1 小时 / 1 天 / 7 天 / 30 天）');
  await B.clickSheetItem('禁言 1 小时');
  const muted = await waitDb('UI 禁言', async () => {
    const r = await userRow(tempUserId);
    return r && r.muted_until && new Date(r.muted_until).getTime() > Date.now() ? r : null;
  });
  check(muted.mute_reason === '自动化验收原因', 'UI「禁言 1 小时」真实生效（数据库核对）', { muted_until: muted.muted_until });

  // UI：解除禁言
  labels = await B.openUserSheet();
  check(labels.some(l => l.indexOf('解除禁言') >= 0), '被禁言账号的管理面板显示「解除禁言」', labels);
  await B.clickSheetItem('解除禁言');
  await approvePendingAsReviewer(base, 1); // V6：解除禁言需第二管理员复核
  const cleared = await waitDb('UI 解除禁言', async () => { const r = await userRow(tempUserId); return r && !r.muted_until ? r : null; });
  check(!cleared.muted_until, 'UI「解除禁言」真实生效（数据库核对）', { muted_until: cleared.muted_until });

  // UI：封禁 → 无法登录 → 解除封禁 → 可登录
  labels = await B.openUserSheet();
  check(labels.some(l => l.indexOf('封禁账号') >= 0), '管理面板提供封禁入口', labels);
  await B.clickSheetItem('封禁账号');
  await approvePendingAsReviewer(base, 1); // V6：封禁需第二管理员复核
  await waitDb('UI 封禁', async () => { const r = await userRow(tempUserId); return r && r.status === 'banned' ? r : null; });
  const bannedLogin = await login(base, userUsername, userPassword);
  check(bannedLogin.status === 403, 'UI 封禁后该账号立即无法登录 → 403', { status: bannedLogin.status });
  await refreshUserList(B); // 复核通过后刷新后台列表缓存
  labels = await B.openUserSheet();
  check(labels.some(l => l.indexOf('解除封禁') >= 0), '已封禁账号的面板显示「解除封禁」', labels);
  await B.clickSheetItem('解除封禁');
  await approvePendingAsReviewer(base, 1); // V6：解封需第二管理员复核
  const unbanned = await waitDb('UI 解封', async () => { const r = await userRow(tempUserId); return r && r.status === 'active' ? r : null; });
  check(unbanned.status === 'active', 'UI「解除封禁」真实生效（数据库核对）', { status: unbanned.status });
  const backLogin = await login(base, userUsername, userPassword);
  check(backLogin.status === 200, 'UI 解封后该账号可正常登录', { status: backLogin.status });

  // UI：设为管理员（授予后台权限）
  labels = await B.openUserSheet();
  await B.clickSheetItem('设为管理员');
  await approvePendingAsReviewer(base, 1); // V6：授予管理员权限需第二管理员复核
  const upgraded = await waitDb('UI 授予管理员', async () => { const r = await userRow(tempUserId); return r && r.role === 'admin' ? r : null; });
  check(upgraded.role === 'admin', 'UI「设为管理员」真实生效（数据库核对）', { role: upgraded.role });
  await refreshUserList(B); // 复核通过后刷新后台列表缓存
  labels = await B.openUserSheet();
  check(labels.some(l => l.indexOf('取消管理员权限') >= 0) && !labels.some(l => l.indexOf('禁言该账号') >= 0),
    '管理员账号的面板提供「取消管理员权限」，且不再提供禁言（后端同样拒绝禁言管理员）', labels);

  // UI：取消管理员权限（还原到普通用户）
  await B.clickSheetItem('取消管理员权限');
  await approvePendingAsReviewer(base, 1); // V6：取消管理员权限需第二管理员复核
  const demoted = await waitDb('UI 取消管理员', async () => { const r = await userRow(tempUserId); return r && r.role === 'user' ? r : null; });
  const finalRow = await userRow(tempUserId);
  check(demoted.role === 'user' && finalRow.status === 'active' && !finalRow.muted_until,
    'UI「取消管理员权限」真实生效，账号回到普通用户且可用', { role: finalRow.role, status: finalRow.status, muted_until: finalRow.muted_until });

  // OTP 管理页对管理员可见
  await B.goto('/admin-otp.html', "document.getElementById('otpBody').hidden === false");
  const otpPage = await B.evaluate('(() => ({ gateHidden: document.getElementById("otpGate").hidden, selectVisible: !!document.getElementById("otpStatus").offsetParent }))()');
  check(otpPage.gateHidden && otpPage.selectVisible, '管理员可以看到 OTP 管理控制台', otpPage);

  const noise = report.errors.filter(e => JSON.stringify(e).indexOf('favicon') === -1);
  check(noise.length === 0, '后台 UI 全流程无 JS 异常 / console 错误 / 资源加载失败', noise.slice(0, 3));
}


// ---------- 清理：只删除本次创建的临时账号与它们的记录 ----------
async function cleanup() {
  const info = { temp_ids: tempIds.slice(), deleted_admin_logs: 0, deleted_login_logs: 0, deleted_chat_messages: 0, deleted_users: 0 };
  try {
    if (tempIds.length && db) {
      const [a] = await db.query('DELETE FROM admin_logs WHERE admin_id IN (?) OR target_user_id IN (?)', [tempIds, tempIds]);
      info.deleted_admin_logs = a.affectedRows;
      const [l] = await db.query('DELETE FROM login_logs WHERE user_id IN (?)', [tempIds]);
      info.deleted_login_logs = l.affectedRows;
      const [c] = await db.query('DELETE FROM chat_messages WHERE user_id IN (?)', [tempIds]);
      info.deleted_chat_messages = c.affectedRows;
      // V6：新增的双人复核 / 在线状态表没有外键，需要显式清理
      try {
        const [ap] = await db.query(
          'DELETE FROM admin_approvals WHERE requested_by IN (?) OR reviewed_by IN (?) OR target_user_id IN (?)',
          [tempIds, tempIds, tempIds]);
        info.deleted_admin_approvals = ap.affectedRows;
      } catch (_) { info.deleted_admin_approvals = 0; }
      try {
        const [pr] = await db.query('DELETE FROM user_presence WHERE user_id IN (?)', [tempIds]);
        info.deleted_user_presence = pr.affectedRows;
      } catch (_) { info.deleted_user_presence = 0; }
      const [u] = await db.query("DELETE FROM users WHERE id IN (?) AND username LIKE 'zzperm%'", [tempIds]);
      info.deleted_users = u.affectedRows;
    }
  } catch (err) {
    info.error = err.message;
  }
  report.cleanup = info;
  save();
  return info;
}

// ---------- 主流程 ----------
async function main() {
  await connectDb();
  tempAdminId = await createTempUser(adminUsername, 'admin', adminPassword);
  tempUserId = await createTempUser(userUsername, 'user', userPassword);
  // V6：双人复核需要第二名管理员（只用于复核，不参与其它断言）
  reviewerId = await createTempUser(reviewerUsername, 'admin', reviewerPassword);
  report.temp_accounts = {
    admin: { id: tempAdminId, username: adminUsername },
    reviewer: { id: reviewerId, username: reviewerUsername },
    user: { id: tempUserId, username: userUsername }
  };
  save();

  const base = await startServer();
  report.server = { base: base };
  save();

  const userLogin = await runHttpPhase(base);
  const adminLogin = await runAdminPhase(base, userLogin);
  await runGuardPhase(base, adminLogin);
  const browserTools = await runBrowserPhase(base, adminLogin.token);
  await runUiFlow(base, browserTools);
}

let finished = false;
async function finish(error) {
  if (finished) return;
  finished = true;
  clearTimeout(watchdog);
  if (error) report.error = error.message;
  const info = await cleanup().catch(err => ({ error: err.message }));
  try { if (ws) ws.close(); } catch (_) {}
  try { if (chrome) chrome.kill(); } catch (_) {}
  try { if (server) server.kill(); } catch (_) {}
  try { if (db) await db.end(); } catch (_) {}
  report.passed = !report.error && report.checks.every(c => c.pass) && !!(info && info.deleted_users === tempIds.length);
  report.finished = new Date().toISOString();
  save();
  const failed = report.checks.filter(c => !c.pass);
  console.log(report.passed
    ? 'ADMIN_ACCESS_BROWSER_PASS (' + report.checks.length + ' checks, temp accounts removed: ' + info.deleted_users + ')'
    : 'ADMIN_ACCESS_BROWSER_FAIL: ' + (report.error || 'checks failed') + ' failed=' + failed.length);
  for (const f of failed) console.log('  FAIL ' + f.name);
  if (!report.passed) {
    console.log('CLEANUP ' + JSON.stringify(report.cleanup));
    console.log('ERRORS ' + JSON.stringify((report.errors || []).slice(0, 3)));
  }
  process.exit(report.passed ? 0 : 1);
}

const watchdog = setTimeout(() => { finish(new Error('端到端验收超时（180 秒）')); }, 180000);
main().then(() => finish()).catch(err => finish(err));
