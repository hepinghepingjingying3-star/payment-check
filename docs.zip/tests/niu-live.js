'use strict';
// ============================================
// 26牛牛娱乐场 - 真实服务器 + 真实数据库 只读验收
// ============================================
// 用真实 server.js（临时端口）+ 测试签发的 JWT 校验：
//   - 未登录 401 / 普通用户 403 / 管理员 200
//   - 配置、场次、状态、战绩、记录、排行榜全部来自数据库（没有数据就是 0）
//   - 非游戏阶段的写操作被状态机拒绝（不产生任何数据）
// 本测试不写入任何业务数据（不发积分、不开局、不落对局）
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const { fork } = require('node:child_process');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const siteSettings = require('../utils/siteSettings');

const output = path.join(__dirname, 'niu-live-report.json');
const report = { mode: 'Real server + real DB, read-only; test-signed JWT', checks: [], passed: false };
let child;

function check(name, pass, detail) {
  report.checks.push({ name, pass: Boolean(pass), ...(detail ? { detail } : {}) });
  if (!pass) console.log('FAIL ' + name + ' ' + JSON.stringify(detail || {}));
}

async function req(base, url, opt) {
  const res = await fetch(base + url, Object.assign({ signal: AbortSignal.timeout(8000) }, opt || {}));
  let body = null;
  try { body = await res.json(); } catch (_) { body = null; }
  return { status: res.status, body };
}

function bearer(token) {
  return { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token };
}

async function main() {
  const [adminRows] = await db.promise().query(
    "SELECT id, role, token_version FROM users WHERE status = 'active' AND role = 'admin' ORDER BY id LIMIT 1");
  const [userRows] = await db.promise().query(
    "SELECT id, role, token_version FROM users WHERE status = 'active' AND role = 'user' ORDER BY id LIMIT 1");
  const admin = adminRows[0];
  const player = userRows[0];
  check('存在可用管理员与普通账号', Boolean(admin && player), { admin: admin && admin.id, player: player && player.id });
  if (!admin || !player) { report.error = 'missing active admin or user account'; return; }

  const sign = u => jwt.sign({ id: Number(u.id), tv: Number(u.token_version || 0) }, process.env.JWT_SECRET, { expiresIn: '120s' });
  const pToken = sign(player);
  const aToken = sign(admin);

  const bootstrap = `const http=require('http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...a){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,a);};require('./server');`;
  child = fork('-e', [bootstrap], { cwd: path.resolve(__dirname, '..'), env: { ...process.env, PORT: '0' }, silent: true });
  // 子进程输出必须留存：游戏消息写入失败时服务端只 console.error，
  // 之前 resume() 掉输出导致「消息没落库」这类问题完全看不到原因。
  const childLog = [];
  const cap = (stream, tag) => {
    let buf = '';
    stream.on('data', d => {
      buf += d.toString();
      const lines = buf.split(/\r?\n/);
      buf = lines.pop();
      lines.forEach(l => { if (l.trim()) childLog.push(tag + ' ' + l.trim()); });
      if (childLog.length > 400) childLog.splice(0, childLog.length - 400);
    });
  };
  cap(child.stdout, '[out]');
  cap(child.stderr, '[err]');
  report.childLog = childLog;
  const port = await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(Error('server start timeout')), 15000);
    child.once('message', m => { clearTimeout(t); resolve(m.port); });
    child.once('exit', c => { clearTimeout(t); reject(Error('server exited: ' + c)); });
  });
  const base = 'http://127.0.0.1:' + port;

  // ---------- 未登录 ----------
  const anon = await req(base, '/api/game/niu/rooms');
  check('未登录读取场次返回 401', anon.status === 401 && anon.body && anon.body.success === false, { status: anon.status });

  // ---------- 配置 ----------
  const cfg = await req(base, '/api/game/niu/config', { headers: bearer(pToken) });
  const d = (cfg.body && cfg.body.data) || {};
  check('配置接口返回 200', cfg.status === 200 && cfg.body.success === true, { status: cfg.status });
  check('配置为游戏积分资产（非现金）', d.asset && d.asset.code === 'GAME_POINTS', { asset: d.asset });
  check('配置含三个场次', Array.isArray(d.rooms) && d.rooms.length === 3, { rooms: (d.rooms || []).map(r => r.key) });
  check('配置含合法倍数白名单', Array.isArray(d.bet_levels) && d.bet_levels.every(b => [1, 2, 3, 5].indexOf(b.level) >= 0));
  check('配置含完整状态机阶段', Array.isArray(d.phases) && d.phases.length === 7 &&
    ['WAITING', 'GRABBING', 'BETTING', 'DEALING', 'RESULT', 'SETTLEMENT', 'FINISHED'].every(p => d.phases.some(x => x.key === p)));
  check('配置含非现金免责声明', typeof d.disclaimer === 'string' && d.disclaimer.indexOf('不可') >= 0);
  check('配置返回真实游戏积分（数字）', typeof d.game_points === 'number', { game_points: d.game_points });
  check('配置不泄露内部字段', !JSON.stringify(cfg.body).includes('base_stake_min') && !JSON.stringify(cfg.body).includes('DB_PASSWORD'));


  // ---------- 场次列表 ----------
  const rooms = await req(base, '/api/game/niu/rooms', { headers: bearer(pToken) });
  const rlist = (rooms.body && rooms.body.data && (rooms.body.data.rooms || rooms.body.data.list)) || [];
  check('场次接口返回 200', rooms.status === 200 && rooms.body.success === true, { status: rooms.status });
  check('场次含实时人数与座位限制', Array.isArray(rlist) && rlist.length === 3 &&
    rlist.every(r => typeof r.player_count === 'number' && typeof r.seat_limit === 'number'), { sample: rlist[0] });

  // ---------- 单场状态（个人视角）----------
  const st = await req(base, '/api/game/niu/state?room=junior', { headers: bearer(pToken) });
  const sd = (st.body && st.body.data) || {};
  check('场次状态返回 200 且含状态机阶段', st.status === 200 && typeof sd.phase === 'string', { phase: sd.phase });
  const others = JSON.stringify((sd.players || []).map(p => ({ id: p.user_id, hasCards: Boolean(p.cards) })));
  check('未开局时不下发任何人手牌', others.indexOf('"hasCards":true') === -1, { others: others });
  const bad = await req(base, '/api/game/niu/state?room=not_a_room', { headers: bearer(pToken) });
  check('不存在的场次返回 404', bad.status === 404, { status: bad.status });

  // ---------- 战绩 / 记录 / 排行榜（真实数据，空则为 0）----------
  const stats = await req(base, '/api/game/niu/stats', { headers: bearer(pToken) });
  const std = (stats.body && stats.body.data) || {};
  check('战绩接口返回 200', stats.status === 200, { status: stats.status });
  check('战绩字段全部是真实数字',
    ['total_rounds', 'win_rounds', 'banker_rounds', 'game_points'].every(k => typeof std[k] === 'number'), std);
  const rec = await req(base, '/api/game/niu/records?page=1&size=10', { headers: bearer(pToken) });
  const rd = (rec.body && rec.body.data) || {};
  check('对局记录接口返回 200 且为列表',
    rec.status === 200 && (Array.isArray(rd.list) || Array.isArray(rd.records)), { keys: Object.keys(rd) });
  const lb = await req(base, '/api/game/niu/leaderboard?limit=10', { headers: bearer(pToken) });
  const ld = (lb.body && lb.body.data) || {};
  check('排行榜接口返回 200 且是列表', lb.status === 200 && (Array.isArray(ld.list) || Array.isArray(ld.rows)), { keys: Object.keys(ld) });
  const lb2 = await req(base, '/api/game/niu/leaderboard?limit=999', { headers: bearer(pToken) });
  const ld2 = (lb2.body && lb2.body.data) || {};
  check('排行榜上限生效（最多 50 条）',
    lb2.status === 200 && ((ld2.list || ld2.rows || []).length <= 50), { count: ((ld2.list || ld2.rows || []).length) });

  // ---------- 状态机拒绝非法阶段操作（不产生任何数据）----------
  const bet = await req(base, '/api/game/niu/bet', {
    method: 'POST', headers: bearer(pToken), body: JSON.stringify({ room: 'junior', bet_level: 5 })
  });
  check('非下注阶段的下注被拒绝', [400, 403, 409].indexOf(bet.status) >= 0 && bet.body.success === false,
    { status: bet.status, code: bet.body && bet.body.code });
  const fake = await req(base, '/api/game/niu/bet', {
    method: 'POST', headers: bearer(pToken),
    body: JSON.stringify({ room: 'junior', bet_level: 5, delta: 99999, result: 'PLAYER', cards: ['S1', 'S2', 'S3', 'S4', 'S5'] })
  });
  check('客户端提交结果 / 牌面不改变结算（仍被拒绝）', [400, 403, 409].indexOf(fake.status) >= 0, { status: fake.status });
  const badRoom = await req(base, '/api/game/niu/grab', { method: 'POST', headers: bearer(pToken), body: JSON.stringify({ room: '' }) });
  check('缺少场次参数返回 422', badRoom.status === 422, { status: badRoom.status });
  const anonFree = await req(base, '/api/game/niu/daily-free', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}'
  });
  check('未登录不能领取每日积分', anonFree.status === 401, { status: anonFree.status });

  // ---------- 管理接口权限 ----------
  const uStatus = await req(base, '/api/admin/niu/status', { headers: bearer(pToken) });
  check('普通用户访问游戏管理接口 403', uStatus.status === 403 && uStatus.body.success === false, { status: uStatus.status });
  const aStatus = await req(base, '/api/admin/niu/status', { headers: bearer(aToken) });
  check('管理员访问游戏管理接口 200', aStatus.status === 200 && aStatus.body.success === true, { status: aStatus.status });
  const uGrant = await req(base, '/api/admin/niu/grant-points', {
    method: 'POST', headers: bearer(pToken), body: JSON.stringify({ user_id: player.id, amount: 1000 })
  });
  check('普通用户不能发放积分', uGrant.status === 403, { status: uGrant.status });
  const anonAdmin = await req(base, '/api/admin/niu/status');
  check('匿名访问游戏管理接口 401', anonAdmin.status === 401, { status: anonAdmin.status });

  // ---------- 结算幂等闸门（数据库层唯一约束 / 枚举 / 开关）----------
  const [idx] = await db.promise().query(
    `SELECT INDEX_NAME, NON_UNIQUE FROM information_schema.statistics
     WHERE table_schema = ? AND table_name = 'game_results' AND INDEX_NAME = 'uq_result_round_user'`,
    [process.env.DB_NAME]);
  check('结算明细唯一约束防重复结算（现有 game_results）', idx.length > 0 && Number(idx[0].NON_UNIQUE) === 0, { found: idx.length });
  const [col] = await db.promise().query(
    `SELECT COLUMN_TYPE ty FROM information_schema.columns
     WHERE table_schema = ? AND table_name = 'balance_transactions' AND column_name = 'currency_type'`,
    [process.env.DB_NAME]);
  check('流水表支持游戏积分币种', col.length > 0 && String(col[0].ty).indexOf('GAME_POINTS') >= 0, { type: col[0] && col[0].ty });
  const [sw] = await db.promise().query(
    "SELECT setting_value v FROM system_settings WHERE setting_key = 'niu_game_enabled'");
  // 库里的原始文本有两种来源，都必须能被配置中心正确还原成布尔值：
  //   迁移 024 写入 '1' / '0'；管理后台保存走 JSON.stringify，写入 'true' / 'false'。
  // 因此这里按应用真实语义（siteSettings.castValue）校验，而不是限定某一种文本。
  const rawSwitch = sw.length === 1 ? String(sw[0].v) : null;
  const switchBool = rawSwitch === 'true' || rawSwitch === '1';
  const switchFalsy = rawSwitch === 'false' || rawSwitch === '0';
  const parsedSwitch = await siteSettings.get('niu_game_enabled');
  check('游戏开关可在数据库配置（管理后台可控）',
    sw.length === 1 && (switchBool || switchFalsy) && typeof parsedSwitch === 'boolean' && parsedSwitch === switchBool,
    { value: rawSwitch, parsed: parsedSwitch });

  // ============================================
  // 架构验收：游戏核心长在聊天群里（不是独立游戏页）
  // ============================================
  const [chatCols] = await db.promise().query(
    `SELECT column_name n FROM information_schema.columns
     WHERE table_schema = ? AND table_name = 'chat_messages'
       AND column_name IN ('room_id','round_id','phase','game_round_pk')`,
    [process.env.DB_NAME]);
  check('聊天消息表可关联游戏房间/局次/阶段', chatCols.length === 4,
    { columns: chatCols.map(x => x.n) });
  const [mtEnum] = await db.promise().query(
    `SELECT COLUMN_TYPE ty FROM information_schema.columns
     WHERE table_schema = ? AND table_name = 'chat_messages' AND column_name = 'message_type'`,
    [process.env.DB_NAME]);
  const mtText = String(mtEnum[0] && mtEnum[0].ty || '');
  check('message_type 保留 text/image/sticker/system/game',
    ['text', 'image', 'sticker', 'system', 'game'].every(t => mtText.indexOf("'" + t + "'") >= 0),
    { type: mtText });

  const [niuRoomRows] = await db.promise().query(
    `SELECT room_key, chat_channel FROM game_rooms WHERE room_key IS NOT NULL ORDER BY room_key`);
  check('场次落在现有 game_rooms（room_key 唯一 + chat_channel=group）',
    niuRoomRows.length >= 1 && niuRoomRows.every(r => r.chat_channel === 'group'),
    { rooms: niuRoomRows.map(r => ({ key: r.room_key, ch: r.chat_channel })) });

  const [stEnum] = await db.promise().query(
    `SELECT COLUMN_TYPE ty FROM information_schema.columns
     WHERE table_schema = ? AND table_name = 'game_rounds' AND column_name = 'status'`,
    [process.env.DB_NAME]);
  const stText = String(stEnum[0] && stEnum[0].ty || '');
  const oldPhases = ['WAITING', 'BANKER_BIDDING', 'BETTING', 'RED_PACKET', 'CLAIMING', 'CALCULATING', 'SETTLEMENT', 'ENDED'];
  const newPhases = ['GRABBING', 'DEALING', 'RESULT', 'FINISHED', 'ABORTED'];
  check('game_rounds.status = 旧枚举全保留 + 26牛牛阶段追加',
    oldPhases.every(p => stText.indexOf("'" + p + "'") >= 0) && newPhases.every(p => stText.indexOf("'" + p + "'") >= 0),
    { enum: stText });

  await runRoundArchitectureChecks(base, pToken, aToken, player.id);
  await runBotChecks(base, pToken, aToken, admin.id, player.id);
  report.completed = true;
}

/**
 * 架构验收：游戏必须真的在「26牛牛游戏群」里进行
 * 用真实 HTTP + 真实数据库跑完一整局，然后断言：
 *   1) game 类型系统消息确实写进 chat_messages（channel='group'）
 *   2) 每条游戏消息都带 room_id / round_id / phase
 *   3) 消息内容覆盖多个游戏阶段
 *   4) 对局落在现有 game_rounds / room_players / game_results
 * 测试产生的对局与消息按 round_no 精确清理，不触碰任何真实数据。
 */
async function runRoundArchitectureChecks(base, pToken, aToken, playerId) {
  const ROOM = 'junior';
  const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + pToken };
  const AH = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aToken };

  // 机器人是「自动推进」的唯一总闸门：整局验收必须先由管理员启动机器人，
  // 否则（机器人已停止）状态机正确地不会开局。收尾时恢复测试前的运行状态。
  const botBefore = await db.promise().query('SELECT running FROM niu_bot_state WHERE id = ?', [1])
    .then(r => (r[0].length ? Number(r[0][0].running) : 0)).catch(() => 0);

  // 「自动游戏消息」必须先打开：关闭期间开局的话，按设计只发结算阶段消息，
  // 阶段话术会被合法抑制（第二十六条）。这里显式打开，避免测试跑在关闭窗口里。
  const autoOn = await req(base, '/api/admin/niu/bot/auto-messages', {
    method: 'POST', headers: AH, body: JSON.stringify({ enabled: true })
  });
  check('自动游戏消息已开启（阶段话术才会进群）',
    autoOn.status === 200 && !!(autoOn.body && autoOn.body.data && autoOn.body.data.auto_messages === true),
    { status: autoOn.status, auto_messages: autoOn.body && autoOn.body.data && autoOn.body.data.auto_messages });

  const startBot = await req(base, '/api/admin/niu/bot/start', {
    method: 'POST', headers: AH, body: JSON.stringify({ room_key: ROOM })
  });
  check('整局验收前机器人已启动（后端权威）', startBot.status === 200 && !!(startBot.body && startBot.body.data && startBot.body.data.running),
    { status: startBot.status, running: startBot.body && startBot.body.data && startBot.body.data.running });

  // 玩家积分是真实的游戏积分（非现金、不可提现/转账），不足时由管理员按正式接口发放，
  // 不走任何 SQL 直改，保证测试路径与生产路径完全一致。
  const [before] = await db.promise().query('SELECT game_points FROM users WHERE id = ?', [playerId]);
  let pointsBefore = Number(before[0] ? before[0].game_points : 0);
  if (pointsBefore < 2000) {
    const grant = await req(base, '/api/admin/niu/grant-points', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aToken },
      body: JSON.stringify({ user_id: playerId, amount: 2000, reason: '自动化对局验收（游戏积分）' })
    });
    check('管理员发放游戏积分（走正式接口）', grant.status === 200 && !!(grant.body && grant.body.success),
      { status: grant.status, code: grant.body && grant.body.code });
    const [after] = await db.promise().query('SELECT game_points FROM users WHERE id = ?', [playerId]);
    pointsBefore = Number(after[0] ? after[0].game_points : 0);
  }
  if (pointsBefore < 2000) {
    check('开局前积分充足', false, { game_points: pointsBefore, hint: '需要至少 2000 游戏积分才能跑完整对局' });
    return;
  }

  const joinRes = await req(base, '/api/game/niu/join', { method: 'POST', headers: H, body: JSON.stringify({ room: ROOM }) });
  check('入座成功', joinRes.status === 200 && joinRes.body.success === true,
    { status: joinRes.status, code: joinRes.body && joinRes.body.code });

  // 26牛牛最少 2 人：第二个座位由管理员账号入座（本局测试数据会按 round_no 精确清理）
  const H2 = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aToken };
  const joinRes2 = await req(base, '/api/game/niu/join', { method: 'POST', headers: H2, body: JSON.stringify({ room: ROOM }) });
  check('第二人入座成功（满足 2 人开局）', joinRes2.status === 200 && joinRes2.body.success === true,
    { status: joinRes2.status, code: joinRes2.body && joinRes2.body.code });

  // 服务端快照字段：round_no 在顶层，自己的手牌在 my.cards（只有本人视角）
  let sawGrabPhase = false;
  let sawBetPhase = false;
  let sawDealtHand = false;
  let sawSettlePhase = false;
  let myCards = null;
  let roundNo = null;
  let settled = false;
  let leakChecked = false;
  const seenPhases = [];
  const deadline = Date.now() + 60000;
  while (Date.now() < deadline && !settled) {
    await new Promise(r => setTimeout(r, 400));
    const st = await req(base, '/api/game/niu/state?room=' + ROOM, { headers: H });
    const d = (st.body && st.body.data) || {};
    if (d.phase && seenPhases.indexOf(d.phase) < 0) seenPhases.push(d.phase);
    if (d.phase === 'GRABBING' && !sawGrabPhase) {
      sawGrabPhase = true;
      check('抢庄阶段出现在实时状态中', true);
      await req(base, '/api/game/niu/grab', { method: 'POST', headers: H, body: JSON.stringify({ room: ROOM, grab: 1 }) });
    } else if (d.phase === 'BETTING' && !sawBetPhase) {
      sawBetPhase = true;
      check('选择倍数阶段出现在实时状态中', true);
      await req(base, '/api/game/niu/bet', { method: 'POST', headers: H, body: JSON.stringify({ room: ROOM, bet_level: 3 }) });
    }
    if (d.my && d.my.cards && !sawDealtHand) {
      sawDealtHand = true;
      myCards = d.my.cards;
      check('发牌后只有本人能看到自己的 5 张牌', Array.isArray(myCards) && myCards.length === 5,
        { count: Array.isArray(myCards) ? myCards.length : 0 });
    }
    // ---------- 手牌保密：只在「尚未亮牌」阶段断言 ----------
    // RESULT 之后服务端按游戏规则公开全桌牌面，那时看不到牌属于测试误报。
    if (d.phase === 'DEALING' && myCards && !leakChecked) {
      leakChecked = true;
      const other = await req(base, '/api/game/niu/state?room=' + ROOM, { headers: H2 });
      const os = (other.body && other.body.data) || {};
      const withCards = (os.players || []).filter(p => Array.isArray(p.cards) && p.cards.length);
      check('未亮牌阶段：他人视角没有任何座位被下发手牌',
        other.status === 200 && withCards.length === 0, { count: withCards.length });
      check('未亮牌阶段：他人视角响应里不含我的牌面',
        JSON.stringify(withCards).indexOf(JSON.stringify(myCards)) < 0);
    }
    if (d.phase === 'SETTLEMENT' || d.phase === 'FINISHED') sawSettlePhase = true;
    if (d.round_no) {
      roundNo = d.round_no;
      // 结算以数据库为准（REST 快照不下发结算结果，结算走聊天群 game 消息 + game_results）
      const [rr] = await db.promise().query(
        'SELECT COUNT(*) c FROM game_results gr JOIN game_rounds r ON r.round_id = gr.round_id WHERE r.round_id = ?',
        [roundNo]);
      if (Number(rr[0].c) > 0) settled = true;
    }
  }
  check('状态机在聊天群里跑完整一局（含结算）', Boolean(roundNo) && sawDealtHand && sawSettlePhase && settled,
    { round_no: roundNo, phases: seenPhases, dealt: sawDealtHand, settle_phase: sawSettlePhase, settled: settled });
  check('一局覆盖完整阶段链路', ['GRABBING', 'BETTING', 'DEALING', 'RESULT'].every(p => seenPhases.indexOf(p) >= 0),
    { phases: seenPhases });

  if (!roundNo) {
    // 人数不足未开局：只验证消息写入路径没崩，然后两人离座
    await req(base, '/api/game/niu/leave', { method: 'POST', headers: H, body: JSON.stringify({ room: ROOM }) });
    await req(base, '/api/game/niu/leave', { method: 'POST', headers: H2, body: JSON.stringify({ room: ROOM }) });
    return;
  }

  // ---------- 核心断言：游戏消息真的在聊天群里 ----------
  // 结算事务先提交 game_results，之后才 await 写群消息；
  // 这里必须等消息真正落库再断言，否则会读到「已结算但消息还在路上」的中间态。
  let msgs = [];
  const msgDeadline = Date.now() + 8000;
  while (Date.now() < msgDeadline) {
    const [rows0] = await db.promise().query(
      `SELECT message_type, content, room_id, round_id, phase, sender_role, user_id, meta
         FROM chat_messages
        WHERE channel = 'group' AND message_type = 'game' AND round_id = ?
        ORDER BY id ASC`, [roundNo]);
    msgs = rows0;
    if (msgs.length) break;
    await new Promise(r => setTimeout(r, 300));
  }
  check('游戏系统消息写入了聊天群（channel=group, message_type=game）', msgs.length > 0,
    { count: msgs.length, round_no: roundNo });
  check('每条游戏消息都带 room_id + phase', msgs.every(m => Number(m.room_id) > 0 && !!m.phase),
    { sample: msgs.slice(0, 3).map(m => ({ room_id: m.room_id, phase: m.phase })) });
  check('游戏消息以系统身份发送（sender_role=system，user_id 为空）',
    msgs.every(m => m.sender_role === 'system' && m.user_id === null));
  check('游戏消息 meta 标明来源为游戏系统（与普通 system 消息可区分）',
    msgs.every(m => m.meta && m.meta.source && String(m.meta.source).indexOf('game') >= 0),
    { sample: msgs[0] && msgs[0].meta });

  const phases = Array.from(new Set(msgs.map(m => m.phase).filter(Boolean)));
  check('群内消息覆盖多个游戏阶段', phases.length >= 2, { phases: phases });
  const joined = msgs.map(m => m.content).join(' | ');
  check('群里有 26牛牛 开局 / 阶段话术', joined.indexOf('26牛牛') >= 0, { sample: joined.slice(0, 160) });
  // 话术是把配置对象拼出来的，最容易退化成 [object Object]，必须挡住
  check('群内话术没有把配置对象拼成 [object Object]',
    joined.indexOf('[object Object]') === -1 && joined.indexOf('[object') === -1,
    { offender: (joined.match(/.{0,24}\[object.{0,24}/) || [''])[0] });

  // ---------- 对局落在现有表（未新建第二套游戏库）----------
  // 注意：room_players.round_id / game_results.round_id 存的是「对局编号字符串」，
  //      不是 game_rounds.id（自增主键），关联时必须用 round_id = 对局编号
  const [rows] = await db.promise().query(
    'SELECT id, round_id, room_id, status FROM game_rounds WHERE round_id = ? LIMIT 1', [roundNo]);
  check('对局记录在现有 game_rounds', rows.length === 1 && Number(rows[0].room_id) > 0, { row: rows[0] });
  const rid = rows.length ? Number(rows[0].id) : 0;
  if (rid) {
    const [rp] = await db.promise().query('SELECT user_id, role, bet_level FROM room_players WHERE round_id = ?', [roundNo]);
    check('对局参与人在现有 room_players', rp.length >= 2, { count: rp.length });
    const [gr] = await db.promise().query('SELECT COUNT(*) c FROM game_results WHERE round_id = ?', [roundNo]);
    check('结算明细在现有 game_results', Number(gr[0].c) >= 2, { count: Number(gr[0].c) });
    check('对局终态为 FINISHED（状态机推到结算完成）', String(rows[0].status) === 'FINISHED',
      { status: rows[0].status });
    const st2 = await req(base, '/api/game/niu/stats', { headers: H });
    const ad = (st2.body && st2.body.data) || {};
    check('战绩来自真实数据库（不是前端假数据）', typeof ad.game_points === 'number', { game_points: ad.game_points });
  }

  // ---------- 清理：只删本测试这一局，绝不动真实数据 ----------
  await db.promise().query('DELETE FROM game_results WHERE round_id = ?', [roundNo]).catch(() => {});
  await db.promise().query('DELETE FROM room_players WHERE round_id = ?', [roundNo]).catch(() => {});
  await db.promise().query(
    "DELETE FROM chat_messages WHERE channel = 'group' AND message_type = 'game' AND round_id = ?", [roundNo]).catch(() => {});
  if (rid) await db.promise().query("UPDATE game_rounds SET status = 'ABORTED' WHERE id = ?", [rid]).catch(() => {});
  await req(base, '/api/game/niu/leave', { method: 'POST', headers: H, body: JSON.stringify({ room: ROOM }) });
  await req(base, '/api/game/niu/leave', { method: 'POST', headers: H2, body: JSON.stringify({ room: ROOM }) });

  // 恢复机器人运行状态（测试前是停止的，就还原成停止；绝不改变生产配置）
  if (!botBefore) {
    await req(base, '/api/admin/niu/bot/stop', { method: 'POST', headers: AH, body: JSON.stringify({ reason: '验收测试收尾恢复原状态' }) });
  }
  const botRestored = await req(base, '/api/admin/niu/bot/status', { headers: AH });
  check('测试后机器人状态已恢复原样（不改生产配置）',
    !!botRestored.body && !!botRestored.body.data && Number(botRestored.body.data.running) === botBefore,
    { restored_running: botRestored.body && botRestored.body.data && botRestored.body.data.running, was: botBefore });
  console.log('  · 测试对局已清理: round_no=' + roundNo);
}

// 看门狗：要连跑两轮真实对局（普通席位轮 + 机器人整局轮）+ 数据库架构断言，留足余量
const watchdog = setTimeout(() => { report.error = 'test exceeded 240s'; finish(); }, 240000);
let finished = false;

/** 机器人验收段的起始时间戳：收尾只删这段时间内新建的对局，绝不碰真实玩家的历史 */
let botChecksStartedAt = null;
/**
 * 26牛牛游戏机器人验收（第五十三~五十五条）
 * 覆盖：普通用户 403 / 管理员启动 / 连点幂等 / 自动消息进群 / 停止保数据 / 再次恢复
 * 测试只驱动机器人状态与本测试产生的对局，收尾全部清理，不触碰真实数据。
 */
async function runBotChecks(base, pToken, aToken, adminId) {
  const AH = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aToken };
  const UH = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + pToken };
  const A = '/api/admin/niu/bot';

  // ---------- 第五十三条：普通用户一律 403 ----------
  const uStatus = await req(base, A + '/status', { headers: UH });
  check('普通用户读不到机器人状态（403）', uStatus.status === 403, { status: uStatus.status });
  const uStart = await req(base, A + '/start', { method: 'POST', headers: UH, body: '{}' });
  check('普通用户不能启动机器人（403）', uStart.status === 403, { status: uStart.status });
  const uStop = await req(base, A + '/stop', { method: 'POST', headers: UH, body: '{}' });
  check('普通用户不能停止机器人（403）', uStop.status === 403, { status: uStop.status });
  const uSay = await req(base, A + '/say', { method: 'POST', headers: UH, body: JSON.stringify({ content: '伪造系统消息' }) });
  check('普通用户不能发送 system/game 消息（403）', uSay.status === 403, { status: uSay.status });
  const uTpl = await req(base, A + '/templates', { method: 'POST', headers: UH, body: JSON.stringify({ templates: { grab_start: 'x' } }) });
  check('普通用户不能修改机器人话术模板（403）', uTpl.status === 403, { status: uTpl.status });
  const anon = await req(base, A + '/status');
  check('匿名访问机器人接口返回 401', anon.status === 401, { status: anon.status });

  // ---------- 恢复现场：先停止，记基线 ----------
  await req(base, A + '/stop', { method: 'POST', headers: AH, body: '{}' });
  // 记录本段验收的起点：收尾只删这段期间新建的对局，绝不碰真实玩家的历史
  // 模块级：清理逻辑在 botRoundAndStopChecks 里执行，需要共享这个基准时间
  botChecksStartedAt = new Date(Date.now() - 3000);
  const chatBefore = Number((await db.promise().query(
    "SELECT COUNT(*) c FROM chat_messages WHERE channel='group' AND message_type='game'"))[0][0].c);

  // ---------- 第五十四条：重复启动幂等 ----------
  const s1 = await req(base, A + '/start', { method: 'POST', headers: AH, body: JSON.stringify({ room_key: 'junior' }) });
  check('管理员启动机器人成功', s1.status === 200 && s1.body.success === true &&
    s1.body.data && s1.body.data.running === true, { status: s1.status, data: s1.body && s1.body.data });
  const s2 = await req(base, A + '/start', { method: 'POST', headers: AH, body: JSON.stringify({ room_key: 'junior' }) });
  check('连续重复启动只保留一个运行实例（幂等）',
    s2.status === 200 && s2.body.data.running === true &&
    (!s2.body.data.current_round_id || s2.body.data.current_round_id === s1.body.data.current_round_id),
    { first: s1.body.data.current_round_id, second: s2.body.data.current_round_id });

  const [stRows] = await db.promise().query(
    "SELECT COUNT(*) c FROM game_rounds WHERE packet_type='PLATFORM' AND room_key='junior' AND status NOT IN ('FINISHED','ABORTED')");
  check('同一房间同一时间只有一个活动 round（防重复建局）', Number(stRows[0].c) <= 1, { active: Number(stRows[0].c) });

  const [notices] = await db.promise().query(
    `SELECT COUNT(*) c FROM chat_messages
      WHERE channel='group' AND message_type='game'
        AND JSON_UNQUOTE(JSON_EXTRACT(meta,'$.kind')) = 'bot_notice'
        AND created_at > (NOW() - INTERVAL 3 MINUTE)`);
  check('重复启动不会重复播报启动提示（事件幂等）', Number(notices[0].c) <= 1, { notices: Number(notices[0].c) });

  await botRoundAndStopChecks(base, UH, AH, A, adminId, chatBefore, botChecksStartedAt);
}

/** 机器人跑完一整局 → 群内消息断言（第五十一条 / 第十九条 / 第二十二条 / 第四十四条） */
async function botRoundAndStopChecks(base, UH, AH, A, adminId, chatBefore, botChecksStartedAt) {
  // ---------- 第五十一条：完整一局在聊天里跑完（两个账号自动入座参与）----------
  const phases = new Set();
  let settled = false;
  let roundNo = null;
  const deadline = Date.now() + 90000;
  while (Date.now() < deadline && !settled) {
    await new Promise(r => setTimeout(r, 500));
    await req(base, '/api/game/niu/join', { method: 'POST', headers: UH, body: JSON.stringify({ room: 'junior' }) });
    await req(base, '/api/game/niu/join', { method: 'POST', headers: AH, body: JSON.stringify({ room: 'junior' }) });
    const st = await req(base, '/api/game/niu/state?room=junior', { headers: UH });
    const d = (st.body && st.body.data) || {};
    if (d.phase) phases.add(d.phase);
    if (d.round_no) roundNo = d.round_no;
    if (d.phase === 'GRABBING') {
      await req(base, '/api/game/niu/grab', { method: 'POST', headers: UH, body: JSON.stringify({ room: 'junior', grab: 1 }) });
      await req(base, '/api/game/niu/grab', { method: 'POST', headers: AH, body: JSON.stringify({ room: 'junior', grab: 0 }) });
    } else if (d.phase === 'BETTING') {
      await req(base, '/api/game/niu/bet', { method: 'POST', headers: UH, body: JSON.stringify({ room: 'junior', bet_level: 2 }) });
      await req(base, '/api/game/niu/bet', { method: 'POST', headers: AH, body: JSON.stringify({ room: 'junior', bet_level: 2 }) });
    }
    // 结算以数据库为准（REST 快照不下发结算结果；结算走聊天群 game 消息 + game_results）
    if (roundNo) {
      const [rr] = await db.promise().query(
        'SELECT COUNT(*) c FROM game_results WHERE round_id = ?', [roundNo]);
      if (Number(rr[0].c) > 0) settled = true;
    }
  }
  check('机器人自动跑完一整局（无需管理员盯页面）', settled, { round_no: roundNo, phases: Array.from(phases) });
  check('状态机覆盖抢庄 → 下注 → 结算',
    ['GRABBING', 'BETTING', 'SETTLEMENT'].every(p => phases.has(p)), { phases: Array.from(phases) });

  // 只断言本测试这一局的机器人消息，绝不混入真实玩家的对局
  const [gmsgs] = roundNo
    ? await db.promise().query(
      `SELECT id, content, phase, round_id, room_id, sender_role, user_id, meta
         FROM chat_messages
        WHERE channel='group' AND message_type='game' AND round_id = ?
        ORDER BY id ASC`, [roundNo])
    : [[]];
  check('机器人游戏消息全部进入「26牛牛游戏群」', gmsgs.length > 0, { count: gmsgs.length, round_no: roundNo });
  check('机器人消息是系统身份（user_id 为空、非管理员冒充）',
    gmsgs.every(m => m.user_id === null && m.sender_role === 'system'),
    { bad: gmsgs.filter(m => m.user_id !== null).slice(0, 2).map(m => ({ id: m.id, user_id: m.user_id })) });
  check('机器人消息标明「26牛牛游戏机器人」身份',
    gmsgs.some(m => m.meta && m.meta.bot_name === '26牛牛游戏机器人'), { sample: gmsgs[0] && gmsgs[0].meta });
  check('机器人消息带 room_id + round_id（可与 game_rounds 关联）',
    gmsgs.some(m => Number(m.room_id) > 0 && !!m.round_id),
    { sample: gmsgs.slice(0, 2).map(m => ({ room_id: m.room_id, round_id: m.round_id })) });
  check('群内游戏消息覆盖多个阶段',
    new Set(gmsgs.map(m => m.phase).filter(Boolean)).size >= 3,
    { phases: Array.from(new Set(gmsgs.map(m => m.phase))) });

  await botSayTemplateStopChecks(base, UH, AH, A, adminId, chatBefore);
}

/** 管理员发消息 / 模板 / 停止保数据 / 再启动 / 自动消息开关 / 审计 / 清理 */
async function botSayTemplateStopChecks(base, UH, AH, A, adminId, chatBefore) {
  // ---------- 第二十四条：管理员发送系统消息到游戏群 ----------
  const sayTxt = '【验收】管理员发送系统消息';
  const say = await req(base, A + '/say', { method: 'POST', headers: AH, body: JSON.stringify({ content: sayTxt, message_type: 'system' }) });
  check('管理员发送系统消息成功', say.status === 200 && say.body.success === true, { status: say.status });
  const [said] = await db.promise().query(
    "SELECT id, message_type, user_id, sender_role, channel FROM chat_messages WHERE content = ? ORDER BY id DESC LIMIT 1",
    [sayTxt]);
  check('系统消息进入游戏群且以机器人系统身份发送',
    said.length === 1 && said[0].channel === 'group' && said[0].user_id === null && said[0].sender_role === 'system',
    { row: said[0] });
  const empty = await req(base, A + '/say', { method: 'POST', headers: AH, body: JSON.stringify({ content: '   ' }) });
  check('空内容被拒绝', empty.status === 422, { status: empty.status });

  // ---------- 第二十五条：话术模板 ----------
  const tpl0 = await req(base, A + '/templates', { headers: AH });
  const tpls0 = ((tpl0.body && tpl0.body.data && tpl0.body.data.templates) || []);
  check('话术模板接口返回全部阶段模板',
    tpls0.length >= 6 && tpls0.some(t => t.key === 'grab_start') && tpls0.some(t => t.key === 'round_end'),
    { keys: tpls0.map(t => t.key) });
  const custom = '【验收】抢庄开始（模板已生效）';
  const tplSave = await req(base, A + '/templates', {
    method: 'POST', headers: AH, body: JSON.stringify({ templates: { grab_start: custom } })
  });
  check('管理员修改话术模板成功', tplSave.status === 200 && tplSave.body.success === true, { status: tplSave.status });
  const tplRead = await req(base, A + '/templates', { headers: AH });
  const got = ((tplRead.body && tplRead.body.data && tplRead.body.data.templates) || []).find(t => t.key === 'grab_start');
  check('新话术立即生效并可读回', got && got.value === custom, { value: got && got.value });

  // ---------- 第五十二条：停止机器人（数据全保留）----------
  const before2 = Number((await db.promise().query(
    "SELECT COUNT(*) c FROM chat_messages WHERE channel='group' AND message_type='game'"))[0][0].c);
  const stopRes = await req(base, A + '/stop', { method: 'POST', headers: AH, body: '{}' });
  check('管理员停止机器人成功', stopRes.status === 200 && stopRes.body.data.running === false, { status: stopRes.status });
  const [stAfter] = await db.promise().query('SELECT running, stopped_at FROM niu_bot_state WHERE id = 1');
  check('停止状态写库（后端权威，与管理员浏览器无关）',
    Number(stAfter[0].running) === 0 && !!stAfter[0].stopped_at, { row: stAfter[0] });
  const after2 = Number((await db.promise().query(
    "SELECT COUNT(*) c FROM chat_messages WHERE channel='group' AND message_type='game'"))[0][0].c);
  check('停止机器人不删除任何聊天记录', after2 >= before2, { before: before2, after: after2 });
  const [histKeep] = await db.promise().query(
    "SELECT COUNT(*) c FROM game_rounds WHERE packet_type='PLATFORM' AND status IN ('FINISHED','ABORTED')");
  check('停止机器人不删除历史对局', Number(histKeep[0].c) >= 1, { finished: Number(histKeep[0].c) });
  const stStill = await req(base, '/api/game/niu/state?room=junior', { headers: UH });
  check('停止后聊天群仍可打开、当前状态仍可读', stStill.status === 200, { status: stStill.status });
  await new Promise(r => setTimeout(r, 3000));
  const [rowsStop] = await db.promise().query(
    "SELECT COUNT(*) c FROM game_rounds WHERE packet_type='PLATFORM' AND status NOT IN ('FINISHED','ABORTED')");
  check('停止后不再自动推进新对局', Number(rowsStop[0].c) <= 1, { active: Number(rowsStop[0].c) });

  // ---------- 第五十二条：再次启动可恢复 ----------
  const reStart = await req(base, A + '/start', { method: 'POST', headers: AH, body: JSON.stringify({ room_key: 'junior' }) });
  check('再次启动机器人成功（可恢复运行）', reStart.status === 200 && reStart.body.data.running === true, { status: reStart.status });

  // ---------- 第二十六条：自动消息开关 ----------
  const off = await req(base, A + '/auto-messages', { method: 'POST', headers: AH, body: JSON.stringify({ enabled: false }) });
  check('可关闭自动游戏消息', off.status === 200 && off.body.data.auto_messages === false, { status: off.status });
  const on = await req(base, A + '/auto-messages', { method: 'POST', headers: AH, body: JSON.stringify({ enabled: true }) });
  check('可开启自动游戏消息', on.status === 200 && on.body.data.auto_messages === true, { status: on.status });

  await botAuditAndCleanup(base, UH, AH, A, adminId, chatBefore, tpls0);
}

/** 审计断言 + 现场清理（模板还原 / 停机器人 / 离座 / 删本测试对局与消息） */
async function botAuditAndCleanup(base, UH, AH, A, adminId, chatBefore, tpls0) {
  // ---------- 第三十八条：审计 ----------
  const [logs] = await db.promise().query(
    `SELECT action, admin_id FROM admin_logs
      WHERE action LIKE 'NIU_BOT%' AND created_at > (NOW() - INTERVAL 30 MINUTE) ORDER BY id ASC`);
  const actions = new Set(logs.map(l => l.action));
  check('机器人关键操作全部写入管理员审计',
    ['NIU_BOT_START', 'NIU_BOT_STOP', 'NIU_BOT_ADMIN_SAY', 'NIU_BOT_TEMPLATE_UPDATE', 'NIU_BOT_AUTO_MSG_ON']
      .every(a => actions.has(a)), { actions: Array.from(actions) });
  check('审计记录了操作管理员', logs.every(l => Number(l.admin_id) === Number(adminId)), { adminId });

  // ---------- 清理：还原模板 + 停机器人 + 两人离座 ----------
  const def = (tpls0.find(t => t.key === 'grab_start') || {}).default_value;
  if (def) {
    await req(base, A + '/templates', {
      method: 'POST', headers: AH, body: JSON.stringify({ templates: { grab_start: def } })
    });
  }
  await req(base, A + '/stop', { method: 'POST', headers: AH, body: '{}' });
  await req(base, '/api/game/niu/leave', { method: 'POST', headers: UH, body: JSON.stringify({ room: 'junior' }) });
  await req(base, '/api/game/niu/leave', { method: 'POST', headers: AH, body: JSON.stringify({ room: 'junior' }) });

  // 删除本测试产生的对局 / 消息 / 事件。
  // 只按「本测试期间新建的 round_id」精确删除 —— 绝不使用时间窗宽删，
  // 否则会把真实玩家的对局消息一起删掉。
  // 基准时间取「基线消息数对应的最早一条」的 created_at，避免误删测试前就存在的对局；
  // 更稳妥的做法是这里直接用 runBotChecks 进入时的墙钟时间。
  const [ownRounds] = await db.promise().query(
    `SELECT round_id FROM game_rounds
      WHERE packet_type = 'PLATFORM' AND started_at >= ?`,
    [botChecksStartedAt]);
  const rids = ownRounds.map(m => m.round_id);
  if (rids.length) {
    await db.promise().query('DELETE FROM game_results WHERE round_id IN (?)', [rids]);
    await db.promise().query('DELETE FROM room_players WHERE round_id IN (?)', [rids]);
    await db.promise().query("UPDATE game_rounds SET status='ABORTED' WHERE round_id IN (?) AND packet_type='PLATFORM'", [rids]);
    await db.promise().query('DELETE FROM niu_bot_events WHERE round_id IN (?)', [rids]);
    await db.promise().query(
      "DELETE FROM chat_messages WHERE channel='group' AND message_type='game' AND round_id IN (?)", [rids]);
  }
  const chatNow = Number((await db.promise().query(
    "SELECT COUNT(*) c FROM chat_messages WHERE channel='group' AND message_type='game'"))[0][0].c);
  console.log('  · 机器人验收清理完成：group/game 消息 ' + chatBefore + ' → ' + chatNow + '，机器人已停止');
}

async function finish() {
  if (finished) return;
  finished = true;
  clearTimeout(watchdog);
  if (child) child.kill();
  await db.promise().end().catch(() => {});
  report.failed = report.checks.filter(c => !c.pass).map(c => c.name);
  report.passed = Boolean(report.completed) && !report.error && report.failed.length === 0;
  report.finished = new Date().toISOString();
  fs.writeFileSync(output, JSON.stringify(report, null, 2));
  console.log(report.passed ? ('NIU_LIVE PASS (' + report.checks.length + '/' + report.checks.length + ')')
    : ('NIU_LIVE FAIL (' + report.failed.length + '/' + report.checks.length + ')'));
  process.exitCode = report.passed ? 0 : 1;
}
main().catch(e => { report.error = e.message; console.log('ERROR ' + e.message); }).finally(finish);


