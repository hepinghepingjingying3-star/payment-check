'use strict';
// Read-only verification of the explicitly updated account; no messages sent.
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
let server;
const report = { passed: false };
(async () => {
  const [rows] = await db.promise().query('SELECT id, username, invite_code, role, status FROM users ORDER BY id');
  // 邀请码规则（见 utils/inviteCode.js）：新账号为 8 位随机数字；历史账号保留 UID 形式。
  // 自动化测试临时账号（zzmob_ / zzperm_ / zzfunds_ / zzniu_ 前缀）不参与格式校验，
  // 它们由 tests/cleanup-temp-accounts.js 独立回收，不应让真实账号规则被牵连失败。
  const realRows = rows.filter(r => !/^zz(mob|perm|funds|niu|otp|chat)_/i.test(String(r.username || '')));
  assert.ok(realRows.length && realRows.every(r => /^[0-9]{8}$/.test(String(r.invite_code)) || r.invite_code === String(r.id)));
  const target = realRows.find(r => r.role === 'admin' && r.status === 'active');
  assert.ok(target, '需要至少一个可用管理员账号');
  const app = express(); app.use('/api', require('../routes/chat'));
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const token = jwt.sign({ id: target.id, role: target.role }, process.env.JWT_SECRET, { expiresIn: '30s' });
  const res = await fetch('http://127.0.0.1:' + server.address().port + '/api/chat/stickers', {
    headers: { Authorization: 'Bearer ' + token }, signal: AbortSignal.timeout(5000)
  });
  const body = await res.json();
  assert.equal(res.status, 200);
  assert.ok(body.data.can_use_official && body.data.official.length > 0);
  Object.assign(report, { passed: true, users_checked: rows.length, target_uid: Number(target.id), invite_code: target.invite_code, role: target.role, can_use_official: true, sticker_count: body.data.official.length });
})().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  await db.promise().end();
  report.checkedAt = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'uid-admin-verify-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
  process.exitCode = report.passed ? 0 : 1;
});
