'use strict';
// Real HTTP + real admin router, isolated database. No user data is written.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const root = path.resolve(__dirname, '..');
const secret = require('node:crypto').randomBytes(32).toString('hex');
const report = { mode: 'HTTP with real admin router, isolated database', checks: [], passed: false };
let queries = [], server, dbRole = 'user';
const HASH = 'secret-strength-hash-marker';
const OTP = '654321';
const db = {
  promise: () => ({
    query: async (sql, params) => {
      queries.push({ sql, params });
      // Current-account lookup used by the auth middleware (role is switched per test case).
      if (sql.includes('FROM users WHERE id = ? LIMIT 1')) {
        return [[{ id: 3, username: 'owner', role: dbRole, status: 'active' }]];
      }
      if (sql.includes('COUNT(*) AS total') && sql.includes('SUM(status')) return [[{ total: 7, active: 6, banned: 1, today: 2 }]];
      if (sql.includes('COUNT(DISTINCT user_id)')) return [[{ c: 1 }]];
      if (sql.includes('SELECT COUNT(*) AS c FROM users u')) return [[{ c: 7 }]];
      if (/COUNT\(\*\) AS c FROM/.test(sql)) return [[{ c: 3 }]];
      if (sql.includes('FROM users u')) {
        return [[{
          id: 3, username: 'owner', nickname: '站长', avatar_url: null, role: 'admin', status: 'active',
          created_at: '2026-09-01 08:00:00', invite_code: '3', invited_by: null, invited_by_username: null,
          phone: '+60123456789', email: 'owner@example.test', real_name: '测试站长',
          last_login_at: '2026-09-17 10:00:00',
          direct_count: 2, second_count: 4, password_hash: HASH
        }]];
      }
      throw Error('Unexpected test SQL');
    }
  })
};
function check(name, pass) { assert.ok(pass, name); report.checks.push({ name, pass: true }); }
async function main() {
  const authMod = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'middleware/auth.js'), 'utf8'), {
    module: authMod, process: { env: { JWT_SECRET: secret } },
    require: name => { if (name === 'jsonwebtoken') return jwt; if (name === '../config/db') return db; throw Error(name); }
  });
  const adminMod = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'routes/admin.js'), 'utf8'), {
    module: adminMod, console: { error() {} },
    require: name => {
      if (name === 'express') return express;
      if (name === '../config/db') return db;
      if (name === '../middleware/auth') return authMod.exports;
      if (name === '../utils/content') return { loadAnnouncements: async () => [{}, {}] };
      if (name === '../utils/request') return require('../utils/request');
      // V6：新增依赖全部用桩函数注入，保持本测试「隔离、绝不连真实数据库」的原则
      if (name === '../utils/adminAudit') return { writeAdminLog: async () => true, listAdminLogs: async () => [] };
      if (name === '../config/moderation') return require('../config/moderation');
      if (name === '../utils/moderation') {
        return {
          mutedSummary: async () => ({ muted_now: null, expiring_24h: null, expiring_1h: null }),
          expiringMutes: async () => [], scopeRules: () => [],
          muteState: async () => ({ muted: false, until: null, reason: null, minutes_left: 0 }),
          muteMessage: () => '', scopeBlocked: async () => null, muteSummary: async () => ({ muted: false }),
          MUTE_MIN_MINUTES: 5, MUTE_MAX_MINUTES: 43200, EXPIRE_REMIND_MINUTES: 1440
        };
      }
      if (name === '../utils/approvals') {
        return {
          gate: async () => ({ dual: false, degraded: false, note: null, other_admins: 0 }),
          preflight: async () => ({ ok: true }),
          createRequest: async () => ({ ok: false, status: 500, message: '测试桩：不创建复核请求' }),
          pendingCount: async () => null, listRequests: async () => ({ list: [], summary: {} }),
          decide: async () => ({ ok: false, status: 500, message: '测试桩' }),
          available: () => false, actions: () => [], actionLabels: () => [], label: a => a,
          otherActiveAdminCount: async () => 0, otherActiveAdminCountExcept: async () => 0
        };
      }
      if (name === '../utils/userAdminOps') {
        return {
          applyUserStatus: async () => ({ ok: false, status: 500, message: '测试桩' }),
          applyUserRole: async () => ({ ok: false, status: 500, message: '测试桩' }),
          applyUnmute: async () => ({ ok: false, status: 500, message: '测试桩' }),
          applyMute: async () => ({ ok: false, status: 500, message: '测试桩' })
        };
      }
      if (name === '../utils/presence') {
        return {
          init() {}, touch: async () => true, onlineCount: async () => null, onlineList: async () => null,
          isOnline: async () => null, socketCount: () => 0, socketUserCount: () => 0,
          kickUser: () => 0, available: () => false, WINDOW: 90
        };
      }
      throw Error('Unexpected dependency: ' + name);
    }
  });
  const app = express();
  // Mount only the admin router: its own guard must work without any outer middleware.
  app.use('/api', adminMod.exports);
  server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = 'http://127.0.0.1:' + server.address().port;
  function token(r, purpose) {
    return jwt.sign(Object.assign({ id: 3, role: r }, purpose ? { purpose } : {}), secret, { expiresIn: 60 });
  }
  async function call(url, r, purpose) {
    dbRole = r || 'user';
    const res = await fetch(base + url, {
      headers: r ? { Authorization: 'Bearer ' + token(r, purpose) } : {}, signal: AbortSignal.timeout(5000)
    });
    return { status: res.status, body: await res.json(), cache: res.headers.get('cache-control') };
  }
  for (const url of ['/api/admin/dashboard', '/api/admin/users']) {
    check('Anonymous denied ' + url, (await call(url)).status === 401);
    for (const r of ['user', 'support']) check(r + ' denied ' + url, (await call(url, r)).status === 403);
    check('Non-login token denied ' + url, (await call(url, 'admin', 'reset_password')).status === 401);
  }
  const dash = await call('/api/admin/dashboard', 'admin');
  check('Dashboard allowed for admin', dash.status === 200 && dash.body.data.users.total === 7);
  check('Dashboard is not cacheable', dash.cache === 'no-store');
  const d = dash.body.data;
  check('Dashboard reports referral levels and today registrations',
    d.referrals.direct === 3 && d.referrals.second === 3 && d.referrals.total === 6 && d.users.today === 2);
  check('Dashboard marks unsupported stats instead of faking them',
    Array.isArray(d.unsupported) && d.unsupported.length >= 1 && d.unsupported.every(x => x.note && x.label) &&
    !d.unsupported.some(x => x.key === 'online_users'));
  // V6：在线人数 / 禁言提醒 / 双人复核改为真实可用字段（不可用时必须是 null，不能编造数字）
  check('Dashboard reports real online / moderation / approvals fields',
    d.online && Object.prototype.hasOwnProperty.call(d.online, 'count') &&
    d.moderation && typeof d.moderation.expiring_remind_minutes === 'number' &&
    d.approvals && typeof d.approvals.enabled === 'boolean');
  check('Dashboard never leaks hash or OTP',
    !JSON.stringify(dash.body).includes(HASH) && !JSON.stringify(dash.body).includes(OTP));
  const list = await call('/api/admin/users?limit=20&offset=0', 'admin');
  const item = list.body.data.list[0];
  check('User lookup allowed for admin', list.status === 200 && list.body.data.total === 7 && item.id === 3);
  check('Response omits password hash', !JSON.stringify(list.body).includes(HASH) && item.password_hash === undefined);
  check('Phone masked in list', item.phone_masked.includes('****'));
  await call('/api/admin/users?q=%25', 'admin');
  const wildcard = queries.filter(q => q.sql.includes('FROM users u') && Array.isArray(q.params)
    && q.params.some(p => String(p).includes('%%')));
  check('LIKE wildcards stripped from search input', wildcard.length === 0);
  report.passed = true;
}
main().catch(e => { report.error = e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'admin-dashboard-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  process.exitCode = report.passed ? 0 : 1;
});