'use strict';
// Real HTTP/routes/JWT; isolated in-memory DB and upload storage, no user data writes.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createRequire } = require('node:module');
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const root = path.resolve(__dirname, '..');
const key = require('node:crypto').randomBytes(32).toString('hex');
const report = { mode: 'HTTP with isolated DB/storage', checks: [], passed: false };
const files = new Map();
const users = { 1: { id: 1, username: 'player', role: 'user', status: 'active' }, 2: { id: 2, username: 'admin', role: 'admin', status: 'active' }, 3: { id: 3, role: 'support', status: 'active' } };
let message, server, failWrites = false;
const db = { promise: () => ({ query: async (sql, p) => {
  if (sql.startsWith('SELECT') && sql.includes('FROM users')) return [[users[p[0]]].filter(Boolean)];
  if (sql.includes('FROM user_stickers')) return [[]];
  if (sql.startsWith('UPDATE users')) {
    if (failWrites) throw Error('test failure');
    const field = sql.includes('nickname') ? 'nickname' : 'avatar_url';
    users[p[1]][field] = p[0]; return [{ affectedRows: 1 }];
  }
  if (sql.startsWith('INSERT INTO chat_messages')) {
    message = { id: 1, channel: p[0], user_id: p[1], message_type: p[2], content: p[3], meta: JSON.parse(p[4]), username: users[p[1]].username };
    return [{ insertId: 1 }];
  }
  if (sql.includes('FROM chat_messages m')) return [[message]];
  throw Error('Unexpected test SQL: ' + sql);
} }) };
function load(file, overrides = {}) {
  const full = path.join(root, file), mod = { exports: {} }, realRequire = createRequire(full);
  vm.runInNewContext(fs.readFileSync(full, 'utf8'), { module: mod, exports: mod.exports, __dirname: path.dirname(full), Buffer, console,
    process: { env: { JWT_SECRET: key } }, require: name => name in overrides ? overrides[name] : realRequire(name) }, { filename: full });
  return mod.exports;
}
const auth = load('middleware/auth.js', { '../config/db': db });
const common = { '../config/db': db, '../middleware/auth': auth };
const profile = load('routes/profile.js', { ...common, 'node:fs/promises': {
  mkdir: async () => {}, writeFile: async (p, b) => files.set(p, b), unlink: async p => files.delete(p)
} });
const chat = load('routes/chat.js', common);
const account = load('routes/auth.js', { ...common, '../utils/inviteCode': {}, '../utils/otp': {} });
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
async function main() {
  const app = express(); app.use(express.json()); app.use('/api', profile, chat, account);
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  async function api(url, id, method = 'GET', body) {
    const headers = id ? { Authorization: 'Bearer ' + jwt.sign({ id, role: 'admin' }, key) } : {};
    if (body && !(body instanceof FormData)) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(body); }
    const r = await fetch('http://127.0.0.1:' + server.address().port + '/api' + url, { method, headers, body, signal: AbortSignal.timeout(5000) });
    return { status: r.status, body: await r.json() };
  }
  const url = '/assets/stickers/official/official-1.jpg';
  for (const id of [1, 3]) {
    for (const type of ['sticker', 'image']) check('Non-admin ' + id + ' denied ' + type, (await api('/chat/messages', id, 'POST', { channel: 'group', message_type: type, meta: { url } })).status === 403);
    const list = await api('/chat/stickers', id);
    check('Non-admin list hides official ' + id, list.body.data.official.length === 0 && !list.body.data.can_use_official);
  }
  check('Admin sends official sticker', (await api('/chat/messages', 2, 'POST', { channel: 'group', message_type: 'sticker', meta: { url } })).status === 201);
  check('Admin list has six official stickers', (await api('/chat/stickers', 2)).body.data.official.length === 6);
  check('Nickname saved', (await api('/profile', 1, 'PATCH', { nickname: '新昵称', id: 2, role: 'admin' })).status === 200);
  let me = await api('/auth/me', 1);
  check('Reload reads nickname; login and role unchanged', me.body.data.nickname === '新昵称' && me.body.data.username === 'player' && me.body.data.role === 'user');
  check('Invalid nickname rejected', (await api('/profile', 1, 'PATCH', { nickname: '<script>' })).status === 400);
  const data = new FormData(); data.append('file', new Blob([fs.readFileSync(path.join(root, 'public/assets/avatars/official.jpg'))], { type: 'image/jpeg' }), 'avatar.jpg');
  const uploaded = await api('/profile/avatar', 1, 'POST', data);
  me = await api('/auth/me', 1);
  check('Avatar saved and reloaded', uploaded.status === 200 && me.body.data.avatar_url === uploaded.body.data.avatar_url && files.size === 1);
  const bad = new FormData(); bad.append('file', new Blob(['<script>bad</script>'], { type: 'image/jpeg' }), 'bad.jpg');
  check('Disguised file rejected', (await api('/profile/avatar', 1, 'POST', bad)).status === 400);
  failWrites = true;
  check('DB error is not fake success', (await api('/profile', 1, 'PATCH', { nickname: '保存失败' })).status === 500);
  check('Anonymous edit rejected', (await api('/profile', null, 'PATCH', { nickname: '匿名昵称' })).status === 401);
  report.passed = true;
}
main().catch(e => { report.error = e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'profile-stickers-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2)); process.exitCode = report.passed ? 0 : 1;
});
