// 清理孤儿凭证文件：删除 storage/vouchers 下数据库中已不存在的凭证（只删测试残留，不动任何有订单引用的文件）
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const fs = require('fs');
const path = require('path');
const db = require('../config/db');
const voucherStore = require('../utils/voucherStore');

(async () => {
  const [rows] = await db.promise().query("SELECT voucher_path FROM wallet_orders WHERE voucher_path IS NOT NULL AND voucher_path <> ''");
  const keep = new Set(rows.map(r => String(r.voucher_path)));
  let removed = 0, kept = 0;
  const root = voucherStore.VOUCHER_DIR;
  if (fs.existsSync(root)) {
    for (const dir of fs.readdirSync(root)) {
      const abs = path.join(root, dir);
      if (!fs.statSync(abs).isDirectory()) continue;
      for (const name of fs.readdirSync(abs)) {
        const rel = 'vouchers/' + dir + '/' + name;
        if (keep.has(rel)) { kept++; continue; }
        fs.unlinkSync(path.join(abs, name));
        removed++;
      }
      if (fs.readdirSync(abs).length === 0) fs.rmdirSync(abs);
    }
  }
  console.log('孤儿凭证清理：删除 ' + removed + ' 个，保留 ' + kept + ' 个（仍有订单引用）');
  await db.promise().end();
})().catch(e => { console.error('清理失败:', e.message); process.exitCode = 1; });
