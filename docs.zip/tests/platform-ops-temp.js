'use strict';
require('dotenv').config();
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { spawn } = require('child_process');

const PORT = 3102;
const BASE = 'http://127.0.0.1:' + PORT;
const prefix = 'zzops_' + Date.now().toString(36) + '_';
const ids = [];
let guestToken = '';
let conn;
let serverProcess;
const results = [];
function check(name, condition, detail) {
  results.push({ name, ok: !!condition, detail: detail || null });
  if (!condition) throw new Error(name + (detail ? ': ' + detail : ''));
}
async function call(path, options) {
  const r = await fetch(BASE + path, options || {});
  const body = await r.json().catch(() => ({}));
  return { status: r.status, body };
}
async function startServer() {
  serverProcess = spawn(process.execPath, ['server.js'], {
    cwd: require('path').join(__dirname, '..'), env: Object.assign({}, process.env, { PORT: String(PORT) }),
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  serverProcess.stdout.on('data', d => { output += d.toString(); });
  serverProcess.stderr.on('data', d => { output += d.toString(); });
  for (let i = 0; i < 30; i++) {
    await new Promise(resolve => setTimeout(resolve, 250));
    try {
      const r = await fetch(BASE + '/');
      if (r.ok) return;
    } catch (_) { /* 服务尚未就绪 */ }
    if (serverProcess.exitCode !== null) throw new Error('verification server stopped: ' + output.slice(-300));
  }
  throw new Error('verification server did not start: ' + output.slice(-300));
}
function token(user) {
  return jwt.sign({ id: user.id, username: user.username, role: user.role, purpose: 'login', tv: Number(user.token_version || 0) }, process.env.JWT_SECRET, { expiresIn: '5m' });
}
async function create(role) {
  const username = prefix + role;
  const hash = await bcrypt.hash('TempPass!123', 10);
  const [r] = await conn.query('INSERT INTO users (username, nickname, email, phone, real_name, password_hash, invite_code, role, status, token_version) VALUES (?, ?, NULL, NULL, ?, ?, ?, ?, \'active\', 0)', [username, username, '临时测试', hash, crypto.randomBytes(4).toString('hex').toUpperCase(), role]);
  ids.push(r.insertId);
  return { id: r.insertId, username, role, token_version: 0 };
}
(async () => {
  conn = await mysql.createConnection({ host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306), user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME });
  await startServer();
  const [supportTables] = await conn.query("SELECT COUNT(*) c FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='support_threads'");
  check('guest support schema migrated', Number(supportTables[0].c) === 1);
  const adminRows = await conn.query("SELECT id, username, role, token_version FROM users WHERE role='admin' AND status='active' ORDER BY id LIMIT 1");
  check('existing active admin available', adminRows[0].length === 1);
  const admin = adminRows[0][0];
  const support = await create('support');
  const user = await create('user');
  const adminToken = token(admin), supportToken = token(support), userToken = token(user);
  let r = await call('/api/admin/support/threads');
  check('anonymous support management denied', r.status === 401, String(r.status));
  r = await call('/api/admin/support/threads', { headers: { Authorization: 'Bearer ' + userToken } });
  check('ordinary user support management denied', r.status === 403, String(r.status));
  r = await call('/api/admin/support/threads', { headers: { Authorization: 'Bearer ' + supportToken } });
  check('support may list support threads', r.status === 200 && r.body.success === true, String(r.status));
  r = await call('/api/admin/users', { headers: { Authorization: 'Bearer ' + supportToken } });
  check('support cannot access user management', r.status === 403, String(r.status));
  r = await call('/api/admin/search?q=zz', { headers: { Authorization: 'Bearer ' + supportToken } });
  check('support cannot access admin global search', r.status === 403, String(r.status));
  r = await call('/api/support/guest/session', { method: 'POST' });
  check('guest session created', r.status === 200 && /^[a-f0-9]{32}$/.test(r.body.token || ''), String(r.status));
  guestToken = r.body.token;
  r = await call('/api/support/guest/messages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: guestToken, content: 'temporary support test message' }) });
  check('guest message saved', r.status === 200 && r.body.ok === true, String(r.status));
  const thread = 'guest:' + guestToken;
  r = await call('/api/admin/support/threads/' + encodeURIComponent(thread) + '/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken }, body: JSON.stringify({ content: 'temporary staff reply' }) });
  check('admin support reply created', r.status === 201 && r.body.success === true, String(r.status));
  r = await call('/api/support/guest/messages?token=' + guestToken);
  check('guest receives staff reply', r.status === 200 && (r.body.messages || []).some(m => m.sender_role === 'admin' && m.content === 'temporary staff reply'), String(r.status));
  r = await call('/api/admin/support/threads/' + encodeURIComponent(thread) + '/status', { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + supportToken }, body: JSON.stringify({ status: 'closed' }) });
  check('support may close thread', r.status === 200 && r.body.data.status === 'closed', String(r.status));
  r = await call('/api/admin/support/threads/' + encodeURIComponent(thread) + '/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adminToken }, body: JSON.stringify({ content: 'must not send' }) });
  check('closed thread blocks reply', r.status === 409, String(r.status));
  r = await call('/api/admin/search?q=' + encodeURIComponent(prefix.slice(0, -1)), { headers: { Authorization: 'Bearer ' + adminToken } });
  const serialized = JSON.stringify(r.body);
  check('admin global search returns categorized results', r.status === 200 && r.body.success && Array.isArray(r.body.data.users), String(r.status));
  check('global search does not expose sensitive credentials', !/password_hash|TempPass|jwt|otp_plain/i.test(serialized));
  const oldToken = userToken;
  r = await call('/api/auth/logout-other', { method: 'POST', headers: { Authorization: 'Bearer ' + oldToken } });
  check('logout other devices returns replacement token', r.status === 200 && r.body.data && r.body.data.token, String(r.status));
  r = await call('/api/auth/me', { headers: { Authorization: 'Bearer ' + oldToken } });
  check('token version invalidates prior token', r.status === 401, String(r.status));
  const [freshRows] = await conn.query('SELECT id, username, role, token_version FROM users WHERE id = ?', [user.id]);
  r = await call('/api/auth/me', { headers: { Authorization: 'Bearer ' + token(freshRows[0]) } });
  check('current token version authenticates', r.status === 200 && r.body.success, String(r.status));
  console.log(JSON.stringify({ passed: true, checks: results }, null, 2));
})().catch(err => {
  console.error(JSON.stringify({ passed: false, error: err.message, checks: results }, null, 2));
  process.exitCode = 1;
}).finally(async () => {
  if (conn) {
    try {
      if (guestToken) {
        await conn.query('DELETE FROM admin_logs WHERE detail LIKE ?', ['%' + guestToken + '%']);
        await conn.query('DELETE FROM support_threads WHERE thread_key = ?', ['guest:' + guestToken]);
        await conn.query('DELETE FROM chat_messages WHERE guest_token = ?', [guestToken]);
      }
      if (ids.length) {
        const { deleteUsersDeep } = require('./temp-user-cleanup');
        await deleteUsersDeep(conn, ids);
      }
    } catch (e) { console.error('temporary test cleanup failed:', e.message); process.exitCode = 1; }
    await conn.end();
  }
  if (serverProcess && serverProcess.exitCode === null) {
    serverProcess.kill();
    await new Promise(resolve => serverProcess.once('exit', resolve));
  }
});