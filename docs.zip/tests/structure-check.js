// ============================================
// 26牛牛 - 源码结构自检（回归用）
// ============================================
// 目的: 防止「用插入式编辑」把函数体/末行弄错位，导致函数被嵌套进另一个函数
//   - Node 模块：函数声明与 module.exports 必须位于顶层（大括号深度 0）
//   - 浏览器 IIFE：函数声明必须位于 IIFE 内（深度 1）
// 运行: node tests/structure-check.js （有可疑项会输出 SUSPECT 并退出码 1）
// ============================================
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const files = [
  'utils/funds.js', 'utils/referralRewards.js', 'utils/imageCheck.js', 'utils/voucherStore.js', 'utils/rateLimit.js',
  'routes/deposits.js', 'routes/withdrawals.js', 'routes/admin-funds.js', 'routes/admin.js', 'routes/wallet.js',
  'routes/promote.js', 'middleware/admin-boundary.js', 'server.js', 'public/js/admin-page.js', 'public/js/app-common.js', 'public/js/me-page.js',
  // 26牛牛娱乐场（非现金化娱乐积分）：集中配置 / 纯逻辑引擎 / 房间状态机 / 接口 / 实时通道 / 前端
  'config/niuGame.js', 'utils/niuEngine.js', 'utils/niuRoom.js', 'routes/niu.js', 'routes/admin-niu.js', 'socket/niuSocket.js',
  'public/js/niu-page.js', 'public/js/admin-niu-panel.js', 'routes/health.js'
];
// 已知的合法嵌套（回调/内部辅助函数），不视为问题
const ALLOW = {
  'public/js/app-common.js': ['show(', 'done(', 'tick(', 'close(', 'collect('],
  'public/js/me-page.js': ['paint('],
  'public/js/niu-page.js': ['paint(', 'tick(', 'step(', 'done(', 'close('],
  'utils/niuRoom.js': ['notice(']
};
let suspects = 0;
for (const f of files) {
  const lines = fs.readFileSync(path.join(root, f), 'utf8').split('\n');
  let depth = 0;
  const bad = [];
  lines.forEach((line, i) => {
    const trimmed = line.trim();
    const isFn = /^(async\s+)?function\s+\w+/.test(trimmed) || /^module\.exports/.test(trimmed);
    if (isFn) {
      const expected = f.startsWith('public/') ? [1] : [0];
      const allowed = (ALLOW[f] || []).some(a => trimmed.indexOf(a) >= 0);
      if (expected.indexOf(depth) < 0 && !allowed) bad.push((i + 1) + ': depth=' + depth + ' ' + trimmed.slice(0, 60));
    }
    for (const ch of line) {
      if (ch === '{') depth++;
      else if (ch === '}') depth--;
    }
  });
  if (bad.length) suspects++;
  console.log((bad.length ? 'SUSPECT ' : 'ok      ') + f + (bad.length ? '\n   ' + bad.join('\n   ') : ''));
}
console.log(suspects ? ('STRUCTURE_CHECK_FAIL (' + suspects + ' files)') : 'STRUCTURE_CHECK_PASS');
process.exitCode = suspects ? 1 : 0;

