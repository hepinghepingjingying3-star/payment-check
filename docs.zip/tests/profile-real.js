'use strict';
// Real login, database and upload storage; only test-owned records are removed.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const express = require('express');
const bcrypt = require('bcryptjs');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const db = require('../config/db');
const report = { checks: [], passed: false, mode: 'Real HTTP login + MySQL + file upload' };
let id, server, avatar;
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
async function main() {
  const suffix = crypto.randomBytes(8).toString('hex');
  const username = 'profile_test_' + suffix;
  const password = crypto.randomBytes(24).toString('hex');
  const hash = await bcrypt.hash(password, 10);
  const [insert] = await db.promise().query(`INSERT INTO users
    (username, real_name, password_hash, role, status)
    VALUES (?, 'isolated profile test', ?, 'user', 'active')`, [username, hash]);
  id = insert.insertId;
  const app = express(); app.use(express.json());
  app.use(express.static(path.resolve(__dirname, '../public')));
  app.use('/api', require('../routes/auth'), require('../routes/profile'));
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = 'http://127.0.0.1:' + server.address().port;
  let token;
  async function api(url, method = 'GET', body) {
    const headers = token ? { Authorization: 'Bearer ' + token } : {};
    if (body && !(body instanceof FormData)) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(body); }
    const res = await fetch(base + url, { method, headers, body, signal: AbortSignal.timeout(8000) });
    return { status: res.status, body: await res.json() };
  }
  const login = await api('/api/auth/login', 'POST', { username, password });
  check('Password login succeeds', login.status === 200 && login.body.data.token);
  token = login.body.data.token;
  check('Nickname update succeeds', (await api('/api/profile', 'PATCH', { nickname: '资料验证' })).status === 200);
  const form = new FormData();
  form.append('file', new Blob([fs.readFileSync(path.resolve(__dirname, '../public/assets/avatars/official.jpg'))], { type: 'image/jpeg' }), 'avatar.jpg');
  const upload = await api('/api/profile/avatar', 'POST', form);
  check('Avatar upload succeeds', upload.status === 200 && upload.body.data.avatar_url);
  avatar = upload.body.data.avatar_url;
  token = null;
  const again = await api('/api/auth/login', 'POST', { username, password });
  check('Original login credentials still work', again.status === 200);
  token = again.body.data.token;
  const me = await api('/api/auth/me');
  check('New login reads persisted nickname and avatar', me.body.data.nickname === '资料验证' && me.body.data.avatar_url === avatar);
  const [rows] = await db.promise().query('SELECT nickname, avatar_url, username, password_hash, role, game_balance, cash_chips FROM users WHERE id = ?', [id]);
  check('Database persisted profile only', rows[0].nickname === '资料验证' && rows[0].avatar_url === avatar && rows[0].username === username && rows[0].password_hash === hash && rows[0].role === 'user' && Number(rows[0].game_balance) === 0 && Number(rows[0].cash_chips) === 0);
  const image = await fetch(base + avatar);
  check('Saved avatar serves as JPEG', image.status === 200 && image.headers.get('content-type').includes('image/jpeg'));
  report.passed = true;
}
main().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  try {
    if (id) {
      const [rows] = await db.promise().query('SELECT avatar_url FROM users WHERE id = ?', [id]);
      avatar = avatar || (rows[0] && rows[0].avatar_url);
      await db.promise().query('DELETE FROM login_logs WHERE user_id = ?', [id]);
      await db.promise().query('DELETE FROM users WHERE id = ?', [id]);
    }
    if (/^\/assets\/avatars\/users\/[a-f0-9-]+\.jpg$/.test(avatar || '')) fs.unlinkSync(path.join(__dirname, '../public', avatar));
    report.cleaned = true;
  } catch (e) { report.cleanup_error = e.code || e.message; report.passed = false; }
  if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  await db.promise().end();
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'profile-real-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2)); process.exitCode = report.passed ? 0 : 1;
});
