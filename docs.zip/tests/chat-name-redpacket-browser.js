'use strict';
// ============================================
// 26牛牛 - 聊天「说话人名字 + 红包」端到端验收
// 环境: 真实服务器（临时端口）+ 真实 MySQL + 真实 Chrome（无头）
// 覆盖:
//   1) 群聊每条消息都显示说话人名字：自己 =「我 · 用户名」，别人 = 对方用户名
//   2) 系统消息显示来源「系统」（不再是无名居中文本）
//   3) 客服留言页同样显示说话人名字
//   4) 群聊「红包」入口可见（图标 + 文案）→ 发红包表单 → 红包卡片
//      → 对方点击抢红包 → 领取金额 / 记录带用户名 / 余额与流水一致
// 数据隔离:
//   - 只创建 zzui_ 前缀临时账号（1 个发红包 + 1 个抢红包），结束后按外键关系删除
//   - 用临时端口 fork server.js，不触碰 3000 端口的开发服务
// 报告: tests/chat-name-redpacket-browser-report.json（每步落盘）
// 截图: tests/chat-name-redpacket-ui.png（群聊名字 + 红包卡片视觉证据）
// ============================================
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn, fork } = require('node:child_process');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const root = path.resolve(__dirname, '..');
const reportPath = path.join(__dirname, 'chat-name-redpacket-browser-report.json');
const shotPath = path.join(__dirname, 'chat-name-redpacket-ui.png');
const report = {
  started: new Date().toISOString(),
  mode: 'Real server (temp port) + Real MySQL + Real headless Chrome; temporary zzui_* accounts removed afterwards',
  checks: [], errors: [], cleanup: null, finished: null
};
const BUDGET = 100;                 // 发红包账号初始测试资产
const SEND_AMOUNT = 10;             // 红包总金额
const SEND_COUNT = 2;               // 红包个数
const BLESSING = '自动化验收红包';
const PREFIX = 'zzui_';
let server = null, chrome = null, ws = null, db = null;
const profile = fs.mkdtempSync(path.join(os.tmpdir(), '26-chatui-'));
const stamp = Date.now().toString(36);
const USERNAMES = { sender: PREFIX + 'send_' + stamp, claimer: PREFIX + 'clm_' + stamp };
const PASSWORD = 'Zz-Chat-Ui-1!';
const ids = {};
const tokens = {};
const tempIds = [];
let systemMsgId = null;
const wait = ms => new Promise(r => setTimeout(r, ms));

function save() {
  try { fs.writeFileSync(reportPath, JSON.stringify(report, null, 2)); } catch (_) { /* 忽略 */ }
}
function check(ok, name, detail) {
  report.checks.push({ name: name, pass: !!ok, ...(detail === undefined ? {} : { detail: detail }) });
  save();
  if (!ok) throw new Error(name + ' :: ' + JSON.stringify(detail));
}

// ---------- 数据库 ----------
async function connectDb() {
  db = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT), user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME
  });
}
async function createTempUser(username) {
  const hash = bcrypt.hashSync(PASSWORD, 11);
  const [result] = await db.query(
    `INSERT INTO users (username, nickname, real_name, password_hash, role, status)
     VALUES (?, ?, ?, ?, 'user', 'active')`,
    [username, username, '临时聊天验收账号', hash]
  );
  const id = Number(result.insertId);
  tempIds.push(id);
  return id;
}
async function one(sql, params) {
  const [rows] = await db.query(sql, params || []);
  return rows[0] || null;
}
async function countOf(sql, params) {
  const row = await one(sql, params);
  return Number(row && row.c) || 0;
}
async function waitDb(describe, fn, timeout = 6000) {
  const deadline = Date.now() + timeout;
  let last = null;
  while (Date.now() < deadline) {
    last = await fn();
    if (last) return last;
    await wait(150);
  }
  throw new Error('DB 条件未满足: ' + describe + ' (last=' + JSON.stringify(last) + ')');
}

// ---------- 服务器（临时端口，使用未修改的 server.js） ----------
async function startServer() {
  const bootstrap = `const http=require('http');const listen=http.Server.prototype.listen;http.Server.prototype.listen=function(...args){this.once('listening',()=>process.send({port:this.address().port}));return listen.apply(this,args);};require('./server');`;
  server = fork('-e', [bootstrap], { cwd: root, env: { ...process.env, PORT: '0' }, silent: true });
  server.stdout.resume();
  server.stderr.resume();
  const port = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('服务器启动超时')), 20000);
    server.once('message', m => { clearTimeout(timer); resolve(m.port); });
    server.once('exit', code => { clearTimeout(timer); reject(new Error('服务器提前退出: ' + code)); });
  });
  return 'http://127.0.0.1:' + port;
}

// ---------- HTTP ----------
async function login(base, username) {
  const response = await fetch(base + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: username, password: PASSWORD }), signal: AbortSignal.timeout(8000)
  });
  const body = await response.json().catch(() => ({}));
  return { status: response.status, token: body && body.data ? body.data.token : null };
}
async function api(base, pathname, opt) {
  opt = opt || {};
  const headers = {};
  if (opt.token) headers.Authorization = 'Bearer ' + opt.token;
  if (opt.body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(base + pathname, {
    method: opt.method || 'GET', headers: headers,
    body: opt.body === undefined ? undefined : JSON.stringify(opt.body),
    signal: AbortSignal.timeout(10000)
  });
  return { status: response.status, json: await response.json().catch(() => null) };
}

// ---------- Chrome（原生 CDP，无额外依赖，与其他浏览器验收测试同一套做法） ----------
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const cdp = {};

async function launchChrome() {
  check(fs.existsSync(CHROME), 'Chrome 可执行文件存在', CHROME);
  chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--window-size=440,940', '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank'
  ], { stdio: 'ignore' });
  chrome.on('error', e => report.errors.push(e.message));

  let debugPort = null;
  for (let i = 0; i < 150; i++) {
    try {
      debugPort = fs.readFileSync(path.join(profile, 'DevToolsActivePort'), 'utf8').split('\n')[0];
      break;
    } catch (_) { await wait(100); }
  }
  check(!!debugPort, 'Chrome DevTools 调试端口可用', { port: debugPort || null });

  const targets = await (await fetch('http://127.0.0.1:' + debugPort + '/json/list')).json();
  const target = targets.find(t => t.type === 'page');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });

  let seq = 0;
  const pending = new Map();
  const errors = [];
  ws.onmessage = event => {
    const m = JSON.parse(event.data);
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id); pending.delete(m.id);
      if (m.error) p.reject(new Error(m.error.message)); else p.resolve(m.result);
    }
    if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails);
  };
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const n = ++seq; pending.set(n, { resolve, reject });
    ws.send(JSON.stringify({ id: n, method, params }));
  });
  const evaluate = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  const evaluateAsync = async expression => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  const waitExpr = async (expr, tries = 60) => {
    for (let i = 0; i < tries; i++) {
      if (await evaluate('(' + expr + ')').catch(() => false)) return true;
      await wait(120);
    }
    return false;
  };
  const goto = async (url, readyExpr, tries = 80) => {
    await send('Page.navigate', { url: base0 + url });
    for (let i = 0; i < tries; i++) {
      if (await evaluate("document.readyState === 'complete' && (" + readyExpr + ")").catch(() => false)) return true;
      await wait(120);
    }
    return false;
  };
  const screenshot = async () => {
    const r = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(shotPath, Buffer.from(r.data, 'base64'));
  };
  /**
   * 预置某个临时账号的登录态。
   * 必须用「新文档注入脚本」，而不是在当前 about:blank 上写 localStorage
   * —— about:blank 的存储不会带到目标站点（这也是 admin-access-browser.js 的做法）。
   * 每次调用追加一段脚本，后追加的在新文档里最后执行，因此切换账号时以最后一次为准。
   */
  const useAccount = async (token, username) => {
    await send('Page.addScriptToEvaluateOnNewDocument', {
      source: 'try {' +
        'localStorage.setItem("token", ' + JSON.stringify(token) + ');' +
        'localStorage.setItem("user", ' + JSON.stringify(JSON.stringify({ username: username })) + ');' +
        '} catch (e) {}'
    });
  };

  await send('Runtime.enable');
  await send('Page.enable');
  await send('Network.enable');
  await send('Network.setCacheDisabled', { cacheDisabled: true });

  Object.assign(cdp, { send, evaluate, evaluateAsync, waitExpr, goto, screenshot, useAccount, errors });
}
let base0 = '';

// ---------- 界面辅助 ----------
/** 打开页面并断言就绪；失败时把标题 / 当前地址 / 首页内容带出来，方便定位 */
async function openPage(url, readyExpr, label) {
  const ok = await cdp.goto(url, readyExpr);
  let info;
  if (!ok) {
    info = await cdp.evaluate('({ url: location.href, title: document.title, hasApp: !!window.App,' +
      'body: (document.body ? document.body.innerText : "").replace(/\\s+/g, " ").slice(0, 140) })')
      .catch(e => ({ error: e.message }));
  }
  check(ok, label, info);
  return ok;
}
function typeAndSend(text) {
  return cdp.evaluate('(() => {' +
    'const el = document.getElementById("chatInput"); if (!el) return false;' +
    'el.focus(); el.value = ' + JSON.stringify(text) + ';' +
    'el.dispatchEvent(new Event("input", { bubbles: true }));' +
    'const btn = document.getElementById("sendBtn"); if (!btn) return false;' +
    'btn.click(); return true; })()');
}
function msgAudit() {
  return cdp.evaluate('Array.from(document.querySelectorAll("#msgList .msg")).map(n => ({' +
    'mine: n.classList.contains("me"),' +
    'name: ((n.querySelector(".m-name") || {}).textContent || "").trim(),' +
    'text: n.textContent.replace(/\\s+/g, " ").trim() }))');
}

// ---------- 阶段一：群聊「每条消息都显示说话人名字」 ----------
async function phaseGroupNames(base) {
  await openPage('/group-chat.html',
    'window.App && document.getElementById("sendBtn") && document.getElementById("chatInput") && document.getElementById("msgList")',
    '打开 26牛牛游戏群（真实页面）');
  check(await cdp.waitExpr('document.querySelectorAll("#msgList .msg, #msgList .sys-line").length > 0', 80),
    '群聊消息已渲染');

  // 1. 自己发消息（真实 UI：输入 → 点发送）
  const myText = '自动化验收：我的名字要显示出来';
  check(await typeAndSend(myText), 'UI 输入并点击发送自己的消息');
  check(await cdp.waitExpr('Array.from(document.querySelectorAll("#msgList .msg")).some(n => ' +
    'n.classList.contains("me") && n.textContent.indexOf(' + JSON.stringify(myText) + ') >= 0)', 80),
    '自己的消息出现在列表中');

  const audit1 = await msgAudit();
  const myRow = audit1.filter(r => r.mine && r.text.indexOf(myText) >= 0).pop();
  check(!!myRow && myRow.name === '我 · ' + USERNAMES.sender,
    '自己的消息名字显示为「我 · 用户名」', { got: myRow && myRow.name, expect: '我 · ' + USERNAMES.sender });

  // 2. 系统消息必须标明来源，而不是无名的居中文本
  const sys = await cdp.evaluate('(() => { const n = document.querySelector("#msgList .sys-line");' +
    'return n ? { name: ((n.querySelector(".sys-name") || {}).textContent || "").trim(),' +
    'text: n.textContent.replace(/\\s+/g, " ").trim() } : null; })()');
  check(!!sys && sys.name === '系统', '系统消息显示来源「系统」', sys);

  // 3. 对方（抢红包账号）通过接口发言 → 轮询后出现在页面上，并显示对方用户名
  const otherText = '自动化验收：对方的名字要显示出来';
  const sent = await api(base, '/api/chat/messages',
    { method: 'POST', token: tokens.claimer, body: { channel: 'group', message_type: 'text', content: otherText } });
  check(sent.status === 201 && sent.json && sent.json.success, '抢红包账号通过接口发消息（模拟真人在线发言）',
    { status: sent.status });

  check(await cdp.waitExpr('Array.from(document.querySelectorAll("#msgList .msg")).some(n => !n.classList.contains("me") && ' +
    'n.textContent.indexOf(' + JSON.stringify(otherText) + ') >= 0)', 90),
    '对方消息经定时轮询出现在页面');
  const otherRow = (await msgAudit()).filter(r => !r.mine && r.text.indexOf(otherText) >= 0).pop();
  check(!!otherRow && otherRow.name === USERNAMES.claimer,
    '对方消息显示对方用户名', { got: otherRow && otherRow.name, expect: USERNAMES.claimer });

  // 4. 全员名字不空白（普通消息 100% 有名字）
  const audit2 = await msgAudit();
  const blank = audit2.filter(r => !r.name);
  check(audit2.length >= 2 && blank.length === 0, '每条普通消息都有说话人名字（没有空白名字的气泡）',
    { total: audit2.length, blank: blank.length });
}

// ---------- 阶段二：红包入口 + 真实发红包 ----------
async function phaseSendRedPacket(base) {
  const rpBtn = await cdp.evaluate('(() => { const b = document.getElementById("rpBtn");' +
    'return b ? { hidden: !!b.hidden, visible: !!b.offsetParent, text: b.textContent.replace(/\\s+/g, "").trim(),' +
    'icon: !!b.querySelector(".ic.i-packet") } : null; })()');
  check(!!rpBtn && rpBtn.visible && !rpBtn.hidden && rpBtn.icon && rpBtn.text.indexOf('红包') >= 0,
    '群聊「红包」入口可见（图标 + 红包文案）', rpBtn);

  check(await cdp.evaluate('(() => { const b = document.getElementById("rpBtn"); if (!b) return false; b.click(); return true; })()'),
    '点击「红包」按钮');
  check(await cdp.waitExpr('!!document.querySelector(".sheet-form") && !!document.getElementById("fs-amount")', 60),
    '发红包表单弹出（金额 / 个数 / 祝福语）');
  const filled = await cdp.evaluate('(() => {' +
    'const set = (id, v) => { const el = document.getElementById(id); if (!el) return false;' +
    'el.value = String(v); el.dispatchEvent(new Event("input", { bubbles: true })); return true; };' +
    'return set("fs-amount", ' + JSON.stringify(String(SEND_AMOUNT)) + ') &&' +
    'set("fs-count", ' + JSON.stringify(String(SEND_COUNT)) + ') &&' +
    'set("fs-blessing", ' + JSON.stringify(BLESSING) + '); })()');
  check(filled, '填写红包金额 ' + SEND_AMOUNT + ' / 个数 ' + SEND_COUNT + ' / 祝福语');
  check(await cdp.evaluate('(() => { const b = document.querySelector("[data-fs-ok]"); if (!b) return false; b.click(); return true; })()'),
    '提交红包（塞钱进红包）');
  check(await cdp.waitExpr('!!document.querySelector("#msgList .rp-card")', 90), '红包卡片出现在聊天里');

  const card = await cdp.evaluate('(() => { const list = document.querySelectorAll("#msgList .rp-card");' +
    'if (!list.length) return null; const c = list[list.length - 1];' +
    'return { packet: Number(c.dataset.packet || 0),' +
    'bless: ((c.querySelector(".rp-bless") || {}).textContent || "").trim(),' +
    'sub: ((c.querySelector(".rp-sub") || {}).textContent || "").trim(),' +
    'state: ((c.querySelector(".rp-state") || {}).textContent || "").trim() }; })()');
  check(!!card && card.bless === BLESSING && card.sub.indexOf('0/' + SEND_COUNT) >= 0,
    '红包卡片显示祝福语与领取进度 0/' + SEND_COUNT, card);
  report.toast = await cdp.evaluate('(() => { const t = document.querySelector("#toast-wrap .toast");' +
    'return t ? t.textContent.trim() : null; })()');
  await cdp.screenshot();
  check(fs.existsSync(shotPath), '已保存群聊截图（说话人名字 + 红包卡片）', shotPath);

  // 后端一致性：红包消息 / 详情 / 流水 / 余额
  const rpMsg = await waitDb('红包消息入库', async () => one(
    "SELECT id, meta FROM chat_messages WHERE user_id = ? AND message_type = 'redpacket' ORDER BY id DESC LIMIT 1",
    [ids.sender]));
  const meta = typeof rpMsg.meta === 'string' ? JSON.parse(rpMsg.meta) : rpMsg.meta;
  const packetId = Number(meta.packet_id);
  check(Number.isInteger(packetId) && packetId > 0, '红包消息 meta 带 packet_id', meta);
  report.packet = { id: packetId, meta: meta };

  const detail = await api(base, '/api/chat/redpackets/' + packetId, { token: tokens.sender });
  const packet = detail.json && detail.json.data ? detail.json.data.packet : null;
  check(detail.status === 200 && !!packet && packet.sender_name === USERNAMES.sender,
    '红包详情里的发送者名字与聊天里的说话人一致', { sender_name: packet && packet.sender_name });
  check(!!packet && Number(packet.total_amount) === SEND_AMOUNT && packet.claimed_count === 0,
    '红包总额 / 领取进度与提交参数一致',
    { total_amount: packet && packet.total_amount, claimed: packet && packet.claimed_count });

  const senderRow = await one('SELECT cash_chips FROM users WHERE id = ?', [ids.sender]);
  check(Math.abs(Number(senderRow.cash_chips) - (BUDGET - SEND_AMOUNT)) < 0.005,
    '发红包先扣款：余额 ' + BUDGET + ' → ' + (BUDGET - SEND_AMOUNT), { cash_chips: Number(senderRow.cash_chips) });
  check(await countOf("SELECT COUNT(*) AS c FROM balance_transactions WHERE user_id = ? AND type = 'RED_PACKET_SEND'",
    [ids.sender]) === 1, '发红包写入资金流水 RED_PACKET_SEND');

  const selfClaim = await api(base, '/api/chat/redpackets/' + packetId + '/claim',
    { method: 'POST', token: tokens.sender });
  check(selfClaim.status >= 400, '发送者不能抢自己的红包',
    { status: selfClaim.status, code: selfClaim.json && selfClaim.json.code });
}

// ---------- 阶段三：另一个账号在界面上抢红包 ----------
async function phaseClaimByUi(base) {
  await cdp.useAccount(tokens.claimer, USERNAMES.claimer);
  await openPage('/group-chat.html',
    'window.App && document.getElementById("sendBtn") && document.getElementById("msgList")',
    '切换到抢红包账号并重新打开群聊');
  // 群聊里可能还留着历史红包消息，这里只针对本次自动化发出的那个红包
  const cardSel = '#msgList .rp-card[data-packet="' + report.packet.id + '"]';
  const cardSelJs = JSON.stringify(cardSel);
  check(await cdp.waitExpr('!!document.querySelector(' + cardSelJs + ')', 90),
    '抢红包账号看到同一个红包卡片（packet ' + report.packet.id + '）');

  const mineRow = (await msgAudit()).filter(r => r.mine).pop();
  check(!!mineRow && mineRow.name === '我 · ' + USERNAMES.claimer,
    '换账号后「自己的消息」名字随登录者变化', { got: mineRow && mineRow.name });
  const otherNames = (await msgAudit()).filter(r => !r.mine).map(r => r.name);
  check(otherNames.indexOf(USERNAMES.sender) >= 0, '发红包账号的消息显示其用户名', otherNames.slice(-4));

  check(await cdp.evaluate('(() => { const c = document.querySelector(' + cardSelJs + ');' +
    'if (!c) return false; c.click(); return true; })()'), '点击红包卡片');
  check(await cdp.waitExpr('!!document.querySelector(".dialog-mask [data-yes]")', 60), '弹出抢红包确认框');
  const dialogText = await cdp.evaluate('(() => { const d = document.querySelector(".dialog-mask .dialog-text");' +
    'return d ? d.textContent.replace(/\\s+/g, " ").trim() : null; })()');
  check(!!dialogText && dialogText.indexOf(USERNAMES.sender) >= 0, '确认框显示「是谁发的红包」', { text: dialogText });
  check(await cdp.evaluate('(() => { const b = document.querySelector(".dialog-mask [data-yes]");' +
    'if (!b) return false; b.click(); return true; })()'), '确认抢红包');
  check(await cdp.waitExpr('!!document.querySelector(".rp-detail-amount .amt")', 90), '抢到后弹出领取金额');

  const amountText = await cdp.evaluate('(() => { const a = document.querySelector(".rp-detail-amount .amt");' +
    'return a ? a.textContent.trim() : null; })()');
  const amount = Number(amountText);
  check(isFinite(amount) && amount > 0 && amount <= SEND_AMOUNT, '领取金额在红包总额以内', { amount: amountText });
  const claimsText = await cdp.evaluate('(() => { const n = document.querySelector(".rp-claims");' +
    'return n ? n.textContent.replace(/\\s+/g, " ").trim() : null; })()');
  check(!!claimsText && claimsText.indexOf(USERNAMES.claimer) >= 0, '领取记录里显示领取人用户名', { claims: claimsText });
  await cdp.evaluate('(() => { const b = document.querySelector("[data-fs-ok]"); if (b) b.click(); return true; })()');

  const stateText = await cdp.evaluate('(() => { const c = document.querySelector(' +
    JSON.stringify(cardSel + ' .rp-state') + ');' +
    'return c ? c.textContent.trim() : null; })()');
  check(!!stateText && stateText.indexOf('已抢') >= 0, '红包气泡状态更新为「已抢 x.xx」', { state: stateText });
  await cdp.screenshot();

  // 资金一致性：领取金额真实入账 + 领取明细 + 流水
  const claimerRow = await one('SELECT cash_chips FROM users WHERE id = ?', [ids.claimer]);
  check(Math.abs(Number(claimerRow.cash_chips) - amount) < 0.005, '抢到的金额真实入账（余额 = 领取金额）',
    { cash_chips: Number(claimerRow.cash_chips), amount: amount });
  const claimRow = await one('SELECT amount FROM chat_red_packet_claims WHERE packet_id = ? AND user_id = ?',
    [report.packet.id, ids.claimer]);
  check(!!claimRow && Math.abs(Number(claimRow.amount) - amount) < 0.005, '领取明细入库且与界面金额一致',
    { db: claimRow && Number(claimRow.amount), ui: amount });
  check(await countOf("SELECT COUNT(*) AS c FROM balance_transactions WHERE user_id = ? AND type = 'RED_PACKET_CLAIM'",
    [ids.claimer]) === 1, '抢红包写入资金流水 RED_PACKET_CLAIM');

  const detail = await api(base, '/api/chat/redpackets/' + report.packet.id, { token: tokens.sender });
  const packet = detail.json && detail.json.data ? detail.json.data.packet : null;
  check(!!packet && packet.claimed_count === 1 && packet.status === 'OPEN',
    '红包详情：已领 1 个、剩余仍可继续抢', { claimed_count: packet && packet.claimed_count, status: packet && packet.status });
  check(!!packet && packet.best && packet.best.username === USERNAMES.claimer, '手气最佳展示领取人用户名',
    { best: packet && packet.best });
  return { amount: amount, amount_text: amountText, claims: claimsText, state: stateText };
}

// ---------- 阶段四：客服留言页同样显示说话人名字 ----------
async function phaseSupportNames() {
  await openPage('/support-chat.html',
    'window.App && document.getElementById("sendBtn") && document.getElementById("msgList")',
    '打开在线客服（留言模式）页');
  const text = '自动化验收：客服留言也要显示说话人名字';
  check(await typeAndSend(text), 'UI 发送客服留言');
  check(await cdp.waitExpr('Array.from(document.querySelectorAll("#msgList .msg")).some(n => n.classList.contains("me") && ' +
    'n.textContent.indexOf(' + JSON.stringify(text) + ') >= 0)', 80), '客服留言出现在列表中');
  const row = (await msgAudit()).filter(r => r.mine && r.text.indexOf(text) >= 0).pop();
  check(!!row && row.name === '我 · ' + USERNAMES.claimer, '客服页自己的留言显示「我 · 用户名」',
    { got: row && row.name });
  const blank = (await msgAudit()).filter(r => !r.name);
  check(blank.length === 0, '客服页没有空白名字的消息', { blank: blank.length });
}

// ---------- 清理临时数据（只删 zzui_ 前缀，按外键关系清理，并核对 0 残留） ----------
async function cleanup() {
  const info = {};
  if (systemMsgId) {
    const [r] = await db.query('DELETE FROM chat_messages WHERE id = ?', [systemMsgId]);
    info.system_messages = r.affectedRows;
  }
  const [rows] = await db.query("SELECT id FROM users WHERE username LIKE '" + PREFIX + "%'");
  if (!rows.length) {
    info.removed = 0;
    info.residue = { users: 0 };
    report.cleanup = info;
    return info;
  }
  const list = rows.map(r => Number(r.id)).join(',');
  const removed = {};
  const [fks] = await db.query(
    `SELECT table_name AS t, column_name AS c FROM information_schema.key_column_usage
     WHERE referenced_table_name = 'users' AND table_schema = DATABASE()`);
  let remaining = fks.slice();
  for (let pass = 0; pass < 4 && remaining.length; pass++) {
    const next = [];
    for (const fk of remaining) {
      try {
        const [r] = await db.query('DELETE FROM `' + fk.t + '` WHERE `' + fk.c + '` IN (' + list + ')');
        if (r.affectedRows) removed[fk.t] = (removed[fk.t] || 0) + r.affectedRows;
      } catch (_) { next.push(fk); }
    }
    remaining = next;
  }
  const extra = [
    ['chat_read_state', 'user_id'], ['user_presence', 'user_id'], ['user_stickers', 'user_id'],
    ['chat_red_packets', 'sender_id'], ['chat_red_packet_claims', 'user_id'],
    ['chat_messages', 'user_id'], ['balance_transactions', 'user_id'],
    ['admin_approvals', 'requested_by'], ['wallet_orders', 'user_id']
  ];
  for (const e of extra) {
    try {
      const [r] = await db.query('DELETE FROM `' + e[0] + '` WHERE `' + e[1] + '` IN (' + list + ')');
      if (r.affectedRows) removed[e[0]] = (removed[e[0]] || 0) + r.affectedRows;
    } catch (_) { /* 表或列不存在时忽略 */ }
  }
  const [del] = await db.query('DELETE FROM users WHERE id IN (' + list + ')');
  removed.users = del.affectedRows;

  const residue = {
    users: await countOf("SELECT COUNT(*) AS c FROM users WHERE username LIKE '" + PREFIX + "%'"),
    chat_messages: await countOf('SELECT COUNT(*) AS c FROM chat_messages WHERE user_id IN (' + list + ')'),
    chat_red_packets: await countOf('SELECT COUNT(*) AS c FROM chat_red_packets WHERE sender_id IN (' + list + ')'),
    chat_red_packet_claims: await countOf(
      'SELECT COUNT(*) AS c FROM chat_red_packet_claims WHERE packet_id IN ' +
      '(SELECT id FROM chat_red_packets WHERE sender_id IN (' + list + ')) OR user_id IN (' + list + ')'),
    balance_transactions: await countOf('SELECT COUNT(*) AS c FROM balance_transactions WHERE user_id IN (' + list + ')')
  };
  report.cleanup = Object.assign(removed, { residue: residue });
  return info;
}

// ---------- 主流程 ----------
(async () => {
  await connectDb();
  ids.sender = await createTempUser(USERNAMES.sender);
  ids.claimer = await createTempUser(USERNAMES.claimer);
  await db.query('UPDATE users SET cash_chips = ? WHERE id = ?', [BUDGET, ids.sender]);
  const [sysRes] = await db.query(
    `INSERT INTO chat_messages (channel, user_id, message_type, content, meta)
     VALUES ('group', NULL, 'system', ?, NULL)`, ['自动化验收：系统消息来源标记']);
  systemMsgId = Number(sysRes.insertId);
  report.accounts = Object.assign({}, USERNAMES);

  const base = await startServer();
  base0 = base;
  report.base = base;

  for (const key of Object.keys(USERNAMES)) {
    const res = await login(base, USERNAMES[key]);
    check(res.status === 200 && !!res.token, '临时账号登录成功: ' + key, { status: res.status });
    tokens[key] = res.token;
  }

  await launchChrome();
  await cdp.useAccount(tokens.sender, USERNAMES.sender);
  await phaseGroupNames(base);
  await phaseSendRedPacket(base);
  report.claim = await phaseClaimByUi(base);
  await phaseSupportNames();
  check(cdp.errors.length === 0, '浏览器运行期间无 JS 异常', cdp.errors.slice(0, 2));
  report.passed = true;
})().catch(err => {
  report.errors.push(err.message);
  console.error('验收失败:', err.message);
}).finally(async () => {
  try { await cleanup(); } catch (e) { report.cleanup = { error: e.message }; }
  await wait(300);
  if (chrome) { try { chrome.kill(); } catch (_) { /* 忽略 */ } }
  if (server) { try { server.kill(); } catch (_) { /* 忽略 */ } }
  if (db) { try { await db.end(); } catch (_) { /* 忽略 */ } }
  report.finished = new Date().toISOString();
  save();

  const failed = report.checks.filter(c => !c.pass).length;
  const residue = (report.cleanup && report.cleanup.residue) || null;
  const residueOk = !residue || Object.keys(residue).every(k => residue[k] === 0);
  console.log('检查项: ' + report.checks.length + '，失败: ' + failed +
    (report.errors.length ? '，错误: ' + report.errors.join(' | ') : ''));
  console.log('清理结果: ' + JSON.stringify(report.cleanup));
  const okAll = report.passed && !failed && !report.errors.length && residueOk;
  console.log(okAll ? 'CHAT_NAME_REDPACKET_BROWSER_PASS' : 'CHAT_NAME_REDPACKET_BROWSER_FAIL');
  process.exitCode = okAll ? 0 : 1;
});
