'use strict';
// Real HTTP + session-local MySQL temporary tables. No persistent data writes.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const express = require('express');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');
const root = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(root, '.env') });
const report = { started: new Date().toISOString(), mode: 'Real HTTP and MySQL temporary tables', checks: [], passed: false };
let conn, server;
function load(file, dependencies, extra = {}) {
  const module = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(root, file), 'utf8'), {
    module, console: { error() {} }, ...extra,
    require(name) {
      if (!(name in dependencies)) throw new Error('Unexpected dependency: ' + name);
      return dependencies[name];
    }
  }, { filename: file });
  return module.exports;
}
function check(name, pass) {
  assert.ok(pass, name);
  report.checks.push({ name, pass: true });
}
async function main() {
  conn = await mysql.createConnection({ host: process.env.DB_HOST, port: process.env.DB_PORT,
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME,
    connectTimeout: 7000 });
  await conn.query(`CREATE TEMPORARY TABLE registration_otp (
    id BIGINT UNSIGNED PRIMARY KEY, phone VARCHAR(20), otp_plain_tmp VARCHAR(12),
    status VARCHAR(20), attempts INT DEFAULT 0, max_attempts INT DEFAULT 5,
    expires_at DATETIME, last_sent_at DATETIME, verified_at DATETIME NULL,
    sent_by INT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  await conn.query(`CREATE TEMPORARY TABLE otp_audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, operator_id INT,
    target_phone VARCHAR(20), otp_id BIGINT, action VARCHAR(30), detail VARCHAR(255),
    ip VARCHAR(45), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  // 会话级临时 users 表：让认证中间件在本连接内查到隔离管理员，绝不读写真实用户表
  await conn.query(`CREATE TEMPORARY TABLE users (
    id BIGINT UNSIGNED PRIMARY KEY, username VARCHAR(50), role VARCHAR(20), status VARCHAR(20), token_version INT NOT NULL DEFAULT 0
  ) ENGINE=InnoDB`);
  await conn.query("INSERT INTO users (id, username, role, status) VALUES (11, 'isolated_admin', 'admin', 'active'), (12, 'isolated_user', 'user', 'active')");
  const code = String(crypto.randomInt(100000, 1000000));
  const phone = '+60000000000';
  await conn.query(`INSERT INTO registration_otp
    (id, phone, otp_plain_tmp, status, expires_at, last_sent_at)
    VALUES (1, ?, ?, 'pending', DATE_ADD(NOW(), INTERVAL 5 MINUTE), NOW())`, [phone, code]);
  const request = require('../utils/request');
  const config = require('../config/otp');
  const otp = { secondsLeft: value => Math.max(0, Math.floor((new Date(value).getTime() - Date.now()) / 1000)) };
  const connection = {
    query: (...args) => conn.query(...args),
    beginTransaction: () => conn.beginTransaction(), commit: () => conn.commit(),
    rollback: () => conn.rollback(), release() {}
  };
  const db = { promise: () => ({ query: connection.query, getConnection: async () => connection }) };
  // Isolated JWT key; does not modify configuration or secrets.
  const key = crypto.randomBytes(32).toString('hex');
  const auth = load('middleware/auth.js', { jsonwebtoken: jwt, '../config/db': db }, { process: { env: { JWT_SECRET: key } } });
  const router = load('routes/admin-otp.js', {
    express, '../config/db': db, '../middleware/auth': auth, '../config/otp': config,
    '../utils/otp': otp, '../utils/request': request,
    './otp': { audit: async () => {}, expireStale: async () => {} }
  });
  const app = express(); app.use(express.json()); app.use('/api', router);
  server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  const base = 'http://127.0.0.1:' + server.address().port;
  const admin = jwt.sign({ id: 11, username: 'isolated_admin', role: 'admin' }, key, { expiresIn: 60 });
  async function api(url, method = 'GET', token = admin) {
    const res = await fetch(base + url, { method, headers: token ? { Authorization: 'Bearer ' + token } : {}, signal: AbortSignal.timeout(5000) });
    return { status: res.status, cache: res.headers.get('cache-control'), body: await res.json() };
  }

  const list = await api('/api/admin/otp');
  check('List omits plaintext', list.status === 200 && list.body.data.list[0].code_available && !JSON.stringify(list.body).includes(code));
  const first = await api('/api/admin/otp/1/reveal', 'POST');
  check('First reveal succeeds', first.status === 200 && first.body.data.code === code);
  check('No caching', first.cache === 'no-store');
  const [[row]] = await conn.query('SELECT otp_plain_tmp FROM registration_otp WHERE id = 1');
  check('MySQL plaintext cleared', row.otp_plain_tmp === null);
  const second = await api('/api/admin/otp/1/reveal', 'POST');
  check('Repeat reveal denied', second.status === 409 && !second.body.data);
  const [logs] = await conn.query('SELECT operator_id, target_phone, action, detail FROM otp_audit_logs');
  check('Target audit recorded without code', logs.some(r => r.action === 'view' && r.operator_id === 11 && r.target_phone === phone) && !JSON.stringify(logs).includes(code));
  const user = jwt.sign({ id: 12, role: 'user' }, key, { expiresIn: 60 });
  check('Player denied', (await api('/api/admin/otp/1/reveal', 'POST', user)).status === 403);
  check('Anonymous denied', (await api('/api/admin/otp/1/reveal', 'POST', '')).status === 401);
  report.passed = true;
}
main().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  if (conn) conn.destroy();
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'otp-reveal-integration-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
  process.exitCode = report.passed ? 0 : 1;
});
