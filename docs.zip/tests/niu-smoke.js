'use strict';
// ============================================
// 26牛牛 - 26牛牛娱乐场接口冒烟测试（需要真实运行中的服务 + 真实数据库）
// ============================================
// 运行: node tests/niu-smoke.js            （先 npm start）
// 账号: TEST_USERNAME / TEST_PASSWORD（普通用户）、TEST_ADMIN_PASSWORD（管理员）
//       不提供账号时只跑「未登录 / 权限」用例，不会自己造用户。
// 说明: 不删除任何数据；不写入任何假数据。
// ============================================

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const BASE = process.env.TEST_BASE || 'http://127.0.0.1:' + (process.env.PORT || 3000);
const report = { base: BASE, checks: [], passed: false };

function check(name, fn) {
  try { fn(); report.checks.push({ name: name, ok: true }); }
  catch (e) { report.checks.push({ name: name, ok: false, err: String(e && e.message).slice(0, 220) }); }
}

async function req(p, opt) {
  opt = opt || {};
  const headers = {};
  if (opt.token) headers.Authorization = 'Bearer ' + opt.token;
  if (opt.body !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(BASE + p, {
    method: opt.method || 'GET',
    headers: headers,
    body: opt.body !== undefined ? JSON.stringify(opt.body) : undefined
  });
  let json = null;
  try { json = await res.json(); } catch (e) { json = null; }
  return { status: res.status, json: json || { success: false } };
}

function login(user, pass) {
  if (!user || !pass) return Promise.resolve(null);
  return req('/api/auth/login', { method: 'POST', body: { username: user, password: pass } })
    .then(r => (r.json && r.json.success && r.json.data && r.json.data.token) ? r.json.data.token : null);
}

function finish() {
  report.passed = report.checks.every(c => c.ok);
  fs.writeFileSync(path.join(__dirname, 'niu-smoke-report.json'), JSON.stringify(report, null, 2));
  const good = report.checks.filter(c => c.ok).length;
  console.log((report.passed ? 'NIU_SMOKE PASS' : 'NIU_SMOKE FAIL') + ' (' + good + '/' + report.checks.length + ')' +
    (report.note ? '  [' + report.note + ']' : ''));
  report.checks.filter(c => !c.ok).forEach(c => console.log('  x ' + c.name + ' -> ' + c.err));
  process.exitCode = report.passed ? 0 : 1;
}


// ============================================
// 用例
// ============================================

async function main() {
  // ---------- 匿名：全部必须 401，不泄露场次 / 积分 ----------
  const anon = await req('/api/game/niu/config');
  check('未登录访问 /config 返回 401', () => assert.equal(anon.status, 401));
  check('未登录响应不含积分数值', () => assert.equal(JSON.stringify(anon.json).indexOf('game_points'), -1));
  const anonJoin = await req('/api/game/niu/join', { method: 'POST', body: { room: 'junior' } });
  check('未登录入座返回 401', () => assert.equal(anonJoin.status, 401));
  const anonAdmin = await req('/api/admin/niu/status');
  check('未登录访问管理端游戏接口返回 401', () => assert.equal(anonAdmin.status, 401));

  const userToken = await login(process.env.TEST_USERNAME, process.env.TEST_PASSWORD);
  const adminToken = await login(process.env.TEST_ADMIN_USERNAME, process.env.TEST_ADMIN_PASSWORD);
  if (!userToken) {
    report.note = '未提供 TEST_USERNAME/TEST_PASSWORD，只验证了匿名边界';
    return finish();
  }

  // ---------- 配置 ----------
  const cfg = await req('/api/game/niu/config', { token: userToken });
  check('已登录可读取游戏配置', () => assert.equal(cfg.status, 200));
  const D = (cfg.json && cfg.json.data) || {};
  check('配置返回场次白名单（不少于 1 个）', () => assert.ok(Array.isArray(D.rooms) && D.rooms.length >= 1));
  check('配置声明资产为游戏积分且不可兑现', () => assert.equal(D.asset.code, 'GAME_POINTS'));
  check('配置带非现金化说明', () => assert.ok(String(D.disclaimer || '').length > 8));
  check('每日免费积分为固定额度', () => assert.ok(Number(D.daily_free.amount) > 0));
  check('积分门槛覆盖最低场次底分', () => {
    const minStake = Math.min.apply(null, D.rooms.map(r => Number(r.base_stake)));
    assert.ok(Number(D.daily_free.amount) >= minStake, 'amount ' + D.daily_free.amount + ' < base ' + minStake);
  });
  check('配置不出现现金符号 / 提现含义', () => {
    const s = JSON.stringify(D);
    assert.equal(s.indexOf('RM'), -1);
    assert.equal(s.indexOf('ithdraw'), -1);
  });

  // ---------- 我的积分 / 战绩（无数据必须为 0）----------
  const stats = await req('/api/game/niu/stats', { token: userToken });
  check('战绩接口可用', () => assert.equal(stats.status, 200));
  check('总对局数为真实整数（无数据即 0）', () => {
    const n = Number(stats.json.data.total_rounds);
    assert.ok(Number.isInteger(n) && n >= 0, String(stats.json.data.total_rounds));
  });
  check('战绩资产标记为不可提现', () => assert.equal(stats.json.data.asset.cashable, false));
  const rec = await req('/api/game/niu/records?page=1&size=20', { token: userToken });
  check('对局记录返回真实分页结构', () => {
    assert.equal(rec.status, 200);
    assert.ok(Array.isArray(rec.json.data.list));
    assert.ok(Number.isInteger(Number(rec.json.data.total)));
    assert.ok(rec.json.data.list.length <= 20);
  });

  // ---------- 排行榜 ----------
  const lb = await req('/api/game/niu/leaderboard', { token: userToken });
  check('排行榜可用且为数组', () => {
    assert.equal(lb.status, 200);
    assert.ok(Array.isArray(lb.json.data.list));
  });
  check('排行榜长度不超过服务端上限（不一次返回全部用户）', () => assert.ok(lb.json.data.list.length <= 50));

  // ---------- 场次 + 入座 / 离座 ----------
  const rooms = await req('/api/game/niu/rooms', { token: userToken });
  check('场次列表可用', () => assert.equal(rooms.status, 200));
  const key = rooms.json.data.rooms[0].key;

  const badRoom = await req('/api/game/niu/join', { method: 'POST', token: userToken, body: { room: 'no_such_room' } });
  check('非法场次被拒绝（白名单）', () => assert.notEqual(badRoom.status, 200));
  const roomInject = await req('/api/game/niu/join', { method: 'POST', token: userToken, body: { room: 'junior; DROP TABLE users' } });
  check('异常场次参数不会造成 500', () => assert.ok(roomInject.status === 400 || roomInject.status === 422 || roomInject.status === 404, String(roomInject.status)));

  const join = await req('/api/game/niu/join', { method: 'POST', token: userToken, body: { room: key } });
  check('入座成功（或给出明确原因码）', () => {
    assert.ok(join.status === 200 || !!join.json.code, JSON.stringify(join.json));
  });
  const st = await req('/api/game/niu/state?room=' + key, { token: userToken });
  check('房间状态由服务端给出阶段与倒计时', () => {
    assert.equal(st.status, 200);
    assert.ok(st.json.data.phase);
    assert.ok(st.json.data.phase_ends_at);
    assert.ok(st.json.data.server_now);
  });
  check('发牌前不泄露任何人手牌', () => {
    const open = ['RESULT', 'SETTLEMENT', 'FINISHED'].indexOf(st.json.data.phase) >= 0;
    if (open) return;
    const leaked = (st.json.data.players || []).filter(p => p.cards && p.cards.length);
    assert.equal(leaked.length, 0, '未开牌却有 ' + leaked.length + ' 个座位带牌');
  });
  const badBet = await req('/api/game/niu/bet', { method: 'POST', token: userToken, body: { room: key, bet_level: 999 } });
  check('非法倍数被拒绝（服务端白名单）', () => assert.notEqual(badBet.status, 200));
  const wrongPhase = await req('/api/game/niu/grab', { method: 'POST', token: userToken, body: { room: key, grab: 1 } });
  check('抢庄只接受服务端阶段（错误阶段被拒绝）', () => {
    if (st.json.data.phase === 'GRABBING') return;
    assert.notEqual(wrongPhase.status, 200);
  });
  const leave = await req('/api/game/niu/leave', { method: 'POST', token: userToken, body: { room: key } });
  check('离座成功', () => assert.equal(leave.status, 200));

  // ---------- 每日免费积分：同一天不重复发放 ----------
  const first = await req('/api/game/niu/daily-free', { method: 'POST', token: userToken });
  check('每日免费积分接口可用', () => assert.equal(first.status, 200));
  const second = await req('/api/game/niu/daily-free', { method: 'POST', token: userToken });
  check('同一天重复请求不会二次发放', () => {
    assert.equal(second.status, 200);
    assert.equal(Number(second.json.data.granted), 0);
  });

  // ---------- 普通用户不得访问管理端游戏接口 ----------
  const userOnAdmin = await req('/api/admin/niu/status', { token: userToken });
  check('普通用户访问 /api/admin/niu/status 返回 403', () => assert.equal(userOnAdmin.status, 403));
  const userSwitch = await req('/api/admin/niu/switch', { method: 'POST', token: userToken, body: { enabled: 0 } });
  check('普通用户无法关闭游戏开关', () => assert.equal(userSwitch.status, 403));
  const userGrant = await req('/api/admin/niu/grant-points', { method: 'POST', token: userToken, body: { user_id: 1, amount: 1, reason: 'x' } });
  check('普通用户无法发放积分', () => assert.equal(userGrant.status, 403));

  // ---------- 管理员端 ----------
  if (adminToken) {
    const ad = await req('/api/admin/niu/status', { token: adminToken });
    check('管理员可读取游戏运行状态', () => assert.equal(ad.status, 200));
    check('管理员状态含真实对局统计', () => {
      assert.ok(Number.isInteger(Number(ad.json.data.week.rounds)));
      assert.ok(Number.isInteger(Number(ad.json.data.today_rounds)));
    });
    check('管理员状态明确资产不可提现', () => assert.equal(ad.json.data.asset.cashable, false));
    const badGrant = await req('/api/admin/niu/grant-points', { method: 'POST', token: adminToken, body: { user_id: 0, amount: 100, reason: '测试' } });
    check('管理员发放积分校验目标用户', () => assert.notEqual(badGrant.status, 200));
    const noReason = await req('/api/admin/niu/grant-points', { method: 'POST', token: adminToken, body: { user_id: 1, amount: 100, reason: '' } });
    check('无原因的积分发放被拒绝（审计要求）', () => assert.notEqual(noReason.status, 200));
  } else {
    report.note = '未提供 TEST_ADMIN_USERNAME/TEST_ADMIN_PASSWORD，跳过管理员用例';
  }

  finish();
}

main().catch(e => {
  report.checks.push({ name: '运行时异常', ok: false, err: String(e && e.message).slice(0, 200) });
  finish();
});
