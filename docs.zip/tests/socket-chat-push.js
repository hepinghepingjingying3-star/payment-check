'use strict';
// Socket.IO 聊天频道实时推送回归测试（真实传输层 + 真实 initGameSocket）。
// 覆盖: chat:join / chat:leave / 频道白名单 / 推送分发 / chat:recall 映射 / 未认证拒绝。
// 只读数据库账号 + 测试签名 JWT，不写任何业务数据。
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const db = require('../config/db');
const { initGameSocket } = require('../socket/gameSocket');

const report = { mode: 'Real Socket.IO chat channel push, test-signed JWT, no business writes', checks: [], passed: false };
let io;

function check(name, pass) { assert.ok(pass, name); report.checks.push({ name, pass: true }); }

// 极简 Socket.IO over WebSocket 客户端（engine.io v4 协议）
class RawClient {
  constructor(port, token) {
    this.port = port; this.token = token;
    this.events = [];                     // 收到的事件 { name, args }
    this._waiters = [];
  }
  open() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket('ws://127.0.0.1:' + this.port + '/socket.io/?EIO=4&transport=websocket');
      this.ws = ws;
      const timer = setTimeout(() => { try { ws.close(); } catch (_) {} reject(Error('connect timeout')); }, 6000);
      ws.addEventListener('error', () => { clearTimeout(timer); reject(Error('transport error')); });
      ws.addEventListener('message', (event) => {
        const packet = String(event.data);
        if (packet.startsWith('0')) {
          ws.send('40' + JSON.stringify({ token: this.token }));
        } else if (packet === '2') {
          ws.send('3');
        } else if (packet.startsWith('40')) {
          clearTimeout(timer); resolve(true);
        } else if (packet.startsWith('44')) {
          clearTimeout(timer); resolve(false);
        } else if (packet.startsWith('42')) {
          try {
            const [name, ...args] = JSON.parse(packet.slice(2));
            this.events.push({ name, args });
            this._waiters = this._waiters.filter(w => !w.match(name) || (w.resolve({ name, args }), false));
          } catch (_) { /* 忽略坏包 */ }
        }
      });
    });
  }
  emit(name, payload) {
    if (!this.ws) return;
    this.ws.send('42' + JSON.stringify([name, payload]));
  }
  /** 等待指定事件；timeoutMs 内未到返回 null */
  wait(name, timeoutMs = 2000) {
    const idx = this.events.findIndex(e => e.name === name);
    if (idx >= 0) return Promise.resolve(this.events.splice(idx, 1)[0]);
    return new Promise(resolve => {
      const t = setTimeout(() => resolve(null), timeoutMs);
      this._waiters.push({
        match: n => n === name,
        resolve: (e) => { clearTimeout(t); resolve(e); }
      });
    });
  }
  async expectSilence(name, quietMs = 900) {
    await new Promise(r => setTimeout(r, quietMs));
    return !this.events.some(e => e.name === name);
  }
  close() { try { this.ws && this.ws.close(); } catch (_) {} }
}

(async () => {
  const [users] = await db.promise().query(
    "SELECT id FROM users WHERE status = 'active' ORDER BY id LIMIT 2");
  assert.ok(users.length >= 1, 'No active account');
  const uidA = users[0].id;
  const uidB = users[1] ? users[1].id : users[0].id;

  const server = http.createServer();
  io = new Server(server);
  initGameSocket(io);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const sign = payload => jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '60s' });

  // 1) 未认证握手拒绝
  const bad = new RawClient(port, 'not-a-token');
  check('未认证连接被拒绝', !(await bad.open().catch(() => false)));
  bad.close();

  // 2) A / B 双端加入 group 频道
  const A = new RawClient(port, sign({ id: uidA }));
  const B = new RawClient(port, sign({ id: uidB }));
  check('A 建立连接', await A.open());
  check('B 建立连接', await B.open());
  A.emit('chat:join', 'group');
  B.emit('chat:join', 'group');
  const ja = await A.wait('chat:joined');
  const jb = await B.wait('chat:joined');
  check('A 加入 group 收到确认', !!ja && ja.args[0] && ja.args[0].channel === 'group');
  check('B 加入 group 收到确认', !!jb && jb.args[0] && jb.args[0].channel === 'group');

  // 3) 服务端向频道推送 → 双端实时收到
  const payload = { channel: 'group', id: 900001, message_type: 'text', content: '推送测试', is_mine: false };
  io.to('chat:group').emit('chat:message', payload);
  const pa = await A.wait('chat:message');
  const pb = await B.wait('chat:message');
  check('A 实时收到频道消息', !!pa && pa.args[0].id === 900001);
  check('B 实时收到频道消息', !!pb && pb.args[0].id === 900001);

  // 4) 非法频道被拒绝（白名单 group/support）
  A.emit('chat:join', 'evil');
  check('非法频道不返回加入确认', await A.expectSilence('chat:joined'));
  A.events = [];

  // 5) chat:leave 后不再收到该频道推送，B 仍收到
  A.emit('chat:leave', 'group');
  await new Promise(r => setTimeout(r, 300));
  io.to('chat:group').emit('chat:message', { channel: 'group', id: 900002 });
  check('A 离开后不再收到推送', await A.expectSilence('chat:message'));
  const pb2 = await B.wait('chat:message');
  check('B 离开后仍正常收到推送', !!pb2 && pb2.args[0].id === 900002);

  // 6) chat:recall 推送
  A.emit('chat:join', 'group');
  await A.wait('chat:joined');
  io.to('chat:group').emit('chat:recall', { id: 900001, channel: 'group' });
  const ra = await A.wait('chat:recall');
  check('A 收到撤回推送', !!ra && ra.args[0].id === 900001);

  // 7) OTP 用途的 JWT 不能建立连接（与 HTTP 同一鉴权边界）
  const C = new RawClient(port, sign({ id: uidA, purpose: 'register_otp' }));
  check('OTP 用途 JWT 被拒绝', !(await C.open().catch(() => false)));
  C.close();

  report.passed = true;
})().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  if (io) await new Promise(resolve => io.close(resolve));
  await db.promise().end();
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'socket-chat-push-report.json'), JSON.stringify(report, null, 2));
  console.log(report.passed ? 'SOCKET_CHAT_PUSH_PASS (' + report.checks.length + ' checks)' : 'SOCKET_CHAT_PUSH_FAIL: ' + (report.error || ''));
  process.exitCode = report.passed ? 0 : 1;
});

