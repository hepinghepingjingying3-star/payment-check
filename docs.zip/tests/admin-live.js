'use strict';
// Live read-only check of /api/admin/dashboard and /api/admin/users against the REAL MySQL.
// GET only: this script performs no writes and changes no user data.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
require('dotenv').config();
const report = { mode: 'Live MySQL read-only', checks: [], passed: false };
let server;
function check(name, value) { assert.ok(value, name); report.checks.push({ name, pass: true }); }
async function main() {
  assert.ok(process.env.JWT_SECRET, 'JWT_SECRET required');
  const [admins] = await db.promise().query(
    "SELECT id, username FROM users WHERE role = 'admin' AND status = 'active' ORDER BY id LIMIT 1");
  assert.ok(admins.length, 'No active admin account available for the live check');
  const [players] = await db.promise().query(
    "SELECT id FROM users WHERE role <> 'admin' AND status = 'active' ORDER BY id LIMIT 1");

  const app = express();
  app.use('/api', require('../routes/admin'));   // real router, real database
  server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = 'http://127.0.0.1:' + server.address().port;
  const sign = (id, role) => jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: 60 });
  async function call(url, token) {
    const res = await fetch(base + url, {
      headers: token ? { Authorization: 'Bearer ' + token } : {}, signal: AbortSignal.timeout(8000)
    });
    return { status: res.status, body: await res.json() };
  }

  const dash = await call('/api/admin/dashboard', sign(admins[0].id, 'admin'));
  check('Live dashboard returns 200 with real SQL', dash.status === 200 && dash.body.success === true);
  const d = dash.body.data;
  check('Live dashboard user totals are consistent',
    Number.isFinite(d.users.total) && d.users.active + d.users.banned <= d.users.total);
  check('Live OTP pending count is a number', Number.isFinite(d.otp.pending));
  check('Live referral counts are numbers', [d.referrals.direct, d.referrals.second, d.referrals.today, d.referrals.month]
    .every(v => Number.isFinite(v)));
  check('Live dashboard marks the three unsupported stats', d.unsupported.length === 3);
  check('Live dashboard leaks no password hash or OTP',
    !JSON.stringify(dash.body).includes('password_hash') && !/otp_plain|otp_hash/.test(JSON.stringify(dash.body)));

  const list = await call('/api/admin/users?limit=5&offset=0', sign(admins[0].id, 'admin'));
  check('Live user list returns 200 with real subqueries', list.status === 200 && Array.isArray(list.body.data.list));
  check('Live list row exposes admin fields but never a hash',
    list.body.data.list.every(u => !('password_hash' in u) && !('password' in u)));
  check('Live list masks phone numbers', list.body.data.list.every(u => u.phone === null || u.phone_masked.includes('****')));
  const admin = list.body.data.list.find(u => Number(u.id) === Number(admins[0].id));
  check('Live list includes last login and referral counters',
    admin && ('last_login_at' in admin) && Number.isFinite(admin.direct_count) && Number.isFinite(admin.second_count));

  const fuzzy = await call('/api/admin/users?q=' + encodeURIComponent(admins[0].username), sign(admins[0].id, 'admin'));
  check('Live fuzzy username search matches against real SQL',
    fuzzy.status === 200 && fuzzy.body.data.list.some(u => u.username === admins[0].username));
  const wildcard = await call('/api/admin/users?q=' + encodeURIComponent('%'), sign(admins[0].id, 'admin'));
  check('Live wildcard-only search does not become a full-table LIKE scan',
    wildcard.status === 200 && wildcard.body.data.list.every(u => u.invite_code === '%'));
  if (players.length) {
    const player = sign(players[0].id, 'user');
    check('Live non-admin blocked from dashboard', (await call('/api/admin/dashboard', player)).status === 403);
    check('Live non-admin blocked from user list', (await call('/api/admin/users', player)).status === 403);
  }
  check('Live anonymous blocked', (await call('/api/admin/dashboard', null)).status === 401);
  report.admin_checked = { id: admins[0].id, username: admins[0].username };
  report.player_checked = players.length ? players[0].id : null;
  report.passed = true;
}
main().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); }
  report.finished = new Date().toISOString();
  fs.writeFileSync(path.join(__dirname, 'admin-live-report.json'), JSON.stringify(report, null, 2));
  console.log(report.passed ? 'ADMIN_LIVE_PASS' : 'ADMIN_LIVE_FAIL');
  await new Promise(resolve => db.end(() => resolve())).catch(() => {});
  process.exitCode = report.passed ? 0 : 1;
});