'use strict';
// Focused real-database check: inserts ONE OTP row into the REAL registration_otp,
// exercises the real route against the real schema, then deletes only rows it created.
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(root, '.env') });
const report = { started: new Date().toISOString(), mode: 'Real table row inserted and deleted by this test', checks: [], passed: false };
let server, conn, id = null;
async function main() {
  assert.ok(process.env.JWT_SECRET, 'JWT_SECRET must exist in .env');
  conn = await mysql.createConnection({ host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME, connectTimeout: 7000 });
  const [ins] = await conn.query(
    `INSERT INTO registration_otp (phone, otp_hash, otp_plain_tmp, status, attempts, max_attempts, expires_at, last_sent_at, created_ip)
     VALUES ('+60000000000', REPEAT('0', 64), ?, 'pending', 0, 5, DATE_ADD(NOW(), INTERVAL 5 MINUTE), NOW(), '127.0.0.1')`,
    [String(Math.floor(100000 + Math.random() * 900000))]);
  id = ins.insertId;
  const [row0] = await conn.query('SELECT otp_plain_tmp FROM registration_otp WHERE id = ?', [id]);
  const code = row0[0].otp_plain_tmp;
  const router = require('../routes/admin-otp');
  const app = require('express')(); app.use(express.json()); app.use('/api', router);
  server = await new Promise(r => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const [admins] = await conn.query("SELECT id, username, token_version FROM users WHERE role = 'admin' AND status = 'active' ORDER BY id LIMIT 1");
  assert.ok(admins[0], 'an active admin is required for the real-row test');
  const token = jwt.sign({ id: Number(admins[0].id), username: admins[0].username, role: 'admin', tv: Number(admins[0].token_version || 0) }, process.env.JWT_SECRET, { expiresIn: 60 });
  const call = async (url, method = 'GET') => {
    const res = await fetch('http://127.0.0.1:' + server.address().port + url, { method, headers: { Authorization: 'Bearer ' + token } });
    return { status: res.status, body: await res.json() };
  };
  const list = await call('/api/admin/otp?limit=50');
  const mine = (list.body.data.list || []).find(r => Number(r.id) === Number(id));
  assert.ok(list.status === 200 && mine && mine.code_available === true, 'list shows inserted row claimable');
  assert.ok(!JSON.stringify(list.body).includes(code), 'list leaks no plaintext');
  const first = await call('/api/admin/otp/' + id + '/reveal', 'POST');
  assert.ok(first.status === 200 && first.body.data.code === code, 'reveal returns code once');
  const [row1] = await conn.query('SELECT otp_plain_tmp FROM registration_otp WHERE id = ?', [id]);
  assert.ok(row1[0].otp_plain_tmp === null, 'real row plaintext cleared');
  const second = await call('/api/admin/otp/' + id + '/reveal', 'POST');
  assert.ok(second.status === 409 && !JSON.stringify(second.body).includes(code), 'repeat reveal denied');
  const [logs] = await conn.query('SELECT action, target_phone FROM otp_audit_logs WHERE otp_id = ?', [id]);
  assert.ok(logs.some(l => l.action === 'view' && l.target_phone === '+60000000000'), 'targeted audit written');
  assert.ok(!JSON.stringify(logs).includes(code), 'audit holds no plaintext');
  report.checks = [
    { name: 'List shows row claimable without plaintext', pass: true },
    { name: 'Reveal returns code once on real schema', pass: true },
    { name: 'Real row plaintext cleared in MySQL', pass: true },
    { name: 'Repeat reveal denied with 409', pass: true },
    { name: 'Targeted audit written without plaintext', pass: true }
  ];
  report.passed = true;
}
main().catch(e => { report.error = e.code || e.message; }).finally(async () => {
  try { if (conn && id != null) { await conn.query('DELETE FROM registration_otp WHERE id = ?', [id]); await conn.query('DELETE FROM otp_audit_logs WHERE otp_id = ?', [id]); } } catch (e) { report.cleanup_error = e.code || e.message; }
  try { if (server) { server.closeAllConnections(); await new Promise(r => server.close(r)); } } catch (_) {}
  try { if (conn) await conn.end(); } catch (_) {}
  try { require('../config/db').end && require('../config/db').end(); } catch (_) {}
  report.finished = new Date().toISOString();
  require('node:fs').writeFileSync(path.join(__dirname, 'otp-reveal-realrow-report.json'), JSON.stringify(report, null, 2));
  console.log(report.passed ? 'OTP_REALROW_PASS' : 'OTP_REALROW_FAIL: ' + (report.error || ''));
  process.exitCode = report.passed ? 0 : 1;
});
